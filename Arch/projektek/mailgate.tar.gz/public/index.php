<?php
	if ((file_exists("../lib/config.php"))and(file_exists("../lib/smtp.php"))){
		include("../lib/config.php");
		include("../lib/smtp.php");
	}else{
		if (file_exists("error.php")){
			include("error.php");
		}else{
		    echo("Rendszerhiba...");
		}
	}
?>

<!DOCTYPE HTML>
<html>
	<head>
		<title>MailGate</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<meta http-equiv="refresh" content="10; url=<?php echo("$ORIGINAL_PAGE"); ?>">
	</head>
	<body>


<style type=text/css>

body {
    color: #333333;
    font-family:'Helvetica', arial;
    height:1500px;
}
.wrap {
    padding: 40px;
    text-align: center;
}
hr {
    clear: both;
    margin-top: 40px;
    margin-bottom: 40px;
    border: 0;
    border-top: 1px solid #aaaaaa;
}
h1 {
    font-size: 30px;
    margin-bottom: 40px;
}
p {
    margin-bottom: 20px;
}
.btn {
    background: #428bca;
    border: #357ebd solid 1px;
    border-radius: 3px;
    color: #fff;
    display: inline-block;
    font-size: 14px;
    padding: 8px 15px;
    text-decoration: none;
    text-align: center;
    min-width: 60px;
    position: relative;
    transition: color .1s ease;
}
.btn:hover {
    background: #357ebd;
}
.btn.btn-big {
    font-size: 18px;
    padding: 15px 20px;
    min-width: 100px;
}
.btn-close {
    color: #aaaaaa;
    font-size: 30px;
    text-decoration: none;
    position: absolute;
    right: 5px;
    top: 0;
}
.btn-close:hover {
    color: #919191;
}
.modal:target:before {
    display: none;
}
.modal:before {
    content:"";
    display: block;
    background: rgba(0, 0, 0, 0.6);
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    z-index: 10;
}
.modal .modal-dialog {
    background: #fefefe;
    border: #333333 solid 1px;
    border-radius: 5px;
    margin-left: -200px;
    position: fixed;
    left: 50%;
    z-index: 11;
    width: 360px;
    -webkit-transform: translate(0, 0);
    -ms-transform: translate(0, 0);
    transform: translate(0, 0);
    -webkit-transition: -webkit-transform 0.3s ease-out;
    -moz-transition: -moz-transform 0.3s ease-out;
    -o-transition: -o-transform 0.3s ease-out;
    transition: transform 0.3s ease-out;
    top: 20%;
}
.modal:target .modal-dialog {
    top: -100%;
    -webkit-transform: translate(0, -500%);
    -ms-transform: translate(0, -500%);
    transform: translate(0, -500%);
}
.modal-body {
    padding: 20px;
}
.modal-header, .modal-footer {
    padding: 10px 20px;
}
.modal-header {
    border-bottom: #eeeeee solid 1px;
}
.modal-header h2 {
    font-size: 20px;
}
.modal-footer {
    border-top: #eeeeee solid 1px;
    text-align: right;

</style>

	<?php
		if (formdata_to_mail()){
		    $uzenet="Köszönjük üzenetét. Hamarosan jelentkezünk...";
		}else{
		    $uzenet="Sajnos a levelet nem sikerült elküldeni, kérjük próbálja meg később.";
		}
		echo("<div class=modal id=modal-one aria-hidden=true>");
		echo("<div class=modal-dialog>");
		echo("	<div class=modal-header>");
		echo("		<h2>Üzenet</h2>");
		echo("		<a href=index.php class=btn-close aria-hidden=true>×</a>");
		echo("	</div>");
		echo("	<div class=modal-body>");
		echo("		<p>$uzenet</p>");
		echo("	</div>");
		echo("	<div class=modal-footer> <a href=$ORIGINAL_PAGE class=btn>Bezár</a>");
		echo("	</div>");
		echo("</div>");
		echo("</div>");
	?>

	</body>
</html>

