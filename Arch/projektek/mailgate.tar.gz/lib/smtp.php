<?php

 #
 # MailGate
 #
 # 2016. GPLv3
 #
 #



	global	$SMTP_HOST,
			$SMTP_PORT,
			$SMTP_USER,
			$SMTP_PASSWORD,
			$SMTP_FROM,
			$SMTP_BCC,
			$SMTP_SUBJECT,
			$SMTP_MESSAGE,
			$SMTP_HEADERS;


function valid_input($data) {
  $data=trim($data);
  $data=stripslashes($data);
  $data=htmlspecialchars($data);
  return($data);
}


function formdata_to_mail(){
	global $SMTP_TO, $PHPMAIL;

	$ret=FALSE;
#		if ($_SERVER['REQUEST_METHOD']=="POST"){
	if ($_POST["fname"]<>""){
		$name=valid_input($_POST["fname"]);
		$email=valid_input($_POST["email"]);
		$mess=valid_input($_POST["message"]);
	}else{
#		if ($_SERVER['REQUEST_METHOD']=="GET"){
		if ($_GET["fname"]<>""){
			$name=valid_input($_GET["fname"]);
			$email=valid_input($_GET["email"]);
			$mess=valid_input($_GET["message"]);
		}
	}
	if (($name<>"")and($email<>"")and($mess<>"")){
		$mess="Feladó: ".$name." - ".$email." <br /><br />".$mess;
		if ($PHPMAIL){
			mail($SMTP_TO,$mess);
		}else{
			smtp_mail_sendto($SMTP_TO,$mess);
		}
		$ret=TRUE;
	}
	return($ret);
}




	function smtp_server_wait($socket,$code){
		$serverstring="";
		socket_set_timeout($socket,2);
		$i=0;
		while ((substr($serverstring,0,3)!=$code)and($i<=1)){
				$serverstring=@fgets($socket,256);
			if ($serverstring<>""){
				# for debug ...
				#echo("$serverstring<br />");
			}
			$i++;
		}
	}



	function smtp_mail_sendto($to,$mess){
		global	$SMTP_HOST,
				$SMTP_PORT,
				$SMTP_USER,
				$SMTP_PASSWORD,
				$SMTP_FROM,
				$SMTP_TO,
				$SMTP_SUBJECT,
				$SMTP_MESSAGE,
				$SMTP_HEADERS;

		smtp_mail_send_2($SMTP_USER,$SMTP_PASSWORD,$SMTP_HOST,$SMTP_PORT,$SMTP_FROM,$to,$SMTP_SUBJECT,$mess,$SMTP_HEADERS);
	}


	function smtp_mail_send(){
		global	$SMTP_HOST,
				$SMTP_PORT,
				$SMTP_USER,
				$SMTP_PASSWORD,
				$SMTP_FROM,
				$SMTP_TO,
				$SMTP_SUBJECT,
				$SMTP_MESSAGE,
				$SMTP_HEADERS;

		smtp_mail_send_2($SMTP_USER,$SMTP_PASSWORD,$SMTP_HOST,$SMTP_PORT,$SMTP_FROM,$SMTP_TO,$SMTP_SUBJECT,$SMTP_MESSAGE,$SMTP_HEADERS);
	}



	function smtp_mail_send_2($user,$pass,$ser,$port,$from,$to,$subject,$message,$headers){
		$recipients=$to;
		$dom=explode('@',$from);
		$domain=$dom[1];
		$pass=$pass;
		$smtp_host=$ser;
		$ready=false;
		$smtp_port=$port;
		if (!($socket=fsockopen($smtp_host,$smtp_port,$errno,$errstr,15))){
			echo("$smtp_host ($errno) ($errstr)<br />");
		}else{	
			socket_set_timeout($socket,2);
			smtp_server_wait($socket,"220",false);
			fwrite($socket,"EHLO ".$domain."\r\n");
			smtp_server_wait($socket,"250",false);
			if ($user<>""){
				fwrite($socket,"AUTH LOGIN \r\n");
				smtp_server_wait($socket, "334");
				fwrite($socket,base64_encode($user)."\r\n");
				smtp_server_wait($socket,"334");
				fwrite($socket,base64_encode($pass)."\r\n");
				smtp_server_wait($socket,"235");
			}
			fwrite($socket,"MAIL FROM: <".$from."> \r\n");
			smtp_server_wait($socket,"250",false);
			fwrite($socket,"RCPT TO: <".$recipients."> \r\n");
			smtp_server_wait($socket,"250",false);
			fwrite($socket,"DATA \r\n");
			smtp_server_wait($socket,"354",true);
			fwrite($socket,"Subject: $subject\r\nTo: <".$recipients.">\r\n$headers\r\n\r\n$message\r\n");
			fwrite($socket,".\r\n");
			smtp_server_wait($socket,"250",false);
			fwrite($socket,"QUIT \r\n");
			fclose($socket);
			$ready=true;
		}
		return($ready);
	}

?>
