<?php

 #
 # MailGate
 #
 # 2016. GPLv3
 #
 #

# configuration - need change it

$ORIGINAL_PAGE="http://localhost/~peter/portal";

$SMTP_HOST="ssl://smtp.gmail.com";
$SMTP_PORT="465";
$SMTP_USER="webstarthely.hu@gmail.com";
$SMTP_PASSWORD="Web2015start1hely.hu";
$SMTP_FROM="webstarthely.hu@gmail.com";
$SMTP_DOMAIN="gmail.com";
$SMTP_TO="pphome2@gmail.com";
$PHPMAIL=FALSE;

# change in program

$SMTP_SUBJECT="Üzenet";
$SMTP_MESSAGE="";
$SMTP_HEADERS="Content-Type: text/html; charset=UTF-8";

?>
