


<link href='http://fonts.googleapis.com/css?family=Open+Sans+Condensed:300' rel='stylesheet' type='text/css'>
<style type="text/css">
.form-style-8{
    font-family: 'Open Sans Condensed', arial, sans;
    width: 500px;
    padding: 30px;
    background: #FFFFFF;
    margin: 50px auto;
    box-shadow: 0px 0px 15px rgba(0, 0, 0, 0.22);
    -moz-box-shadow: 0px 0px 15px rgba(0, 0, 0, 0.22);
    -webkit-box-shadow:  0px 0px 15px rgba(0, 0, 0, 0.22);

}
.form-style-8 h2{
    background: #4D4D4D;
    text-transform: uppercase;
    font-family: 'Open Sans Condensed', sans-serif;
    color: #797979;
    font-size: 18px;
    font-weight: 100;
    padding: 20px;
    margin: -30px -30px 30px -30px;
}
.form-style-8 input[type="text"],
.form-style-8 input[type="date"],
.form-style-8 input[type="datetime"],
.form-style-8 input[type="email"],
.form-style-8 input[type="number"],
.form-style-8 input[type="search"],
.form-style-8 input[type="time"],
.form-style-8 input[type="url"],
.form-style-8 input[type="password"],
.form-style-8 textarea,
.form-style-8 select
{
    box-sizing: border-box;
    -webkit-box-sizing: border-box;
    -moz-box-sizing: border-box;
    outline: none;
    display: block;
    width: 100%;
    padding: 7px;
    border: none;
    border-bottom: 1px solid #ddd;
    background: transparent;
    margin-bottom: 10px;
    font: 16px Arial, Helvetica, sans-serif;
    height: 45px;
}
.form-style-8 textarea{
    resize:none;
    overflow: hidden;
}
.form-style-8 input[type="button"],
.form-style-8 input[type="reset"],
.form-style-8 input[type="submit"]{
    -moz-box-shadow: inset 0px 1px 0px 0px #45D6D6;
    -webkit-box-shadow: inset 0px 1px 0px 0px #45D6D6;
    box-shadow: inset 0px 1px 0px 0px #45D6D6;
    background-color: #2CBBBB;
    border: 1px solid #27A0A0;
    display: inline-block;
    cursor: pointer;
    color: #FFFFFF;
    font-family: 'Open Sans Condensed', sans-serif;
    font-size: 14px;
    padding: 8px 18px;
    text-decoration: none;
    text-transform: uppercase;
}
.form-style-8 input[type="button"]:hover,
.form-style-8 input[type="reset"]:hover,
.form-style-8 input[type="submit"]:hover {
    background:linear-gradient(to bottom, #34CACA 5%, #30C9C9 100%);
    background-color:#34CACA;
}
</style>


<div class="form-style-8">
<h2>Méret és súly kalkulátor</h2>


	<?php
		$tnev= array("",
					"Cső",
					"Lemez",
					"T-profil",
					"Zártszelvény (téglalap)",
					"Hatszögrúd",
					"Körrúd",
					"L-profil",
					"U-profil",
					"Laposrúd-vastaglemez",
					"Négyzetrúd",
					"Zártszelvény (négyzetes)"
					);
		$anev=array("","Vas","Réz","Alumínium","Acél");


		function valid_input($adat){
			if (($adat>0)and($adat<100000000)){
			}else{
				$adat="";
			}
			return($adat);
		}

		echo("<form method='post' id='formkalkxx' name='formkalkxx'>");
		echo("	<select name=termek>");
		for($i=1;$i<=count($tnev)-1;$i++){
			echo("<option value=$i>$tnev[$i]</option>");
		}
		echo("	</select>");
		echo("	<br />");
		echo("	<select name=anyag>");
		for($i=1;$i<=count($anev)-1;$i++){
			echo("<option value=$i>$anev[$i]</option>");
		}
		echo("	</select>");
		echo("	<input type='text' name='mx' placeholder='Magasság (mm)' />");
		echo("	<input type='text' name='sx' placeholder='Szélesség (mm)' />");
		echo("	<input type='text' name='vx' placeholder='Vastagság (mm)' />");
		echo("	<input type='text' name='hx' placeholder='Hosszúság (mm)' />");
		echo("	<input type='submit' value='Számol'>");
		echo("	<input type='reset' value='Újra'>");
		echo("</form>");

	?>
</div>

<div class="form-style-8">
<h2>Eredmény</h2>


	<?php
		echo("<p><b>Figyelem!</b><br />A kész terméknél a számított értékektől eltérések lehetnek.</p>");

		$termek="";
		$anyag="";
		$mag="";
		$sze="";
		$vas="";
		$hos="";
		if ($_SERVER['REQUEST_METHOD']=='POST'){
			$termek=$_POST["termek"];
			$anyag=$_POST["anyag"];
			$mag=valid_input($_POST["mx"]);
			$sze=valid_input($_POST["sx"]);
			$vas=valid_input($_POST["vx"]);
			$hos=valid_input($_POST["hx"]);
		}else{
			if ($_SERVER['REQUEST_METHOD']=='GET'){
				$termek=$_GET["termek"];
				$anyag=$_GET["anyag"];
				$mag=valid_input($_GET["mx"]);
				$sze=valid_input($_GET["sx"]);
				$vas=valid_input($_GET["vx"]);
				$hos=valid_input($_GET["hx"]);
			}
		}
		if (($hos<>"")and($mag<>"")and($sze<>"")){
			if ($anyag=="1"){ $fajsuly=7200;} # vas
			if ($anyag=="2"){ $fajsuly=8900;} # réz
			if ($anyag=="3"){ $fajsuly=2700;} # aluminium
			if ($anyag=="4"){ $fajsuly=7800;} # acél
            $sztermek=$tnev[$termek].' ('.$anev[$anyag].') ';

			echo("<p>$sztermek<br />");
            echo("Magasság: $mag mm, szélesség: $sze mm, vastagság: $vas mm, hossz: $hos mm.</p>");
            $szkg=0.00000;

			if ($termek=="1"){ # cső
                $szkg=($mag/2)*($mag/2)*3.14;
                $szkg=$szkg-((($mag-$vas-$vas)/2)*(($mag-$vas-$vas)/2)*3.14);
                $szkg=$szkg*$hos;
                $szkg=$szkg/1000000000*$fajsuly;
			}
			if ($termek=="2"){ # lemez
                $szkg=$mag*$sze;
                $szkg=$szkg*$hos;
                $szkg=$szkg/1000000000*$fajsuly;
            }
			if ($termek=="3"){ # T-profil
                $szkg=($mag*$vas)+(($sze-$vas)*$vas);
                $szkg=$szkg*$hos;
                $szkg=$szkg/1000000000*$fajsuly;
            }
			if ($termek=="4"){ # zártszelvény - téglalap
                $szkg=($mag*$sze)-(($mag-$vas)*($sze-$vas));
                $szkg=$szkg*$hos;
                $szkg=$szkg/1000000000*$fajsuly;
			}
			if ($termek=="5"){ # hatszögrúd
                $szkg=(3/2)*(($mag/2)*($mag/2))*1.73;
                $szkg=$szkg*$hos;
                $szkg=$szkg/1000000000*$fajsuly;
			}
			if ($termek=="6"){ # körrúd
                $szkg=($mag/2)*($mag/2)*3.14;
                $szkg=$szkg*$hos;
                $szkg=$szkg/1000000000*$fajsuly;
            }
			if ($termek=="7"){ # L-profil
                $szkg=($mag*$vas)+(($sze-$vas)*$vas);
                $szkg=$szkg*$hos;
                $szkg=$szkg/1000000000*$fajsuly;
            }
			if ($termek=="8"){ # U-profil
                $szkg=($mag*$vas)+(($sze-$vas)*$vas)+(($sze-$vas)*$vas);
                $szkg=$szkg*$hos;
                $szkg=$szkg/1000000000*$fajsuly;
            }
			if ($termek=="9"){ # laposrúd-vastag lemez
                $szkg=$mag*$sze;
                $szkg=$szkg*$hos;
                $szkg=$szkg/1000000000*$fajsuly;
			}
			if ($termek=="10"){ # négyzetrúd
                $szkg=$mag*$mag;
                $szkg=$szkg*$hos;
                $szkg=$szkg/1000000000*$fajsuly;
            }
			if ($termek=="11"){ # zártszelvény négyzetes
                $szkg=($mag*$mag)-(($mag-$vas)*($mag-$vas));
                $szkg=$szkg*$hos;
                $szkg=$szkg/1000000000*$fajsuly;
			}
            $szkg=round($szkg,5);
            echo("<p><b>Termék: $sztermek - Súly: ".$szkg." kg.</p>");
		}else{
			if ($termek<>""){
				echo("<p>Valami hiányzik. Magasság, szélesség, hosszúság kitöltése kötelező...</p>");
			}
		}

	?>
</div>



<style type="text/css">
<p>.datagrid table { border-collapse: collapse; text-align: left; width: 100%; } .datagrid {font: normal 12px/150% Arial, Helvetica, sans-serif; background: #fff; overflow: hidden; border: 2px solid #8C8C8C; -webkit-border-radius: 3px; -moz-border-radius: 3px; border-radius: 3px; }.datagrid table td, .datagrid table th { padding: 4px 2px; }.datagrid table thead th {background:-webkit-gradient( linear, left top, left bottom, color-stop(0.05, #8C8C8C), color-stop(1, #7D7D7D) );background:-moz-linear-gradient( center top, #8C8C8C 5%, #7D7D7D 100% );filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#8C8C8C', endColorstr='#7D7D7D');background-color:#8C8C8C; color:#FFFFFF; font-size: 17px; font-weight: bold; border-left: 3px solid #A3A3A3; } .datagrid table thead th:first-child { border: none; }.datagrid table tbody td { color: #7D7D7D; border-left: 2px solid #DBDBDB;font-size: 14px;border-bottom: 2px solid #E1EEF4;font-weight: normal;  font-style: normal; }.datagrid table tbody .alt td { background: #EBEBEB; color: #7D7D7D; }.datagrid table tbody td:first-child { border-left: none; }.datagrid table tbody tr:last-child td { border-bottom: none; }
.tg  {border-collapse:collapse;border-spacing:0;border-color:#ccc;margin:0px auto;}.tg td{font-family:Arial, sans-serif;font-size:14px;padding:10px 5px;border-style:solid;border-width:0px;overflow:hidden;word-break:normal;border-color:#ccc;color:#333;background-color:#fff;}.tg th{font-family:Arial, sans-serif;font-size:14px;font-weight:normal;padding:10px 5px;border-style:solid;border-width:0px;overflow:hidden;word-break:normal;border-color:#ccc;color:#333;background-color:#f0f0f0;.tg .tg-yw4l{vertical-align:top}@media screen and (max-width: 767px) {.tg {width: auto !important;}.tg col {width: auto !important;}.tg-wrap {overflow-x: auto;-webkit-overflow-scrolling: touch;margin: auto 0px;}
text-left{   display: block;  width: 100%;    padding: 7px;   border: none;   border-bottom: 1px solid #ddd; background: transparent;    margin-bottom: 10px;    font: 16px Arial, Helvetica, sans-serif;}</style>
<div class="table-title2">
<h3>Termékek</h3>
</div>
<div class="datagrid">
<table width="100%">
<thead class="table-head">
<tr>
<th width="30%">Név</th>
<th width="30%">Elérhető</th>
<th>Kialakítás</th>
</tr>
</thead>
<tbody class="table-hover">
<tr>
<td class="text-left">Cső</td>
<td class="text-left">vas, réz, alumínium</td>
<td class="text-left"><a href="http://www.szolnokvas.hu/vas/wp-content/uploads/2016/11/korrud.jpg"><img class="wp-image-227 aligncenter" src="http://www.szolnokvas.hu/vas/wp-content/uploads/2016/11/korrud-300x138.jpg" alt="korrud" width="195" height="90" /></a></td>
</tr>
<tr>
<td class="text-left">Lemez</td>
<td class="text-left">vas, réz, alumínium</td>
<td class="text-left"><a href="http://www.szolnokvas.hu/vas/wp-content/uploads/2016/11/lemez.jpg"><img class="wp-image-229 aligncenter" src="http://www.szolnokvas.hu/vas/wp-content/uploads/2016/11/lemez-300x138.jpg" alt="lemez" width="196" height="90" /></a></td>
</tr>
<tr>
<td class="text-left">T-profil</td>
<td class="text-left">vas, réz, alumínium</td>
<td class="text-left"><a href="http://www.szolnokvas.hu/vas/wp-content/uploads/2016/11/t-profil.jpg"><img class="wp-image-232 aligncenter" src="http://www.szolnokvas.hu/vas/wp-content/uploads/2016/11/t-profil-300x138.jpg" alt="t-profil" width="196" height="90" /></a></td>
</tr>
<tr>
<td class="text-left">Zártszelvény (téglalap)</td>
<td class="text-left">vas, réz, alumínium</td>
<td class="text-left"><a href="http://www.szolnokvas.hu/vas/wp-content/uploads/2016/11/zartszelveny-teglalap.jpg"><img class="alignnone wp-image-235 aligncenter" src="http://www.szolnokvas.hu/vas/wp-content/uploads/2016/11/zartszelveny-teglalap-300x138.jpg" alt="zartszelveny-teglalap" width="196" height="90" /></a></td>
</tr>
<tr>
<td class="text-left">Hatszögrúd</td>
<td class="text-left">vas, réz, alumínium</td>
<td class="text-left"><a href="http://www.szolnokvas.hu/vas/wp-content/uploads/2016/11/hatszogrud.jpg"><img class="alignnone wp-image-226 aligncenter" src="http://www.szolnokvas.hu/vas/wp-content/uploads/2016/11/hatszogrud-300x138.jpg" alt="hatszogrud" width="196" height="90" /></a></td>
</tr>
<tr>
<td class="text-left">Körrúd</td>
<td class="text-left">vas, réz, alumínium</td>
<td class="text-left"><a href="http://www.szolnokvas.hu/vas/wp-content/uploads/2016/11/korrud.jpg"><img class="alignnone wp-image-227 aligncenter" src="http://www.szolnokvas.hu/vas/wp-content/uploads/2016/11/korrud-300x138.jpg" alt="korrud" width="196" height="90" /></a></td>
</tr>
<tr>
<td class="text-left">L-profil</td>
<td class="text-left">vas, réz, alumínium</td>
<td class="text-left"><a href="http://www.szolnokvas.hu/vas/wp-content/uploads/2016/11/l-profil.jpg"><img class="wp-image-230 aligncenter" src="http://www.szolnokvas.hu/vas/wp-content/uploads/2016/11/l-profil-300x138.jpg" alt="l-profil" width="196" height="90" /></a></td>
</tr>
<tr>
<td class="text-left">U-profil</td>
<td class="text-left">vas, réz, alumínium</td>
<td class="text-left"><a href="http://www.szolnokvas.hu/vas/wp-content/uploads/2016/11/u-profil.jpg"><img class="wp-image-233 aligncenter" src="http://www.szolnokvas.hu/vas/wp-content/uploads/2016/11/u-profil-300x138.jpg" alt="u-profil" width="196" height="90" /></a></td>
</tr>
<tr>
<td class="text-left">Laposrúd-vastaglemez</td>
<td class="text-left">vas, réz, alumínium</td>
<td class="text-left"><a href="http://www.szolnokvas.hu/vas/wp-content/uploads/2016/11/laposrud-vastaglemez.jpg"><img class="wp-image-228 aligncenter" src="http://www.szolnokvas.hu/vas/wp-content/uploads/2016/11/laposrud-vastaglemez-300x138.jpg" alt="laposrud-vastaglemez" width="196" height="90" /></a></td>
</tr>
<tr>
<td class="text-left">Négyzetrúd</td>
<td class="text-left">vas, réz, alumínium</td>
<td class="text-left"><a href="http://www.szolnokvas.hu/vas/wp-content/uploads/2016/11/negyzetrud.jpg"><img class="wp-image-231 aligncenter" src="http://www.szolnokvas.hu/vas/wp-content/uploads/2016/11/negyzetrud-300x138.jpg" alt="negyzetrud" width="196" height="90" /></a></td>
</tr>
<tr>
<td class="text-left">Zártszelvény (négyzetes)</td>
<td class="text-left">vas, réz, alumínium</td>
<td class="text-left"><a href="http://www.szolnokvas.hu/vas/wp-content/uploads/2016/11/zartszelveny-negyzetes.jpg"><img class="wp-image-234 aligncenter" src="http://www.szolnokvas.hu/vas/wp-content/uploads/2016/11/zartszelveny-negyzetes-300x138.jpg" alt="zartszelveny-negyzetes" width="196" height="90" /></a></td>
</tr>
</tbody>
</table>
</div>



