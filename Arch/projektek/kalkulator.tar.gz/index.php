<?php
?>

<!DOCTYPE HTML>
<html>
	<head>
		<title>Kalkulátor</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
	</head>
	<body>


<style type=text/css>
@import url(http://fonts.googleapis.com/css?family=Roboto:400,500,700,300,100);

body {
  background-color: #3e94ec;
  font-family: "Roboto", helvetica, arial, sans-serif;
  font-size: 16px;
  font-weight: 400;
  text-rendering: optimizeLegibility;
}

div.table-title {
   display: block;
  margin: auto;
  max-width: 600px;
  padding:5px;
  width: 100%;
}

.table-title h3 {
   color: #fafafa;
   font-size: 30px;
   font-weight: 400;
   font-style:normal;
   font-family: "Roboto", helvetica, arial, sans-serif;
   text-shadow: -1px -1px 1px rgba(0, 0, 0, 0.1);
   text-transform:uppercase;
}


/*** Table Styles **/

.table-fill {
  background: white;
  border-radius:3px;
  border-collapse: collapse;
  height: 320px;
  margin: auto;
  max-width: 600px;
  padding:5px;
  width: 100%;
  box-shadow: 0 5px 10px rgba(0, 0, 0, 0.1);
  animation: float 5s infinite;
}
 
th {
  color:#D5DDE5;;
  background:#1b1e24;
  border-bottom:4px solid #9ea7af;
  border-right: 1px solid #343a45;
  font-size:23px;
  font-weight: 100;
  padding:24px;
  text-align:left;
  text-shadow: 0 1px 1px rgba(0, 0, 0, 0.1);
  vertical-align:middle;
}

th:first-child {
  border-top-left-radius:3px;
}
 
th:last-child {
  border-top-right-radius:3px;
  border-right:none;
}
  
tr {
  border-top: 1px solid #C1C3D1;
  border-bottom-: 1px solid #C1C3D1;
  color:#666B85;
  font-size:16px;
  font-weight:normal;
  text-shadow: 0 1px 1px rgba(256, 256, 256, 0.1);
}
 
tr:hover td {
  background:#4E5066;
  color:#FFFFFF;
  border-top: 1px solid #22262e;
  border-bottom: 1px solid #22262e;
}
 
tr:first-child {
  border-top:none;
}

tr:last-child {
  border-bottom:none;
}
 
tr:nth-child(odd) td {
  background:#EBEBEB;
}
 
tr:nth-child(odd):hover td {
  background:#4E5066;
}

tr:last-child td:first-child {
  border-bottom-left-radius:3px;
}
 
tr:last-child td:last-child {
  border-bottom-right-radius:3px;
}
 
td {
  background:#FFFFFF;
  padding:20px;
  text-align:left;
  vertical-align:middle;
  font-weight:300;
  font-size:18px;
  text-shadow: -1px -1px 1px rgba(0, 0, 0, 0.1);
  border-right: 1px solid #C1C3D1;
}

td:last-child {
  border-right: 0px;
}

th.text-left {
  text-align: left;
}

th.text-center {
  text-align: center;
}

th.text-right {
  text-align: right;
}

td.text-left {
  text-align: left;
}

td.text-center {
  text-align: center;
}

td.text-right {
  text-align: right;
}

</style>


<div class="table-title">
<h3>Termékek</h3>
</div>
<table class="table-fill">
<thead>
<tr>
<th class="text-left">Név</th>
<th class="text-left">Elérhető</th>
<th class="text-left">Kialakítás</th>
</tr>
</thead>
<tbody class="table-hover">
<tr>
<td class="text-left">Cső</td>
<td class="text-left">vas, réz, alumínium</td>
<td class="text-left"><img src=cso.jpg></td>
</tr>
<tr>
<td class="text-left">Lemez</td>
<td class="text-left">vas, réz, alumínium</td>
<td class="text-left"><img src=lemez.jpg></td>
</tr>
<tr>
<td class="text-left">T-profil</td>
<td class="text-left">vas, réz, alumínium</td>
<td class="text-left"><img src=t-profil.jpg></td>
</tr>
<tr>
<td class="text-left">Zártszelvény (téglalap)</td>
<td class="text-left">vas, réz, alumínium</td>
<td class="text-left"><img src=zartszelveny-teglalap.jpg></td>
</tr>
<tr>
<td class="text-left">Hatszögrúd</td>
<td class="text-left">vas, réz, alumínium</td>
<td class="text-left"><img src=hatszogrud.jpg></td>
</tr>
<tr>
<td class="text-left">Körrúd</td>
<td class="text-left">vas, réz, alumínium</td>
<td class="text-left"><img src=korrud.jpg></td>
</tr>
<tr>
<td class="text-left">L-profil</td>
<td class="text-left">vas, réz, alumínium</td>
<td class="text-left"><img src=l-profil.jpg></td>
</tr>
<tr>
<td class="text-left">U-profil</td>
<td class="text-left">vas, réz, alumínium</td>
<td class="text-left"><img src=u-profil.jpg></td
</tr>
<tr>
<td class="text-left">Laposrúd-vastaglemez</td>
<td class="text-left">vas, réz, alumínium</td>
<td class="text-left"><img src=laposrud-vastaglemez.jpg></td>
</tr>
<tr>
<td class="text-left">Négyzetrúd</td>
<td class="text-left">vas, réz, alumínium</td>
<td class="text-left"><img src=negyzetrud.jpg></td>
</tr>
<tr>
<td class="text-left">Zártszelvény (négyzetes)</td>
<td class="text-left">vas, réz, alumínium</td>
<td class="text-left"><img src=zartszelveny-negyzetes.jpg></td>
</tr>
</tbody>
</table>




<link href='http://fonts.googleapis.com/css?family=Open+Sans+Condensed:300' rel='stylesheet' type='text/css'>
<style type="text/css">
.form-style-8{
    font-family: 'Open Sans Condensed', arial, sans;
    width: 500px;
    padding: 30px;
    background: #FFFFFF;
    margin: 50px auto;
    box-shadow: 0px 0px 15px rgba(0, 0, 0, 0.22);
    -moz-box-shadow: 0px 0px 15px rgba(0, 0, 0, 0.22);
    -webkit-box-shadow:  0px 0px 15px rgba(0, 0, 0, 0.22);

}
.form-style-8 h2{
    background: #4D4D4D;
    text-transform: uppercase;
    font-family: 'Open Sans Condensed', sans-serif;
    color: #797979;
    font-size: 18px;
    font-weight: 100;
    padding: 20px;
    margin: -30px -30px 30px -30px;
}
.form-style-8 input[type="text"],
.form-style-8 input[type="date"],
.form-style-8 input[type="datetime"],
.form-style-8 input[type="email"],
.form-style-8 input[type="number"],
.form-style-8 input[type="search"],
.form-style-8 input[type="time"],
.form-style-8 input[type="url"],
.form-style-8 input[type="password"],
.form-style-8 textarea,
.form-style-8 select
{
    box-sizing: border-box;
    -webkit-box-sizing: border-box;
    -moz-box-sizing: border-box;
    outline: none;
    display: block;
    width: 100%;
    padding: 7px;
    border: none;
    border-bottom: 1px solid #ddd;
    background: transparent;
    margin-bottom: 10px;
    font: 16px Arial, Helvetica, sans-serif;
    height: 45px;
}
.form-style-8 textarea{
    resize:none;
    overflow: hidden;
}
.form-style-8 input[type="button"],
.form-style-8 input[type="reset"],
.form-style-8 input[type="submit"]{
    -moz-box-shadow: inset 0px 1px 0px 0px #45D6D6;
    -webkit-box-shadow: inset 0px 1px 0px 0px #45D6D6;
    box-shadow: inset 0px 1px 0px 0px #45D6D6;
    background-color: #2CBBBB;
    border: 1px solid #27A0A0;
    display: inline-block;
    cursor: pointer;
    color: #FFFFFF;
    font-family: 'Open Sans Condensed', sans-serif;
    font-size: 14px;
    padding: 8px 18px;
    text-decoration: none;
    text-transform: uppercase;
}
.form-style-8 input[type="button"]:hover,
.form-style-8 input[type="reset"]:hover,
.form-style-8 input[type="submit"]:hover {
    background:linear-gradient(to bottom, #34CACA 5%, #30C9C9 100%);
    background-color:#34CACA;
}
</style>



	<br /><br /><hr width=70%><br /><br />


<div class="form-style-8">
<h2>Méret és súly kalkulátor</h2>


	<?php	
		$tnev= array("",
					"Cső",
					"Lemez",
					"T-profil",
					"Zártszelvény (téglalap)",
					"Hatszögrúd",
					"Körrúd",
					"L-profil",
					"U-profil",
					"Laposrúd-vastaglemez",
					"Négyzetrúd",
					"Zártszelvény (négyzetes)"
					);
		$anev=array("","Vas","Réz","Alumínium");

		
		function valid_input($adat){
			if (($adat>0)and($adat<100000000)){
			}else{
				$adat="";
			}
			return($adat);
		}
		
		echo("<form method='post'>");
		echo("	<select name=termek>");
		for($i=1;$i<=count($tnev)-1;$i++){
			echo("<option value=$i>$tnev[$i]</option>");
		}
		echo("	</select>");
		echo("	<br />");
		echo("	<select name=anyag>");
		for($i=1;$i<=count($anev)-1;$i++){
			echo("<option value=$i>$anev[$i]</option>");
		}
		echo("	</select>");
		echo("	<input type='text' name='m' placeholder='Magasság (mm)' />");
		echo("	<input type='text' name='s' placeholder='Szélesség (mm)' />");
		echo("	<input type='text' name='v' placeholder='Vastagság (mm)' />");
		echo("	<input type='text' name='h' placeholder='Hosszúság (mm)' />");
		echo("	<input type='submit' value='Számol'>");
		echo("	<input type='reset' value='Újra'>");
		echo("</form>");
		echo("	<br /><br /><p><b>Figyelem!</b><br />A kész terméknél a számított értékektől eltérések lehetnek.</p>");

		$termek="";
		$anyag="";
		$mag="";
		$sze="";
		$vas="";
		$hos="";
		if ($_SERVER['REQUEST_METHOD']=='POST'){
			$termek=$_POST["termek"];
			$anyag=$_POST["anyag"];
			$mag=valid_input($_POST["m"]);
			$sze=valid_input($_POST["s"]);
			$vas=valid_input($_POST["v"]);
			$hos=valid_input($_POST["h"]);
		}else{
			if ($_SERVER['REQUEST_METHOD']=='GET'){
				$termek=$_GET["termek"];
				$anyag=$_GET["anyag"];
				$mag=valid_input($_GET["m"]);
				$sze=valid_input($_GET["s"]);
				$vas=valid_input($_GET["v"]);
				$hos=valid_input($_GET["h"]);
			}
		}
		if (($hos<>"")and($mag<>"")and($sze<>"")){			
			if ($anyag=="1"){ $fajsuly=7.8; $anev="";}
			if ($anyag=="2"){ $fajsuly=8.9;}
			if ($anyag=="3"){ $fajsuly=2.7;}

			if ($vas==""){$vas=1;}

			echo("<br />A megadott adatok: $termek - $anyag - Magasság: $mag - Szélesség: $sze - Vastagság: $vas - Hossz: $hos .");

			if ($termek="1"){}
			if ($termek="2"){}
			if ($termek="3"){}
			if ($termek="4"){}
			if ($termek="5"){}
			if ($termek="6"){}
			if ($termek="7"){}
			if ($termek="8"){}
			if ($termek="9"){}
			if ($termek="10"){}
			if ($termek="11"){}
		}else{
			if ($termek<>""){
				echo("Valami hiányzik. Magasság, szélesség, hosszúság kitöltése kötelező...");
			}
		}
		echo("</div>");
	
	?>






	</body>
</html>

