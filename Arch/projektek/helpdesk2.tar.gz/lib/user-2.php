<?php

 #
 # PHPPortal
 #
 # info: main folder copyright file
 #
 #



?>
