
	<!-- Banner -->
	<section id="banner">
		<div class="inner">
			<div class="flex ">
				<div>
					<h3>Árlista</h3>
				</div>
			</div>
		</div>
	</section>

	<!-- Three -->
	<br /><br /><br />
	<center>
	<div class=content_box>
	<div class="1m">
		<table class="m">
			<tr>
				<td colspan=2>
					<center>Árlista</center><br /><br />
					<font size=-1>
					<p>
					<?php show_file("../content/Arlista/arlista.txt"); ?>
					</p>
					</font>
				</td>
			</tr>
		</table>
	</div>
	</div>
	</center>
