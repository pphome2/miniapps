
	<!-- Banner -->
	<section id="banner">
		<div class="inner">
			<div class="flex ">
				<div>
					<h3>Vállalási feltételek</h3>
				</div>
			</div>
		</div>
	</section>


	<!-- Three -->

	<br /><br />
	<center>
	<div class=content_box>
	<div class="1m">
		<table class="m">
			<tr>
				<td colspan=2>
					<center>Vállalási feltételek</center><br /><br />
					<font size=-1>
					<p>
					<?php show_file("../content/Feltetelek/feltetelek.txt"); ?>
					</p>
					</font>
				</td>
			</tr>
		</table>
	</div>
	</div>
	</center>
