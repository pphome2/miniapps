<?php

 #
 # PHPPortal
 #
 # info: main folder copyright file
 #
 #


function sql_init(){
	$sqltable="create table nevek (
		                iid varchar(14),
		                lname varchar(255),
		                fname varchar(255),
		                address varchar(255),
		                city varchar(255))
		                unique (iid)";

	# create table to database
	sql_run_command($sqltable);
}




?>
