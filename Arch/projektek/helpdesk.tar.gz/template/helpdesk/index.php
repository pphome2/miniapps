<!DOCTYPE HTML>
<html>
	<head>
		<title><?php echo("$PORTAL_NAME") ?></title>
		<meta charset="utf-8" />
		<meta http-equiv="Content-Type" content="text/html;charset=UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1" />
	</head>
	<body>

	<div id="Kezdőlap"></div>

		<!-- Header -->
			<header id="header">
				<div class="inner">
					<a href="index.php" class="logo">

					<nav class="fixed-nav-bar">
						<div id="menu" class="menu">
							<a class="sitename" href="index.php"><?php echo("$PORTAL_NAME"); ?></a>
							<ul class="menu-items">
								<li><a href="#Kezdőlap">Kezdőlap</a></li>
								<li><a href="#Hibabejelentés">Hibabejelentés</a></li>
								<li><a href="#Kapcsolat">Kapcsolat</a></li>
							</ul>
						</div>
					</nav>
				</div>
			</header>

			<?php

			?>

		<!-- Banner -->
			<section id="banner">
				<div class="inner">

					<div class="flex ">

						<div>
							<img src="../images/fejlesztes.png"><br />
							<br />
							<h3>Fejlesztés</h3>
							<br />
							<p>Egyedi szoftverek, weboldalak <br />fejlesztése a legmodernebb <br />eszközök felhasználásával.</p>
						</div>

						<div>
							<img src="../images/rendszer.png"><br />
							<br />
							<h3>Rendszerfelügyelet</h3>
							<br />
							<p>Teljes számítástechnikai <br />infrastruktúra kezelése. <br />Hibamegelőzés, tervezett fejlesztés.</p>
						</div>

						<div>
							<img src="../images/szerviz.png"><br />
							<br />
							<h3>Szervíz</h3>
							<br />
							<p>Számítástechnikai eszközök <br />javítása, eszközcserék <br />ütemezése.</p>
						</div>

					</div>

					<footer>
						<a href="#Kapcsolat" class="button">Kérjen testreszabott árajánlatot</a>
					</footer>
					<br /><br /><br /><br />

					<div class="flex ">

						<div>
						</div>
						<div>
							<img src="../images/hiba.png"><br />
						</div>
						<div>
						</div>
					</div>


					<footer>
						<a href="#Hibabejelentés" class="button">Hibabejelentés</a>
					</footer>
				</div>
			</section>


		<!-- Three -->
			<div id="Hibabejelentés"></div>
			<section id="three" class="wrapper align-center">
				<div class="inner">
					<img src="../images/hiba.png"><br /><br /><br />
					<p>
						Kérjük írja le milyen hibát tapasztalt.
						Ügyfélazonosítója, szerződése száma gyorsíthatja az ügyintézést.
					</p>
					<p>
						Az űrlap kitöltése után kap egy azonosítót, ez alapján láthatja
						a bejelentés állapotát és érdeklődhet a hibaelhárítás menetéről.
					<br />
						Az űrlap alatt láthatja a nyitott hibabejelentéseket, azonosító és
						állapot szerint.
					</p>
						A jelölt (*) mezőket kötelező kitölteni.
					<br /><br />
					<form id="error" action="" method="get" accept-charset="UTF-8">

						<div class="field half first">
							<label for="tname">Név / cégnév *</label><br />
							<input name="tname" id="tname" type="text" placeholder="Név / cégnév">
						</div>
						<div class="field half">
							<label for="tusz">Ügyfélszám / szerződés száma</label><br />
							<input name="tusz" id="tusz" type="text" placeholder="Ügyfélszám / szerződés száma">
						</div>
						<div class="field half first">
							<label for="ttsz">Telefonszám *</label><br />
							<input name="ttsz" id="ttsz" type="text" placeholder="Telefonszám">
						</div>
						<div class="field half">
							<label for="tmail">E-mail cím *</label><br />
							<input name="tmail" id="tmail" type="email" placeholder="E-mail">
						</div>
						<div class="field">
							<label for="tmess">Hibaleírás *</label><br />
							<textarea name="tmess" id="tmess" rows="6" placeholder="Hibaleírás"></textarea>
						</div>
						<?php form_protect($e1,$e2,$e3) ?>
						<div class="field">
							<label for="tell">Ellenőrzés * - Adja meg a két szám összegét: <?php echo("$e1 és $e2"); ?></label><br />
							<input name="tell" id="tell" type="text" placeholder="Ellenőrző szám">
						</div>
						<input name="tell2" id="tell2" type="hidden" value="<?php echo("$e3"); ?>" >
						<ul class="actions">
							<li><input value="Küldés" class="button" type="submit"></li>
						</ul>
					</form>
					<br /><br />
					<ul class="actions">
						<li><a href="index.php?page=feltetelek.php">
							<input value="Vállalási feltételek" class="button" type="ssubmit"></a>
						</li>
					</ul>
					<br /><br />
					<ul class="actions">
						<li><a href="index.php?page=arlista.php">
							<input value="Árlista" class="button" type="ssubmit"></a>
						</li>
					</ul>
					<br />
				<?php
					echo("<br /><br /><br /><br />");
					$data=datatable_in2();
				?>
			</section>


		<!-- Footer -->
			<div id="Kapcsolat"></div>
			<footer id="footer">
				<div class="inner">
					<img src="../images/email.png"><br /><br />
					<h3>Keressen minket</h3>
					<p>
						Kérjen egyedi árajánlatot. Szakembereink az Ön igényeihez mérten határozzák meg a
						feladatokat, ennek alapján adnak ajánlatot.<br /><br />
						A jelölt (*) mezőket kötelező kitölteni.
					</p>
					<br /><br /><br />
					<form id="kapcsolat" action="" method="get" accept-charset="UTF-8">

						<div class="field half first">
							<label for="name">Név *</label><br />
							<input name="fname" id="fname" type="text" placeholder="Név">
						</div>
						<div class="field half">
							<label for="email">E-mail cím *</label><br />
							<input name="email" id="email" type="email" placeholder="E-mail">
						</div>
						<div class="field">
							<label for="message">Üzenet *</label><br />
							<textarea name="message" id="message" rows="6" placeholder="Üzenet"></textarea>
						</div>
						<?php form_protect($k1,$k2,$k3) ?>
						<div class="field">
							<label for="kell">Ellenőrzés * - Adja meg a két szám összegét: <?php echo("$k1 és $k2"); ?></label><br />
							<input name="kell" id="kell" type="text" placeholder="Ellenőrző szám">
						</div>
						<input name="kell2" id="kell2" type="hidden" value="<?php echo("$k3"); ?>" >
						<ul class="actions">
							<li><input value="Küldés" class="button alt" type="submit"></li>
						</ul>
					</form>
					<br /><br /><br />
					<div class="copyright"><br /><br /><br />
						<img src="../images/webstarthely_logo.png"><br />
						<?php echo("$COPYRIGHT $PORTAL_NAME - $PORTAL_DEV") ?> <br /><br />
						<a href="?page=admin.php"> -[ Adminisztráció ]- </a>
					</div>

				</div>
			</footer>


	<?php
		$code=formdata_in();
		if ($code<>""){
			if (strlen($code)>10){
				echo("<div class=modal id=modal-one aria-hidden=true>");
				echo("<div class=modal-dialog>");
				echo("	<div class=modal-header>");
				echo("		<h2>Üzenet</h2>");
				echo("		<a href=index.php class=btn-close aria-hidden=true>×</a>");
				echo("	</div>");
				echo("	<div class=modal-body>");
				echo("		<p>Bejelentését rögzítettük. <br /><br />Azonosító: ".$code." <br /><br />Hamarosan jelentkezünk...</p>");
				echo("	</div>");
				echo("	<div class=modal-footer> <a href=index.php#Hibabejelentés class=btn>Bezár</a>");
				echo("	</div>");
				echo("</div>");
				echo("</div>");
			}else{
				if (strlen($code)>1){
					echo("<div class=modal id=modal-one aria-hidden=true>");
					echo("<div class=modal-dialog>");
					echo("	<div class=modal-header>");
					echo("		<h2>Üzenet</h2>");
					echo("		<a href=index.php class=btn-close aria-hidden=true>×</a>");
					echo("	</div>");
					echo("	<div class=modal-body>");
					echo("		<p>Köszönjük üzenetét. Hamarosan jelentkezünk...</p>");
					echo("	</div>");
					echo("	<div class=modal-footer> <a href=index.php#Kapcsolat class=btn>Bezár</a>");
					echo("	</div>");
					echo("</div>");
					echo("</div>");
				}else{
					echo("<div class=modal id=modal-one aria-hidden=true>");
					echo("<div class=modal-dialog>");
					echo("	<div class=modal-header>");
					echo("		<h2>Üzenet</h2>");
					echo("		<a href=index.php class=btn-close aria-hidden=true>×</a>");
					echo("	</div>");
					echo("	<div class=modal-body>");
					echo("		<p>Hiányos adatok vagy az ellenőrző mező nem jó. Minden jelölt mezőt ki kell tölteni.</p>");
					echo("	</div>");
					if (count($REQUEST_DATA)>5){
						$c="#Hibabejelentés";
					}else{
						$c="#Kapcsolat";
					}
					echo("	<div class=modal-footer> <a href=index.php?$c class=btn>Bezár</a>");
					echo("	</div>");
					echo("</div>");
					echo("</div>");
				}
			}
		}
	?>
	</body>
</html>
