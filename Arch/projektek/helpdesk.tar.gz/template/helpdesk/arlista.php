<!DOCTYPE HTML>
<html>
	<head>
		<title><?php echo("$PORTAL_NAME") ?></title>
		<meta charset="utf-8" />
		<meta http-equiv="Content-Type" content="text/html;charset=UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1" />
	</head>
	<body style="height:100%;">

	<div id="Kezdőlap"></div>

		<!-- Header -->
			<header id="header">
				<div class="inner">
					<a href="index.php" class="logo">

					<nav class="fixed-nav-bar">
						<div id="menu" class="menu">
							<a class="sitename" href="index.php"><?php echo("$PORTAL_NAME"); ?></a>
							<ul class="menu-items">
								<li><a href="index.php?#Kezdőlap">Kezdőlap</a></li>
								<li><a href="index.php?#Hibabejelentés">Hibabejelentés</a></li>
								<li><a href="index.php?#Kapcsolat">Kapcsolat</a></li>
							</ul>
						</div>
					</nav>
				</div>
			</header>

			<?php

			?>

		<!-- Banner -->
			<section id="banner">
				<div class="inner">

					<div class="flex ">

						<div>
							<h3>Árlista</h3>
						</div>
					</div>
			</section>


		<!-- Three -->

		<style>
			table.m {
				width:95%;
				align:center;
			}
			table.m tbody tr {
				width:100%;
				background-color:#ffffff;
			}
			table.m tbody td {
				width:50%;
				border: solid 1px #dbdbdb;
			}
			table.m tbody th {
				width:50%;
			}
		</style>
				<?php
				?>
					<br />
					<center>
					<br /><br />
					<ul class="actions">
						<li><a href="index.php#Hibabejelentés">
							<input value="Hiba bejelentése" class="button" type="submit"></a>
						</li>
					</ul>
					</center>
					<br /><br />
					<center>
					<div class="1m">
						<table class="m">
							<tr>
								<td colspan=2>
									<center>Árlista</center><br /><br />
									<font size=-1>
									<p>
										<?php show_file("arlista.txt"); ?>
									</p>
									</font>
								</td>
							</tr>
						</table>
					</div>
					</center>


					<br /><br />
					<br /><br />
					<br /><br />
				<?php
				?>

		<!-- Footer -->

			<div id="Kapcsolat"></div>
			<footer id="footer">
				<div class="inner">
					<div class="copyright"><br /><br /><br />
						&copy; 2017. <?php echo("$PORTAL_NAME - $PORTAL_DEV") ?>
					</div>
				</div>
			</footer>

	<?php
	?>
	</body>
</html>
