<!DOCTYPE HTML>
<html>
	<head>
		<title><?php echo("$PORTAL_NAME") ?></title>
		<meta charset="utf-8" />
		<meta http-equiv="Content-Type" content="text/html;charset=UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1" />
	</head>
	<body style="height:100%;">

	<div id="Kezdőlap"></div>

		<!-- Header -->
			<header id="header">
				<div class="inner">
					<a href="index.php" class="logo">

					<nav class="fixed-nav-bar">
						<div id="menu" class="menu">
							<a class="sitename" href="index.php"><?php echo("$PORTAL_NAME"); ?></a>
							<ul class="menu-items">
								<li><a href="index.php?#Kezdőlap">Kezdőlap</a></li>
								<li><a href="index.php?#Hibabejelentés">Hibabejelentés</a></li>
								<li><a href="index.php?#Kapcsolat">Kapcsolat</a></li>
							</ul>
						</div>
					</nav>
				</div>
			</header>

			<?php

			?>

		<!-- Banner -->
			<section id="banner">
				<div class="inner">

					<div class="flex ">

						<div>
							<h3>Hibabejelentések kezelése</h3>
						</div>
					</div>
			</section>


		<!-- Three -->
			<div id="Hibabejelentés"></div>
			<section id="three" class="wrapper align-center">
				<div class="inner">


				<?php
					$data=array("","","","","","","","","","","",);
					$linkad=i_admin();
					if ($linkad<>""){

				?>
					<form id="error" action="" method="get" accept-charset="UTF-8">
						<input name="page" id="page" type="hidden" value="admin.php" >
						<input name="code" id="code" type="hidden" value="<?php echo("$data[0]"); ?>" >
						<input name="lpass" id="luser" type="hidden" value="<?php $g=get_sublink("lpass"); echo($g); ?>" >
						<input name="luser" id="lpass" type="hidden" value="<?php $g=get_sublink("luser"); echo($g); ?>" >
						<div class="field half first">
							<label for="xdat">Dátum</label><br />
							<input name="xdat" id="xdat" type="text" placeholder="Például: 20170117 (az azonosító eleje)" value="" >
						</div>
						<div class="field half">
							<label for="xceg">Cégnév</label><br />
							<input name="xceg" id="xceg" type="text" placeholder="Cégnév" value="" >
						</div>
						<ul class="actions">
							<li><input value="Szűrés" class="button" type="submit"></li>
						</ul>
					</form>
					<br /><br />
				<?php
						$dataline="code";
						$datadel="del";
						$data=datatable_row_in($dataline,$datadel);
						echo("<br /><br /><br /><br />");
						$link=$linkad."page=admin.php&code=";
						$link2="?page=admin.php";
						$link3=$linkad."page=admin2.php&code=";
						$link4=$linkad."page=admin3.php&code=";
						$link5=$linkad."page=feltetelek.php&code=";
						$linkall=datatable_in($link,"buttonx");
						echo("<br /><br /><br /><br />");

				?>
					<br /><br />
					<form id="error" action="" method="get" accept-charset="UTF-8">

						<input name="page" id="page" type="hidden" value="admin.php" >
						<input name="code" id="code" type="hidden" value="<?php echo("$data[0]"); ?>" >
						<input name="lpass" id="luser" type="hidden" value="<?php $g=get_sublink("lpass"); echo($g); ?>" >
						<input name="luser" id="lpass" type="hidden" value="<?php $g=get_sublink("luser"); echo($g); ?>" >
						<input name="xdat" id="xdat" type="hidden" value="<?php $g=get_sublink("xdat"); echo($g); ?>" >
						<input name="xceg" id="xceg" type="hidden" value="<?php $g=get_sublink("xceg"); echo($g); ?>" >
						<div class="field half first">
							<label for="taz">Dátum</label><br />
							<input name="taz" id="taz" type="text" placeholder="Dátum" value="<?php $d=id_to_onlydate("$data[0]"); echo($d); ?>" >
						</div>
						<div class="field half">
							<label for="tid">Azonosító</label><br />
							<input name="tid" id="tid" type="text" placeholder="Azonosító" value="<?php echo("$data[0]"); ?>" >
						</div>
						<div class="field half first">
							<label for="tname">Név / cégnév</label><br />
							<input name="tname" id="tname" type="text" placeholder="Név / cégnév" value="<?php echo("$data[1]"); ?>" >
						</div>
						<div class="field half">
							<label for="tusz">Ügyfélszám / szerződés száma</label><br />
							<input name="tusz" id="tusz" type="text" placeholder="Ügyfélszám / szerződés száma" value="<?php echo("$data[2]"); ?>" >
						</div>
						<div class="field half first">
							<label for="ttsz">Telefonszám</label><br />
							<input name="ttsz" id="ttsz" type="text" placeholder="Telefonszám" value="<?php echo("$data[3]"); ?>" >
						</div>
						<div class="field half">
							<label for="tmail">E-mail cím</label><br />
							<input name="tmail" id="tmail" type="email" placeholder="E-mail" value="<?php echo("$data[4]"); ?>" >
						</div>
						<div class="field">
							<label for="tmess">Hibaleírás</label><br />
							<textarea name="tmess" id="tmess" rows="6" placeholder="Hibaleírás"><?php echo("$data[5]"); ?></textarea>
						</div>
						<div class="field">
							<label for="tstat">Javítás állapota</label><br />
							<input name="tstat" id="tstat" type="text" placeholder="Javítás állapota" value="<?php echo("$data[6]"); ?>" >
						</div>
						<div class="field">
							<label for="twork">Javítás leírás</label><br />
							<textarea name="twork" id="twork" rows="6" placeholder="Javítás leírása"><?php echo("$data[7]"); ?></textarea>
						</div>
						<div class="field half first">
							<label for="thour">Munkaidő</label><br />
							<input name="thour" id="thour" type="text" placeholder="Munkaidő" value="<?php echo("$data[8]"); ?>" >
						</div>
						<div class="field half">
							<label for="tkm">Kiszállás (km)</label><br />
							<input name="tkm" id="tkm" type="text" placeholder="Kiszállás (km)" value="<?php echo("$data[9]"); ?>" >
						</div>
						<div class="field">
							<label for="tdat">Javítás befejezésének dátuma</label><br />
							<input name="tdat" id="tdat" type="text" placeholder="<?php $da=date('Y.m.d. G:i');echo("Például: $da"); ?>" value="<?php echo("$data[10]"); ?>" >
						</div>
						<div class="field">
							<input name="ttomail" id="ttomail" type="checkbox" value="email"> Ügyfél kiértesítése (mail).
						</div>
						<ul class="actions">
							<li><input value="Küldés" class="button" type="submit"></li>
						</ul>
					</form>
					<br /><br />
					<ul class="actions">
						<li><a href="<?php $l="index.php?".$link3.$data[0]; echo("$l"); ?>">
							<input value="Munkalap" class="button" type="submit"></a>
						</li>
					</ul>
					<br /><br />
					<ul class="actions">
						<li><a href="<?php $l="index.php?".$link4.$data[0]; echo("$l"); ?>">
							<input value="Megrendelőlap" class="button" type="submit"></a>
						</li>
					</ul>
					<br /><br />
					<br /><br />
					<br /><br />
					<ul class="actions">
						<li><a href="<?php echo("$link2"); ?>"><input value="Kilépés" class="button" type="submit"></a></li>
					</ul>
				<?php
				}else{
				?>
					<br /><br />
					<br /><br />
					<br /><br />
					<form id="login" action="" method="get" accept-charset="UTF-8">
						<input name="page" id="page" type="hidden" value="admin.php" >
						<div class="field half first">
							<label for="luser">Felhasználó</label><br />
							<input name="luser" id="luser" type="text" placeholder="Felhasználó" >
						</div>
						<div class="field half">
							<label for="lpass">Jelszó</label><br />
							<input name="lpass" id="lpass" type="text" placeholder="Jelszó" >
						</div>
					<br /><br />
					<br /><br />
					<br /><br />
					<br /><br />
						<ul class="actions">
							<li><input value="Bejelentkezés" class="button" type="submit"></li>
						</ul>
					</form>
					<br /><br />
					<br /><br />
					<br /><br />
					<br /><br />
					<br /><br />
					<br /><br />
					<br /><br />
					<br /><br />
					<br /><br />
					<br /><br />
					<?php
						}
					?>
				</div>
			</section>


		<!-- Footer -->

			<div id="Kapcsolat"></div>
			<footer id="footer">
				<div class="inner">
					<div class="copyright"><br /><br /><br />
						&copy; 2017. <?php echo("$PORTAL_NAME - $PORTAL_DEV") ?>
					</div>
				</div>
			</footer>

	<?php
		$code=formdata_change();
		if ($code<>""){
			if (strlen($code)>10){
				echo("<div class=modal id=modal-one aria-hidden=true>");
				echo("<div class=modal-dialog>");
				echo("	<div class=modal-header>");
				echo("		<h2>Üzenet</h2>");
				echo("		<a href=index.php class=btn-close aria-hidden=true>×</a>");
				echo("	</div>");
				echo("	<div class=modal-body>");
				echo("		<p>Azonosító: ".$code." <br /><br />Adatok javítva...</p>");
				echo("	</div>");
				echo("	<div class=modal-footer> <a href=\"$linkall$code\" class=btn>Bezár</a>");
				echo("	</div>");
				echo("</div>");
				echo("</div>");
			}
		}
	?>
	</body>
</html>

