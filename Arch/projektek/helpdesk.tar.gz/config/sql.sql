
# create it with phpmyadmin...

# create database tickets;

create table tickets (
    tid varchar(20),
    tname varchar(255),
    tusz varchar(255),
    ttsz varchar(255),
    tmail varchar(255),
    tmess text,
    tstat varchar(255),
    twork text,
    thour int,
    tkm int,
    tdat varchar(20),
    primary key (tid)
);
