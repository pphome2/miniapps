<?php

 #
 # Helpdesk
 #
 # info: main folder copyright file
 #
 #



function formdata(){
	global $REQUEST_DATA;

	if ($REQUEST_DATA["fname"]<>""){
		$id=id();
		$fname=valid_input($REQUEST_DATA["fname"]);
		$lname=valid_input($REQUEST_DATA["lname"]);
		$address=valid_input($REQUEST_DATA["address"]);
		$city=valid_input($REQUEST_DATA["city"]);
	}

	if ($lname<>""){
		$sqlinsert="insert into nevek value (
						\"$id\",
						\"$lname\",
						\"$fname\",
						\"$address\",
						\"$city\")";
		echo($sqlinsert);
		sql_run_command($sqlinsert);
	}
}


function formdata_in(){
	global $REQUEST_DATA;

	$ret="";
	$pcount=count($REQUEST_DATA);
	if ($pcount>5){
		$sid=id();
		$sname=valid_input($REQUEST_DATA["tname"]);
		$susz=valid_input($REQUEST_DATA["tusz"]);
		$stsz=valid_input($REQUEST_DATA["ttsz"]);
		$smail=valid_input($REQUEST_DATA["tmail"]);
		$smess=valid_input($REQUEST_DATA["tmess"]);
		$sstat="Új bejelentés";
		$swork="";
		$shour=0;
		$skm=0;
		$sdat="";
		$sell=valid_input($REQUEST_DATA["tell"]);
		$sell2=valid_input($REQUEST_DATA["tell2"]);
		if ($sell==$sell2){
			$ret=$sid;
		}else{
			$ret="-";
		}
	}else{
		if ($pcount>0){
			$ret=formdata_to_mail();
		}
	}

	$sizeret=strlen($ret);
	if ($sizeret>10){
		if ((($sname<>"")and($smess<>""))and
			(($stsz<>"")or($smail<>""))){
			$sqlinsert="insert into tickets value (
							\"$sid\",
							\"$sname\",
							\"$susz\",
							\"$stsz\",
							\"$smail\",
							\"$smess\",
							\"$sstat\",
							\"$swork\",
							\"$shour\",
							\"$skm\",
							\"$sdat\")";
			sql_run_command($sqlinsert);
		}else{
			$ret="-";
		}
	}
	return($ret);
}


function formdata_change(){
	global $REQUEST_DATA,$PORTAL_NAME;

	$ret="";
	$pcount=count($_GET);
	if ($pcount>5){
		$sid=valid_input($REQUEST_DATA["tid"]);
		$sname=valid_input($REQUEST_DATA["tname"]);
		$susz=valid_input($REQUEST_DATA["tusz"]);
		$stsz=valid_input($REQUEST_DATA["ttsz"]);
		$smail=valid_input($REQUEST_DATA["tmail"]);
		$smess=valid_input($REQUEST_DATA["tmess"]);
		$sstat=valid_input($REQUEST_DATA["tstat"]);
		$swork=valid_input($REQUEST_DATA["twork"]);
		$shour=valid_input($REQUEST_DATA["thour"]);
		$skm=valid_input($REQUEST_DATA["tkm"]);
		$sdat=valid_input($REQUEST_DATA["tdat"]);
		$stomail=valid_input($REQUEST_DATA["ttomail"]);
		$ret=$sid;
	}

	$sizeret=strlen($ret);
	if ($sizeret>10){
		$sqlinsert="update tickets set
						tid=\"$sid\",
						tname=\"$sname\",
						tusz=\"$susz\",
						ttsz=\"$stsz\",
						tmail=\"$smail\",
						tmess=\"$smess\",
						tstat=\"$sstat\",
						twork=\"$swork\",
						thour=\"$shour\",
						tkm=\"$skm\",
						tdat=\"$sdat\" where tid=\"$sid\" ";
		sql_run_command($sqlinsert);
		if (strlen($stomail)>0){
			$mess="<html>";
			$mess=$mess."<body>";
			$mess=$mess."Tisztelt Ügyfelünk!<br /><br />";
			$mess=$mess."Értesítjük, hogy a $sid azonosítójú hiba állapota megváltozott.<br />";
			$mess=$mess."Állapot: $sstat<br /><br />";
			$mess=$mess."Üdvözlettel:<br />$PORTAL_NAME";
			$mess=$mess."</body>";
			$mess=$mess."</html>";
			formdata_to_mail_2($mess);
		}
	}
	return($ret);
}


function formdata_to_mail_2($mess){
	global $SMTP_TO,$PHPMAIL,$PORTAL_NAME;


	if ($PHPMAIL){
		mail($SMTP_TO,$PORTAL_NAME,$mess);
	}else{
		smtp_mail_sendto($SMTP_TO,$mess);
	}
}


function formdata_to_mail(){
	global $GETDATA,$SMTP_TO,$PORTAL_ADMIN_MAIL,$PHPMAIL,$PORTAL_NAME,$REQUEST_DATA;

	$ret="";
	$pcount=count($REQUEST_DATA);
	$name="";
	$email="";
	$mess="";
	if ($pcount>2){
		$id=id();
		$name=valid_input($REQUEST_DATA["fname"]);
		$email=valid_input($REQUEST_DATA["email"]);
		$mess=valid_input($REQUEST_DATA["message"]);
		$ell=valid_input($REQUEST_DATA["kell"]);
		$ell2=valid_input($REQUEST_DATA["kell2"]);
		$GETDATA=TRUE;
	}
	if (($name<>"")and($email<>"")and($mess<>"")and($ell==$ell2)){
		if ($PHPMAIL){
			$mess="Feladó: ".$name." - ".$email." - ".$mess;
			mail($SMTP_TO,$PORTAL_NAME,$mess);
		}else{
			$mess="Feladó: ".$name." - ".$email." <br /><br />".$mess;
			smtp_mail_sendto($SMTP_TO,$mess);
		}
		$ret="123456";
	}else{
		$ret="-";
	}
	return($ret);
}



function datatable_in($link,$buttonclass){
	global $ROW_PER_TABLE_PAGE;

	$lap=get_table_page("tp");
	$ret="";
	$felt="";
	$szdat=get_sublink("xdat");
	$sznev=get_sublink("xceg");
	if ($szdat<>""){
		$felt="where tid like '%$szdat"."%'";
		$link="xdat=$szdat"."&".$link;
	}
	if ($sznev<>""){
		$felt="where tname like '%$sznev"."%'";
		$link="xceg=$sznev"."&".$link;
	}
	$link="?".$link;
	$sqlcomm="select * from tickets $felt order by tid desc";
	sql_run_command($sqlcomm);
	$db=sql_result_num();
	if ($db>100){
		#$db=100;
	}
	$i=($lap-1)*$ROW_PER_TABLE_PAGE;
	$ig=$i+$ROW_PER_TABLE_PAGE;
	if ($ig>$db){
		$ig=$db;
	}
	if ($ROW_PER_TABLE_PAGE>$db){
		$i=1;
		$ig=$db;
	}
	echo("<table>");
	echo("<tr><th>Beérkezés ideje</th><th>Azonosító</th><th>Bejelentő</th><th>Állapot</th>");
	if ($link<>""){
	}
	echo("</tr>");
	echo("<tr>");
	while ($i<$ig){
		$data=sql_result($i);
		if ($data[8]==0){
			echo("<tr>");
			$out=id_to_onlydate($data[0]);
			echo("<td>$out</td>");
			if ($link<>""){
				$l=$link.$data[0];
				echo("<td><a href=$l>$data[0]</a>");
				$d=$l."&del=".$data[0];
				echo(" - <a href=$d>Töröl</td>");
			}else{
				echo("<td>$data[0]</td>");
			}
			echo("<td>$data[1]</td>");
			if ($data[10]<>""){
				echo("<td>Lezárva</td>");
			}else{
				echo("<td>$data[6]</td>");
			}
			echo("</tr>");
		}
		$i++;
	}
	echo("</table>");
	$l=$link;
	table_pager($lap,$db,$l,$buttonclass);
	return($link);
}


function datatable_in2(){
	$ret="";
	$sqlcomm="select * from tickets order by tid desc";
	sql_run_command($sqlcomm);
	$db=sql_result_num();
	if ($db>30){
		$db=30;
	}
	echo("<table>");
	echo("<tr><th>Beérkezés ideje</th><th>Azonosító</th><th>Állapot</th>");
	if ($link<>""){
	}
	echo("</tr>");
	echo("<tr>");
	for($i=0;$i<$db;$i++){
		$data=sql_result($i);
		if ($data[8]==0){
			echo("<tr>");
			$out=id_to_onlydate($data[0]);
			echo("<td>$out</td>");
			echo("<td>$data[0]</td>");
			if ($data[10]<>""){
				echo("<td>Lezárva</td>");
			}else{
				echo("<td>$data[6]</td>");
			}
			echo("</tr>");
		}
	}
	echo("</table>");
	return($ret);
}


function datatable_row_in($code,$del){
	global $GETDATA,$REQUEST_DATA;

	if ($REQUEST_DATA[$code]<>""){
		$c=$REQUEST_DATA[$code];
		$d=$REQUEST_DATA[$del];
		$GETDATA=TRUE;
	}
	if ($d<>""){
		$sqlcomm="delete from tickets where tid=\"".$d."\"";
		sql_run_command($sqlcomm);
	}
	$sqlcomm="select * from tickets where tid=\"".$c."\"";
	sql_run_command($sqlcomm);
	$db=sql_result_num();
	if ($db>0){
		$ret=sql_result(0);
	}else{
		$ret=array("","","","","","","","","","","",);
	}
	return($ret);
}





?>
