
beuszás
  $('element_to_pop_up').bPopup({
        easing: 'easeOutBack', //uses jQuery easing plugin
            speed: 450,
            transition: 'slideDown'
        });
                



kép

 $('element_to_pop_up').bPopup({
            content:'image', //'ajax', 'iframe' or 'image'
            contentContainer:'.content',
            loadUrl:'image.jpg'
        });
                


tartalom fájlból

   var self = $(this) //button
        , content = $('.content'); 
        
        $('element_to_pop_up').bPopup({
            onOpen: function() {
                content.html(self.data('bpopup') || '');
            },
            onClose: function() {
                content.empty();
            }
        });
             
autoclose 

        $('element_to_pop_up').bPopup({
            autoClose: 1000 //Auto closes after 1000ms/1sec
        });
             