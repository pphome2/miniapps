var FlatBox = new FlatBox('.post', {
  changeSlideSpeed: 200
});
