<?php

 #
 # PHPPortal
 #
 # info: main folder copyright file
 #
 #



function formdata_to_mail(){
	global $GETDATA,$SMTP_TO,$PORTAL_ADMIN_MAIL,$PHPMAIL,$PORTAL_NAME,$REQUEST_DATA;

	$ret="";
	$pcount=count($REQUEST_DATA);
	$name="";
	$email="";
	$mess="";
	if ($pcount>2){
		$id=id();
		$name=valid_input($REQUEST_DATA["fname"]);
		$email=valid_input($REQUEST_DATA["email"]);
		$mess=valid_input($REQUEST_DATA["message"]);
		$ell=valid_input($REQUEST_DATA["kell"]);
		$ell2=valid_input($REQUEST_DATA["kell2"]);
		$GETDATA=TRUE;
	}
	if (($name<>"")and($email<>"")and($mess<>"")and($ell==$ell2)){
		if ($PHPMAIL){
			$mess="Feladó: ".$name." - ".$email." - ".$mess;
			mail($SMTP_TO,$PORTAL_NAME,$mess);
		}else{
			$mess="Feladó: ".$name." - ".$email." <br /><br />".$mess;
			smtp_mail_sendto($SMTP_TO,$mess);
		}
		$ret="123456";
	}else{
		$ret="-";
	}
	return($ret);
}




?>
