<?php

 #
 # PHPPortal
 #
 # info: main folder copyright file
 #
 #


	if (file_exists("../config/config.php")){
		include("../config/config.php");
		if ((file_exists("$DIR_LIB/mysql.php"))and
			(file_exists("$DIR_LIB/smtp.php"))and
			(file_exists("$DIR_LIB/user.php"))and
			(file_exists("$DIR_LIB/lib.php"))){
			include("$DIR_LIB/mysql.php");
			include("$DIR_LIB/smtp.php");
			include("$DIR_LIB/user.php");
			include("$DIR_LIB/lib.php");
			main();
		}else{
			echo("<br /><hr /><br /><b>Hiba történt: hiányzik néhány fájl...</b><br /><br /><hr /><br />");
		}
	}else{
		echo("<br /><hr /><br /><b>Hiba történt: hiányzik néhány fájl...</b><br /><br /><hr /><br />");
	}



function main(){
	global	$PORTAL_NAME,
			$PORTAL_ADMIN_NAME,
			$PORTAL_ADMIN_PASSWORD,
			$MYSQL_SERVER,
			$MYSQL_PORT,
			$MYSQL_DATABASE,
			$MYSQL_USER,
			$MYSQL_PASSWORD,
			$MAIN_JS,
			$DIR_INCLUDE,
			$ACTIVE_PLUGINS,
			$DIR_TEMPLATE,
			$TEMPLATE,
			$DIR_PLUGINS,
			$REQUEST_DATA;

	echo("<style>");
	$cdir=scandir("$DIR_INCLUDE/css");
	foreach ($cdir as $key => $value){
		if (!in_array($value,array(".","..",".htaccess"))){
			include("$DIR_INCLUDE/css/$value");
		}
	}

	$cdir=scandir("$DIR_TEMPLATE/$TEMPLATE/css");
	foreach ($cdir as $key => $value){
		if (!in_array($value,array(".","..",".htaccess"))){
			include("$DIR_TEMPLATE/$TEMPLATE/css/$value");
		}
	}
	echo("</style>");

	echo("<script type=text/javascript>");
	if ($MAIN_JS){
		$cdir=scandir("$DIR_INCLUDE/js");
		foreach ($cdir as $key => $value){
			if (!in_array($value,array(".","..",".htaccess"))){
				include("$DIR_INCLUDE/js/$value");
			}
		}
	}else{
		if (file_exists("$DIR_INCLUDE/js/main.js")){
			include("$DIR_INCLUDE/js/main.js");
		}
	}
	$cdir=scandir("$DIR_TEMPLATE/$TEMPLATE/js");
	foreach ($cdir as $key => $value){
		if (!in_array($value,array(".","..",".htaccess"))){
			include("$DIR_TEMPLATE/$TEMPLATE/js/$value");
		}
	}
	echo("</script>");

	$db=count($ACTIVE_PLUGINS);
	for($i=0;$i<$db;$i++){
		echo("<style>");
		$cdir=scandir("$DIR_PLUGINS/$ACTIVE_PLUGINS[$i]/css");
		foreach ($cdir as $key => $value){
			if (!in_array($value,array(".","..",".htaccess"))){
				include("$DIR_PLUGINS/$ACTIVE_PLUGINS[$i]/css/$value");
			}
		}
		echo("</style>");

		echo("<script type=text/javascript>");
		$cdir=scandir("$DIR_PLUGINS/$ACTIVE_PLUGINS[$i]/js");
		foreach ($cdir as $key => $value){
			if (!in_array($value,array(".","..",".htaccess"))){
				include("$DIR_PLUGINS/$ACTIVE_PLUGINS[$i]/js/$value");
			}
		}
		echo("</script>");

		$cdir=scandir("$DIR_PLUGINS/$ACTIVE_PLUGINS[$i]/php");
		foreach ($cdir as $key => $value){
			if (!in_array($value,array(".","..",".htaccess"))){
				include("$DIR_PLUGINS/$ACTIVE_PLUGINS[$i]/php/$value");
			}
		}
	}

	if ($_SERVER['REQUEST_METHOD']=="POST"){
		$REQUEST_DATA=$_POST;
	}else{
		if ($_SERVER['REQUEST_METHOD']=="GET"){
			$REQUEST_DATA=$_GET;
		}
	}
}

?>
