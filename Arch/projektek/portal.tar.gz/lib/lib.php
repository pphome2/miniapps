<?php

 #
 # PHPPortal
 #
 # info: main folder copyright file
 #
 #

function system_message($line){
    echo("<br /><hr /><br /><br /><b>$line</b></br /><hr /><br />");
}


function system_xmessage(){
    global $SYSTEM_MESSAGE;

    echo("<br /><hr /><br /><br /><b>$SYSTEM_MESSAGE</b></br /><hr /><br />");
}


function id(){
    $idcode="";

    $idcode=date('YmdHis').strval(rand(1000,9999));
    return($idcode);
}


function id_to_date($d){
    if ($d<>""){
	$out=substr($d,0,4).".".substr($d,4,2).".".substr($d,6,2).". ";
	$out=$out.substr($d,8,2).":".substr($d,10,2).".".substr($d,12,2)." - ";
	$out=$out.substr($d,14,4);
    }else{
	$out="";
    }
    return($out);
}


function id_to_onlydate($d){
    if ($d<>""){
	$out=substr($d,0,4).".".substr($d,4,2).".".substr($d,6,2).". ";
	$out=$out.substr($d,8,2).":".substr($d,10,2);
    }else{
	$out="";
    }
    return($out);
}



function valid_input($data) {
  $data=trim($data);
  $data=stripslashes($data);
  $data=htmlspecialchars($data);
  return($data);
}


function get_page_name(){
    global $PAGE_NAME,$GETDATA,$REQUEST_DATA;

    $ret="";
    if ($REQUEST_DATA[$PAGE_NAME]<>""){
	$ret=$REQUEST_DATA[$PAGE_NAME];
	$GETDATA=TRUE;
    }
    return($ret);
}


function show_file($file){
    global $DIR_TEMPLATE, $TEMPLATE;

    $sub=substr($file,0,1);
    if (($sub<>".")and($sub<>"/")){
	$file="$DIR_TEMPLATE/$TEMPLATE/$file";
    }
    if (file_exists($file)){
	$f=file_get_contents($file);
	echo($f);
    }
}



function form_protect(&$a1,&$a2,&$a3){
    $ret=FALSE;
    if (($a1+$a2)==$a3){
	$ret=TRUE;
    }
    $a1=rand(0,20);
    $a2=rand(0,20);
    $a3=$a1+$a2;
    return($ret);
}



function get_page_pos(){
    $ret=$_SERVER[REQUEST_URI];
    $c=strpos($ret,'#');
    $ret=substr($ret,$c);
    return($ret);
}



function i_admin(){
    global $PORTAL_ADMIN_NAME,$PORTAL_ADMIN_PASSWORD,$PORTAL_ADMIN_PASSWORD_MD5,$REQUEST_DATA;

    $ret="";
    $lu=valid_input($REQUEST_DATA["luser"]);
    $lp=valid_input($REQUEST_DATA["lpass"]);
    if ($PORTAL_ADMIN_PASSWORD_MD5){
	if (strlen($lp)<30){
	    $lp2=md5($lp);
	}else{
	    $lp2=$lp;
	}
    }else{
	$lp2=$lp;
    }
    if (($lu==$PORTAL_ADMIN_NAME)and($lp2==$PORTAL_ADMIN_PASSWORD)){
	$ret="luser=".$lu."&lpass=".$lp2."&";
    }
    return($ret);
}


function get_table_page($key){
    global $REQUEST_DATA;

    $ret="";
    $ret=$REQUEST_DATA[$key];
    if ($ret==""){
	$ret="1";
    }
    return($ret);
}


function table_pager($tpage,$tmaxrow,$urli,$class){
    global $ROW_PER_TABLE_PAGE;

    if ($tmaxrow>$ROW_PER_TABLE_PAGE){
	$allpage=$tmaxrow/$ROW_PER_TABLE_PAGE;
	if ($allpage%1>0){
	    $allpage=ceil($allpage);
	}else{
	    $allpage=ceil($allpage)-1;
	}
	$link=change_link($urli,"tp",1);
	echo("<a href=$link><div class=$class> << </div></a>");
	if ($tpage>1){
	    $link=change_link($urli,"tp",$tpage-1);
	}
	echo("<a href=$link><div class=$class> < </div></a>");
	if ($allpage>10){
	    $ok=TRUE;
	    if ($tpage-5<1){
		$i=1;
		$ig=10;
		$ok=FALSE;
	    }
	    if ($tpage+5>$allpage){
		$i=$allpage-9;
		$ig=$allpage;
		$ok=FALSE;
	    }
	    if ($ok){
		$i=$tpage-4;
		$ig=$tpage+5;
	    }
	}else{
	    $i=1;
	    $ig=$allpage;
	}
	if ($i>1){
	    echo(" ... ");
	}
	while ($i<=$ig){
	    $link=change_link($urli,"tp",$i);
	    echo("<a href=$link><div class=$class>");
	    if ($i==$tpage){
		echo("<b>$i</b>");
	    }else{
		echo("$i");
	    }
	    echo("</div></a>");
	    $i++;
	}
	if ($ig<$allpage){
	    echo(" ... ");
	}
	if ($tpage<$allpage){
	    $link=change_link($urli,"tp",$tpage+1);
	}else{
	    $link=change_link($urli,"tp",$allpage);
	}
	echo("<a href=$link><div class=$class> > </div></a>");
	$link=change_link($urli,"tp",$allpage);
	echo("<a href=$link><div class=$class> >> </div></a>");
    }

}


function change_link($xlink,$xkey,$xdata){
    global $REQUEST_DATA,$INDEX_FILE;

    $l2=$INDEX_FILE."?";
    $first=TRUE;
    $found=FALSE;
    foreach($REQUEST_DATA as $key => $value){
	if (!$first){
	    $l2=$l2."&";
	}else{
	    $first=FALSE;
	}
	if ($key==$xkey){
	    $l2=$l2.$key."=".$xdata;
	    $found=TRUE;
	}else{
	    $l2=$l2.$key."=".$value;
	}
    }
    if (!$found){
	$l2=$l2."&".$xkey."=".$xdata;
    }
    return($l2);
}


function get_sublink($code){
    global $REQUEST_DATA;

    $ret=valid_input($REQUEST_DATA["$code"]);
    return($ret);
}




?>
