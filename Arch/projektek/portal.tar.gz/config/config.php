<?php

 #
 # PHPPortal
 #
 # info: main folder copyright file
 #

# configuration - need change it

$COPYRIGHT="&copy; 2017.";

$PORTAL_NAME="Webstarthely.hu";
$PORTAL_DEV="P";
$PORTAL_ADMIN_NAME="p";
$PORTAL_ADMIN_PASSWORD="p";
$PORTAL_ADMIN_MAIL="webstarthely.hu@gmail.com";

$MYSQL_SERVER="localhost";
$MYSQL_PORT="";
$MYSQL_DATABASE="";
$MYSQL_USER="";
$MYSQL_PASSWORD="";

$SMTP_HOST="ssl://smtp.gmail.com";
$SMTP_SECURE="ssl";
$SMTP_PORT="465";
#$SMTP_PORT="587";
$SMTP_USER="webstarthely.hu@gmail.com";
$SMTP_PASSWORD="Web2015start1hely.hu";
$SMTP_FROM="webstarthely.hu@gmail.com";
$SMTP_DOMAIN="gmail.com";
$SMTP_TO="webstarthely.hu@gmail.com";
$PHPMAIL=FALSE;

# mail form send data to other site

$MAILGATE="#";
# or hashmark to local page

$ACTIVE_PLUGINS=array("slider","pricetable","fixedmenu","pageloadpopup");
$TEMPLATE="1";

# change in program

$SMTP_SUBJECT=$PORTAL_NAME." - Üzenet";
$SMTP_MESSAGE="";
$SMTP_HEADERS="Content-Type: text/html; charset=UTF-8";


# inside variable initilaized - no change!

$MAIN_JS=FALSE;

$SYSTEM_MESSAGE="";

$MYSQL_RESULT;
$MYSQL_LINK;
$REQUEST_DATA=array();

$GETDATA=FALSE;

$DIR_CONFIG="../config";
$DIR_LIB="../lib";
$DIR_INCLUDE="../include";
$DIR_IMAGES="../images";
$DIR_PLUGINS="../plugins";
$DIR_TEMPLATE="../template";

?>
