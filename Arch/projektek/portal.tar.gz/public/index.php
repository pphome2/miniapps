<?php

 #
 # PHPPortal
 #
 # info: main folder copyright file
 #
 #


	if (file_exists("../lib/main.php")){
		include("../lib/main.php");
		$page=get_page_name();
		if ($page==""){
			$page="index.php";
		}
		include("$DIR_TEMPLATE/$TEMPLATE/$page");
	}else{
		if (file_exists("error.php")){
			include("error.php");
		}else{
		    echo("Rendszerhiba...");
		}
	}
?>
