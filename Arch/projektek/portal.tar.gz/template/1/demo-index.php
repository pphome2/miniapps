<html>
	<head>
		<title><?php echo("$PORTAL_NAME") ?></title>
	</head>
<body>
	
<?php
?> 
  
	<br />
	<br />


	<div class="container">
		<div id="content-slider">
			<div id="slider">
				<div id="mask">
				<ul>
					<li id="first" class="firstanimation">
						<a href="#">
						<img src="../images/1.jpg" alt="Fejlesztés"/>
						</a>
						<div class="tooltip">
							<h1>Fejlesztés</h1>
						</div>
					</li>
					<li id="second" class="secondanimation">
						<a href="#">
							<img src="../images/2.jpg" alt="Rendszerfelügyelet"/>
						</a>
						<div class="tooltip">
							<h1>Szervíz</h1>
						</div>
					</li>
           			<li id="third" class="thirdanimation">
						<a href="#">
							<img src="../images/3.jpg" alt="Szervíz"/>
							</a>
						<div class="tooltip">
							<h1>Felügyelet</h1>
						</div>
					</li>           
					<li id="fourth" class="fourthanimation">
						<a href="#">
							<img src="../images/1.jpg" alt="Howling"/>
						</a>
						<div class="tooltip">
							<h1>Fejlesztés</h1>
						</div>
					</li>
                        
					<li id="fifth" class="fifthanimation">
						<a href="#">
							<img src="../images/2.jpg" alt="Sunbathing"/>
						</a>
						<div class="tooltip">
							<h1>Felügyelet</h1>
						</div>
					</li>
				</ul>
				</div>
            <div class="progress-bar"></div>
			</div>
		</div>
	</div>



    <div id="pricing-table" class="clear">
    <div class="plan">
        <h3>Cég<span>50.000,-</span></h3>
        <a class="signup" href="Kapcsolat">Kérjen ajánlatot</a>         
        <ul>
            <li>Teljeskörű felügyelet</li>
            <li>0-24 órás elérhetőség</li>
            <li>Egyéni kapcsolattartó</li>
			<li>Azzonali hibaelhárítás</li>			
        </ul> 
    </div>
    <div class="plan" id="most-popular">
        <h3>Profi<span>30.000,-</span></h3>
        <a class="signup" href="Kapcsolat">Kérjen ajánlatot</a>        
        <ul>
            <li>Teljeskörű felügyelet</li>
            <li>Munkaidőben elérhetőség</li>
            <li>Egyéni kapcsolattartó</li>
			<li>Azonnali hibaelhárítás</li>			
        </ul>    
    </div>
    <div class="plan">
        <h3>Iroda<span>20.000,-</span></h3>
		<a class="signup" href="Kapcsolat">Kérjen ajánlatot</a>
        <ul>
            <li>Korlátozott felügyelet</li>
            <li>Munkaidőben elérhetőség</li>
            <li>Elérhető szakember</li>
			<li>Hibaelhárítás munkaidőben</li>			
        </ul>
    </div>
    <div class="plan">
        <h3>Alap<span>10.000,-</span></h3>
        <a class="signup" href="Kapcsolat">Kérjen ajánlatot</a>		
        <ul>
            <li>Tanácsadás</li>
            <li>Munkaidőben elérhetőség</li>
            <li>Elérhető szakember</li>
			<li>Hibaelhárítás munkaidőben</li>			
        </ul>
    </div> 	
</div>
	<p>PHPPortal project starter.</p>

</body>
</html>
