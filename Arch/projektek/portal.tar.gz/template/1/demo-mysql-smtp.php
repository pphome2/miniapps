<html>
	<head>
		<title>PHP Test</title>
	</head>
<body>
	
<?php
		# mail send
		#smtp_mail_system_message("teszt");


		# teszt mysql connect
		#sql_server_connect();
		if ($MYSQL_LINK){
			#echo("<br>connect...<br>");
			#sql_server_close();
		}else{
			#echo("<br>not connect...<br>");
		}

		# check incoming data from form
		#formdata();
		echo("<br /><br />");
		#tabledata();
	#}
	
	echo("<br /><br /><hr /><br />$PORTAL_NAME");
	echo("<br /><b>PHPPortal loaded...</b><br />");
?> 
  
	<br />
	<form method="get">
		Vezetéknév:
		<input type="text" name="fname"><br />
		Keresztnév:
		<input type="text" name="lname"><br />
		Lakcím:
		<input type="text" name="address"><br />
		Lakhely:
		<input type="text" name="city">
		<br /><br />
		<input type="submit" value="Mehet">
	</form> 
	<br />
	<br />  

	<script>
    $(function () {

      // Slideshow 3
      $("#slider3").responsiveSlides({
        auto: true,
        pager: true,
        speed: 300,
        maxwidth: 540
      });

      // Slideshow 4
      $("#slider4").responsiveSlides({
        auto: true,
        pager: false,
        nav: true,
        speed: 300,
        maxwidth: 700,
        namespace: "callbacks",
        before: function () {
          $('.events').append("<li>before event fired.</li>");
        },
        after: function () {
          $('.events').append("<li>after event fired.</li>");
        }
      });

    });

    </script>



    <!-- Slideshow 3 Pager -->
    <ul id="slider3">
      <li><a href="#"><img src="../images/1.jpg" alt=""></a></li>
      <li><a href="#"><img src="../images/2.jpg" alt=""></a></li>
      <li><a href="#"><img src="../images/3.jpg" alt=""></a></li>
    </ul>



    <!-- Slideshow 4 -->
    <div class="callbacks_container">
      <ul class="rslides" id="slider4">
        <li>
          <img src="../images/1.jpg" alt="">
          <p class="caption">This is a caption</p>
        </li>
        <li>
          <img src="../images/2.jpg" alt="">
          <p class="caption">This is another caption</p>
        </li>
        <li>
          <img src="../images/3.jpg" alt="">
          <p class="caption">The third caption</p>
        </li>
      </ul>
    </div>

    

            
	<p>PHPPortal project starter.</p>

</body>
</html>
