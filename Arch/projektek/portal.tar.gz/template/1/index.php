<!DOCTYPE HTML>
<html>
	<head>
		<title><?php echo("$PORTAL_NAME") ?></title>
		<meta charset="utf-8" /> 
		<meta http-equiv="Content-Type" content="text/html;charset=UTF-8"> 
		<meta name="viewport" content="width=device-width, initial-scale=1" />
	</head>
	<body>

	<div id="Kezdőlap"></div>
		
		<!-- Header -->
			<header id="header">
				<div class="inner">
					<a href="index.php" class="logo">
		
					<nav class="fixed-nav-bar">
						<div id="menu" class="menu">
							<a class="sitename" href="">Webstarthely.hu</a>
							<ul class="menu-items">
								<li><a href="#Kezdőlap">Kezdőlap</a></li>
								<li><a href="#Szolgáltatások">Szolgáltatások</a></li>
								<li><a href="#Kapcsolat">Kapcsolat</a></li>
							</ul>
						</div>
					</nav>
				</div>
			</header>

			<?php
							
			?>

		<!-- Banner -->
			<section id="banner">
				<div class="inner">
					
					<div class="container">
						<div id="content-slider">
							<div id="slider">
								<div id="mask">
								<ul>
									<li id="first" class="firstanimation">
										<a href="#">
										<img class="imgsl" src="../images/1.jpg" alt="Fejlesztés"/>
										</a>
										<div class="tooltip">
											<h1>Fejlesztés</h1>
										</div>
									</li>
									<li id="second" class="secondanimation">
										<a href="#">
											<img class="imgsl" src="../images/2.jpg" alt="Rendszerfelügyelet"/>
										</a>
										<div class="tooltip">
											<h1>Szervíz</h1>
										</div>
									</li>
									<li id="third" class="thirdanimation">
										<a href="#">
											<img class="imgsl" src="../images/3.jpg" alt="Szervíz"/>
											</a>
										<div class="tooltip">
											<h1>Felügyelet</h1>
										</div>
									</li>           
									<li id="fourth" class="fourthanimation">
										<a href="#">
											<img class="imgsl" src="../images/1.jpg" alt="Fejlesztés"/>
										</a>
										<div class="tooltip">
											<h1>Fejlesztés</h1>
										</div>
									</li>                        
									<li id="fifth" class="fifthanimation">
										<a href="#">
											<img class="imgsl" src="../images/2.jpg" alt="Rendszerfelügyelet"/>
										</a>
										<div class="tooltip">
											<h1>Felügyelet</h1>
										</div>
									</li>
								</ul>
								</div>
							<div class="progress-bar"></div>
							</div>
						</div>
					</div>

					<div class="flex ">

						<div>
							<img src="../images/fejlesztes.png"><br />
							<br />
							<h3>Fejlesztés</h3>
							<br />
							<p>Egyedi szoftverek, weboldalak <br />fejlesztése a legmodernebb <br />eszközök felhasználásával.</p>
						</div>

						<div>
							<img src="../images/rendszer.png"><br />
							<br />
							<h3>Rendszerfelügyelet</h3>
							<br />
							<p>Teljes számítástechnikai <br />infrastruktúra kezelése. <br />Hibamegelőzés, azonnali <br />javítás, tervezett fejlesztések.</p>
						</div>

						<div>
							<img src="../images/szerviz.png"><br />
							<br />
							<h3>Szervíz</h3>
							<br />
							<p>Számítástechnikai eszközök <br />javítása, eszközcserék <br />ütemezése.</p>
						</div>

					</div>

					<footer>
						<a href="#Kapcsolat" class="button">Kérjen testreszabott árajánlatot</a>
					</footer>
				</div>
			</section>


		<!-- Three -->
			<div id="Szolgáltatások"></div>
			<section id="three" class="wrapper align-center">
				<div class="inner">
					<div class="flex flex-2">
						<article>
							<div class="image round">
								<img src="../images/cimke.png" alt="Pic 01" /><br /><br />
							</div>
							<header>
								<h3>Áraink<br /> a legjobbak lehetnek</h3><br />
							</header>
							<p>Minden esetben egyedi árad adunk.
								<br />Szakembereink mérik fel azokat a feladatokat,
								<br />melyek az Ön informatikai rendszerének
								<br />megbízható működéséhez szükségesek.
								<br />Az elvégzendő feladatokhoz számítjuk árainkat,
								<br />a részletes feladatleírás után egyeztetünk.
							</p>
							<footer><br>
								<a href="#Kapcsolat" class="button">Tudjon meg többet</a>
							</footer>
						</article>
						<article>
							<div class="image round">
								<img src="../images/ora.png" alt="Pic 02" /><br /><br />
							</div>
							<header>
								<h3>Feladatvégzés<br /> rövid határidőkkel</h3><br />
							</header>
							<p>Szerződéses partnereinket kiemelt kezeljük.
								<br />Kirendelt szakemberünk folyamatosan elérhető,
								<br />a hibabejelentés után azonnal elkezdi
								<br />a hiba felderítését, elhárítását.
								<br />A kiadott, megrendelt feladatok elvégzésének
								<br />tervezése, illetve a végrehajtás azonnal megkezdődik.
							</p>
							<footer><br>
								<a href="#Kapcsolat" class="button">Tudjon meg többet</a>
							</footer>
						</article>
					</div>
				</div>
			</section>


			<section>
			<p style="text-align:center;color:red;">
				Áraink tájékoztató jellegűek, minden ajánlat egyedileg készül a megrendelő igényei szerint.
			</p>
			<div id="pricing-table" class="clear">
			<div class="plan">
				<h3>Cég<span>50.000,-</span></h3>
				<a class="signup" href="Kapcsolat">Kérjen ajánlatot</a>         
				<ul>
					<li>Teljeskörű felügyelet</li>
					<li>0-24 órás elérhetőség</li>
					<li>Egyéni kapcsolattartó</li>
					<li>Azzonali hibaelhárítás</li>
					<li>Forint / hó</li>		
				</ul> 
			</div>
			<div class="plan" id="most-popular">
				<h3>Profi<span>30.000,-</span></h3>
				<a class="signup" href="Kapcsolat">Kérjen ajánlatot</a>        
				<ul>
					<li>Teljeskörű felügyelet</li>
					<li>Munkaidőben elérhetőség</li>
					<li>Egyéni kapcsolattartó</li>
					<li>Azonnali hibaelhárítás</li>
					<li>Forint / hó</li>					
				</ul>    
			</div>
			<div class="plan">
				<h3>Iroda<span>20.000,-</span></h3>
				<a class="signup" href="Kapcsolat">Kérjen ajánlatot</a>
				<ul>
						<li>Korlátozott felügyelet</li>
					<li>Munkaidőben elérhetőség</li>
					<li>Elérhető szakember</li>
					<li>Hibaelhárítás munkaidőben</li>
					<li>Forint / hó</li>		
				</ul>
			</div>
			<div class="plan">
				<h3>Alap<span>10.000,-</span></h3>
				<a class="signup" href="Kapcsolat">Kérjen ajánlatot</a>		
				<ul>
					<li>Tanácsadás</li>
					<li>Munkaidőben elérhetőség</li>
					<li>Elérhető szakember</li>
					<li>Hibaelhárítás munkaidőben</li>			
					<li>Forint / hó</li>		
				</ul>
			</div>
			</div>
			</section>
    

		<!-- Footer -->
			<div id="Kapcsolat"></div>
			<footer id="footer">
				<div class="inner">
					<img src="../images/email.png"><br /><br />
					<h3>Keressen minket</h3>
					<p>
						Kérjen egyedi árajánlatot. Szakembereink az Ön igényeihez mérten határozzák meg a
						feladatokat, ennek alapján adnak ajánlatot.<br /><br />
						A jelölt (*) mezőket kötelező kitölteni.
					</p>
					<br /><br /><br />
					<form id="kapcsolat" action="" method="get" accept-charset="UTF-8">

						<div class="field half first">
							<label for="name">Név *</label><br />
							<input name="fname" id="fname" type="text" placeholder="Név">
						</div>
						<div class="field half">
							<label for="email">E-mail cím *</label><br />
							<input name="email" id="email" type="email" placeholder="E-mail">
						</div>
						<div class="field">
							<label for="message">Üzenet *</label><br />
							<textarea name="message" id="message" rows="6" placeholder="Üzenet"></textarea>
						</div>
						<?php form_protect($k1,$k2,$k3) ?>
						<div class="field">
							<label for="kell">Ellenőrzés * - Adja meg a két szám összegét: <?php echo("$k1 és $k2"); ?></label><br />
							<input name="kell" id="kell" type="text" placeholder="Ellenőrző szám">
						</div>
						<input name="kell2" id="kell2" type="hidden" value="<?php echo("$k3"); ?>" >
						<ul class="actions">
							<li><input value="Küldés" class="button alt" type="submit"></li>
						</ul>
					</form>
				
					<br /><br /><br />
					<div class="copyright"><br /><br /><br />

			<div class="copyright"><br /><br /><br />

			<img src="../images/webstarthely_logo.png"><br />
			<?php echo("$COPYRIGHT $PORTAL_NAME - $PORTAL_DEV") ?> <br /><br />
			</div>
			</footer>


	<?php
		$code=formdata_to_mail();
		if (strlen($code)>1){
			echo("<div class=modal id=modal-one aria-hidden=true>");
			echo("<div class=modal-dialog>");
			echo("	<div class=modal-header>");
			echo("		<h2>Üzenet</h2>");
			echo("		<a href=index.php class=btn-close aria-hidden=true>×</a>");
			echo("	</div>");
			echo("	<div class=modal-body>");
			echo("		<p>Köszönjük üzenetét. Hamarosan jelentkezünk...</p>");
			echo("	</div>");
			echo("	<div class=modal-footer> <a href=index.php class=btn>Bezár</a>");
			echo("	</div>");
			echo("</div>");
			echo("</div>");
		}
	?>
	</body>
</html>
