<?php

  // w_robot --- PHP portalrobot
  // (verzioadatok a konfiguracios fajlban)
  //
  // fejleszto: InalR Fejlesztoi Iroda


  global $enable_message,$smtp_timeout;

  $enable_message=false;
  $smtp_timeout=10;


  function  smtp_message_enable(){
    global $enable_message;

    $enable_message=true;
  }


  function smtp_server_wait($socket,$code){
    global $enable_message;

    $serverstring="";
    while (substr($serverstring,0,3)!=$code){
      $serverstring=@fgets($socket,256);
      if ($enable_message){
        echo("$serverstring<br />");
      }
    }
  }


  function smtp_mail_send($user,$pass,$host,$port,$from,$to,$cc,$bcc,$sub,$mess,$headers){
    $from=trim($from,"<>");
    $to=trim($to,"<>");
    $cc=trim($cc,"<>");
    $bcc=trim($bcc,"<>");
    $rec1=explode(',',$to);
    $rec2=explode(',',$cc);
    $rec3=explode(',',$bcc);
    $ready=false;
    $ready=smtp_communication($host,$port,$user,$pass,$from,$rec1,$sub,$mess,$headers);
    if ($cc<>""){
      $ready=smtp_communication($host,$port,$user,$pass,$from,$rec2,$sub,$mess,$headers);
    }
    if ($bcc<>""){
      $em=array();
      foreach ($rec3 as $email){
        $em[0]=$email;
        $ready=smtp_communication($host,$port,$user,$pass,$from,$em,$sub,$mess,$headers);
      }
    }
    return($ready);
  }


  function smtp_communication($host,$port,$user,$pass,$from,$rec,$sub,$mess,$headers){
    global $enable_message,$smtp_timeout;

    $ready=false;
    if (!($socket=fsockopen($host,$port,$errno,$errstr,15))){
      if ($enable_message){
        echo("$host ($errno) ($errstr)<br />");
      }
    }else{
      socket_set_timeout($socket,$smtp_timeout);
      smtp_server_wait($socket,"220",false);
      fwrite($socket,"EHLO ".$host."\r\n");
      smtp_server_wait($socket,"250",false);
      if ($user<>""){
        fwrite($socket,"AUTH LOGIN \r\n");
        smtp_server_wait($socket, "334");
        fwrite($socket,base64_encode($user)."\r\n");
        smtp_server_wait($socket,"334");
        fwrite($socket,base64_encode($pass)."\r\n");
        smtp_server_wait($socket,"235");
      }
      fwrite($socket,"MAIL FROM: <".$from."> \r\n");
      smtp_server_wait($socket,"250",false);
      foreach ($rec as $email){
        fwrite($socket,"RCPT TO: <".$email."> \r\n");
        //fwrite($socket,"RCPT TO: <".$to."> \r\n");
        smtp_server_wait($socket,"250",false);
      }
      fwrite($socket,"DATA \r\n");
      smtp_server_wait($socket,"354",true);
      fwrite($socket,"Subject: $sub\r\nTo: <".implode('>, <', $rec).'>'."\r\n$headers\r\n\r\n$mess\r\n");
      fwrite($socket,".\r\n");
      smtp_server_wait($socket,"250",false);
      fwrite($socket,"QUIT \r\n");
      fclose($socket);
      $ready=true;
    }
    return($ready);
  }



  function smtp_mail_send_nobcc($user,$pass,$ser,$port,$from,$to,$subject,$message,$headers){
    global $enable_message,$smtp_timeout;

    $recipients=explode(',',$to);
    $user="";
    $pass=$pass;
    $smtp_host=$ser;
    $ready=false;
    $smtp_port=$port;
    if (!($socket=fsockopen($smtp_host,$smtp_port,$errno,$errstr,15))){
      if ($enable_message){
        echo("$smtp_host ($errno) ($errstr)<br />");
      }
    }else{
      socket_set_timeout($socket,$smtp_timeout);
      smtp_server_wait($socket,"220",false);
      fwrite($socket,"EHLO ".$smtp_host."\r\n");
      smtp_server_wait($socket,"250",false);
      if ($user<>""){
        fwrite($socket,"AUTH LOGIN \r\n");
        smtp_server_wait($socket, "334");
        fwrite($socket,base64_encode($user)."\r\n");
        smtp_server_wait($socket,"334");
        fwrite($socket,base64_encode($pass)."\r\n");
        smtp_server_wait($socket,"235");
      }
      fwrite($socket,"MAIL FROM: $from \r\n");
      smtp_server_wait($socket,"250",false);
      foreach ($recipients as $email){
        fwrite($socket,"RCPT TO: <".$email."> \r\n");
        //fwrite($socket,"RCPT TO: <".$to."> \r\n");
        smtp_server_wait($socket,"250",false);
      }
      fwrite($socket,"DATA \r\n");
      smtp_server_wait($socket,"354",true);
      fwrite($socket,"Subject: $subject\r\nTo: <".implode('>, <', $recipients).'>'."\r\n$headers\r\n\r\n$message\r\n");
      fwrite($socket,".\r\n");
      smtp_server_wait($socket,"250",false);
      fwrite($socket,"QUIT \r\n");
      fclose($socket);
      $ready=true;
    }
    return($ready);
  }

?>
