<?php

  // w_robot --- PHP portalrobot
  // (verzioadatok a konfiguracios fajlban)
  //
  // fejleszto: InalR Fejlesztoi Iroda


  global $sql_server_link,
         $sql_server_error;


  function sql_func_exists(){
    // its need for check this file load
    return true;
  }


  function sql_error_echo($error){
    global $sql_server_error;

    echo("<br />SQL: $error.<br />");
    if ($sql_server_error==""){
      echo("<br />SQL: error.<br />");
    }
    $sql_server_error=$error;
  }


  function sql_server_close(){
    global $sql_server_link;

    mysql_close($sql_server_link);
  }


  function sql_server_open(){
    global $sql_server_link;

    $sql_server_link=false;
  }


  function sql_server_connect($showmessage,$server,$user,$pass,$db){
    global $sql_server_link;

    if (!$sql_server_link){
      $sql_error="";
      $sql_server_link=mysql_connect($server,$user,$pass);
      $sql_error=mysql_error($sql_server_link);
      if (($sql_server_link)and($sql_error=="")){
        if ($db<>""){
          mysql_select_db($db,$sql_server_link);
          $sql_error=mysql_error($sql_server_link);
        }
      }
      if (($sql_error<>"")and($showmessage)){
        sql_error_echo($sql_error);
      }
    }
    return($sql_server_link);
  }


  function sql_server_query($showmessage,$sqllink,$sqlcomm){
    $sql_error="";
    $sqlres=mysql_query($sqlcomm,$sqllink);
    $sql_error=mysql_error($sqllink);
    if (($sql_error<>"")and($showmessage)){
      sql_error_echo($sql_error);
    }
    return($sqlres);
  }


  function sql_connect_close($sqllink){
    if ($sqllink){
      mysql_close($sqllink);
    }
  }


  function sql_run_command($showmessage,$sql_server,$sql_user,$sql_pass,$sql_db,$sql_command){
    $sql_result="";
    $sql_error="";
    $sqllink=sql_server_connect($showmessage,$sql_server,$sql_user,$sql_pass,$sql_db);
    $sql_error=mysql_error($sqllink);
    if ($sql_error==""){
      $sql_result=sql_server_query($showmessage,$sqllink,$sql_command);
      //sql_server_close($sqllink);
    }
    return($sql_result);
  }


  function sql_result_num($res){
    if ($res){
      $d=mysql_num_rows($res);
    }else{
      $d=0;
    }
    return($d);
  }


  function sql_result_fields($res){
    if ($res){
      $d=mysql_num_fields($res);
    }else{
      $d=0;
    }
    return($d);
  }


  function sql_result($res,$s,$o){
    $d="";
    if ($res){
      if (mysql_num_rows($res)>$s){
        $d=mysql_result($res,$s,$o);
      }
    }
    return($d);
  }


  function sql_table_search($showmessage,$server,$user,$pass,$db,$table,$field,$q){
    $sqlres="";
    if (($table<>"")and($field<>"")and($q<>"")){
      $q=trim($q);
      $sqlcommand="select * from $table where $field like '%$q%';";
      $sqlres=sql_run_command($showmessage,$server,$user,$pass,$db,$sqlcommand);
    }
    return($sqlres);
  }


  function sql_result_all($res,$s){
    $d=array();
    if ($res){
      if (mysql_num_rows($res)>$s){
        mysql_data_seek($res,$s);
        $d=mysql_fetch_row($res);
      }
    }
    return($d);
  }


  function sql_delete_alldata_table($showmessage,$server,$user,$pass,$db,$tn){
    if ($tn<>""){
      $sqlcommand="delete from $tn;";
      sql_run_command($showmessage,$server,$user,$pass,$db,$sqlcommand);
    }
  }


  function sql_insert_data_table($showmessage,$server,$user,$pass,$db,$to,$tn){
    if ($tn<>""){
      $c=count($to);
      $v=0;
      $sqlcommand="insert into $tn values(";
      while ($v<$c){
        if ($v>0){
          $sqlcommand=$sqlcommand.",";
        }
        $sqlcommand=$sqlcommand.'"'.$to[$v].'"';
        $v++;
      }
      $sqlcommand=$sqlcommand.");";
      sql_run_command($showmessage,$server,$user,$pass,$db,$sqlcommand);
    }
  }

  function sql_table_insert_data($showmessage,$server,$user,$pass,$db,$table,$data){
    $sqlcommand="insert into $table values (";
    $x=count($data);
    $y=0;
    while($y<$x){
      if ($y<>0){
        $sqlcommand=$sqlcommand.",";
      }
      $sqlcommand=$sqlcommand."\"".$data[$y]."\"";
      $y++;
    }
    $sqlcommand=$sqlcommand.");";
    sql_run_command($showmessage,$server,$user,$pass,$db,$sqlcommand);
  }


  function sql_table_update_data($showmessage,$server,$user,$pass,$db,$table,$data,$rowname,$fname,$where){
    $sqlcommand="update $table set ";
    $x=count($data);
    $y=0;
    while($y<$x){
      if ($y<>0){
        $sqlcommand=$sqlcommand.",";
      }
      $sqlcommand=$sqlcommand."$rowname[$y]=\"".$data[$y]."\"";
      $y++;
    }
    $sqlcommand=$sqlcommand." where $fname=\"$where\";";
    sql_run_command($showmessage,$server,$user,$pass,$db,$sqlcommand);
  }

  function sql_table_delete_data($showmessage,$server,$user,$pass,$db,$table,$field,$data){
    $sqlcommand="delete from $table where $field=\"$data\";";
    sql_run_command($showmessage,$server,$user,$pass,$db,$sqlcommand);
  }


  function sql_table_select($showmessage,$server,$user,$pass,$db,$table,$name,$where,$order,$desc){
    $sqlcommand="select *";
    $sqlcommand=$sqlcommand." from $table ";
    if ($where<>""){
      $sqlcommand=$sqlcommand." where $name=\"$where\" ";
    }
    if ($order<>""){
      $sqlcommand=$sqlcommand." order by $order ";
    }
    if ($desc<>""){
      $sqlcommand=$sqlcommand." desc ";
    }
    $sqlcommand=$sqlcommand.";";
    $sqlresult=sql_run_command($showmessage,$server,$user,$pass,$db,$sqlcommand);
    return($sqlresult);
  }


  function sql_pack_command($showmessage,$server,$user,$pass,$db,$command){
    $x=count($command);
    $y=0;
    while ($y<$x){
      $sqlresult[$y]=$sqlresult[$y].sql_run_command($showmessage,$server,$user,$pass,$db,$command[$y]);
      $y++;
    }
    return($sqlresult);
  }


  function sql_db_create($showmessage,$server,$user,$pass,$db,$mess){
    $sqlcommand="create database $db;";
    sql_run_command($showmessage,$server,$user,$pass,"",$sqlcommand);
  }


  function sql_table_create($showmessage,$server,$user,$pass,$db,$tname,$tabledata,$tablevar,$mess){
    $sqlcommand="create table $tname (";
    $x=count($tabledata);
    $y=0;
    while ($y<$x){
      $sqlcommand=$sqlcommand."$tabledata[$y] $tablevar[$y], ";
      $y++;
    }
    $sqlcommand=$sqlcommand." unique ($tabledata[0])";
    $sqlcommand=$sqlcommand.");";
    sql_run_command($showmessage,$server,$user,$pass,$db,$sqlcommand);
  }


  function sql_db_delete($showmessage,$server,$user,$pass,$db,$mess){
    $sqlcommand="drop database $db;";
    sql_run_command($showmessage,$server,$user,$pass,"",$sqlcommand);
  }


  function sql_table_delete($showmessage,$server,$user,$pass,$db,$tname,$mess){
    $sqlcommand="drop table $tname;";
    sql_run_command($showmessage,$server,$user,$pass,$db,$sqlcommand);
  }


?>
