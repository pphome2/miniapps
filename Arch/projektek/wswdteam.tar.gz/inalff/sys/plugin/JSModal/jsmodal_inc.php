<?php

// JSModal plugin --- PHP portalrobot
// (verzioadatok a konfiguracios fajlban)
//
// fejleszto: InalR Fejlesztoi Iroda

// plugin

    $jsmodal_plugin_name="JSModal";

    $jsmodal_lang="";
    $jsmodal_langt=array();
    $jsmodal_css="jsmodal.css";
    $jsmodal_js="jsmodal.js";

    $jsmodal_close_img="i_close.png";
    $jsmodal_left_img="i_left.png";
    $jsmodal_right_img="i_right.png";
    $jsmodal_loading_img="i_loading.gif";

?>
