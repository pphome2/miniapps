
<script language='JavaScript'>

  var akt=1;
  var kitxt="";
  var time;

  function jsmodal_show(){
    scroll(0,0);
    document.getElementById('backgroundpopup').style.display='block';
    document.getElementById('popupwindow').style.display='block';
    document.getElementById('popupwindow').style.opacity='1';
    document.body.style.overflow='hidden';

    document.onmousewheel=function(){gotop();}
    if(document.addEventListener){
      document.addEventListener('DOMMouseScroll', gotop, false);
    }
    document.onkeydown=function(){noarrow()};
  }


  function jsmodal_close(){
    document.getElementById('popupwindow').style.display='none';
    document.getElementById('backgroundpopup').style.display='none';
    document.body.style.overflow='auto';

    document.onkeydown=null;
    document.onmousewheel=null;
    if(document.addEventListener){
      document.removeEventListener('DOMMouseScroll', gotop, false);
    }
  }


  function jsmodal_ishow(){
    scroll(0,0);
    document.getElementById('ibackground').style.display='block';
    document.getElementById('ipopupwin').style.display='block';
    document.getElementById('ipopupwin').style.opacity='1';
    document.body.style.overflow='hidden';

    document.onmousewheel=function(){gotop();}
    if(document.addEventListener){
      document.addEventListener('DOMMouseScroll', gotop, false);
    }
    document.onkeydown=function(){noarrow()};
  }


  function jsmodal_iclose(){
    document.getElementById('ipopupwin').style.display='none';
    document.getElementById('ibackground').style.display='none';
    document.body.style.overflow='auto';

    document.onkeydown=null;
    document.onmousewheel=null;
    if(document.addEventListener){
      document.removeEventListener('DOMMouseScroll', gotop, false);
    }
  }


  function jsmodal_grefresh(imgs){
    document.getElementById('gimgdesc').innerHTML=kitxt;
    clearTimeout(time);
  }


  function jsmodal_gleft(){
    jsmodal_gstep(-1);
  }


  function jsmodal_gright(){
    jsmodal_gstep(1);
  }


  function jsmodal_gshow(){
    scroll(0,0);
    document.getElementById('gbackground').style.display='block';
    document.getElementById('gpopupwin').style.display='block';
    document.body.style.overflow='hidden';

    document.onmousewheel=function(){gotop();}
    if(document.addEventListener){
      document.addEventListener('DOMMouseScroll', gotop, false);
    }
    document.onkeydown=function(){noarrow()};
    jsmodal_gstep(0);
  }


  function jsmodal_gstep(istep){
    var ibox=document.getElementById('imgbox').childNodes;
    var x=ibox.length;
    var ib=akt-1;
    var ez=akt+istep;
    if (ez>x){
      ez=1;
    }
    if (ez<1){
      ez=x;
    }
    akt=ez;
    ib=ez-1;
    document.getElementById('gjsimgclass').src=ibox[ib].innerHTML;
    document.getElementById('gjsimgclass').onload=function(){
      time=setTimeout('jsmodal_grefresh()',10);
    };
    var ki=akt+" / "+x;
    document.getElementById('headtext').innerHTML=ki;
    kitxt=ibox[ib].getAttribute('alt');
  }


  function jsmodal_gclose(){
    document.getElementById('gpopupwin').style.display='none';
    document.getElementById('gbackground').style.display='none';
    document.body.style.overflow='auto';

    document.onkeydown=null;
    document.onmousewheel=null;
    if(document.addEventListener){
      document.removeEventListener('DOMMouseScroll', gotop, false);
    }
  }


  function noarrow(){
    scroll(0,0);
    return (event.keyCode!=38 && event.keyCode!=40 && event.keyCode!=37 && event.keyCode!=39);
  }


  function gotop(e){
    scroll(0,0);
    e.returnValue=false;
  }

</script>
