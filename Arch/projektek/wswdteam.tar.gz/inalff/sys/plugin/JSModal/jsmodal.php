<?php

// JSModal plugin --- PHP portalrobot
// (verzioadatok a konfiguracios fajlban)
//
// fejleszto: InalR Fejlesztoi Iroda

// plugin


  function jsmodal_gallery($button,$imgdir){
    global $dir_plugin,
           $jsmodal_plugin_name,
           $jsmodal_lang,
           $jsmodal_langt,
           $jsmodal_close_img,
           $jsmodal_left_img,
           $jsmodal_right_img,
           $jsmodal_loading_img,
           $lang_system,
           $dir_plugin,
           $dir_img,
           $dir_site,
           $default_site,
           $list_img_ext,
           $text_ext,
           $plugin_return_embed_line;

    jsmodal_init();
    $imgout="$dir_site/$default_site/$dir_img/$imgdir";
    $dirt=array();
    sys_dir_list($imgout,$dirt);
    $oktxt=false;
    $c=count($dirt);
    $l=0;
    while (($l<$c)and(!$oktxt)){
      $ext=substr($dirt[$l],strlen($dirt[$l])-4,4);
      if ($ext==$text_ext){
        $f=$imgout."/".$dirt[$l];
        if (file_exists($f)){
          sys_file_in($f,$txt);
          $oktxt=true;
        }
      }
      $l++;
    }
    sort($dirt);
    //echo("<button class='ijsbutton_1' id='button1' onclick='jsmodal_ishow()'>$button</button>");
    $plugin_return_embed_line="<a href='#top' class='jshref' id='button1' onclick='jsmodal_gshow()'> $button </a>";
    $plugin_return_embed_line=$plugin_return_embed_line."<div id='gpopupwin' class='gpopupwin'>";
    $plugin_return_embed_line=$plugin_return_embed_line."<div class='gpopupdesc'>";
    $plugin_return_embed_line=$plugin_return_embed_line."<div class='garrow_img1' id='atext1' >";
    $plugin_return_embed_line=$plugin_return_embed_line." <img src='$jsmodal_left_img' onclick='jsmodal_gleft()'> ";
    $plugin_return_embed_line=$plugin_return_embed_line."</div>";
    $plugin_return_embed_line=$plugin_return_embed_line."<div class='garrow_img2' id='atext2' >";
    $plugin_return_embed_line=$plugin_return_embed_line." <img src='$jsmodal_right_img' onclick='jsmodal_gright()'> ";
    $plugin_return_embed_line=$plugin_return_embed_line."</div>";
    $plugin_return_embed_line=$plugin_return_embed_line."<label class='ghead_line' id='headtext' ></label>";
    $plugin_return_embed_line=$plugin_return_embed_line."<div class='gclose_img' id='itext' onclick='jsmodal_gclose()'><img src='$jsmodal_close_img'></div>";
    $plugin_return_embed_line=$plugin_return_embed_line."<br /><br />";
    $plugin_return_embed_line=$plugin_return_embed_line."<div id='gjsimgwin' class='gjsimgwin'>";
    $plugin_return_embed_line=$plugin_return_embed_line."<img class='gjsimgclass' id='gjsimgclass' src='' alt=''>";
    $plugin_return_embed_line=$plugin_return_embed_line."</div>";
    $plugin_return_embed_line=$plugin_return_embed_line."<div id='imgbox' class='gjsimgbox'>";
    $x=0;
    $kitett=0;
    $j=count($txt);
    $c=count($dirt);
    while ($x<$c){
      $d="d".$x+1;
      $kiimg="$imgout/$dirt[$x]";
      $ext=substr($dirt[$x],strlen($dirt[$x])-4,4);
      if (in_array($ext,$list_img_ext)){
        //$plugin_return_embed_line=$plugin_return_embed_line."<div id='$d' class='gjsimgbox'><img class='gjsimgclass' src='$kiimg'></div>";
        if ($oktxt){
          $i=0;
          $kalt="";
          $besor=false;
          while (($i<$j)and(!$besor)){
            $d=substr($txt[$i],0,strlen($dirt[$x]));
            if ($d==$dirt[$x]){
              $besor=true;
              $kalt=substr($txt[$i],strlen($dirt[$x])+1,strlen($txt[$i]));
            }
            $i++;
          }
        }
        $plugin_return_embed_line=$plugin_return_embed_line."<label class='gjsimglabel' id='gjsimglabel' alt='$kalt'>$kiimg</label>";
        $kitett++;
      }
      $x++;
    }
    $plugin_return_embed_line=$plugin_return_embed_line."</div>";
    $plugin_return_embed_line=$plugin_return_embed_line."<label id='gimgdesc' class='gimgdesc'>";
    $plugin_return_embed_line=$plugin_return_embed_line."</label>";
    $plugin_return_embed_line=$plugin_return_embed_line."</div></div>";
    $plugin_return_embed_line=$plugin_return_embed_line."<div id='gbackground' class='gbackground'></div>";
  }


  function jsmodal_image($button,$imgfile){
    global $dir_plugin,
           $jsmodal_plugin_name,
           $jsmodal_lang,
           $jsmodal_langt,
           $jsmodal_close_img,
           $jsmodal_left_img,
           $jsmodal_right_img,
           $jsmodal_loading_img,
           $lang_system,
           $dir_plugin,
           $dir_img,
           $dir_site,
           $default_site,
           $plugin_return_embed_line;

    jsmodal_init();
    $imgout="$dir_site/$default_site/$dir_img/$imgfile";
    //echo("<button class='ijsbutton_1' id='button1' onclick='jsmodal_ishow()'>$button</button>");
    $plugin_return_embed_line="<a href='#top' class='jshref' id='button1' onclick='jsmodal_ishow()'> $button </a>";
    $plugin_return_embed_line=$plugin_return_embed_line."<div id='ipopupwin' class='ipopupwin'>";
    $plugin_return_embed_line=$plugin_return_embed_line."<div class='ipopupdesc'>";
    $plugin_return_embed_line=$plugin_return_embed_line."<label class='iclose_img' id='itext' onclick='jsmodal_iclose()'><img src='$jsmodal_close_img'></label>";
    $plugin_return_embed_line=$plugin_return_embed_line."<br /><br />";
    $plugin_return_embed_line=$plugin_return_embed_line."<div class='ijsimgbox'><img class='ijsimgclass' src='$imgout'></div>";
    $plugin_return_embed_line=$plugin_return_embed_line."</div></div>";
    $plugin_return_embed_line=$plugin_return_embed_line."<div id='ibackground' class='ibackground'></div>";
  }


  function jsmodal_open($button){
    global $dir_plugin,
           $jsmodal_plugin_name,
           $jsmodal_lang,
           $jsmodal_langt,
           $jsmodal_close_img,
           $jsmodal_left_img,
           $jsmodal_right_img,
           $jsmodal_loading_img,
           $lang_system,
           $dir_plugin,
           $plugin_return_embed_line;

    jsmodal_init();
    echo("<a href='#top' class='jshref' id='button1' onclick='jsmodal_show()'> $button </a>");
    $plugin_return_embed_line=$plugin_return_embed_line."<div id='popupwindow' class='popupwindow'>";
    $plugin_return_embed_line=$plugin_return_embed_line."<div class='popupdesc'>";
    $plugin_return_embed_line=$plugin_return_embed_line."<label class='close_img' id='text' onclick='jsmodal_close()'> <img src='$jsmodal_close_img'> </label>";
    $plugin_return_embed_line=$plugin_return_embed_line."<br /><br />";
  }


  function jsmodal_close(){
    global $plugin_return_embed_line;

    $plugin_return_embed_line=$plugin_return_embed_line."</div>";
    $plugin_return_embed_line=$plugin_return_embed_line."</div>";
    $plugin_return_embed_line=$plugin_return_embed_line."<div id='backgroundpopup' class='backgroundpopup'></div>";
  }


  function jsmodal_teszt(){
    global $dir_plugin,
           $jsmodal_plugin_name,
           $jsmodal_lang,
           $jsmodal_langt,
           $jsmodal_close_img,
           $jsmodal_left_img,
           $jsmodal_right_img,
           $jsmodal_loading_img,
           $lang_system,
           $dir_plugin;

    jsmodal_init();
    echo("<div id='backgroundpopup' class='backgroundpopup' onscroll='jsmodal_noscroll()'>");
    echo("<div id='popupwindow' class='popupwindow'>");
    echo("<div class='popupdesc'>");
    $img_file="$dir_plugin/$jsmodal_plugin_name/$jsmodal_close_img";
    echo("<label class='close_img' id='text' onclick='jsmodal_close()'><img src=$jsmodal_close_img></label>");
    echo("<br /><br />kiir�s sokf  sdgr awet erh h g gggtrh wrh eh srth dh m");
    echo("</div>");
    echo("</div>");
    echo("</div>");
    echo("<label id='testtext' onclick='jsmodal_show()'>Ablak nyit�sa</label>");
  }


  function jsmodal_init(){
    global $dir_plugin,
           $jsmodal_plugin_name,
           $jsmodal_lang,
           $jsmodal_langt,
           $jsmodal_css,
           $jsmodal_js,
           $jsmodal_close_img,
           $jsmodal_left_img,
           $jsmodal_right_img,
           $jsmodal_loading_img,
           $lang_system;

    if ($jsmodal_lang==""){
      $jsmodal_plugin_name="JSModal";
      $inc_file="$dir_plugin/$jsmodal_plugin_name/jsmodal_inc.php";
      if (file_exists($inc_file)){
        include("$inc_file");
      }
      $js_file="$dir_plugin/$jsmodal_plugin_name/$jsmodal_js";
      if (file_exists($js_file)){
        include("$js_file");
      }
      $style_file="$dir_plugin/$jsmodal_plugin_name/$jsmodal_css";
      sys_style("$style_file");
      $jsmodal_lang="$dir_plugin/$jsmodal_plugin_name/lang_$lang_system";
      $jsmodal_close_img="$dir_plugin/$jsmodal_plugin_name/$jsmodal_close_img";
      $jsmodal_left_img="$dir_plugin/$jsmodal_plugin_name/$jsmodal_left_img";
      $jsmodal_right_img="$dir_plugin/$jsmodal_plugin_name/$jsmodal_right_img";
      $jsmodal_loading_img="$dir_plugin/$jsmodal_plugin_name/$jsmodal_loading_img";
    }
  }

  // plugins close

  function jsmodal_end(){
  }


?>
