<?php

// Recapctha plugin --- PHP portalrobot
// (verzioadatok a konfiguracios fajlban)
//
// fejleszto: InalR Fejlesztoi Iroda

// plugin




  function rc_key(){
    global $server_public_key,$server_private_key;

    $server_public_key="6Lfj5s0SAAAAALPlLsc96GkcKB940UotI0ax0kb3";
    $server_private_key="6Lfj5s0SAAAAAPq-k7DQcrDM2jxMAfD1QiRGAraW";
  }


  function rc_form($gomb){
    global $s_program,$server_public_key,$server_private_key;

    rc_key();
    $ready=false;
    $ok=sys_data_post($dbx,$tkx,$tex);
    if ($ok){
      $ready=rc_verify($tex[0],$tex[1]);
    }
    if (!$ready){
      $e=sys_env_pack();
      echo("<center>");
      echo("<form method='post' action='./$s_program?$e'>");

      rc_noform($server_public_key);
      echo("<br />");

      if ($gomb==""){
        $gomb="...";
      }
      echo("<button class='button_1' type='submit' id='b7' name='b7' value='$gomb'>$gomb</button>");
      echo("</form>");
      echo("</center>");
    }
    return($ready);
  }


  function rc_verify($cha,$res){
    global $server_private_key;

    rc_key();
    $ready=false;
    $ok=sys_data_post($dbx,$tkx,$tex);
    if ($ok){
      $rip=$_SERVER['REMOTE_ADDR'];
      $data="privatekey=$server_private_key&";
      $data.="remoteip=$rip&";
      $data.="challenge=$cha&";
      $data.="response=$res";
      $params=array('http'=>array(
                              'method'=>'POST',
                              'header'=>'Content-Type: application/x-www-form-urlencoded;\n\r',
                              'content'=>$data
                              )
              );
      $ctx=stream_context_create($params);
      $file=file_get_contents('http://www.google.com/recaptcha/api/verify',false,$ctx);
      $fi=substr($file,0,4);
      if ($fi=="true"){
        $ready=true;
      }else{
      }
    }
    return($ready);
  }


  function rc_noform(){
    global $server_public_key;

    rc_key();
    echo("<script type='text/javascript'>");
    echo("var RecaptchaOptions = {");
    echo("    theme : 'clean'");
    echo("    };");
    echo("</script>");
    echo("<script type='text/javascript'");
    echo("  src='http://www.google.com/recaptcha/api/challenge?k=$server_public_key'>");
    echo("</script>");
    echo("<noscript>");
    echo("<iframe src='http://www.google.com/recaptcha/api/noscript?k=$server_public_key'");
    echo("  height='300' width='500' frameborder='0'></iframe><br>");
    echo("<textarea name='recaptcha_challenge_field' rows='3' cols='40'>");
    echo("</textarea>");
    echo("<input type='hidden' name='recaptcha_response_field'");
    echo("value='manual_challenge'>");
    echo("</noscript>");
  }


  function rc_init(){
  }

  // plugins close

  function rc_end(){
  }


?>
