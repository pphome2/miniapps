<?php

// SDownload plugin --- PHP portalrobot
// (verzioadatok a konfiguracios fajlban)
//
// fejleszto: InalR Fejlesztoi Iroda

// plugin

    $sd_plugin_name="SDownload";

    $sd_lang="";
    $sd_langt=array();
    $sd_list_db=2;
    $sd_css="sd.css";
    $sd_file_dir="files";
    $sd_download_link_live=36000;
    $sd_admin_users=array();

?>
