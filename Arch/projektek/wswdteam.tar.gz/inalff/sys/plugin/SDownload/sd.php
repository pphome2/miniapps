<?php

// SDownload plugin --- PHP portalrobot
// (verzioadatok a konfiguracios fajlban)
//
// fejleszto: InalR Fejlesztoi Iroda

// plugin



  function sd(){
    global $sd_langt,
           $user_admin,
           $dir_plugin,
           $sd_lang,
           $lang_system,
           $sd_list_db,
           $sd_file_dir,
           $sd_download_link_live,
           $sd_plugin_name,
           $sd_admin_users,
           $s_program,
           $delkod,
           $deldata,
           $usercode,
           $sd_load,
           $messpage,
           $mess_per_page,
           $mess_akt_page;

    if (!isset($sd_load)){
      $sd_plugin_name="SDownload";
      $inc_file="$dir_plugin/$sd_plugin_name/sd_inc.php";
      include("$inc_file");

      $sd_lang="$dir_plugin/$sd_plugin_name/lang_$lang_system";
    }else{
      $sd_load=true;
    }
    $sd_css="$dir_plugin/$sd_plugin_name/$sd_css";
    sys_style($sd_css);
    $filedir="$dir_plugin/$sd_plugin_name/$sd_file_dir";
    $uc=sys_env_find($usercode);
    $uname=site_user($uc);

    if ($delkod<>""){
      $fnme=$filedir."/".sys_unstandard_name($delkod);
      $ki=sys_line("F�jl t�r�lve",$sd_lang,$sd_langt,$sd_lang_db);
      echo("$ki: $fnme.<br /><br />");
      sys_file_del($fnme);
      echo("<br /><br />");
    }

    $dload=false;
    $ok=sys_data_post($dbx,$tkx,$tex);
    if ($ok){
      if ($dbx<2){
        if (!sys_file_upload($filedir)){
          $ki=sys_line("F�jl felt�lt�se nem siker�lt",$sd_lang,$sd_langt,$sd_lang_db);
          echo("$ki.<br /><br />");
        }
      }else{
        $jo=rc_verify($tex[1],$tex[2]);
        if ($jo){
          $dload=true;
        }
      }
    }

    if ($dload){
      $t=sys_time_code();
      $ujdir="$filedir/$t";
      sys_mkdir($ujdir);
      sys_file_link("$filedir/$tex[0]","$ujdir/$tex[0]");
      $ki=sys_line("A k�rt f�jlhoz tartoz� link l�trej�tt",$sd_lang,$sd_langt,$sd_lang_db);
      $ki2=sys_line("indulhat a let�lt�s",$sd_lang,$sd_langt,$sd_lang_db);
      echo("<br /><br />$ki: ");
      echo("<a class='href' href='$ujdir/$tex[0]'>$ki2</a>.");
      $ora=$sd_download_link_live/60/60;
      $ki=sys_line("A link a k�vetkez�",$sd_lang,$sd_langt,$sd_lang_db);
      $ki2=sys_line("�r�ban �l",$sd_lang,$sd_langt,$sd_lang_db);
      echo("<br /><br />$ki $ora $ki2.");
    }else{
      if (($user_admin)or(in_array($uname,$sd_admin_users))){
        $e=sys_env_pack();
        echo("<center>");
        echo("<form method='post' enctype='multipart/form-data' action='./$s_program?$e'>");
        $ki=sys_line("F�jl felt�lt�se",$sd_lang,$sd_langt,$sd_lang_db);
        echo("<div class='div_r1'>$ki: </div>");
        echo("<input class='input_f1' type='file' id='userfile' name='userfile' size='40' /><br /><br />");
        $ki=sys_line("Mehet",$sd_lang,$sd_langt,$sd_lang_db);
        echo("<button class='button_1' type='submit' id='b01' name='b01' value='$ki'>$ki</button>");
        echo("</form>");
        echo("</center><br /><br />");
      }

      $ft=array();
      sys_dir_list($filedir,$ft);
      $filedb=count($ft);
      $fdb=0;
      $x=0;
      while ($x<$filedb){
        if (is_dir("$filedir/$ft[$x]")){
          $now=time();
          $dfc=$now-substr($ft[$x],0,strlen($ft[$x])-8);
          if ($dfc>$sd_download_link_live){
            $fnevek=array();
            sys_dir_list("$filedir/$ft[$x]",$fnevek);
            $cc=0;
            $ccc=count($fnevek);
            while ($cc<$ccc){
              sys_file_del("$filedir/$ft[$x]/$fnevek[$cc]");
              $cc++;
            }
            sys_file_del("$filedir/$ft[$x]");
          }
        }else{
          $fdb++;
        }
        $x++;
      }
      if ($fdb>0){
        echo("<br /><br /><center>");
        echo("<form method='post' enctype='multipart/form-data' action='./$s_program?$e'>");
        //$ki=sys_line("Let�ltend� f�jl",$sd_lang,$sd_langt,$sd_lang_db);
        //echo("<div class='div_r1'>$ki: </div><br /><br />");
        //$ki=sys_line("Felt�ltve",$sd_lang,$sd_langt,$sd_lang_db);
        //echo("<div class='div_r1'>$ki: </div><br /><br />");
        $tol=($mess_akt_page-1)*$sd_list_db;
        if ($tol<0){
          $tol=0;
        }
        if ($tol>=$fdb){
          $mess_akt_page-=1;
          $tol=($mess_akt_page-1)*$sd_list_db;
          if ($tol<0){
            $tol=0;
          }
        }
        echo("<div class='sd_input_field'>");
        $ki=sys_line("F�jl neve",$sd_lang,$sd_langt,$sd_lang_db);
        echo("<div class='sd_div_fr2'>$ki");
        echo("</div>");
        $ki=sys_line("Felt�lt�s d�tuma",$sd_lang,$sd_langt,$sd_lang_db);
        echo("<div class='sd_div_fr1'>$ki</div>");
        $ki=sys_line("Kijel�l�s",$sd_lang,$sd_langt,$sd_lang_db);
        echo("<div class='sd_div_fr3'>$ki</div> ");
        echo("</div>");
        $x=0;
        $kidb=0;
        $irt=0;
        while ($x<$filedb){
          if (is_dir("$filedir/$ft[$x]")){
          }else{
            $kidb++;
            if (($kidb>$tol)and($kidb<=$tol+$sd_list_db)){
              echo("<div class='sd_input_field'>");
              $fdate=date("Y.m.d. H:i",filemtime("$filedir/$ft[$x]"));
              echo("<div class='sd_div_r2'>$ft[$x]");
              if (($user_admin)or(in_array($uname,$sd_admin_users))){
                $ki=sys_line("F�jl t�rl�se",$sd_lang,$sd_langt,$sd_lang_db);
                $fnme=sys_standard_name($ft[$x]);
                sys_env_new($deldata,$fnme);
                $e=sys_env_pack();
                echo(" - <a class='href' href='$s_program?$e'>$ki</a>");
                sys_env_del($deldata);
              }
              echo("</div>");
              echo("<div class='sd_div_r3'><input class='sd_radio_r1' type='radio' id='ufile' name='ufile' size='2' value='$ft[$x]' ");
              if ($irt==0){
                echo("checked=checked ");
                $irt++;
              }
              echo("/></div>");
              echo("<div class='sd_div_r1'>$fdate</div>");
              echo("</div><br />");
            }
          }
          $x++;
        }
        echo("<br /><br />");
        site_pageing($fdb,$sd_list_db,$mess_akt_page,$messpage);
        if ($fdb>$sd_list_db){
          echo("<br /><br />");
        }
        rc_noform();
        echo("<br /><br />");
        $ki=sys_line("Mehet",$sd_lang,$sd_langt,$sd_lang_db);
        echo("<button class='button_1' type='submit' id='b01' name='b01' value='$ki'>$ki</button>");
        echo("</form>");
        $dd=sys_time_code();
        echo("</center><br /><br />");
      }else{
        $ki=sys_line("Nincs let�lthet� f�jl",$sd_lang,$sd_langt,$sd_lang_db);
        echo("$ki.");
        echo("<br /><br />");
      }
    }
  }


  function sd_init(){
    global $dir_plugin,
           $sd_file_dir,
           $sd_download_link_live,
           $sd_plugin_name,
           $sd_load;

    if (!isset($sd_load)){
      $sd_plugin_name="SDownload";
      $inc_file="$dir_plugin/$sd_plugin_name/sd_inc.php";
      include("$inc_file");
    }else{
      $sd_load=true;
    }
    $filedir="$dir_plugin/$sd_plugin_name/$sd_file_dir";

    $ft=array();
    sys_dir_list($filedir,$ft);
    $filedb=count($ft);
    $x=0;
    while ($x<$filedb){
      if (is_dir("$filedir/$ft[$x]")){
        $now=time();
        $dfc=$now-substr($ft[$x],0,strlen($ft[$x])-8);
        if ($dfc>$sd_download_link_live){
          $fnevek=array();
          sys_dir_list("$filedir/$ft[$x]",$fnevek);
          $cc=0;
          $ccc=count($fnevek);
          while ($cc<$ccc){
            sys_file_del("$filedir/$ft[$x]/$fnevek[$cc]");
            $cc++;
          }
          sys_file_del("$filedir/$ft[$x]");
        }
      }
      $x++;
    }
  }

  // plugins close

  function sd_end(){
  }


?>
