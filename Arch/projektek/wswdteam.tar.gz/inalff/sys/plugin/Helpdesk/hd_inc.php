<?php

// Helpdesk plugin --- PHP portalrobot
// (verzioadatok a konfiguracios fajlban)
//
// fejleszto: InalR Fejlesztoi Iroda

// plugin

    $hd_plugin_name="Helpdesk";

    $sql_hd_name="_hd";
    $sql_hd_n=array('hdcode',
                    'bdate',
                    'uname',
                    'ucim',
                    'utel',
                    'umail',
                    'evendor',
                    'ename',
                    'eserial',
                    'ehardware',
                    'esoftware',
                    'epack',
                    'eerror',
                    'mdate',
                    'mtext',
                    'muser',
                    'mgar',
                    'mwtime',
                    'mkm',
                    'mprice',
                    'mstate'
                    );
    $sql_hd_t=array('varchar (30)',
                    'varchar (30)',
                    'varchar (100)',
                    'varchar (100)',
                    'varchar (100)',
                    'varchar (100)',
                    'varchar (100)',
                    'varchar (100)',
                    'varchar (100)',
                    'text',
                    'text',
                    'text',
                    'text',
                    'varchar (30)',
                    'text',
                    'varchar (100)',
                    'varchar (100)',
                    'varchar (100)',
                    'varchar (100)',
                    'varchar (100)',
                    'varchar (100)'
                    );

    $hd_service_name=array('Nagy Szalonn�s Bt.',
                           '2700, Cegl�d, Kossuth t�r 1/a',
                           '53/323-123, 20/234-8765'
                           );
    $hd_service_man=array('-',
                          'Magyar Istv�n',
                          'Kiss Lajos',
                          'Moln�r B�la'
                          );
    $hd_service_state=array('R�gz�tve, jav�t�s elkezdve',
                            'R�gz�tve, eszk�z �tv�ve',
                            'Szervizesnek �tadva',
                            'Bevizsg�l�s alatt',
                            'Alkatr�szre v�r',
                            'Jav�tott',
                            '�gyf�lre v�r',
                            'Jav�t�s befejezve'
                            );

    $hd_files=array("hd_prn.php","hd_frm.php","hd_usr.php","hd_lst.php");

    $hd_show_userticket=true;
    $hd_lang="";
    $hd_langt=array();
    $hd_menu_start=0;
    $hd_list_db=20;
    $cond_file="$dir_plugin/".$hd_plugin_name."/hd.txt";
    $hd_css="$dir_plugin/".$hd_plugin_name."//hd.css";


?>
