<?php

// Helpdesk plugin --- PHP portalrobot
// (verzioadatok a konfiguracios fajlban)
//
// fejleszto: InalR Fejlesztoi Iroda

// plugin


  function hd_mlap($c,$miez,$kod,$pldata){
    global $newdata,$usercode,$s_program,$sitepos,
           $sql_hd_name,$sql_hd_n,$pluginenv1,$separator,
           $hd_lang,$hd_langt,$hd_lang_db,$hd_service_name,
           $cond_file,$s_program,$sitepage,$k_print,
           $pluginenv1,$printed;


    sys_env_new($sitepos,$c);
    if ($kod==""){
      $tomb=array();
    }else{
      $tx=sql_data_get($sql_hd_name,$sql_hd_n[0],$kod);
      $tomb=sql_get_result_data($tx,0);
    }
    $db=count($tomb);
    if ($db==0){
      $i=0;
      while ($i<25){
        $tomb[$i]="-";
        $i++;
      }
      $tomb[0]=sys_time_code();
      $tomb[1]=date("Y.m.d. H:i");
    }else{
      $i=0;
      while ($i<$db){
        if ($tomb[$i]==""){
          $tomb[$i]="-";
        }
        $i++;
      }
    }
    $d=date("Y.m.d. H:i");
    echo("<br /><br />");
    if (!$printed){
      $sp=sys_env_find($sitepage);
      sys_env_new($sitepage,$k_print);
      sys_env_new($pluginenv1,$pldata);
      $e=sys_env_pack();
      sys_env_new($sitepage,$sp);
      sys_env_del($pluginenv1);
      $ki=sys_line("Nyomtat�s",$hd_lang,$hd_langt,$hd_lang_db);
      echo("<a class='href' href=$s_program?$e>$ki</a>");
      echo("<br /><br />");
      echo("<br /><br />");
    }

    echo("<center><table width=90% border=1>");

    echo("<tr>");
    echo("<td colspan=2 valign=top align=center>");
    echo("<h2><b>$miez</b></h2>");
    echo("</td>");
    echo("</tr>");

    echo("<tr>");
    echo("<td width=30% valign=center>");
    //echo("<br />");
    $c=count($hd_service_name);
    $x=0;
    while ($x<$c){
      if ($x==0){
        echo("<b>$hd_service_name[$x]</b>");
      }else{
        echo("$hd_service_name[$x]");
      }
      echo("<br />");
      $x++;
    }
    $ki=sys_line("D�tum",$hd_lang,$hd_langt,$hd_lang_db);
    echo("</td>");
    echo("<td align=right>$ki: $d<br />");
    $ki=sys_line("Azonos�t�",$hd_lang,$hd_langt,$hd_lang_db);
    echo("$ki: $tomb[0]<br /></td>");
    echo("</tr>");

    echo("<tr>");
    $ki=sys_line("Megrendel�",$hd_lang,$hd_langt,$hd_lang_db);
    echo("<td colspan=2 valign=top><b><br />$ki</b>");
    echo("</td>");
    echo("</tr>");

    echo("<tr>");
    $ki=sys_line("N�v, c�m",$hd_lang,$hd_langt,$hd_lang_db);
    echo("<td width=30% valign=top>$ki:");
    echo("</td>");
    echo("<td align=center>$tomb[2], $tomb[3]");
    echo("</td>");
    echo("</tr>");

    echo("<tr>");
    $ki=sys_line("Telefon, e-mail",$hd_lang,$hd_langt,$hd_lang_db);
    echo("<td width=30% valign=top>$ki:");
    echo("</td>");
    echo("<td align=center>$tomb[4], $tomb[5]");
    echo("</td>");
    echo("</tr>");

    echo("<tr>");
    $ki=sys_line("Eszk�z",$hd_lang,$hd_langt,$hd_lang_db);
    echo("<td colspan=2 valign=top><br /><b>$ki</b>");
    echo("</td>");
    echo("</tr>");

    echo("<tr>");
    $ki=sys_line("Gy�rt�, tipus, gy�ri sz�m",$hd_lang,$hd_langt,$hd_lang_db);
    echo("<td width=30% valign=top>$ki:");
    echo("</td>");
    echo("<td align=center>$tomb[6], $tomb[7], $tomb[8]");
    echo("</td>");
    echo("</tr>");

    echo("<tr>");
    $ki=sys_line("Hardver elemek",$hd_lang,$hd_langt,$hd_lang_db);
    echo("<td width=30% valign=top>$ki:");
    echo("</td>");
    echo("<td align=center>$tomb[9]");
    echo("</td>");
    echo("</tr>");

    echo("<tr>");
    $ki=sys_line("Szoftver elemek",$hd_lang,$hd_langt,$hd_lang_db);
    echo("<td width=30% valign=top>$ki:");
    echo("</td>");
    echo("<td align=center>$tomb[10]");
    echo("</td>");
    echo("</tr>");

    echo("<tr>");
    $ki=sys_line("�tvett tartoz�kok",$hd_lang,$hd_langt,$hd_lang_db);
    echo("<td width=30% valign=top>$ki:");
    echo("</td>");
    echo("<td align=center>$tomb[11]");
    echo("</td>");
    echo("</tr>");

    echo("<tr>");
    $ki=sys_line("Hiba le�r�sa",$hd_lang,$hd_langt,$hd_lang_db);
    echo("<td width=30% valign=top>$ki:");
    echo("</td>");
    echo("<td align=center>$tomb[12]");
    echo("</td>");
    echo("</tr>");

    $ki=sys_line("Munkalap",$hd_lang,$hd_langt,$hd_lang_db);
    if ($miez<>$ki){
      sys_file_in($cond_file,$be);
      echo("<tr>");
      $ki=sys_line("Felt�telek",$hd_lang,$hd_langt,$hd_lang_db);
      echo("<td width=30% valign=top>$ki:");
      echo("</td>");
      echo("<td align=left>");
      echo("<br />");
      $cb=count($be);
      $x=0;
      while ($x<$cb){
        echo(" $be[$x]<br />");
        $x++;
      }
      echo("</td>");
      echo("</tr>");
      $ki=sys_line("A megadott felt�telekkel, a szerv�zben megtekintett",$hd_lang,$hd_langt,$hd_lang_db);
      $ki2=sys_line("�rlista alapj�n a jav�t�st megrendelem",$hd_lang,$hd_langt,$hd_lang_db);

    }else{
      echo("<tr>");
      $ki=sys_line("Megold�s (jav�t�s)",$hd_lang,$hd_langt,$hd_lang_db);
      echo("<td colspan=2 valign=top><br /><b>$ki</b>");
      echo("</td>");
      echo("</tr>");

      echo("<tr>");
      $ki=sys_line("Jav�t�s ideje, jav�t�st v�gezte",$hd_lang,$hd_langt,$hd_lang_db);
      echo("<td width=30% valign=top>$ki:");
      echo("</td>");
      echo("<td align=center>$tomb[14], $tomb[16]");
      echo("</td>");
      echo("</tr>");

      echo("<tr>");
      $ki=sys_line("Jav�t�s le�r�sa",$hd_lang,$hd_langt,$hd_lang_db);
      echo("<td width=30% valign=top>$ki:");
      $ki=sys_line("felhaszn�lt alkatr�szek",$hd_lang,$hd_langt,$hd_lang_db);
      echo("($ki)");
      echo("</td>");
      echo("<td align=center>");
      echo("<br /><br />$tomb[15]<br /><br />");
      echo("</td>");
      echo("</tr>");

      echo("<tr>");
      $ki=sys_line("Jav�t�s k�lt�ge",$hd_lang,$hd_langt,$hd_lang_db);
      echo("<td width=30% valign=top>$ki:");
      $ki=sys_line("munkaid�, kisz�ll�s",$hd_lang,$hd_langt,$hd_lang_db);
      echo("($ki)");
      echo("</td>");
      echo("<td align=center>$tomb[19] ($tomb[17] + $tomb[18])");
      echo("</td>");
      echo("</tr>");
      $ki=sys_line("A jav�tott eszk�zt (a megrendel�skor �tadott",$hd_lang,$hd_langt,$hd_lang_db);
      $ki2=sys_line("tartoz�kokal hi�nytalanul,) m�k�d�k�pesen �tvettem",$hd_lang,$hd_langt,$hd_lang_db);
    }

    echo("<tr>");
    $kim=sys_line("Megjegyz�s",$hd_lang,$hd_langt,$hd_lang_db);
    echo("<td colspan=2 width=30% valign=top align=left>");
    echo("$kim:<br />");
    echo("<br /><br /><br /><br />");
    echo("</td>");
    echo("</tr>");

    echo("<tr>");
    echo("<td colspan=2 valign=top><br /><b>$d</b>");
    echo("</td>");
    echo("</tr>");

    echo("</table></center>");

    echo("<center><table width=90% border=0>");

    echo("<tr>");
    echo("<td colspan=2 valign=top align=left width=50%>");
    echo("<br />$ki $ki2.<br />");
    echo("</td>");
    echo("</tr>");
    echo("<td valign=top align=center width=50%>");
    $ki=sys_line("megrendel�",$hd_lang,$hd_langt,$hd_lang_db);
    echo("<br /><br /><br /><br />");
    echo(".........................................<br />");
    echo("$ki<br />");
    echo("</td>");
    echo("<td valign=top align=center width=50%>");
    $ki=sys_line("szerv�z",$hd_lang,$hd_langt,$hd_lang_db);
    echo("<br /><br /><br /><br />");
    echo(".........................................<br />");
    echo("$ki<br />");
    echo("</td>");
    echo("</tr>");

    echo("</table></center>");
    echo("<br /><br />");
  }


?>
