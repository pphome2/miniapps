<?php

// Helpdesk plugin --- PHP portalrobot
// (verzioadatok a konfiguracios fajlban)
//
// fejleszto: InalR Fejlesztoi Iroda

// plugin




  function hd_list($c,$all){
    if ($all){
      hd_list_all($c);
    }else{
      hd_list_open($c,"");
    }
  }



  function hd_list_all($c){
    global $sql_hd_name,$hd_list_db,$sitepos,$sitepage,
           $hd_lang,$hd_langt,$hd_lang_db,$s_program,
           $mess_akt_page,$delkod,$deldata,$messpage,
           $user_admin,$sql_hd_n,$site_data_css_container,
           $pluginenv1,$separator;

    sys_env_new($sitepos,$c);
    $tomb=array();
    if ($delkod<>""){
      sql_data_del($sql_hd_name,$sql_hd_n[0],$delkod);
      $ki=sys_line("T�rl�s megt�rt�nt",$hd_lang,$hd_langt,$hd_lang_db);
      echo("<br />$ki.<br/><br />");
    }
    $ul=sys_env_find($sitepos);
    $db=0;
    $tx=sql_data_allget_desc($sql_hd_name,$sql_hd_n[0]);
    $db=sql_result_db($tx);
    site_pageing_init($db,$tol,$ig,$hd_list_db,$mess_akt_page);
    $ki0=sys_line("T�r�l",$hd_lang,$hd_langt,$hd_lang_db);
    $ki1=sys_line("M�dos�t, lez�r",$hd_lang,$hd_langt,$hd_lang_db);
    $ki2=sys_line("Megrendel�s",$hd_lang,$hd_langt,$hd_lang_db);
    $ki3=sys_line("Munkalap",$hd_lang,$hd_langt,$hd_lang_db);
    $ki4=sys_line("Lez�rva",$hd_lang,$hd_langt,$hd_lang_db);
    $ki5=sys_line("Nyitott",$hd_lang,$hd_langt,$hd_lang_db);
    $x=$tol;
    $za=0;
    while ($x<$ig){
      $txx=array();
      $txx=sql_get_result_data($tx,$x);
      $co=count($txx);
      if ($co>0){
        $za++;
        hd_list_out($txx,$za,$ki0,$ki1,$ki2,$ki3,$ki4,$ki5,true);
      }
      $x++;
    }
    if ($db>$hd_list_db){
      if ($site_data_css_container<>""){
        echo("<div class='div_p'></div>");
        echo("</div><div class='$site_data_css_container'>");
      }else{
        echo("<hr width='85%' />");
      }
    }else{
      echo("<br />");
    }
    sys_env_del($pluginenv1);
    site_pageing($db,$hd_list_db,$mess_akt_page,$messpage);
    sys_env_del($sitepage);
  }


  function hd_list_open($c,$user){
    global $sql_hd_name,$hd_list_db,$sitepos,$sitepage,
           $hd_lang,$hd_langt,$hd_lang_db,$s_program,
           $mess_akt_page,$delkod,$deldata,$messpage,
           $user_admin,$sql_hd_n,$site_data_css_container,
           $pluginenv1,$separator;

    sys_env_new($sitepos,$c);
    $tomb=array();
    if ($delkod<>""){
      sql_data_del($sql_hd_name,$sql_hd_n[0],$delkod);
      $ki=sys_line("T�rl�s megt�rt�nt",$hd_lang,$hd_langt,$hd_lang_db);
      echo("<br />$ki.<br/><br />");
    }
    $ul=sys_env_find($sitepos);
    $tx=sql_data_allget_desc($sql_hd_name,$sql_hd_n[0]);
    $db=sql_result_db($tx);
    $kidb=0;
    $x=0;
    while($x<$db){
      $txx=sql_get_result_data($tx,$x);
      if ($txx[19]==""){
        $kidb++;
      }
      $x++;
    }
    site_pageing_init($kidb,$tol,$ig,$hd_list_db,$mess_akt_page);
    $ki0=sys_line("T�r�l",$hd_lang,$hd_langt,$hd_lang_db);
    $ki1=sys_line("M�dos�t, lez�r",$hd_lang,$hd_langt,$hd_lang_db);
    $ki2=sys_line("Megrendel�s",$hd_lang,$hd_langt,$hd_lang_db);
    $ki3=sys_line("Munkalap",$hd_lang,$hd_langt,$hd_lang_db);
    $ki4=sys_line("Lez�rva",$hd_lang,$hd_langt,$hd_lang_db);
    $ki5=sys_line("Nyitott",$hd_lang,$hd_langt,$hd_lang_db);
    $x=$tol;
    $za=0;
    $zu=0;
    $y=0;
    $out=0;
    while ($x<$ig){
      $txx=sql_get_result_data($tx,$y);
      $y++;
      if ($y>$db){
        $x=$ig;
      }
      $co=count($txx);
      if (($co>0)and($txx[19]=="")){
        $out++;
        if (($out>=$tol)and($out<=$ig)){
          $x++;
          $z=$out+1;
          if ($user<>""){
            if ($txx[2]==$user){
              $zu++;
              hd_list_out($txx,$zu,$ki0,$ki1,$ki2,$ki3,$ki4,$ki5,false);
            }
          }else{
            $za++;
            hd_list_out($txx,$za,$ki0,$ki1,$ki2,$ki3,$ki4,$ki5,true);
          }
        }
      }
    }
    if (($za==0)and($zu==0)){
      $ki=sys_line("Nincs bejelent�s",$hd_lang,$hd_langt,$hd_lang_db);
      echo("$ki.");
      echo("<br />");
    }
    if ($db>$hd_list_db){
      if ($site_data_css_container<>""){
        echo("<div class='div_p'></div>");
        echo("</div><div class='$site_data_css_container'>");
      }else{
        echo("<hr width='85%' />");
      }
    }else{
      echo("<br />");
    }
    sys_env_del($pluginenv1);
    site_pageing($kidb,$hd_list_db,$mess_akt_page,$messpage);
    sys_env_del($sitepage);
  }


  function hd_list_out($txx,$z,$ki0,$ki1,$ki2,$ki3,$ki4,$ki5,$hdadmin){
    global $sql_hd_name,$hd_list_db,$sitepos,$sitepage,
           $hd_lang,$hd_langt,$hd_lang_db,$s_program,
           $mess_akt_page,$delkod,$deldata,$messpage,
           $user_admin,$sql_hd_n,$site_data_css_container,
           $pluginenv1,$separator;

    echo("<div class='page_table'>");
    echo("<div class='div_a1'>");
    if (($user_admin)and($hdadmin)){
      sys_env_new($messpage,$mess_akt_page);
      sys_env_new($deldata,$txx[0]);
      $e=sys_env_pack();
      sys_env_del($deldata);
      echo("<a class='href' href=$s_program?$e>$ki0</a>");
      echo("<br />");
      $s="1".$separator.$txx[0];
      sys_env_new($pluginenv1,$s);
      $e=sys_env_pack();
      echo("<a class='href' href=$s_program?$e>$ki1</a>");
      echo("<br />");
      $s="2".$separator.$txx[0];
      sys_env_new($pluginenv1,$s);
      $e=sys_env_pack();
      echo("<a class='href' href=$s_program?$e>$ki2</a>");
      echo("<br />");
      $s="3".$separator.$txx[0];
      sys_env_new($pluginenv1,$s);
      $e=sys_env_pack();
      echo("<a class='href' href=$s_program?$e>$ki3</a>");
      sys_env_del($messpage);
    }else{
      echo("$z");
    }
    echo("</div>");
    echo("<div class='div_a2'>");
    echo("$txx[1]<br />$txx[2]<br />");
    echo("$txx[4]<br />");
    echo("<a href='mailto:$txx[5]'>$txx[5]</a>");
    echo("</div>");
    echo("<div class='div_a3'>");
    echo("$txx[6], $txx[7]<br />$txx[8]<br />");
    echo("$txx[12]<br />");
    if ($txx[19]<>""){
      echo("$ki4: $txx[13]");
    }else{
      echo("<b>$ki5. $txx[20].</b>");
    }
    echo("</div>");
    echo("</div>");
  }


?>
