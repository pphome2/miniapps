<?php

// Helpdesk plugin --- PHP portalrobot
// (verzioadatok a konfiguracios fajlban)
//
// fejleszto: InalR Fejlesztoi Iroda

// plugin



  function hd_user_form($c){
    global $newdata,$usercode,$s_program,$sitepos,
           $sql_hd_name,$sql_hd_n,$pluginenv1,$separator,
           $hd_lang,$hd_langt,$hd_lang_db,$hd_service_man,
           $hd_service_state,$usercode,$hd_show_userticket;

    sys_env_new($newdata,$newdata);
    sys_env_new($sitepos,$c);
    $uc=sys_env_find($usercode);
    $utomb=site_user_data_all($uc);
    echo("<br />");
    $ki=sys_line("Bejelent�s adatai",$hd_lang,$hd_langt,$hd_lang_db);
    echo("<div class='div_p'><b>$ki</b></div>");
    echo("<br /><br />");
    $tomb=array();
    $c=0;
    while($c<30){
     $tomb[$c]="";
     $c++;
    }
    $tomb[0]=sys_time_code();
    $tomb[1]=date("Y.m.d. H:i");
    if (count($utomb)>0){
      $tomb[2]=$utomb[5];
      $tomb[3]=$utomb[6];
      $tomb[4]="";
      $tomb[5]=$utomb[7];
    }
    $e=sys_env_pack();

    echo("<center>");
    echo("<form method='post' action='./$s_program?$e'>");
    echo("<input class='input_r1' type='hidden' id='m01' name='m01' value='$tomb[0]' />");
    $ki=sys_line("Id�",$hd_lang,$hd_langt,$hd_lang_db);
    echo("<div class='div_r1'>$ki:</div>");
    echo("<input class='input_r1' type='text' id='m02' name='m02' value='$tomb[1]' size='120' readonly /><br />");
    echo("<br />");

    $ki=sys_line("Bejelent� neve",$hd_lang,$hd_langt,$hd_lang_db);
    echo("<div class='div_r1'>$ki:</div>");
    echo("<input class='input_r1' type='text' id='m03' name='m03' value='$tomb[2]' size='120' maxlength='100' readonly/><br />");
    $ki=sys_line("c�me",$hd_lang,$hd_langt,$hd_lang_db);
    echo("<div class='div_r1'>- $ki:</div>");
    echo("<input class='input_r1' type='text' id='m04' name='m04' value='$tomb[3]' size='120' maxlength='100' readonly/><br />");
    $ki=sys_line("telefonsz�ma",$hd_lang,$hd_langt,$hd_lang_db);
    echo("<div class='div_r1'>- $ki:</div>");
    echo("<input class='input_r1' type='text' id='m05' name='m05' value='$tomb[4]' size='120' maxlength='100' /><br />");
    $ki=sys_line("e-mail c�me",$hd_lang,$hd_langt,$hd_lang_db);
    echo("<div class='div_r1'>- $ki:</div>");
    echo("<input class='input_r1' type='text' id='m06' name='m06' value='$tomb[5]' size='120' maxlength='100' readonly/><br />");
    echo("<br />");

    $ki=sys_line("Eszk�z (szoftver) gy�rt�ja",$hd_lang,$hd_langt,$hd_lang_db);
    echo("<div class='div_r1'>$ki:</div>");
    echo("<input class='input_r1' type='text' id='m07' name='m07' value='$tomb[6]' size='120' maxlength='100' /><br />");
    $ki=sys_line("neve",$hd_lang,$hd_langt,$hd_lang_db);
    echo("<div class='div_r1'>- $ki:</div>");
    echo("<input class='input_r1' type='text' id='m08' name='m08' value='$tomb[7]' size='120' maxlength='100' /><br />");

    echo("<input type='hidden' id='m09' name='m09' value='' />");
    echo("<input type='hidden' id='m10' name='m10' value='' />");

    echo("<input type='hidden' id='m11' name='m11' value='' />");
    echo("<input type='hidden' id='m12' name='m12' value='' />");

    $ki=sys_line("hiba",$hd_lang,$hd_langt,$hd_lang_db);
    echo("<div class='div_r1'>- $ki:</div>");
    echo("<textarea class='textarea_e1' id='m13' name='m13' cols=75 rows=6 />$tomb[12]</textarea><br />");
    echo("<br />");
    echo("<br />");

    echo("<input type='hidden' id='m14' name='m14' value='' />");
    echo("<input type='hidden' id='m15' name='m15' value='' />");
    echo("<input type='hidden' id='m16' name='m16' value='' />");
    echo("<input type='hidden' id='m17' name='m17' value='' />");
    echo("<input type='hidden' id='m18' name='m18' value='' />");
    echo("<input type='hidden' id='m19' name='m19' value='' />");
    echo("<input type='hidden' id='m20' name='m20' value='' />");
    echo("<input type='hidden' id='m21' name='m21' value='' />");

    $ki=sys_line("Mehet",$hd_lang,$hd_langt,$hd_lang_db);
    echo("<button class='button_1' type='submit' id='b7' name='b7' value='$ki'>$ki</button>");
    echo("</form>");
    echo("</center>");

    if ($hd_show_userticket){
      echo("<br />");
      echo("<br />");
      $ki=sys_line("Nyitott bejelent�sek",$hd_lang,$hd_langt,$hd_lang_db);
      echo("<div class='div_p'><b>$ki ($utomb[5])</b></div>");
      echo("<br />");
      echo("<br />");
      hd_list_open($c,$utomb[5]);
    }
    sys_env_del($newdata);
    sys_env_del($pluginenv1);

  }

?>
