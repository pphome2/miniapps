<?php

// Helpdesk plugin --- PHP portalrobot
// (verzioadatok a konfiguracios fajlban)
//
// fejleszto: InalR Fejlesztoi Iroda

// plugin


  function hd($cim){
    global $plugin_menu,$hd_menu_start,$plugin_page,
           $plugin_data_1,$separator;

    if ($plugin_data_1<>""){
      $t=explode($separator,$plugin_data_1);
      switch ($t[0]){
        case "1":
          $cim=$plugin_page.$cim;
          hd_data($cim,$t[1],false);
          break;
        case "2":
          $cim=$plugin_page.$cim;
          hd_mlap($cim,"Megrendel�s",$t[1],$plugin_data_1);
          break;
        case "3":
          $cim=$plugin_page.$cim;
          hd_mlap($cim,"Munkalap",$t[1],$plugin_data_1);
          break;
        case "4":
          break;
      }
    }
    switch ($cim){
      case $plugin_menu[$hd_menu_start]:
        echo("<br /><b>");
        echo($plugin_menu[$hd_menu_start+1]);
        echo("</b><br /><br />");
        $cim=$plugin_page.$cim;
        hd_data($cim,"",false);
        break;
      case $plugin_menu[$hd_menu_start+1]:
        echo("<br /><b>");
        echo($plugin_menu[$hd_menu_start+1]);
        echo("</b><br /><br />");
        $cim=$plugin_page.$cim;
        hd_list($cim,true);
        break;
      case $plugin_menu[$hd_menu_start+2]:
        echo("<br /><b>");
        echo($plugin_menu[$hd_menu_start+2]);
        echo("</b><br /><br />");
        $cim=$plugin_page.$cim;
        hd_list($cim,false);
        break;
      case $plugin_menu[$hd_menu_start+3]:
        echo("<br /><b>");
        echo($plugin_menu[$hd_menu_start+3]);
        echo("</b><br /><br />");
        $cim=$plugin_page.$cim;
        hd_data($cim,"",true);
        break;
    }
  }


  function hd_init(){
    global $hd_langt,$user_admin,$hd_css,
           $dir_plugin,$hd_lang,$lang_system,
           $sql_hd_n,$sql_hd_t,$sql_hd_name,
           $hd_menu_start,$hd_list_db,
           $cond_file,$hd_service_name,$hd_service_man,
           $hd_service_state,$dev_moduls,
           $hd_plugin_name,$mess_per_page,
           $hd_files,$usercode,$hd_show_userticket;

    $hd_plugin_name="Helpdesk";
    $inc_file="$dir_plugin/".$hd_plugin_name."/hd_inc.php";
    include("$inc_file");
    $x=0;
    $c=count($hd_files);
    while ($x<$c){
      $inc_file="$dir_plugin/".$hd_plugin_name."/".$hd_files[$x];
      include("$inc_file");
      $x++;
    }

    if ($hd_list_db>$mess_per_page){
      $hd_list_db=$mess_per_page;
    }
    $hd_lang="$dir_plugin/".$hd_plugin_name."/lang_$lang_system";
    $c=count($hd_service_state);
    $x=0;
    while ($x>$c){
      $hd_service_state[$x]=sys_line($hd_service_state[$x],$hd_lang,$hd_langt,$hd_lang_db);
      $x++;
    }
    sys_style($hd_css);
    $c=0;
    if ($user_admin){
      $ki=sys_line("HD �j bejelent�s",$hd_lang,$hd_langt,$hd_lang_db);
      $hd_menu[$c]=$ki;
      $hd_func[$c]="hd";
      $c++;
      $ki=sys_line("HD bejelent�sek",$hd_lang,$hd_langt,$hd_lang_db);
      $hd_menu[$c]=$ki;
      $hd_func[$c]="hd";
      $c++;
      $ki=sys_line("HD nyitott bejelent�sek",$hd_lang,$hd_langt,$hd_lang_db);
      $hd_menu[$c]=$ki;
      $hd_func[$c]="hd";
    } //else{
      $cu=sys_env_find($usercode);
      if ($cu<>""){
        $c++;
        $ki=sys_line("Hiba bejelent�se",$hd_lang,$hd_langt,$hd_lang_db);
        $hd_menu[$c]=$ki;
        $hd_func[$c]="hd";
      }
    //}
    if ($c>0){
      $hd_menu_start=plugin_menu($hd_menu,$hd_func);
    }

    sql_plugin_init($sql_hd_name,$sql_hd_n,$sql_hd_t);

    $c=count($dev_moduls);
    $dev_moduls[$c]=$hd_plugin_name;
  }

  // plugins close

  function hd_end(){
  }


?>
