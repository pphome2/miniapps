<?php

// Helpdesk plugin --- PHP portalrobot
// (verzioadatok a konfiguracios fajlban)
//
// fejleszto: InalR Fejlesztoi Iroda

// plugin


  function hd_data($c,$kod,$user){
    global $sql_hd_name,$sql_hd_n,
           $hd_lang,$hd_langt,$hd_lang_db;

    $ok=sys_data_post($dbx,$tkx,$tex);
    if ($ok){
      $x=0;
      while ($x<$dbx){
        $to[$x]=$tex[$x];
        $x++;
      }
      if ($kod==""){
        sql_data_add($sql_hd_name,$to);
      }else{
        if (($to[14]<>"")and
            ($to[15]<>"")and
            ($to[16]<>"")and
            ($to[17]<>"")){
          $to[13]=date("Y.m.d. H:i");
        }
        sql_data_update($sql_hd_name,$sql_hd_n,$sql_hd_n[0],$kod,$to);
      }
      $ki=sys_line("Adatok t�rol�sa megt�rt�nt",$hd_lang,$hd_langt,$hd_lang_db);
      echo("<br />$ki.<br /><br />");
    }
    if ($user){
      hd_user_form($c);
    }else{
      hd_form($c,$kod);
    }
  }


  function hd_form($c,$kod){
    global $newdata,$usercode,$s_program,$sitepos,
           $sql_hd_name,$sql_hd_n,$pluginenv1,$separator,
           $hd_lang,$hd_langt,$hd_lang_db,$hd_service_man,
           $hd_service_state;

    sys_env_new($newdata,$newdata);
    sys_env_new($sitepos,$c);
    echo("<br />");
    $ki=sys_line("Bejelent�s adatai",$hd_lang,$hd_langt,$hd_lang_db);
    echo("<div class='div_p'><b>$ki</b></div>");
    echo("<br /><br />");
    if ($kod==""){
      $tomb=array();
    }else{
      $tx=sql_data_get($sql_hd_name,$sql_hd_n[0],$kod);
      $tomb=sql_get_result_data($tx,0);
      $s="1".$separator.$tomb[0];
      sys_env_new($pluginenv1,$s);
    }
    $db=count($tomb);
    if ($db==0){
      $i=0;
      $sor=count($sql_hd_n);
      while ($i<$sor){
        $tomb[$i]="";
        $i++;
      }
      $tomb[0]=sys_time_code();
      $tomb[1]=date("Y.m.d. H:i");
    }else{
      $tomb[13]=date("Y.m.d. H:i");
    }
    $e=sys_env_pack();

    echo("<center>");
    echo("<form method='post' action='./$s_program?$e'>");
    echo("<input class='input_r1' type='hidden' id='m01' name='m01' value='$tomb[0]' />");
    $ki=sys_line("Id�",$hd_lang,$hd_langt,$hd_lang_db);
    echo("<div class='div_r1'>$ki:</div>");
    echo("<input class='input_r1' type='text' id='m02' name='m02' value='$tomb[1]' size='120' readonly /><br />");
    echo("<br />");

    $ki=sys_line("Bejelent� neve",$hd_lang,$hd_langt,$hd_lang_db);
    echo("<div class='div_r1'>$ki:</div>");
    echo("<input class='input_r1' type='text' id='m03' name='m03' value='$tomb[2]' size='120' maxlength='100' /><br />");
    $ki=sys_line("c�me",$hd_lang,$hd_langt,$hd_lang_db);
    echo("<div class='div_r1'>- $ki:</div>");
    echo("<input class='input_r1' type='text' id='m04' name='m04' value='$tomb[3]' size='120' maxlength='100' /><br />");
    $ki=sys_line("telefonsz�ma",$hd_lang,$hd_langt,$hd_lang_db);
    echo("<div class='div_r1'>- $ki:</div>");
    echo("<input class='input_r1' type='text' id='m05' name='m05' value='$tomb[4]' size='120' maxlength='100' /><br />");
    $ki=sys_line("e-mail c�me",$hd_lang,$hd_langt,$hd_lang_db);
    echo("<div class='div_r1'>- $ki:</div>");
    echo("<input class='input_r1' type='text' id='m06' name='m06' value='$tomb[5]' size='120' maxlength='100' /><br />");
    echo("<br />");
    echo("<br />");

    $ki=sys_line("Eszk�z (szoftver) gy�rt�ja",$hd_lang,$hd_langt,$hd_lang_db);
    echo("<div class='div_r1'>$ki:</div>");
    echo("<input class='input_r1' type='text' id='m07' name='m07' value='$tomb[6]' size='120' maxlength='100' /><br />");
    $ki=sys_line("neve",$hd_lang,$hd_langt,$hd_lang_db);
    echo("<div class='div_r1'>- $ki:</div>");
    echo("<input class='input_r1' type='text' id='m08' name='m08' value='$tomb[7]' size='120' maxlength='100' /><br />");
    $ki=sys_line("gy�ri sz�ma (verzi�ja)",$hd_lang,$hd_langt,$hd_lang_db);
    echo("<div class='div_r1'>- $ki:</div>");
    echo("<input class='input_r1' type='text' id='m09' name='m09' value='$tomb[8]' size='120' maxlength='100' /><br />");
    $ki=sys_line("hardver elemek",$hd_lang,$hd_langt,$hd_lang_db);
    echo("<div class='div_r1'>- $ki:</div>");
    echo("<input class='input_r1' type='text' id='m10' name='m10' value='$tomb[9]' size='120' maxlength='450' /><br />");
    $ki=sys_line("szoftver elemek",$hd_lang,$hd_langt,$hd_lang_db);
    echo("<div class='div_r1'>- $ki:</div>");
    echo("<input class='input_r1' type='text' id='m11' name='m11' value='$tomb[10]' size='120' maxlength='450' /><br />");
    $ki=sys_line("tartoz�kok",$hd_lang,$hd_langt,$hd_lang_db);
    echo("<div class='div_r1'>- $ki:</div>");
    echo("<input class='input_r1' type='text' id='m12' name='m12' value='$tomb[11]' size='120' maxlength='450' /><br />");
    $ki=sys_line("hiba",$hd_lang,$hd_langt,$hd_lang_db);
    echo("<div class='div_r1'>- $ki:</div>");
    //echo("<input class='input_r1' type='text' id='m13' name='m13' value='$tomb[12]' size='120' maxlength='250' /><br />");
    echo("<textarea class='textarea_e1' id='m13' name='m13' cols=75 rows=6 />$tomb[12]</textarea><br />");
    echo("<br />");
    echo("<br />");

    $ki=sys_line("Megold�s ideje",$hd_lang,$hd_langt,$hd_lang_db);
    echo("<div class='div_r1'>$ki:</div>");
    echo("<input class='input_r1' type='text' id='m14' name='m14' value='$tomb[13]' size='120' readonly /><br />");
    $ki=sys_line("le�r�sa",$hd_lang,$hd_langt,$hd_lang_db);
    echo("<div class='div_r1'>- $ki:</div>");
    echo("<textarea class='textarea_e1' id='m15' name='m15' cols=75 rows=6 />$tomb[14]</textarea><br />");
    $ki=sys_line("jav�t�st v�gezte",$hd_lang,$hd_langt,$hd_lang_db);
    echo("<div class='div_r1'>- $ki:</div>");
    echo("<select class='select_r1' id='m16' name='m16'>");
    $c=count($hd_service_man);
    $x=0;
    while ($x<$c){
      if ($tomb[15]==$hd_service_man[$x]){
        echo("<option value='$hd_service_man[$x]' selected='selected'>$hd_service_man[$x]</option>");
      }else{
        echo("<option value='$hd_service_man[$x]'>$hd_service_man[$x]</option>");
      }
      $x++;
    }
    echo("</select>");
    $ki=sys_line("garanci�lis jav�t�s",$hd_lang,$hd_langt,$hd_lang_db);
    echo("<div class='div_r1'>- $ki:</div>");
    echo("<input class='input_r1' type='text' id='m17' name='m17' value='$tomb[16]' size='120' maxlength='100' /><br />");
    $ki=sys_line("jav�t�s munkaideje",$hd_lang,$hd_langt,$hd_lang_db);
    echo("<div class='div_r1'>- $ki:</div>");
    echo("<input class='input_r1' type='text' id='m18' name='m18' value='$tomb[17]' size='120' maxlength='100' /><br />");
    $ki=sys_line("jav�t�si kisz�ll�s (km)",$hd_lang,$hd_langt,$hd_lang_db);
    echo("<div class='div_r1'>- $ki:</div>");
    echo("<input class='input_r1' type='text' id='m19' name='m19' value='$tomb[18]' size='120' maxlength='100' /><br />");
    $ki=sys_line("jav�t�si k�lts�g",$hd_lang,$hd_langt,$hd_lang_db);
    echo("<div class='div_r1'>- $ki:</div>");
    echo("<input class='input_r1' type='text' id='m20' name='m20' value='$tomb[19]' size='120' maxlength='100' /><br />");
    echo("<br />");

    $ki=sys_line("Jav�t�si �llapota",$hd_lang,$hd_langt,$hd_lang_db);
    echo("<div class='div_r1'>$ki:</div>");
    echo("<select class='select_r1' id='m21' name='m21'>");
    $c=count($hd_service_state);
    $x=0;
    while ($x<$c){
      $ki=sys_line($hd_service_state[$x],$hd_lang,$hd_langt,$hd_lang_db);
      if ($tomb[20]==$ki){
        echo("<option value='$ki' selected='selected'>$ki</option>");
      }else{
        echo("<option value='$ki'>$ki</option>");
      }
      $x++;
    }
    echo("</select>");
    echo("<br />");
    echo("<br />");

    $ki=sys_line("Mehet",$hd_lang,$hd_langt,$hd_lang_db);
    echo("<button class='button_1' type='submit' id='b7' name='b7' value='$ki'>$ki</button>");
    echo("</form>");
    echo("</center>");
    sys_env_del($newdata);
    sys_env_del($pluginenv1);
  }


?>
