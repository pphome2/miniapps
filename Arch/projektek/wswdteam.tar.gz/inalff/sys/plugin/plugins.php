<?php

// w_robot --- PHP portalrobot
// (verzioadatok a konfiguracios fajlban)
//
// fejleszto: InalR Fejlesztoi Iroda


  // global used plugins, plugin system load

  plugin_load("$dir_plugin/Helpdesk/hd.php");
  plugin_load("$dir_plugin/EShop/eshop.php");
  plugin_load("$dir_plugin/MiniVote/mv.php");
  plugin_load("$dir_plugin/Recaptcha/rc.php");
  plugin_load("$dir_plugin/SDownload/sd.php");


  // plugins initialization, plugin system run function

  function plugin_init(){
    plugin_run("hd_init",0);
    plugin_run("eshop_init",1);
    plugin_run("mv_init",0);
    plugin_run("sd_init",0);
  }

  // plugins close

  function plugin_end(){
    plugin_run("hd_end",0);
    plugin_run("eshop_end",1);
  }

?>
