<?php

// Helpdesk plugin --- PHP portalrobot
// (verzioadatok a konfiguracios fajlban)
//
// fejleszto: InalR Fejlesztoi Iroda

// plugin



  function mv_data($cim,$kod){
    global $sql_mvn_name,$sql_mvn_n,
           $sql_mvt_name,$sql_mvt_n,
           $mv_lang,$mv_langt,$mv_lang_db,
           $delkod,$separator;

    if ($kod==""){
      if ($delkod<>""){
        sql_data_del($sql_mvn_name,$sql_mvn_n[0],$delkod);
        sql_data_del_rec($sql_mvt_name,$sql_mvt_n[0],1,$delkod);
        $ki=sys_line("Szavaz�s t�rl�se megt�rt�nt",$mv_lang,$mv_langt,$mv_lang_db);
        echo("<br />$ki.<br /><br />");
      }else{
        $ok=sys_data_post($dbx,$tkx,$tex);
        if ($ok){
          $x=0;
          while ($x<$dbx){
            $to[$x]=$tex[$x];
            $x++;
          }
          if ($dbx==2){
            $to[2]="";
            sql_data_add($sql_mvn_name,$to);
          }else{
            $to[3]="0";
            sql_data_add($sql_mvt_name,$to);
          }
          $ki=sys_line("Adatok t�rol�sa megt�rt�nt",$mv_lang,$mv_langt,$mv_lang_db);
          echo("<br />$ki.<br /><br />");
        }
      }
    }else{
      $tx=sql_data_get($sql_mvn_name,$sql_mvn_n[0],$kod);
      if (count($tx)>0){
        $tomb=sql_get_result_data($tx,0);
        $tomb[2]=$separator;
        sql_data_update($sql_mvn_name,$sql_mvn_n,$sql_mvn_n[0],$kod,$tomb);
      }
    }
    mv_form($cim);
  }


  function mv_form($c){
    global $usercode,$s_program,$sitepos,
           $sql_mvn_name,$sql_mvn_n,
           $sql_mvt_name,$sql_mvt_n,
           $pluginenv1,$separator,
           $mv_lang,$mv_langt,$mv_lang_db,
           $mess_akt_page,$messpage,
           $mv_list_db;

    sys_env_new($sitepos,$c);
    echo("<br />");
    $ki=sys_line("Szavaz�s adatai",$mv_lang,$mv_langt,$mv_lang_db);
    echo("<div class='div_p'><b>$ki</b></div>");
    echo("<br /><br />");
    $tomb=array("","","");
    $ttomb=array("","","");
    $polltomb=array();
    $tx=sql_data_allget_desc($sql_mvn_name,1);
    $x=0;
    $ddb=sql_result_db($tx);
    while($x<$ddb){
      $polltomb[$x]=sql_get_result_data($tx,$x);
      $x++;
    }
    $tomb[0]=sys_time_code();
    $ttomb[0]=sys_time_code();
    $e=sys_env_pack();

    echo("<center>");
    echo("<form method='post' action='./$s_program?$e'>");
    echo("<input class='input_r1' type='hidden' id='m01' name='m01' value='$tomb[0]' />");
    $ki=sys_line("�j szavaz�s k�rd�se",$mv_lang,$mv_langt,$mv_lang_db);
    echo("<div class='div_r1'>$ki:</div>");
    echo("<input class='input_r1' type='text' id='m02' name='m02' value='$tomb[1]' size='120' /><br />");
    echo("<br />");
    echo("<br />");

    $ki=sys_line("Mehet",$mv_lang,$mv_langt,$mv_lang_db);
    echo("<button class='button_1' type='submit' id='b7' name='b7' value='$ki'>$ki</button>");
    echo("</form>");
    echo("<br />");
    echo("<br />");

    echo("<form method='post' action='./$s_program?$e'>");
    echo("<input class='input_r1' type='hidden' id='n01' name='n01' value='$ttomb[0]' />");
    $ki=sys_line("Szavaz�s",$mv_lang,$mv_langt,$mv_lang_db);
    echo("<div class='div_r1'>$ki:</div>");

    echo("<select class='select_r1' id='n02' name='n02'>");
    $c=count($polltomb);
    $x=0;
    while ($x<$c){
      $ptomb=$polltomb[$x];
      if ($ptomb[2]==""){
        echo("<option value='$ptomb[0]'>$ptomb[1]</option>");
      }
      $x++;
    }
    echo("</select>");

    $ki=sys_line("�j t�tel",$mv_lang,$mv_langt,$mv_lang_db);
    echo("<div class='div_r1'>$ki:</div>");
    echo("<input class='input_r1' type='text' id='n03' name='n03' value='$tomb[2]' size='120' maxlength='100' /><br />");
    echo("<br />");
    echo("<br />");

    $ki=sys_line("Mehet",$mv_lang,$mv_langt,$mv_lang_db);
    echo("<button class='button_1' type='submit' id='b7' name='b7' value='$ki'>$ki</button>");
    echo("</form>");
    echo("<br />");
    echo("<br />");
    echo("</center>");

    site_pageing_init($ddb,$tol,$ig,$mv_list_db,$mess_akt_page);

    $ki0=sys_line("T�r�l",$mv_lang,$hd_langt,$mv_lang_db);
    $ki1=sys_line("Lez�r",$mv_lang,$hd_langt,$mv_lang_db);
    $ki2=sys_line("Nyitott",$mv_lang,$hd_langt,$mv_lang_db);
    $ki3=sys_line("Lez�rt",$mv_lang,$hd_langt,$mv_lang_db);
    $x=$tol;
    $y=0;
    $out=0;
    while ($x<$ddb){
      $txx=sql_get_result_data($tx,$x);
      $co=count($txx);
      if ($co>0){
        if (($x>=$tol)and($x<$ig)){
          $out++;
          mv_list_out($txx,$out+1,$ki0,$ki1,$ki2,$ki3);
        }
      }
      $x++;
    }
    if ($out==0){
      $ki=sys_line("Nincs szavaz�s",$mv_lang,$mv_langt,$mv_lang_db);
      echo("$ki.");
      echo("<br />");
    }else{
      echo("<br />");
      echo("<br />");
      site_pageing($ddb,$mv_list_db,$mess_akt_page,$messpage);
    }
    sys_env_del($pluginenv1);
  }


  function mv_list_out($txx,$z,$ki0,$ki1,$ki2,$ki3){
    global $sql_mvt_name,$mv_list_db,$sitepos,$sitepage,
           $mv_lang,$mv_langt,$mv_lang_db,$s_program,
           $mess_akt_page,$delkod,$deldata,$messpage,
           $user_admin,$sql_mvt_n,$site_data_css_container,
           $pluginenv1,$separator;

    echo("<div class='page_table'>");
    echo("<div class='div_a1'>");
    if ($user_admin){
      sys_env_new($messpage,$mess_akt_page);
      sys_env_new($deldata,$txx[0]);
      $e=sys_env_pack();
      sys_env_del($deldata);
      echo("<a class='href' href=$s_program?$e>$ki0</a>");
      echo("<br />");
      if ($txx[2]==""){
        $s="1".$separator.$txx[0];
        sys_env_new($pluginenv1,$s);
        $e=sys_env_pack();
        echo("<a class='href' href=$s_program?$e>$ki1</a>");
        echo("<br />");
      }
    }else{
      echo("$z");
    }
    echo("</div>");
    echo("<div class='div_a2'>");
    echo("$txx[1]<br />");
    if ($txx[2]==""){
      echo("<b>$ki2.</b>");
    }else{
      echo("<b>$ki3.</b>");
    }
    echo("</div>");
    echo("<div class='div_a3'>");
    $txb=sql_data_allget($sql_mvt_name);
    $x=0;
    $o=0;
    $ddb=sql_result_db($txb);
    $allvote=0;
    $poll1=array();
    $poll2=array();
    $odb=0;
    while($x<$ddb){
      $poll=sql_get_result_data($txb,$x);
      if ($poll[1]==$txx[0]){
        $allvote+=$poll[3];
        $poll1[$odb]=$poll[2];
        $poll2[$odb]=$poll[3];
        $odb++;
      }
      $x++;
    }
    if ($allvote>0){
      $onevote=100/$allvote;
    }else{
      $onevote=0;
    }
    $x=0;
    while($x<$odb){
      if ($o<>0){
        echo("<br />");
      }
      $o++;
      $v=$poll2[$x]*$onevote;
      $v=round($v,0);
      echo("$poll1[$x] - $poll2[$x] ( $v % )");
      $x++;
    }

    echo("</div>");
    echo("</div>");
  }




?>
