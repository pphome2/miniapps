<?php

// Helpdesk plugin --- PHP portalrobot
// (verzioadatok a konfiguracios fajlban)
//
// fejleszto: InalR Fejlesztoi Iroda

// plugin

    $mv_plugin_name="MiniVote";

    $sql_mvn_name="_mvn";
    $sql_mvn_n=array('mvcode',
                     'mvname',
                     'mvopen'
                    );
    $sql_mvn_t=array('varchar (30)',
                     'varchar (100)',
                     'varchar (1)'
                    );
    $sql_mvt_name="_mvt";
    $sql_mvt_n=array('mvtcode',
                     'mvtnamecode',
                     'mvt',
                     'mvvote'
                    );
    $sql_mvt_t=array('varchar (30)',
                     'varchar (30)',
                     'varchar (100)',
                     'int(5)'
                    );


    $mv_files=array("mv_frm.php","mv_akt.php","mv_old.php");

    $mv_lang="";
    $mv_akt_page="";
    $mv_langt=array();
    $mv_menu_start=0;
    $mv_list_db=20;
    $mv_css="$dir_plugin/".$mv_plugin_name."/mv.css";


?>
