<?php

// Helpdesk plugin --- PHP portalrobot
// (verzioadatok a konfiguracios fajlban)
//
// fejleszto: InalR Fejlesztoi Iroda

// plugin



  function mv_oldpoll($cim=""){
    global $usercode,$s_program,$sitepos,
           $sql_mvn_name,$sql_mvn_n,
           $sql_mvt_name,$sql_mvt_n,
           $pluginenv1,$plugin_data_1,
           $separator,$mv_plugin_name,
           $mv_lang,$mv_langt,$mv_lang_db,
           $mess_akt_page,$messpage,
           $mv_list_db,$mv_akt_page,
           $mv_akt_page,
           $messpage,$mess_akt_page;

    $s=sys_env_find($sitepos);
    if ($cim<>""){
      sys_env_new($sitepos,$cim);
    }
    //echo("<br />");
    $tx=sql_data_allget_desc($sql_mvn_name,1);
    $x=0;
    $odb=0;
    $ddb=sql_result_db($tx);
    while($x<$ddb){
      $polltomb=sql_get_result_data($tx,$x);
      if ($polltomb[2]<>""){
        $odb++;
      }
      $x++;
    }
    if ($odb>0){
      site_pageing_init($odb,$tol,$ig,$mv_akt_page,$mess_akt_page);
      $x=$tol;
      $ddb=sql_result_db($tx);
      while($x<$ig){
        $polltomb=sql_get_result_data($tx,$x);
        if ($polltomb[2]<>""){
          $txb=sql_data_allget($sql_mvt_name);
          $x=0;
          $y=0;
          $vpoll1=array();
          $vpoll2=array();
          $ddb=sql_result_db($txb);
          $allvote=0;
          while($x<$ddb){
            $poll=sql_get_result_data($txb,$x);
            if ($poll[1]==$polltomb[0]){
              $allvote+=$poll[3];
              $vpoll1[$y]=$poll[2];
              $vpoll2[$y]=$poll[3];
              $y++;
            }
            $x++;
          }
          echo("<br />");
          echo("<br />");
          echo("<b>$polltomb[1]</b>");
          echo("<br />");
          echo("<br />");
          if ($allvote>0){
            $onevote=100/$allvote;
          }else{
            $onevote=0;
          }
          $x=0;
          $c=count($vpoll1);
          while($x<$c){
            $v=$vpoll2[$x]*$onevote;
            $v=round($v,0);
            echo("<div class='mv_div1'>$vpoll1[$x] ( $v % )</div>");
            //echo("<div class='mv_div2'>$v % ($poll[3])</div>");
            //echo("<div class='mv_hr1'><hr style='width=$v%;height=10px;'></div>");
            echo("<div class='mv_hr1'>");
            echo("<div style='width:$v%;background-color:red;'>.</div>");
            echo("</div>");
            $x++;
          }
        }
        $x++;
      }
      echo("<br />");
      site_pageing($odb,$mv_akt_page,$mess_akt_page,$messpage);
      echo("<br />");
    }else{
      echo("<br />");
      echo("<br />");
      $ki=sys_line("Nincs lez�rt szavaz�s",$mv_lang,$mv_langt,$mv_lang_db);
      echo("$ki.");
    }
  }




?>
