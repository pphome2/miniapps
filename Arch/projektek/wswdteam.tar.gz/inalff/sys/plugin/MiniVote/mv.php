<?php

// Helpdesk plugin --- PHP portalrobot
// (verzioadatok a konfiguracios fajlban)
//
// fejleszto: InalR Fejlesztoi Iroda

// plugin


  function mv($cim){
    global $plugin_menu,$mv_menu_start,$plugin_page,
           $plugin_data_1,$separator;

    if ($plugin_data_1<>""){
      $t=explode($separator,$plugin_data_1);
      switch ($t[0]){
        case "1":
          $cim=$plugin_page.$cim;
          mv_data($cim,$t[1]);
          break;
        case "2":
          echo("<br /><b>");
          echo($plugin_menu[$mv_menu_start+1]);
          echo("</b><br /><br />");
          $cim=$plugin_page.$cim;
          mv_aktpoll($cim,true);
          break;
      }
    }
    switch ($cim){
      case $plugin_menu[$mv_menu_start]:
        echo("<br /><b>");
        echo($plugin_menu[$mv_menu_start]);
        echo("</b><br /><br />");
        $cim=$plugin_page.$cim;
        mv_data($cim,"");
        break;
      case $plugin_menu[$mv_menu_start+1]:
        echo("<br /><b>");
        echo($plugin_menu[$mv_menu_start+1]);
        echo("</b><br /><br />");
        $cim=$plugin_page.$cim;
        mv_aktpoll($cim,true);
        break;
      case $plugin_menu[$mv_menu_start+2]:
        echo("<br /><b>");
        echo($plugin_menu[$mv_menu_start+2]);
        echo("</b><br /><br />");
        $cim=$plugin_page.$cim;
        mv_oldpoll($cim);
        break;
    }
  }


  function mv_init(){
    global $mv_langt,$user_admin,$mv_css,
           $dir_plugin,$mv_lang,$lang_system,
           $sql_mvn_n,$sql_mvn_t,$sql_mvn_name,
           $sql_mvt_n,$sql_mvt_t,$sql_mvt_name,
           $mv_menu_start,$mv_list_db,
           $dev_moduls,$mv_plugin_name,$mess_per_page,
           $mv_files,$usercode,$hd_show_userticket,
           $mv_akt_page;

    $mv_plugin_name="MiniVote";
    $inc_file="$dir_plugin/".$mv_plugin_name."/mv_inc.php";
    include("$inc_file");
    $x=0;
    $c=count($mv_files);
    while ($x<$c){
      $inc_file="$dir_plugin/".$mv_plugin_name."/".$mv_files[$x];
      include("$inc_file");
      $x++;
    }

    if ($mv_list_db>$mess_per_page){
      $mv_list_db=$mess_per_page;
    }
    $mv_lang="$dir_plugin/".$mv_plugin_name."/lang_$lang_system";
    sys_style($mv_css);
    $c=0;
    if ($user_admin){
      $ki=sys_line("Szavaz�s adminisztr�ci�",$mv_lang,$mv_langt,$mv_lang_db);
      $mv_menu[$c]=$ki;
      $mv_func[$c]="mv";
      $c++;
    }
    $ki=sys_line("Aktu�lis szavaz�s",$mv_lang,$mv_langt,$mv_lang_db);
    $mv_menu[$c]=$ki;
    $mv_func[$c]="mv";
    $c++;
    $ki=sys_line("Lez�rt szavaz�sok",$mv_lang,$mv_langt,$mv_lang_db);
    $mv_menu[$c]=$ki;
    $mv_func[$c]="mv";
    $c++;

    if ($c>0){
      $mv_menu_start=plugin_menu($mv_menu,$mv_func);
      $mv_akt_page=plugin_get_menu($mv_menu_start+1);
    }

    sql_plugin_init($sql_mvt_name,$sql_mvt_n,$sql_mvt_t);
    sql_plugin_init($sql_mvn_name,$sql_mvn_n,$sql_mvn_t);

    $c=count($dev_moduls);
    $dev_moduls[$c]=$mv_plugin_name;
  }

  // plugins close

  function mv_end(){
  }


?>
