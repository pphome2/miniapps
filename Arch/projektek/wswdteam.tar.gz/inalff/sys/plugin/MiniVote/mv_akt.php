<?php

// Helpdesk plugin --- PHP portalrobot
// (verzioadatok a konfiguracios fajlban)
//
// fejleszto: InalR Fejlesztoi Iroda

// plugin



  function mv_aktpoll($cim="",$page=false){
    global $usercode,$s_program,$sitepos,
           $sql_mvn_name,$sql_mvn_n,
           $sql_mvt_name,$sql_mvt_n,
           $pluginenv1,$plugin_data_1,
           $separator,$mv_plugin_name,
           $mv_lang,$mv_langt,$mv_lang_db,
           $mess_akt_page,$messpage,
           $mv_list_db,$mv_akt_page,
           $mv_akt_page;

    $sp=sys_env_find($sitepos);
    if ($cim<>""){
      sys_env_new($sitepos,$cim);
    }else{
      sys_env_new($sitepos,$mv_akt_page);
    }
    //echo("<br />");
    $ok=sys_data_post($dbx,$tkx,$tex);
    if ($ok){
      $x=0;
      while ($x<$dbx){
        $to[$x]=$tex[$x];
        $x++;
      }
      if ($dbx>1){
        $tomb=array("","","","");
        $txdd=sql_data_get($sql_mvt_name,$sql_mvt_n[0],$to[1]);
        $ddb=sql_result_db($txdd);
        if ($ddb>0){
          $tomb=sql_get_result_data($txdd,0);
          $tomb[3]=$tomb[3]+1;
          sql_data_update($sql_mvt_name,$sql_mvt_n,$sql_mvt_n[0],$to[1],$tomb);
        }
        $ki=sys_line("Adatok t�rol�sa megt�rt�nt",$mv_lang,$mv_langt,$mv_lang_db);
        echo("<br />$ki.<br /><br />");
      }else{
      }
    }
    $polltomb=array();
    $tx=sql_data_allget_desc($sql_mvn_name,1);
    $x=0;
    $okny=false;
    $ddb=sql_result_db($tx);
    while($x<$ddb){
      $polltomb=sql_get_result_data($tx,$x);
      if ($polltomb[2]==""){
        $okny=true;
        $x=$ddb;
      }
      $x++;
    }
    if ($okny){
      $txb=sql_data_allget($sql_mvt_name);
      $x=0;
      $y=0;
      $vpoll1=array();
      $vpoll2=array();
      $ddb=sql_result_db($txb);
      $allvote=0;
      while($x<$ddb){
        $poll=sql_get_result_data($txb,$x);
        $pollx[$x]=$poll;
        if ($poll[1]==$polltomb[0]){
          $allvote+=$poll[3];
          $vpoll1[$y]=$poll[0];
          $vpoll2[$y]=$poll[2];
          $y++;
        }
        $x++;
      }
      if (!$ok){
        if ($page){
          echo("<br /><br />");
        }
        //echo("<div class='div_p'>$polltomb[2]</div>");
        $e=sys_env_pack();

        echo("<center>");
        echo("<form method='post' action='./$s_program?$e'>");
        echo("<input class='input_r1' type='hidden' id='1' name='1' value='$polltomb[0]' />");
        if ($page){
          echo("<div class='raddiv_r2'>");
        }else{
          echo("<div class='raddiv_r2'>");
        }
        echo("<b>$polltomb[1]</b>");
        echo("</div><br />");

        $x=0;
        $y=count($vpoll1);
        while($x<$y){
          echo("<div class='page_table'>");
          if ($page){
            echo("<div class='raddiv_r1'>");
          }else{
            echo("<div class='raddiv_r2'>");
          }
          $xx=$x+2;
          echo("<input class='radio_r2' type='radio' id='$xx' name='$xx' value='$vpoll1[$x]' size='120' />$vpoll2[$x]");
          echo("</div>");
          echo("</div>");
          $x++;
        }

        echo("<br />");
        echo("<br />");

        if ($page){
          $ki=sys_line("Mehet",$mv_lang,$mv_langt,$mv_lang_db);
          echo("<button class='button_1' type='submit' id='b7' name='b7' value='$ki'>$ki</button>");
        }else{
          $ki=sys_line("Tov�bb a szavaz�shoz",$mv_lang,$mv_langt,$mv_lang_db);
          echo("<a class='href' href='./$s_program?$e'>$ki</a>");
        }
        echo("</form>");
        echo("</center>");
        if ($page){
          echo("<br />");
        }
      }
      if ((!strpos($plugin_data_1,$mv_plugin_name))and(!$ok)){
        $s="2".$separator.$mv_plugin_name;
        sys_env_new($pluginenv1,$s);
        $sx=sys_env_find($sitepos);
        sys_env_new($sitepos,$sp);
        $e=sys_env_pack();
        sys_env_del($pluginenv1);
        sys_env_new($sitepos,$sx);
        $ki=sys_line("A szavaz�s �ll�sa",$mv_lang,$mv_langt,$mv_lang_db);
        echo("<center>");
        echo("<a class='href' href=./$s_program?$e>$ki</a>");
        echo("</center>");
      }else{
        $ki=sys_line("A szavaz�s �ll�sa",$mv_lang,$mv_langt,$mv_lang_db);
        echo("<b>$ki</b>");
        echo("<br />");
        echo("<br />");
        $onevote=100/$allvote;
        $x=0;
        $c=count($pollx);
        while($x<$c){
          $poll=$pollx[$x];
          $v=$poll[3]*$onevote;
          $v=round($v,0);
          echo("<div class='mv_div1'>$poll[2] ( $v % )</div>");
          //echo("<div class='mv_div2'>$v % ($poll[3])</div>");
          //echo("<div class='mv_hr1'><hr style='width=$v%;height=10px;'></div>");
          echo("<div class='mv_hr1'>");
          echo("<div style='width:$v%;background-color:red;'>.</div>");
          echo("</div>");
          $x++;
        }
      }
      if ($page){
        echo("<br />");
        echo("<br />");
      }
    }else{
      $ki=sys_line("Nincs nyitott szavaz�s",$mv_lang,$mv_langt,$mv_lang_db);
      echo("$ki.");
    }
    sys_env_new($sitepos,$sp);
  }




?>
