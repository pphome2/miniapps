<?php

// EShop plugin --- PHP portalrobot
// (verzioadatok a konfiguracios fajlban)
//
// fejleszto: InalR Fejlesztoi Iroda

// plugin


  function es_cat($cim){
    global $sql_esc_name,$sql_esc_n,$sql_esc_t,
           $es_lang,$es_langt,$deldata,$delkod,
           $s_program,$sitepos,$es_res,
           $es_none_code,$es_list_db,
           $mess_akt_page,$messpage;

    $p=sys_env_find($sitepos);
    sys_env_new($sitepos,$cim);
    if ($delkod<>""){
      sql_data_del($sql_esc_name,$sql_esc_n[0],$delkod);
    }
    $ok=sys_data_post($db,$tkx,$tex);
    if ($ok){
      $t[0]=$tex[0];
      $t[1]=$tex[1];
      $t[2]=$tex[2];
      $t[3]=$tex[3];
      $t[4]=$tex[4];
      sql_data_add($sql_esc_name,$t);
    }
    $es_res=sql_data_allget($sql_esc_name,$sql_esc_n[0]);
    $db=sql_result_db($es_res);
    $ki=sys_line("Term�k kateg�ri�k",$es_lang,$es_langt,$es_lang_db);
    echo("<div class='div_p'><b>$ki</b></div>");
    echo("<br />");
    echo("<center><div class='es_table'>");
    $ki=sys_line("Feladat",$es_lang,$es_langt,$es_lang_db);
    echo("<div class='div_a1'><b>$ki</b></div>");
    $ki=sys_line("Sz�l� kateg�ria",$es_lang,$es_langt,$es_lang_db);
    echo("<div class='div_a2'><b>$ki</b></div>");
    $ki=sys_line("Kateg�ria neve (le�r�sa)",$es_lang,$es_langt,$es_lang_db);
    echo("<div class='div_a3'><b>$ki</b></div>");
    echo("</div>");
    $ki=sys_line("T�r�l",$es_lang,$es_langt,$es_lang_db);
    $x=0;
    $tomb2=array();
    $y=0;
    $x=0;
    site_pageing_init($db,$tol,$ig,$es_list_db,$mess_akt_page);
    $x=$tol;
    while ($x<$ig){
      $tomb=sql_get_result_data($es_res,$x);
      if ($tomb[0]<>""){
        $tomb2[$y]=$tomb[1];
        $y++;
        echo("<center><div class='es_table'>");
        sys_env_new($deldata,$tomb[0]);
        $e=sys_env_pack();
        echo("<div class='div_a1'>");
        echo("<a class='href' href='./$s_program?$e'>$ki</a>");
        echo("</div>");
        echo("<div class='div_a2'>$tomb[2]");
        echo("</div>");
        echo("<div class='div_a3'>$tomb[1] ($tomb[3])</div>");
        echo("</div>");
      }
      $x++;
    }
    echo("</div>");
    sys_env_del($deldata);
    sys_env_new($messpage,$mess_akt_page);
    site_pageing($db,$es_list_db,$mess_akt_page,$messpage);
    sys_env_del($messpage);
    echo("<br /><br />");
    $ki=sys_line("�j kateg�ria",$es_lang,$es_langt,$es_lang_db);
    echo("<div class='div_p'><b>$ki</b></div>");
    echo("<br />");
    echo("<div class='es_table'>");
    sys_env_del($deldata);
    $e=sys_env_pack();
    echo("<form method='post' enctype='multipart/form-data' action='./$s_program?$e'>");
    $ki=sys_line("Kateg�ria neve",$es_lang,$es_langt,$es_lang_db);
    $ti=sys_time_code();
    echo("<input class='input_r1' type='hidden' id='ucat1' name='ucat1' value='$ti' />");
    echo("<div class='div_r1'>$ki: </div>");
    echo("<input class='input_r1' type='text' id='ucat2' name='ucat2' size='120' maxlength='100' /><br />");
    $ki=sys_line("Sz�l� kateg�ria",$es_lang,$es_langt,$es_lang_db);
    echo("<div class='div_r1'>$ki: </div>");
    echo("<select class='select_r1' id='ucat3' name='ucat3'>");
    echo("<option value='$es_none_code'>$es_none_code</option>");
    $y2=0;
    while ($y2<$y){
      echo("<option value='$tomb2[$y2]'>$tomb2[$y2] </option>");
      $y2++;
    }
    echo("</select>");
    $ki=sys_line("Kateg�ria le�r�sa",$es_lang,$es_langt,$es_lang_db);
    echo("<div class='div_r1'>$ki: </div>");
    echo("<input class='input_r1' type='text' id='ucat4' name='ucat4' size='120' maxlength='200' /><br />");
    $ki=sys_line("Kateg�ria k�pe",$es_lang,$es_langt,$es_lang_db);
    echo("<div class='div_r1'>$ki: </div>");
    echo("<input class='input_r1' type='text' id='ucat5' name='ucat5' size='120' maxlength='30' /><br /><br />");
    $ki=sys_line("Mehet",$es_lang,$es_langt,$es_lang_db);
    echo("<button class='button_1' type='submit' id='b01' name='b01' value='$ki'>$ki</button>");
    echo("</form>");
    echo("<br /></ddiv></center><br />");
    sys_env_new($sitepos,$p);
  }

?>
