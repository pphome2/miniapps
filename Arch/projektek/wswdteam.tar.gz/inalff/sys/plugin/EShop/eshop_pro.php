<?php

// EShop plugin --- PHP portalrobot
// (verzioadatok a konfiguracios fajlban)
//
// fejleszto: InalR Fejlesztoi Iroda

// plugin


  function es_products($c1){
    global $sql_esp_name,$sql_esp_n,$sql_esp_t,
           $es_lang,$es_langt,$deldata,$delkod,
           $s_program,$sitepos,$es_res,
           $es_none_code,$es_money_code,
           $pluginenv1,$plugin_data_1,
           $es_list_db,$es_img_dir,
           $es_product_status,$es_product_in,
           $mess_akt_page,$messpage;

    $p=sys_env_find($sitepos);
    sys_env_new($sitepos,$c1);
    if ($delkod<>""){
      $res=sql_data_get($sql_esp_name,$sql_esp_n[0],$delkod);
      $db=sql_result_db($res);
      if ($db>0){
        $tomb=sql_get_result_data($res,0);
        if ($tomb[9]<>""){
          $f1=$es_img_dir."/".$tomb[9];
          sys_file_del($f1);
        }
        if ($tomb[10]<>""){
          $f2=$es_img_dir."/".$tomb[10];
          sys_file_del($f2);
        }
        sql_data_del($sql_esp_name,$sql_esp_n[0],$delkod);
      }
    }
    $t[0]=sys_time_code();
    $t[1]="";
    $t[2]="";
    $t[3]="";
    $t[4]="";
    $t[5]="";
    $t[6]="";
    $t[7]="";
    $t[8]="";
    $t[9]="";
    $t[10]="";
    $t[11]="";
    $t[12]="";
    $t[13]="";
    $db=0;
    if ($plugin_data_1<>""){
      $res=sql_data_get($sql_esp_name,$sql_esp_n[0],$plugin_data_1);
      $db=sql_result_db($res);
      if ($db>0){
        $tomb=sql_get_result_data($res,0);
        $t[0]=$tomb[0];
        $t[1]=$tomb[1];
        $t[2]=$tomb[2];
        $t[3]=$tomb[3];
        $t[4]=$tomb[4];
        $t[5]=$tomb[5];
        $t[6]=$tomb[6];
        $t[7]=$tomb[7];
        $t[8]=$tomb[8];
        $t[9]=$tomb[9];
        $t[10]=$tomb[10];
        $t[11]=$tomb[11];
        $t[12]=$tomb[12];
        $t[13]=$tomb[13];
      }
    }
    if (!sys_file_upload($es_img_dir)){
      $ok=sys_data_post($db,$tkx,$tex);
      if ($ok){
        $t[0]=$tex[0];
        $t[1]=$tex[1];
        $t[2]=$tex[2];
        $t[3]=$tex[3];
        $t[4]=$tex[4];
        $t[5]=$tex[5];
        $t[6]=$tex[6];
        $t[7]=$tex[7];
        $t[8]=$tex[8];
        $t[9]=$tex[9];
        $t[10]=$tex[10];
        $t[11]=$tex[11];
        $t[12]=$tex[12];
        $t[13]=$tex[13];
        $r=sql_data_get($sql_esp_name,$sql_esp_n[0],$t[0]);
        $db=sql_result_db($r);
        if ($db==0){
          sql_data_add($sql_esp_name,$t);
        }else{
          sql_data_update($sql_esp_name,$sql_esp_n,$sql_esp_n[0],$t[0],$t);
        }
        $t[0]=sys_time_code();
        $t[1]="";
        $t[2]="";
        $t[3]="";
        $t[4]="";
        $t[5]="";
        $t[6]="";
        $t[7]="";
        $t[8]="";
        $t[9]="";
        $t[10]="";
        $t[11]="";
        $t[12]="";
        $t[13]="";
      }
    }
    $res=sql_data_allget($sql_esp_name,$sql_esp_n[0]);
    $db=sql_result_db($res);
    $ki=sys_line("Term�kek",$es_lang,$es_langt,$es_lang_db);
    echo("<div class='div_p'><b>$ki</b></div>");
    echo("<br />");
    echo("<center>");
    echo("<div class='es_table'>");
    $ki=sys_line("Feladat",$es_lang,$es_langt,$es_lang_db);
    echo("<div class='div_a1'><b>$ki</b></div>");
    $ki=sys_line("Term�k neve",$es_lang,$es_langt,$es_lang_db);
    echo("<div class='div_a2'><b>$ki</b></div>");
    $ki=sys_line("Kateg�ria (r�vid le�r�s), �rak, rakt�rk�szlet",$es_lang,$es_langt,$es_lang_db);
    echo("<div class='div_a3'><b>$ki</b></div>");
    echo("</div>");
    if ($db>0){
      $ki=sys_line("T�r�l",$es_lang,$es_langt,$es_lang_db);
      $ki2=sys_line("M�dos�t",$es_lang,$es_langt,$es_lang_db);
      $ki3=sys_line("Rakt�ron",$es_lang,$es_langt,$es_lang_db);
      $ki4=sys_line("Elad�si �r",$es_lang,$es_langt,$es_lang_db);
      $ki5=sys_line("Sz�ll�t�s",$es_lang,$es_langt,$es_lang_db);
      site_pageing_init($db,$tol,$ig,$es_list_db,$mess_akt_page);
      $x=$tol;
      $tomb2=array();
      while ($x<$ig){
        $tomb=sql_get_result_data($res,$x);
        if ($tomb[0]<>""){
          echo("<div class='es_table'>");
          echo("<div class='div_a1'>");
          sys_env_new($messpage,$mess_akt_page);
          sys_env_new($deldata,$tomb[0]);
          $e=sys_env_pack();
          sys_env_del($deldata);
          echo("<a class='href' href='./$s_program?$e'>$ki</a><br />");
          sys_env_new($pluginenv1,$tomb[0]);
          $e=sys_env_pack();
          sys_env_del($pluginenv1);
          echo("<a class='href' href='./$s_program?$e'>$ki2</a>");
          echo("</div>");
          echo("<div class='div_a2'>$tomb[1]");
          echo("</div>");
          echo("<div class='div_a3'>$tomb[2] ($tomb[3])<br />");
          echo("$ki4 : <b>$tomb[9] $es_money_code</b> ($tomb[8] $es_money_code). ");
          echo("$ki3: <b>$tomb[10]. </b> $ki5: <b>$tomb[7]</b>.");
          echo("</div>");
          echo("</div>");
        }
        $x++;
      }
      echo("</div>");
      echo("<br />");
      echo("<br />");
      sys_env_new($messpage,$mess_akt_page);
      site_pageing($db,$es_list_db,$mess_akt_page,$messpage);
      echo("<br />");
    }
    echo("<br />");
    es_form_prod($c1,$t);
    site_edit_help();
    sys_env_new($sitepos,$p);
    sys_env_del($messpage);
    sys_env_del($pluginenv1);
  }


?>
