<?php

// EShop plugin --- PHP portalrobot
// (verzioadatok a konfiguracios fajlban)
//
// fejleszto: InalR Fejlesztoi Iroda

// plugin


  function es_search($c1){
    global $sql_esp_name,$sql_esp_n,$sql_esp_t,
           $es_lang,$es_langt,
           $s_program,$sitepos,
           $usercode,$plugin_page,
           $es_none_code,$es_money_code,
           $pluginenv1,$plugin_data_1,
           $pluginenv2,$plugin_data_2,
           $es_img_dir,$es_list_db,
           $mess_akt_page,$messpage,
           $searchpar,$searchdata,
           $separator;

    $p=sys_env_find($sitepos);
    sys_env_new($sitepos,$c1);

    $res=sql_data_allget($sql_esp_name,$sql_esp_n[0]);
    $db=sql_result_db($res);
    $x=0;
    $gy=array("");
    $gydb=0;
    $kat=array("");
    $katdb=0;
    while ($x<$db){
      $tomb=sql_get_result_data($res,$x);
      if (($gy[$gydb]<>$tomb[5])and($tomb[5]<>"")){
        $gydb++;
        $gy[$gydb]=$tomb[5];
      }
      if (($kat[$katdb]<>$tomb[2])and($tomb[2]<>"")){
        $katdb++;
        $kat[$katdb]=$tomb[2];
      }
      $x++;
    }
    $mit="";
    $gyar="";
    $kate="";
    $alar="";
    $fear="";
    $rak=false;
    $u1="";
    $u2="";
    $u3="";
    $u4="";
    $u5="";
    $u6="";
    $ok=sys_data_post($dbbe,$tkx,$tex);
    if ($ok){
      $u1=$tex[0];
      $u2=$tex[1];
      $u3=$tex[2];
      $u4=$tex[3];
      $u5=$tex[4];
      $u6=$tex[5];
      $mit=$tex[0];
      $gyar=$tex[1];
      $kate=$tex[2];
      $alar=$tex[3];
      $fear=$tex[4];
      if ($tex[5]=='on'){
        $rak=true;
      }else{
        $rak=false;
      }
    }else{
      $sor=$searchdata;
      if ($sor<>""){
        $t=explode($separator,$sor);
        $ok=true;
        $mit=$t[0];
        $gyar=$t[1];
        $kate=$t[2];
        $alar=$t[3];
        $fear=$t[4];
        if ($t[5]=='on'){
          $rak=true;
        }else{
          $rak=false;
        }
        $u1=$t[0];
        $u2=$t[1];
        $u3=$t[2];
        $u4=$t[3];
        $u5=$t[4];
        $u6=$t[5];
      }
    }
    $e=sys_env_pack();
    echo("<br />");
    $ki=sys_line("Keres�s a term�kek k�z�tt",$es_lang,$es_langt,$es_lang_db);
    echo("<div class='div_p'><b>$ki</b></div>");
    echo("<br />");
    echo("<center>");
    echo("<form method='post' enctype='multipart/form-data' action='./$s_program?$e'>");
    $ki=sys_line("Keresend�",$es_lang,$es_langt,$es_lang_db);
    echo("<div class='div_r1'>$ki: </div>");
    echo("<input class='input_r1' type='text' id='u1' name='u1' value='$u1' size='120' maxlength='150' /><br />");
    $ki=sys_line("Gy�rt�",$es_lang,$es_langt,$es_lang_db);
    echo("<div class='div_r1'>$ki: </div>");
    echo("<select class='select_r1' id='u2' name='u2'>");
    $sdb=0;
    $rdb=count($gy);
    while ($sdb<$rdb){
      if ($u2==$gy[$sdb]){
        echo("<option selected='selected' value='$gy[$sdb]'>$gy[$sdb] </option>");
      }else{
        echo("<option value='$gy[$sdb]'>$gy[$sdb] </option>");
      }
      $sdb+=1;
    }
    echo("</select>");
    echo("<br />");
    $ki=sys_line("Kateg�ria",$es_lang,$es_langt,$es_lang_db);
    echo("<div class='div_r1'>$ki: </div>");
    echo("<select class='select_r1' id='u3' name='u3'>");
    $sdb=0;
    $rdb=count($kat);
    while ($sdb<$rdb){
      if ($u3==$kat[$sdb]){
        echo("<option selected='selected' value='$kat[$sdb]'>$kat[$sdb] </option>");
      }else{
        echo("<option value='$kat[$sdb]'>$kat[$sdb] </option>");
      }
      $sdb+=1;
    }
    echo("</select>");
    echo("<br />");
    $ki=sys_line("Als� �r",$es_lang,$es_langt,$es_lang_db);
    echo("<div class='div_r1'>$ki: </div>");
    echo("<input class='input_r1' type='text' id='u4' name='u4' value='$u4' size='8' maxlength='150' /><br />");
    $ki=sys_line("Fels� �r",$es_lang,$es_langt,$es_lang_db);
    echo("<div class='div_r1'>$ki: </div>");
    echo("<input class='input_r1' type='text' id='u5' name='u5' value='$u5' size='8' maxlength='150' /><br />");
    $ki=sys_line("Csak rakt�ron l�v� term�kek",$es_lang,$es_langt,$es_lang_db);
    echo("<div class='div_r1'>$ki: </div>");
    if ($u6=="on"){
      echo("<input class='input_r1' type='checkbox' id='u6' name='u6' checked='checked' /><br />");
    }else{
      echo("<input class='input_r1' type='checkbox' id='u6' name='u6'  /><br />");
    }
    echo("<br />");
    $ki=sys_line("Mehet",$es_lang,$es_langt,$es_lang_db);
    echo("<button class='button_1' type='submit' id='b01' name='b01' value='$ki'>$ki</button>");
    echo("</form>");
    echo("</center>");

    if ($mess_akt_page>0){
      $ok=true;
    }
    if (($mit=="")and($gyar=="")and($kate=="")){
      $ok=false;
      $ki=sys_line("Nincs megadott felt�tel",$es_lang,$es_langt,$es_lang_db);
      $ki0=sys_line("Az els� h�rom felt�tel valamelyike k�telez�",$es_lang,$es_langt,$es_lang_db);
      echo("<div class='div_stat'>$ki.($ki0.)</div>");
    }
    if ($ok){
      $uc=sys_env_find($usercode);
      $ki2=sys_line("Nincs k�p",$es_lang,$es_langt,$es_lang_db);
      $ki3=sys_line("R�szletek",$es_lang,$es_langt,$es_lang_db);
      $ki4=sys_line("Kos�rba",$es_lang,$es_langt,$es_lang_db);
      $ki5=sys_line("Kateg�ria",$es_lang,$es_langt,$es_lang_db);
      $ki6=sys_line("R�szletek",$es_lang,$es_langt,$es_lang_db);
      $ki7=sys_line("Sz�ll�t�s",$es_lang,$es_langt,$es_lang_db);
      $ki8=sys_line("Gy�rt�",$es_lang,$es_langt,$es_lang_db);
      $ki9=sys_line("�sszesen",$es_lang,$es_langt,$es_lang_db);
      $ki10=sys_line("Nincs",$es_lang,$es_langt,$es_lang_db);
      $ki11=sys_line("tal�lat",$es_lang,$es_langt,$es_lang_db);
      $ki12=sys_line("Elad�si �r",$es_lang,$es_langt,$es_lang_db);
      site_pageing_init($db,$tol,$ig,$es_list_db,$mess_akt_page);
      $odb=0;
      //$x=$tol;
      //echo("$tol-$ig=");
      $x=0;
      while ($x<$db){
        $tomb=array();
        $tomb=sql_get_result_data($res,$x);
        $ok=true;
        if (($ok)and($mit<>"")){
          $mib=" ".$tomb[1].$tomb[3].$tomb[4];
          $f=strpos($mib,$mit);
          if ($f==false){
            $ok=false;
          }
        }
        if (($ok)and($gyar<>"")){
          $mib=" ".$tomb[5];
          $f=strpos($mib,$gyar);
          if ($f==false){
            $ok=false;
          }
        }
        if (($ok)and($kate<>"")){
          $mib=" ".$tomb[2];
          $f=strpos($mib,$kate);
          if ($f==false){
            $ok=false;
          }
        }
        if (($ok)and($alar<>"")and($fear<>"")){
          if (($tomb[9]<$alar)or($tomb[9]>$fear)){
            $ok=false;
          }
        }
        if (($ok)and($rak)){
          if ($tomb[10]<1){
            $ok=false;
          }
        }
        if ($ok){
          if (($odb>=$tol)and($odb<$ig)){
            echo("<div class='es_table'>");
            echo("<br />");
            echo("<div class='es_prodline'>");
            $cc=$plugin_page.$tomb[2];
            sys_env_new($sitepos,$cc);
            sys_env_new($pluginenv1,$tomb[0]);
            $e=sys_env_pack();
            echo("<div class='es_a1'>");
            if ($tomb[9]==""){
              echo("$ki2");
            }else{
              $d=$es_img_dir."/".$tomb[9];
              if (file_exists($d)){
                echo("<a class='href' href='./$s_program?$e'><img class='img' src='$d'></a>");
              }else{
                echo("$ki2");
              }
            }
            echo("</div>");
            echo("<div class='es_a2'>");
            echo("<a class='href' href='./$s_program?$e'><b>$tomb[1]</b></a>");
            echo("</div>");
            echo("<div class='es_a3'>$tomb[3]<br /><br />");
            echo("$ki8 : <b>$tomb[5]</b> <br />");
            echo("$ki12 : <b>$tomb[9] $es_money_code</b> ($tomb[8] $es_money_code). ");
            echo("$ki7 : <b>$tomb[7]</b>.");
            echo("<br />");
            echo("<br />");
            echo("<a class='href' href='./$s_program?$e'><b>$ki3</b></a>");
            echo("</div>");
            echo("<div class='es_a4'>");
            if ($uc<>""){
              sys_env_new($pluginenv2,$tomb[0]);
              $e=sys_env_pack();
              sys_env_del($pluginenv2);
              echo("<a class='href' href='./$s_program?$e'><b>$ki4</b></a>");
            }else{
            }
            echo("</div>");
            echo("</div>");
            echo("</div>");
            echo("<br />");
          }
          $odb++;
        }
        $x++;
      }
      echo("<br />");
      $sor=$mit.$separator.$gyar.$separator.$kate.$separator.$alar.$separator.$fear;
      if ($rak){
        $sor=$sor.$separator."on";
      }else{
        $sor=$sor.$separator."off";
      }
      sys_env_new($searchpar,$sor);
      sys_env_del($pluginenv1);
      sys_env_new($sitepos,$c1);
      if ($odb>0){
        echo("<div class='div_stat'>$ki9: $odb $ki11.</div>");
        sys_env_new($messpage,$mess_akt_page);
        site_pageing($odb,$es_list_db,$mess_akt_page,$messpage);
        sys_env_del($messpage);
      }else{
        echo("<div class='div_stat'>$ki10 $ki11.</div>");
      }
      sys_env_del($searchpar);
    }
    sys_env_del($messpage);
    sys_env_del($pluginenv1);
  }

?>
