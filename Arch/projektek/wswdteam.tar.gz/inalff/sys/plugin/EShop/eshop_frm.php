<?php

// EShop plugin --- PHP portalrobot
// (verzioadatok a konfiguracios fajlban)
//
// fejleszto: InalR Fejlesztoi Iroda

// plugin


  function es_form_adm($cim,$t,$utomb){
    global $es_money_code,$es_admin,$es_order_status,
           $sql_eso_name,$sql_eso_n,$sql_eso_t,
           $sql_est_name,$sql_est_n,$sql_est_t,
           $sql_esp_name,$sql_esp_n,$sql_esp_t,
           $es_lang,$es_langt,$es_list_db,
           $usercode,$deldata,$delkod,
           $user_admin,$pluginenv1,$plugin_data_1,
           $messpage,$mess_akt_page,
           $sitepos,$s_program,
           $es_admin_email;

    $ki=sys_line("Megrendel�s",$es_lang,$es_langt,$es_lang_db);
    echo("<div class='div_p'><b>$ki</b></div>");
    echo("<br />");
    echo("<div class='es_table'>");
    sys_env_new($sitepos,$cim);
    $e=sys_env_pack();
  
    $ki=sys_line("N�v",$es_lang,$es_langt,$es_lang_db);
    echo("<div class='div_r1'>$ki: </div>");
    echo("<input class='input_r1' type='text' id='u0' name='u0' value='$utomb[5]' size='120' maxlength='150' readonly /><br />");
    $ki=sys_line("C�m",$es_lang,$es_langt,$es_lang_db);
    echo("<div class='div_r1'>$ki: </div>");
    echo("<input class='input_r1' type='text' id='u1' name='u1' value='$utomb[6]' size='120' maxlength='150' readonly /><br />");
    $ki=sys_line("E-mail",$es_lang,$es_langt,$es_lang_db);
    echo("<div class='div_r1'>$ki: </div>");
    echo("<input class='input_r1' type='text' id='u2' name='u2' value='$utomb[7]' size='120' maxlength='150' readonly /><br />");
    $ki=sys_line("Fizetend�",$es_lang,$es_langt,$es_lang_db);
    echo("<div class='div_r1'>$ki: </div>");
    $sor="$t[3] $es_money_code";
    echo("<input class='input_r1' type='text' id='u3' name='u3' value='$sor' size='120' maxlength='150' readonly /><br />");
    $ki=sys_line("Kisz�ll�t�si c�m",$es_lang,$es_langt,$es_lang_db);
    echo("<div class='div_r1'>$ki: </div>");
    echo("<input class='input_r1' type='text' id='ucat5' name='ucat5' value='$t[4]' size='120' maxlength='150' readonly /><br />");
  
    echo("<form method='post' enctype='multipart/form-data' action='./$s_program?$e'>");
    echo("<input class='input_r1' type='hidden' id='ucat1' name='ucat1' value='$t[0]' />");
    echo("<input class='input_r1' type='hidden' id='ucat2' name='ucat2' value='$t[1]' />");
  
    $ki=sys_line("Megrendel�s st�tusza",$es_lang,$es_langt,$es_lang_db);
    echo("<div class='div_r1'>$ki: </div>");
    echo("<select class='select_r1' id='ucat3' name='ucat3'>");
    $y2=count($es_order_status);
    $y=0;
    while ($y<$y2){
      echo("<option ");
      if ($t[2]==$es_order_status[$y]){
        echo("selected='selected' ");
      }
      echo("value='$es_order_status[$y]'>$es_order_status[$y] </option>");
      $y++;
    }
    echo("</select>");
    echo("<input class='input_r1' type='hidden' id='ucat4' name='ucat4' value='$t[3]' />");
    echo("<input class='input_r1' type='hidden' id='ucat5' name='ucat5' value='$t[4]' />");
    $ki=sys_line("El�rhet�s�g (megjegyz�s)",$es_lang,$es_langt,$es_lang_db);
    echo("<div class='div_r1'>$ki: </div>");
    echo("<textarea class='textarea_e1' id='ucat6' name='ucat6' cols='70' rows='5'>");
    echo("$t[5]</textarea><br />");
    $ki=sys_line("�gyf�l automatikus ki�rtes�t�se",$es_lang,$es_langt,$es_lang_db);
    echo("<div class='div_r1'>$ki: </div>");
    echo("<input class='input_r1' type='checkbox' id='ucat7' name='ucat7' /><br />");
    echo("<br />");
    $ki=sys_line("Mehet",$es_lang,$es_langt,$es_lang_db);
    echo("<button class='button_1' type='submit' id='b01' name='b01' value='$ki'>$ki</button>");
    echo("</form>");
    echo("<br /></div></center><br />");
    $ki0=sys_line("�gyf�l ki�rtes�t�se (levelez�)",$es_lang,$es_langt,$es_lang_db);
    $ki1=sys_line("�rtes�t�s web�ruh�zi rendel�sr�l (rendszer)",$es_lang,$es_langt,$es_lang_db);
    echo("<br /><a href='mailto:$utomb[7]?Subject=$ki1'>$ki0: $utomb[7]</a><br /><br /><br />");

  }



  function es_form_prod($c1,$t){
    global $sql_esp_name,$sql_esp_n,$sql_esp_t,
           $es_lang,$es_langt,$deldata,$delkod,
           $s_program,$sitepos,$es_res,
           $es_none_code,$es_money_code,
           $pluginenv1,$plugin_data_1,
           $es_list_db,$es_img_dir,
           $es_product_status,$es_product_in,
           $mess_akt_page,$messpage;

    $ki=sys_line("�j term�k / adatm�dos�t�s",$es_lang,$es_langt,$es_lang_db);
    echo("<div class='div_p'><b>$ki</b></div>");
    echo("<br />");
    echo("<div class='es_table'>");
    sys_env_del($deldata);
    $e=sys_env_pack();
    echo("<form method='post' enctype='multipart/form-data' action='./$s_program?$e'>");
    echo("<input class='input_r1' type='hidden' id='ucat1' name='ucat1' value='$t[0]' />");
    $ki=sys_line("Term�k neve",$es_lang,$es_langt,$es_lang_db);
    echo("<div class='div_r1'>$ki: </div>");
    echo("<input class='input_r1' type='text' id='ucat2' name='ucat2' value='$t[1]' size='120' maxlength='150' /><br />");
    $ki=sys_line("Kateg�ria",$es_lang,$es_langt,$es_lang_db);
    echo("<div class='div_r1'>$ki: </div>");
    echo("<select class='select_r1' id='ucat3' name='ucat3'>");
    $y2=sql_result_db($es_res);
    $y=0;
    while ($y<$y2){
      $tomb=sql_get_result_data($es_res,$y);
      echo("<option value='$tomb[1]'>$tomb[1] </option>");
      $y++;
    }
    echo("</select>");
    $ki=sys_line("R�vid le�r�s (kulcsszavakkal)",$es_lang,$es_langt,$es_lang_db);
    echo("<div class='div_r1'>$ki: </div>");
    echo("<input class='input_r1' type='text' id='ucat4' name='ucat4' value='$t[3]' size='120' maxlength='200' /><br />");
    $ki=sys_line("R�szletes le�r�s",$es_lang,$es_langt,$es_lang_db);
    echo("<div class='div_r1'>$ki: </div>");
    echo("<textarea class='textarea_e1' id='ucat5' name='ucat5' cols='70' rows='5'>");
    echo("$t[4]</textarea><br />");
    $ki=sys_line("Gy�rt�",$es_lang,$es_langt,$es_lang_db);
    echo("<div class='div_r1'>$ki: </div>");
    echo("<input class='input_r1' type='text' id='ucat6' name='ucat6' value='$t[5]' size='120' maxlength='150' /><br />");
    $ki=sys_line("Beszerz�s",$es_lang,$es_langt,$es_lang_db);
    echo("<div class='div_r1'>$ki: </div>");
    echo("<select class='select_r1' id='ucat7' name='ucat7'>");
    $sdb=0;
    $rdb=count($es_product_status);
    while ($sdb<$rdb){
      if ($t[6]==$es_product_status[$sdb]){
        echo("<option selected='selected' value='$es_product_status[$sdb]'>$es_product_status[$sdb] </option>");
      }else{
        echo("<option value='$es_product_status[$sdb]'>$es_product_status[$sdb] </option>");
      }
      $sdb+=1;
    }
    echo("</select>");
    $ki=sys_line("Sz�ll�t�si id�",$es_lang,$es_langt,$es_lang_db);
    echo("<div class='div_r1'>$ki: </div>");
    echo("<select class='select_r1' id='ucat8' name='ucat8'>");
    $sdb=0;
    $rdb=count($es_product_in);
    while ($sdb<$rdb){
      if ($t[7]==$es_product_in[$sdb]){
        echo("<option selected='selected' value='$es_product_in[$sdb]'>$es_product_in[$sdb] </option>");
      }else{
        echo("<option value='$es_product_in[$sdb]'>$es_product_in[$sdb] </option>");
      }
      $sdb+=1;
    }
    echo("</select>");
    $ki=sys_line("Nett� �r",$es_lang,$es_langt,$es_lang_db);
    echo("<div class='div_r1'>$ki: </div>");
    echo("<input class='input_r1' type='text' id='ucat9' name='ucat9' value='$t[8]' size='120' maxlength='12' /><br />");
    $ki=sys_line("Elad�si �r",$es_lang,$es_langt,$es_lang_db);
    echo("<div class='div_r1'>$ki: </div>");
    echo("<input class='input_r1' type='text' id='ucat10' name='ucat10' value='$t[9]' size='120' maxlength='12' /><br />");
    $ki=sys_line("Rakt�r- (el�rhet�) k�szlet",$es_lang,$es_langt,$es_lang_db);
    echo("<div class='div_r1'>$ki: </div>");
    echo("<input class='input_r1' type='text' id='ucat11' name='ucat11' value='$t[10]' size='120' maxlength='12' /><br />");
    $ki=sys_line("Term�kb�l eladott ",$es_lang,$es_langt,$es_lang_db);
    echo("<div class='div_r1'>$ki: </div>");
    echo("<input class='input_r1' type='text' id='ucat12' name='ucat12' value='$t[11]' size='120' maxlength='12' /><br />");
    $ki=sys_line("Kis k�p neve",$es_lang,$es_langt,$es_lang_db);
    echo("<div class='div_r1'>$ki: </div>");
    echo("<input class='input_r1' type='text' id='ucat13' name='ucat13' value='$t[12]' size='120' maxlength='30' /><br />");
    $ki=sys_line("Nagy k�p neve",$es_lang,$es_langt,$es_lang_db);
    echo("<div class='div_r1'>$ki: </div>");
    echo("<input class='input_r1' type='text' id='ucat14' name='uca14' value='$t[13]' size='120' maxlength='30' /><br />");
    echo("<br />");
    $ki=sys_line("Mehet",$es_lang,$es_langt,$es_lang_db);
    echo("<button class='button_1' type='submit' id='b01' name='b01' value='$ki'>$ki</button>");
    echo("</form>");
    echo("<br /></center>");
    $ki=sys_line("K�p felt�lt�se k�pt�rba",$es_lang,$es_langt,$es_lang_db);
    echo("<br /><div class='div_p'><b>$ki</b></div>");
    echo("<br /><br />");
    echo("<center>");
    echo("<form method='post' enctype='multipart/form-data' action='./$s_program?$e'>");
    $ki=sys_line("K�pf�jl",$es_lang,$es_langt,$es_lang_db);
    echo("<div class='div_r1'>$ki: </div>");
    //echo("<input class='input_f1' type='file' id='userfile' name='userfile' size='70' maxlength='100' /><br /><br />");
    echo("<input class='input_f1' type='file' id='userfile' name='userfile' size='40' /><br /><br />");
    $ki=sys_line("Mehet",$es_lang,$es_langt,$es_lang_db);
    echo("<button class='button_1' type='submit' id='b01' name='b01' value='$ki'>$ki</button>");
    echo("</form>");
    echo("</center><br /><br /><br />");
  }

?>
