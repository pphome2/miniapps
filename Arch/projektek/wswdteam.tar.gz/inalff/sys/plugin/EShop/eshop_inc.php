<?php

// EShop plugin --- PHP portalrobot
// (verzioadatok a konfiguracios fajlban)
//
// fejleszto: InalR Fejlesztoi Iroda

// plugin

    $es_plugin_name="EShop";

    $sql_esc_name="_es_cat";
    $sql_esc_n=array('esccode',
                     'escname',
                     'escparent',
                     'escline',
                     'escimg'
                     );
    $sql_esc_t=array('varchar (30)',
                     'varchar (100)',
                     'varchar (100)',
                     'varchar (200)',
                     'varchar (30)'
                     );

    $sql_esp_name="_es_prod";
    $sql_esp_n=array('espcode',
                     'espname',
                     'espcat',
                     'espkey',
                     'esptext',
                     'espmanufact',
                     'espstatus',
                     'espin',
                     'espnetto',
                     'espbrutto',
                     'espinstore',
                     'espout',
                     'espimg',
                     'espbimg'
                     );
    $sql_esp_t=array('varchar (30)',
                     'varchar (150)',
                     'varchar (100)',
                     'varchar (200)',
                     'text',
                     'varchar (150)',
                     'varchar (150)',
                     'varchar (150)',
                     'int',
                     'int',
                     'int',
                     'int',
                     'varchar (30)',
                     'varchar (30)'
                     );

    $sql_est_name="_es_cart";
    $sql_est_n=array('esccode',
                     'escuser',
                     'escprod',
                     'escprice',
                     'escdb'
                     );
    $sql_est_t=array('varchar (30)',
                     'varchar (30)',
                     'varchar (30)',
                     'int',
                     'int'
                     );

    $sql_eso_name="_es_order";
    $sql_eso_n=array('esocode',
                     'esouser',
                     'esostatus',
                     'esoprice',
                     'esoaddress',
                     'esotext'
                     );
    $sql_eso_t=array('varchar (30)',
                     'varchar (30)',
                     'varchar (100)',
                     'int',
                     'varchar (200)',
                     'text'
                     );

    $es_owner_name=array('Nagy Szalonn�s Bt.',
                         '2700, Cegl�d, Kossuth t�r 1/a',
                         '53/323-123, 20/234-8765'
                         );

    // ne legyen ures sor!!
    $es_admin=array("peter",
                    "zsolt"
                    );
    $es_admin_email="wswdteam@gmail.com";
    $es_lang="";
    $es_langt=array();
    $es_menu_start=0;
    $es_amenu_start=0;
    $es_list_db=20;
    $es_products_main="Term�kek";
    $es_none_code="-";
    $es_css="$dir_plugin/$es_plugin_name/eshop.css";
    $es_money_code="Ft";
    $es_img_dir="$dir_plugin/$es_plugin_name/img";
    $es_menu=array();
    $es_func=array();
    $es_default_function="";

    $es_order_status=array("Megrendel�s fogadva",
                           "Feldolgoz�s alatt",
                           "Csomag �ssze�ll�t�s",
                           "Fut�rnak �tadva",
                           "Lez�rva"
                           );

    $es_product_status=array("Saj�t rakt�rban",
                             "Nagykeresked�i rakt�rban",
                             "Gy�rt�i rakt�rban",
                             "Egyedi beszerz�s",
                             "Pillanatnyi hi�ny"
                             );

    $es_product_in=array("1-2 nap",
                         "3-5 nap",
                         "5-10 nap",
                         "Egyedi aj�nlat",
                         "�rdekl�dj�n el�rhet�s�geinken"
                         );

    $es_include=array("eshop_adm.php",
                      "eshop_cat.php",
                      "eshop_dis.php",
                      "eshop_frm.php",
                      "eshop_ord.php",
                      "eshop_pro.php",
                      "eshop_sea.php",
                      "eshop_shp.php"
                      );


?>
