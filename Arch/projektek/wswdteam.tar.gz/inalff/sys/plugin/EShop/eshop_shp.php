<?php

// EShop plugin --- PHP portalrobot
// (verzioadatok a konfiguracios fajlban)
//
// fejleszto: InalR Fejlesztoi Iroda

// plugin


  function es_cart_in($code,$price){
    global $sql_est_name,$sql_est_n,$sql_est_t,
           $usercode;

    //echo("term�k a kos�rba");
    $uc=sys_env_find($usercode);
    if (($uc<>"")and($code<>"")){
      $t[0]=sys_time_code();
      $t[1]=$uc;
      $t[2]=$code;
      $t[3]=$price;
      $t[4]=1;
      sql_data_add($sql_est_name,$t);
    }
  }


  function es_cart_stat(){
    global $sql_est_name,$sql_est_n,$sql_est_t,
           $es_lang,$es_langt,$s_program,
           $usercode,$es_money_code;

    $uc=sys_env_find($usercode);
    if ($uc<>""){
      $res=sql_data_get($sql_est_name,$sql_est_n[1],$uc);
      $db=sql_result_db($res);
      echo("<br />");
      if ($db>0){
        $op=0;
        $x=0;
        while ($x<$db){
          $tomb=sql_get_result_data($res,$x);
          if ($tomb[0]<>""){
            $op=$op+$tomb[3];
          }
          $x++;
        }
        $ki0=sys_line("A kos�rban",$es_lang,$es_langt,$es_lang_db);
        $ki1=sys_line("darab term�k van",$es_lang,$es_langt,$es_lang_db);
        $ki2=sys_line("Fizetend�",$es_lang,$es_langt,$es_lang_db);
        echo("<div class='div_rightst'>$ki0 $db $ki1.  $ki2: $op $es_money_code.</div>");
      }else{
        $ki=sys_line("A kos�r m�g �res",$es_lang,$es_langt,$es_lang_db);
        echo("<div class='div_rightst'>$ki.</div>");
      }
    }else{
      //$ki=sys_line("A v�s�rl�shoz be kell jelentkeznie",$es_lang,$es_langt,$es_lang_db);
      //echo("<b>$ki.</b>");
    }
    //$ki=sys_line("A kos�r tartalma",$es_lang,$es_langt,$es_lang_db);
    //$e=sys_env_pack();
    //echo("<a class='href' href='$s_program?$e'><b> $ki. </b></a>");
  }


  function es_cart_display($c){
    global $sql_est_name,$sql_est_n,$sql_est_t,
           $sql_esp_name,$sql_esp_n,$sql_esp_t,
           $es_lang,$es_langt,$s_program,
           $usercode,$es_money_code,
           $delkod,$deldata,$sitepos,
           $pluginenv1,$plugin_data_1,
           $plugin_page,$es_products_main;

    $delete=true;
    $uc=sys_env_find($usercode);
    $price=0;
    if ($uc<>""){
      if ($delkod<>""){
        sql_data_del($sql_est_name,$sql_est_n[0],$delkod);
      }
      $res=sql_data_get($sql_est_name,$sql_est_n[1],$uc);
      $db=sql_result_db($res);
      if ($db>0){
        $es_cart_line=array();
        $es_cart_db=0;
        $p=sys_env_find($sitepos);
        echo("<center>");
        $ki0=sys_line("A kos�r tartalma",$es_lang,$es_langt,$es_lang_db);
        $ki=sys_line("T�r�l",$es_lang,$es_langt,$es_lang_db);
        $ki1=sys_line("�r",$es_lang,$es_langt,$es_lang_db);
        $ki2=sys_line("Nincs adat",$es_lang,$es_langt,$es_lang_db);
        $ki3=sys_line("t�tel",$es_lang,$es_langt,$es_lang_db);
        $op=0;
        $x=0;
        while ($x<$db){
          $tomb=sql_get_result_data($res,$x);
          if ($tomb[0]<>""){
            echo("<div href='es_table'>");
            echo("<div class='div_a1'>");
            if ($delete){
              sys_env_new($sitepos,$c);
              sys_env_new($deldata,$tomb[0]);
              $e=sys_env_pack();
              sys_env_del($deldata);
              echo("<a class='href' href='./$s_program?$e'>$ki</a>");
            }else{
              $b=$x+1;
              echo("$b. $ki3");
            }
            echo("</div>");
            echo("<div class='div_a2'>");
            echo("$ki1 : <b>$tomb[3] $es_money_code</b>");
            echo("</div>");
            echo("<div class='div_a3'>");
            $pd=$plugin_page.$es_products_main;
            sys_env_new($sitepos,$pd);
            sys_env_new($pluginenv1,$tomb[2]);
            $e=sys_env_pack();
            sys_env_del($pluginenv1);
            $rs=sql_data_get($sql_esp_name,$sql_esp_n[0],$tomb[2]);
            $dob=sql_result_db($rs);
            if ($dob>0){
              $to=sql_get_result_data($rs,0);
              $kiir=$to[1];
              echo("<a class='href' href='./$s_program?$e'>$kiir</a>");
            }else{
              $kiir=$ki2;
              echo("$kiir");
            }
            echo("</div>");
            echo("</div>");
            $op=$op+$tomb[3];
          }
          $x++;
        }
        echo("</center><br /><br />");
        $ki0=sys_line("A kos�rban",$es_lang,$es_langt,$es_lang_db);
        $ki1=sys_line("darab term�k van",$es_lang,$es_langt,$es_lang_db);
        $ki2=sys_line("Fizetend�",$es_lang,$es_langt,$es_lang_db);
        echo("$ki0 $db $ki1.  $ki2: $op $es_money_code.");
        sys_env_new($sitepos,$p);
        $price=$op;
      }else{
        $ki=sys_line("A kos�r m�g �res",$es_lang,$es_langt,$es_lang_db);
        echo("$ki.");
      }
    }else{
      $ki=sys_line("A v�s�rl�shoz be kell jelentkeznie",$es_lang,$es_langt,$es_lang_db);
      echo("$ki.");
    }
    return($price);
  }


  function es_cart_getlist($c){
    global $sql_est_name,$sql_est_n,$sql_est_t,
           $sql_esp_name,$sql_esp_n,$sql_esp_t,
           $es_lang,$es_langt,$s_program,
           $usercode,$es_money_code;

    $es_cart_line=array();
    $price=0;
    if ($c<>""){
      $res=sql_data_get($sql_est_name,$sql_est_n[1],$c);
      $db=sql_result_db($res);
      if ($db>0){
        $es_cart_line=array();
        $es_cart_db=0;
        $x=0;
        while ($x<$db){
          $tomb=sql_get_result_data($res,$x);
          if ($tomb[0]<>""){
            $rs=sql_data_get($sql_esp_name,$sql_esp_n[0],$tomb[2]);
            $to=sql_get_result_data($rs,0);
            $kiir=$to[1];
            $es_cart_line[$es_cart_db]="$kiir, $tomb[3] $es_money_code";
            echo("$es_cart_line[$es_cart_db]=");
            $es_cart_db++;
          }
          $x++;
        }
      }else{
      }
    }else{
    }
    return($es_cart_line);
  }


  function es_cart_close($uc,$ordcode){
    global $sql_est_name,$sql_est_n,$sql_est_t;

    if ($uc<>""){
      $res=sql_data_get($sql_est_name,$sql_est_n[1],$uc);
      $db=sql_result_db($res);
      if ($db>0){
        $x=0;
        while ($x<$db){
          $tomb=sql_get_result_data($res,$x);
          if ($tomb[0]<>""){
            $tomb[1]=$ordcode;
            sql_data_update($sql_est_name,$sql_est_n,$sql_est_n[0],$tomb[0],$tomb);
          }
          $x++;
        }
      }
    }
  }


?>
