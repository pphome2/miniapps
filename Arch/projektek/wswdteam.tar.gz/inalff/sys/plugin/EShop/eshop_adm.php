<?php

// EShop plugin --- PHP portalrobot
// (verzioadatok a konfiguracios fajlban)
//
// fejleszto: InalR Fejlesztoi Iroda

// plugin


  function es_order_admin($cim){
    global $es_money_code,$es_admin,$es_order_status,
           $sql_eso_name,$sql_eso_n,$sql_eso_t,
           $sql_est_name,$sql_est_n,$sql_est_t,
           $sql_esp_name,$sql_esp_n,$sql_esp_t,
           $es_lang,$es_langt,$es_list_db,
           $usercode,$deldata,$delkod,
           $user_admin,$pluginenv1,$plugin_data_1,
           $messpage,$mess_akt_page,
           $sitepos,$s_program,
           $es_admin_email;

    $p=sys_env_find($sitepos);
    sys_env_new($sitepos,$cim);
    $uc=sys_env_find($usercode);
    $utomb=array();
    if (($user_admin)or(in_array($uc,$es_admin))){
      $t[0]="";
      $t[1]="";
      $t[2]="";
      $t[3]="";
      $t[4]="";
      $t[5]="";
      if ($delkod<>""){
        sql_data_del($sql_eso_name,$sql_eso_n[0],$delkod);
        sql_data_del($sql_est_name,$sql_est_n[1],$delkod);
      }
      $ok=sys_data_post($db,$tkx,$tex);
      if ($ok){
        $t[0]=$tex[0];
        $t[1]=$tex[1];
        $t[2]=$tex[2];
        $t[3]=$tex[3];
        $t[4]=$tex[4];
        $t[5]=$tex[5];
        sql_data_update($sql_eso_name,$sql_eso_n,$sql_eso_n[0],$t[0],$t);
        if ($tex[6]=="on"){
          $utomb=site_user_data_all($t[1]);
          $add=$utomb[7];
          $cc="";
          $rep=$es_admin_email;
          $bcc=$es_admin_email;
          $ki=sys_line("A megrendel�s st�tusza megv�ltozott",$es_lang,$es_langt,$es_lang_db);
          $sub=$ki;
          $ki=sys_line("Tisztelt V�s�rl�nk",$es_lang,$es_langt,$es_lang_db);
          $mess="$ki! \r\n \r\n";
          $ki=sys_line("Az �n megrendel�s�nek adatai",$es_lang,$es_langt,$es_lang_db);
          $mess=$mess."$ki: \r\n \r\n";
          $ki=sys_line("Azonos�t�",$es_lang,$es_langt,$es_lang_db);
          $mess=$mess."$ki: $t[0]\r\n \r\n";
          $ki=sys_line("St�tusz",$es_lang,$es_langt,$es_lang_db);
          $st=$t[2];
          $mess=$mess."$ki: $st \r\n \r\n";
          $ki=sys_line("Weboldalunkon figyelemmel kis�rheti a megrendel�se alakul�s�t",$es_lang,$es_langt,$es_lang_db);
          $mess=$mess."$ki. \r\n \r\n";
          $ki=sys_line("K�sz�nj�k bizalm�t",$es_lang,$es_langt,$es_lang_db);
          $mess=$mess."$ki. \r\n \r\n";
          site_send_mail($add,$rep,$cc,$bcc,$sub,$mess);
        }
        $ki=sys_line("Adatok ment�se megt�rt�nt",$es_lang,$es_langt,$es_lang_db);
        echo("<br />$ki.<br /><br /y");
      }else{
        if ($plugin_data_1<>""){
          $rs=sql_data_get_desc($sql_eso_name,$sql_eso_n[0],$plugin_data_1);
          $db=sql_result_db($rs);
          if ($db>0){
            $t=sql_get_result_data($rs,0);
          }
        }
      }
      echo("<div class='es_table'>");
      $ki=sys_line("Aktu�lis megrendel�sek",$es_lang,$es_langt,$es_lang_db);
      echo("<div class='div_p'><b>$ki</b></div><br />");
      $res=sql_data_get_desc($sql_eso_name,$sql_eso_n[1],"");
      $db=sql_result_db($res);
      echo("<div class='es_table'>");
      $ki=sys_line("Feladat",$es_lang,$es_langt,$es_lang_db);
      echo("<div class='div_a1'><b>$ki</b></div>");
      $ki=sys_line("D�tum",$es_lang,$es_langt,$es_lang_db);
      echo("<div class='div_a2'><b>$ki</b></div>");
      $ki=sys_line("�r, st�tusz",$es_lang,$es_langt,$es_lang_db);
      echo("<div class='div_a3'><b>$ki</b></div>");
      echo("</div>");
      if ($db>0){
        $ki=sys_line("St�tusz",$es_lang,$es_langt,$es_lang_db);
        $ki1=sys_line("�r",$es_lang,$es_langt,$es_lang_db);
        $ki2=sys_line("T�rl�s",$es_lang,$es_langt,$es_lang_db);
        $ki3=sys_line("M�dos�t�s",$es_lang,$es_langt,$es_lang_db);
        $x=0;
        site_pageing_init($db,$tol,$ig,$es_list_db,$mess_akt_page);
        $x=$tol;
        while ($x<$ig){
          $tomb=sql_get_result_data($res,$x);
          if ($tomb[0]<>""){
            echo("<div class='es_table'>");
            echo("<div class='div_a1'>");
            sys_env_new($messpage,$mess_akt_page);
            sys_env_new($deldata,$tomb[0]);
            $e=sys_env_pack();
            sys_env_del($deldata);
            echo("<a class='href' href='./$s_program?$e'>$ki2</a><br />");
            sys_env_new($pluginenv1,$tomb[0]);
            $e=sys_env_pack();
            sys_env_del($pluginenv1);
            echo("<a class='href' href='./$s_program?$e'>$ki3</a>");
            echo("</div>");
            echo("<div class='div_a2'>");
            $ido=sys_time_code_to_date("Y.m.d. H:i",$tomb[0]);
            echo("$ido");
            echo("</div>");
            echo("<div class='div_a3'>");
            echo("$ki1: <b>$tomb[3] $es_money_code</b> <br />");
            echo("$ki: <b>$tomb[2]</b>");
            echo("</div>");
            echo("</div>");
          }
          $x++;
        }
        echo("</div>");
        echo("<div class='es_table'>");
        echo("<br />");
        sys_env_new($messpage,$mess_akt_page);
        site_pageing($db,$es_list_db,$mess_akt_page,$messpage);
        sys_env_del($messpage);
        echo("</div>");
        echo("<div class='es_table'>");
        echo("<br />");
        if ($t[0]<>""){
          $c=count($utomb);
          if ($c==0){
            $utomb=site_user_data_all($t[1]);
            $c=count($utomb);
            if ($c==0){
              $ki=sys_line("Nincs adat",$es_lang,$es_langt,$es_lang_db);
              $utomb[1]=$ki;
              $utomb[2]=$ki;
              $utomb[3]=$ki;
              $utomb[4]=$ki;
              $utomb[5]=$ki;
              $utomb[6]=$ki;
              $utomb[7]=$ki;
              $utomb[8]=$ki;
              $utomb[9]=$ki;
              $utomb[10]=$ki;
              $utomb[11]=$ki;
              $utomb[12]=$ki;
              $utomb[13]=$ki;
              $utomb[14]=$ki;
              $utomb[15]=$ki;
              $utomb[16]=$ki;
              $utomb[17]=$ki;
              $utomb[18]=$ki;
              $utomb[19]=$ki;
            }
          }
          es_form_adm($cim,$t,$utomb);
          $ki=sys_line("A megrendel�s tatalma",$es_lang,$es_langt,$es_lang_db);
          echo("<div class='div_p'><b>$ki</b></div>");
          echo("<br />");
          $rse=sql_data_get($sql_est_name,$sql_est_n[1],$t[0]);
          $db=sql_result_db($rse);
          if ($db>0){
            $p=sys_env_find($sitepos);
            echo("<center><div class='es_table'>");
            $ki1=sys_line("�r",$es_lang,$es_langt,$es_lang_db);
            $ki2=sys_line("Nincs adat",$es_lang,$es_langt,$es_lang_db);
            $ki3=sys_line("t�tel",$es_lang,$es_langt,$es_lang_db);
            $op=0;
            $x=0;
            while ($x<$db){
              $tomb=sql_get_result_data($rse,$x);
              if ($tomb[0]<>""){
                echo("<br />");
                echo("<div class='es_table'>");
                echo("<div class='div_a1'>");
                $b=$x+1;
                echo("$b. $ki3");
                echo("</div>");
                echo("<div class='div_a2'>");
                echo("$ki1 : <b>$tomb[3] $es_money_code</b>");
                echo("</div>");
                echo("<div class='div_a3'>");
                $rs=sql_data_get($sql_esp_name,$sql_esp_n[0],$tomb[2]);
                $dob=sql_result_db($rs);
                if ($dob>0){
                  $to=sql_get_result_data($rs,0);
                  $kiir=$to[1];
                }else{
                  $kiir=$ki2;
                }
                echo("$kiir");
                $op=$op+$tomb[3];
                echo("</div>");  
                echo("</div>");
              }
              $x++;
            }
            echo("</center><br /><br />");
            //echo("<div class='es_table'>");
          }else{
          }
        }
      }else{
        echo("");
      }
      echo("</div>");
    }else{
      $ki2=sys_line("Nem enged�lyezett feladat",$es_lang,$es_langt,$es_lang_db);
      echo("<br /><br />$ki2.<br /><br />");
    }
    sys_env_new($sitepos,$p);
  }



?>
