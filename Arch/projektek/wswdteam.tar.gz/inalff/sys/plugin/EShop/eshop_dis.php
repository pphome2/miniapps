<?php

// EShop plugin --- PHP portalrobot
// (verzioadatok a konfiguracios fajlban)
//
// fejleszto: InalR Fejlesztoi Iroda

// plugin


  function es_display_prod($c2){
    global $es_res,$es_products_main,
           $es_none_code,$es_img_dir,
           $s_program,$sitepos,
           $plugin_page,
           $sql_esp_name,$sql_esp_n,$sql_es_t,
           $es_list_db,
           $messpage,$mess_akt_page,
           $s_program,
           $es_lang,$es_langt,$es_money_code,
           $pluginenv1,$plugin_data_1,
           $pluginenv2,$plugin_data_2,
           $plugin_page,$usercode;

    $c1=$c2;
    $uc=sys_env_find($usercode);
    $c2=substr($c2,strlen($plugin_page),strlen($c2));
    $ki=sys_line("Elad�si �r",$es_lang,$es_langt,$es_lang_db);
    $ki0=sys_line("Kateg�ria",$es_lang,$es_langt,$es_lang_db);
    $ki1=sys_line("K�szlet",$es_lang,$es_langt,$es_lang_db);
    $ki2=sys_line("Nincs k�p",$es_lang,$es_langt,$es_lang_db);
    $ki3=sys_line("db",$es_lang,$es_langt,$es_lang_db);
    $ki4=sys_line("Kos�rba",$es_lang,$es_langt,$es_lang_db);
    $ki5=sys_line("Kateg�ria",$es_lang,$es_langt,$es_lang_db);
    $ki6=sys_line("R�szletek",$es_lang,$es_langt,$es_lang_db);
    $ki7=sys_line("Sz�ll�t�s",$es_lang,$es_langt,$es_lang_db);
    $ki8=sys_line("Gy�rt�",$es_lang,$es_langt,$es_lang_db);
    $p=sys_env_find($sitepos);
    $jo=false;
    if ($plugin_data_1<>""){
      $ik=substr($plugin_data_1,0,1);
      $ikt=array("1","2","3","4","5","6","7","8","9","0");
      if (in_array($ik,$ikt)){
        $rs=sql_data_get($sql_esp_name,$sql_esp_n[0],$plugin_data_1);
      }else{
        $rs=sql_data_get($sql_esp_name,$sql_esp_n[1],$plugin_data_1);
      }
      $dob=sql_result_db($rs);
      if ($dob>0){
        $tomb=sql_get_result_data($rs,0);
        $jo=true;
      }
    }else{
    }
    $res=sql_data_get($sql_esp_name,$sql_esp_n[2],$c2);
    $db=sql_result_db($res);
    sys_env_new($sitepos,$c1);
    if (($jo)and($plugin_data_2==$tomb[0])){
      es_cart_in($tomb[0],$tomb[9]);
    }
    es_cart_stat();
    echo("<br />");
    if ($jo){
      echo("<div class='es_table'>");
      sys_env_new($pluginenv1,$tomb[0]);
      $e=sys_env_pack();
      sys_env_del($pluginenv1);
      echo("<br />");
      $e=sys_env_pack();
      echo("<div class='es_prodline'>"); 
      echo("<div class='es_a1'>");
      if ($tomb[9]==""){
        echo("$ki2");
      }else{
        $d=$es_img_dir."/".$tomb[9];
        if (file_exists($d)){
          echo("<a class='href' href='./$s_program?$e'><img class='img' src='$d'></a>");
        }else{
          echo("$ki2");
        }
      }
      echo("</div>");
      echo("<div class='es_a2'>");
      echo("<a class='href' href='./$s_program?$e'><b>$tomb[1]</b></a>");
      echo("</div>");
      echo("<div class='es_a3'><b>$ki5:</b> $tomb[2]");
      echo("<br /><br />$tomb[3]<br /><br />");
      if ($tomb[10]<>""){
        $d=$es_img_dir."/".$tomb[10];
        if (file_exists($d)){
          echo("<br /><center><img class='img' src='$d'></center><br /><br />");
        }
      }
      site_text_out($tomb[4]);
      echo("<br /><br />");
      echo("$ki8 : <b>$tomb[5]</b> <br />");
      echo("$ki : <b>$tomb[9] $es_money_code</b> ($tomb[8] $es_money_code). ");
      echo("$ki7 : <b>$tomb[7]</b>.");
      echo("<br />");
      echo("</div>");
      echo("<div class='es_a4'>");
      if ($uc<>""){
        sys_env_new($pluginenv2,$tomb[0]);
        $e=sys_env_pack();
        sys_env_del($pluginenv2);
        echo("<a class='href' href='./$s_program?$e'><b>$ki4</b></a>");
        echo("<br />");
      }else{
      }
      echo("</div>");
      echo("<br />");
      echo("</div>");
      echo("</div>");
      echo("<br />");
      echo("<br />");
      echo("<br />");
    }
    echo("<div class='es_div_kat'>$ki0:</div>");
    $cx=$c1;
    $kisor="";
    $kis="";
    $k=es_find_c($es_res,1,$c2,2,$kis);
    while (strlen($k)>1){
      sys_env_new($sitepos,$plugin_page.$kis);
      $e=sys_env_pack();
      if ($kisor<>""){
        $kisor="<a class='href' href='./$s_program?$e'>$kis</a> - $kisor";
      }else{
        $kisor="<a class='href' href='./$s_program?$e'>$kis</a>";
      }
      $k=es_find_c($es_res,1,$k,2,$kis);
    }
    sys_env_new($sitepos,$plugin_page.$kis);
    $e=sys_env_pack();
    if ($kis<>""){
      if ($kisor<>""){
        $kisor="<a class='href' href='./$s_program?$e'>$kis</a> - $kisor";
      }else{
        $kisor="<a class='href' href='./$s_program?$e'>$kis</a>";
      }
    }
    sys_env_new($sitepos,$plugin_page.$es_products_main);
    $e=sys_env_pack();
    if ($kisor<>""){
      $kisor="<a class='href' href='./$s_program?$e'><b>$es_products_main</b></a> - $kisor";
      $ker=$c2;
    }else{
      $kisor="<a class='href' href='./$s_program?$e'><b>$es_products_main</b></a>";
      $ker=$es_none_code;
    }
    echo("$kisor");
    echo("<br /><br />");

    $x=0;
    $y=sql_result_db($es_res);
    while ($x<$y){
      $tomb=sql_get_result_data($es_res,$x);
      if ($tomb[2]==$ker){
        sys_env_new($sitepos,$plugin_page.$tomb[1]);
        $e=sys_env_pack();
        echo("<div class='es_div_kat'></div>");
        echo("<a class='href' href='./$s_program?$e'><b>$tomb[1]</b></a><br />");
      }
      $x++;
    }

    //product
    $res=sql_data_get($sql_esp_name,$sql_esp_n[2],$c2);
    $db=sql_result_db($res);
    sys_env_new($sitepos,$c1);
    $e=sys_env_pack();
    echo("<br />");
    if ($db>0){
      site_pageing_init($db,$tol,$ig,$es_list_db,$mess_akt_page);
      $x=$tol;
      $tomb2=array();
      while ($x<$ig){
        $tomb=sql_get_result_data($res,$x);
        if ($tomb[0]<>""){
          sys_env_new($pluginenv1,$tomb[0]);
          $e=sys_env_pack();
          echo("<div href='es_table'>");
          echo("<div class='es_prodline'>");
          $e=sys_env_pack();
          echo("<div class='es_a1'>");
          if ($tomb[9]==""){
            echo("$ki2");
          }else{
            $d=$es_img_dir."/".$tomb[9];
            if (file_exists($d)){
              echo("<a class='href' href='./$s_program?$e'><img class='img' src='$d'></a>");
            }else{
              echo("$ki2");
            }
          }
          echo("</div>");
          echo("<div class='es_a2'>");
          echo("<a class='href' href='./$s_program?$e'><b>$tomb[1]</b></a>");
          echo("</div>");
          echo("<div class='es_a3'>$tomb[3]<br /><br />");
          echo("$ki8 : <b>$tomb[5]</b> <br />");
          echo("$ki : <b>$tomb[9] $es_money_code</b> ($tomb[8] $es_money_code). ");
          echo("$ki7 : <b>$tomb[7]</b>.");
          echo("<br />");
          echo("<br />");
          echo("<a class='href' href='./$s_program?$e'><b>$ki6</b></a>");
          echo("</div>");
          echo("<div class='es_a4'>");
          if ($uc<>""){
            sys_env_new($pluginenv2,$tomb[0]);
            $e=sys_env_pack();
            sys_env_del($pluginenv2);
            echo("<a class='href' href='./$s_program?$e'><b>$ki4</b></a>");
          }else{
          }
          echo("</div>");
          echo("</div>");
          echo("</div>");
          echo("<br />");
        }
        $x++;
      }
      echo("<br />");
      echo("<br />");
      sys_env_del($pluginenv1);
      sys_env_new($sitepos,$c1);
      sys_env_new($messpage,$mess_akt_page);
      site_pageing($db,$es_list_db,$mess_akt_page,$messpage);
    }
    echo("<br />");
    echo("<br />");
    sys_env_new($sitepos,$p);

  }

  function es_find_c($res,$ind1,$sor,$ind2,&$kis){
    $ret="";
    $x=0;
    $y=sql_result_db($res);
    while ($x<$y){
      $tomb=sql_get_result_data($res,$x);
      if ($tomb[$ind1]==$sor){
        $kis=$tomb[$ind1];
        $ret=$tomb[$ind2];
      }
      $x++;
    }
    return($ret);
  }

?>
