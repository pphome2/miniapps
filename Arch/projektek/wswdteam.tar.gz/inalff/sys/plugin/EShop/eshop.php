<?php

// EShop plugin --- PHP portalrobot
// (verzioadatok a konfiguracios fajlban)
//
// fejleszto: InalR Fejlesztoi Iroda

// plugin

  function eshop($cim){
    global $plugin_menu,$plugin_page,
           $plugin_data,$separator,
           $es_menu_start,$es_amenu_start,
           $user_admin,$es_admin,$usercode;

    $uc=sys_env_find($usercode);
    $username=site_user($uc);
    //echo("<br /><b>");
    //echo($cim);
    //echo("</b><br /><br />");
    $admin_ok=false;
    if (($user_admin)or(in_array($uc,$es_admin))){
      $func[0]="es_cat";
      $func[1]="es_products";
      $func[2]="es_order_admin";
      $admin_ok=plugin_function_start($func,$cim,$es_amenu_start,"");
    }
    if (!$admin_ok){
      $ufunc[0]="es_cart_display";
      $ufunc[1]="es_order";
      $ufunc[2]="es_order_all";
      $ufunc[3]="es_search";
      $ufunc[4]="";
      $ufunc[5]="es_display_prod";
      plugin_function_start($ufunc,$cim,$es_menu_start,"es_display_prod");
    }
  }



  function eshop_init(){
    global $es_menu,$es_func,$es_langt,
           $dir_plugin,$es_lang,$lang_system,
           $sql_esc_name,$sql_esc_n,$sql_esc_t,
           $sql_esp_name,$sql_esp_n,$sql_esp_t,
           $sql_est_name,$sql_est_n,$sql_est_t,
           $sql_eso_name,$sql_eso_n,$sql_eso_t,
           $es_menu_start,$es_amenu_start,
           $user_admin,$es_products_main,
           $cond_file,$es_owner_name,
           $dev_moduls,$es_res,$es_admin,
           $es_plugin_name,$es_money_code,
           $es_include,$es_none_code,
           $es_admin_menu_db,$es_img_dir,
           $es_default_function,$es_list_db,
           $es_product_status,$es_product_in,
           $es_order_status,$usercode,
           $sep_at,$sep_eq,$sitepos,
           $pluginenv1,$plugin_page,
           $mess_per_page;


    $es_plugin_name="EShop";
    $inc_file="$dir_plugin/".$es_plugin_name."/eshop_inc.php";
    if (file_exists($inc_file)){
      include("$inc_file");
    }
    if ($es_list_db>$mess_per_page){
      $es_list_db=$mess_per_page;
    }
    $x=0;
    $y=count($es_include);
    while ($x<$y){
      if ($es_include[$x]<>""){
        $inc_file="$dir_plugin/$es_plugin_name/$es_include[$x]";
        //echo("$inc_file<br />");
        if (file_exists($inc_file)){
          include("$inc_file");
        }
      }
      $x++;
    }
    sys_style($es_css);
    $es_lang="$dir_plugin/".$es_plugin_name."/lang_$lang_system";
    $uc=sys_env_find($usercode);
    $username=site_user($uc);

    $cc2=count($es_order_status);
    $x=0;
    while ($x<$cc2){
      $es_order_status[$x]=sys_line($es_order_status[$x],$es_lang,$es_langt,$es_lang_db);
      $x++;
    }

    sql_plugin_init($sql_esc_name,$sql_esc_n,$sql_esc_t);
    sql_plugin_init($sql_esp_name,$sql_esp_n,$sql_esp_t);
    sql_plugin_init($sql_est_name,$sql_est_n,$sql_est_t);
    sql_plugin_init($sql_eso_name,$sql_eso_n,$sql_eso_t);

    plugin_default_function("eshop");
    $c=0;
    if (($user_admin)or(in_array($uc,$es_admin))){
      $ki=sys_line("Kateg�ri�k",$es_lang,$es_langt,$es_lang_db);
      $es_menu[$c]="$es_plugin_name $ki";
      $es_func[$c]="eshop";
      $c++;
      $ki=sys_line("Term�kek",$es_lang,$es_langt,$es_lang_db);
      $es_menu[$c]="$es_plugin_name $ki";
      $es_func[$c]="eshop";
      $c++;
      $ki=sys_line("Megrendel�sek",$es_lang,$es_langt,$es_lang_db);
      $es_menu[$c]="$es_plugin_name $ki";
      $es_func[$c]="eshop";
      $c++;
      $es_amenu_start=plugin_menu($es_menu,$es_func);
    }
    $c=0;
    $ki=sys_line("Kos�r tartalma",$es_lang,$es_langt,$es_lang_db);
    $es_menu[$c]=$ki;
    $es_func[$c]="eshop";
    $c++;
    $ki=sys_line("Megrendel�s",$es_lang,$es_langt,$es_lang_db);
    $es_menu[$c]=$ki;
    $es_func[$c]="eshop";
    $c++;
    $ki=sys_line("Kor�bbi megrendel�sek",$es_lang,$es_langt,$es_lang_db);
    $es_menu[$c]=$ki;
    $es_func[$c]="eshop";
    $c++;
    $ki=sys_line("Term�k keres�se",$es_lang,$es_langt,$es_lang_db);
    $es_menu[$c]=$ki;
    $es_func[$c]="eshop";
    $c++;
    $es_menu[$c]="";
    $es_func[$c]="";
    $c++;
    $ki=sys_line($es_products_main,$es_lang,$es_langt,$es_lang_db);
    $es_menu[$c]=$ki;
    $es_func[$c]="eshop";
    $c++;

    $es_res=sql_data_allget($sql_esc_name,$sql_esc_n[0]);
    $db=sql_result_db($es_res);
    $x=0;
    while ($x<$db){
      $tomb=sql_get_result_data($es_res,$x);
      if (($tomb[0]<>"")and(strlen($tomb[2])<=1)){
        $es_menu[$c]=$tomb[1];
        $es_func[$c]="eshop";
        $c++;
      }
      $x++;
    }
    $es_menu_start=plugin_menu($es_menu,$es_func);

    $c=count($dev_moduls);
    $dev_moduls[$c]=$es_plugin_name;

    $link=$sitepos.$sep_eq.$plugin_page.$es_products_main.$sep_at.$pluginenv1.$sep_eq;
    $ki=sys_line("Gy�rt�",$es_lang,$es_langt,$es_lang_db);
    plugin_search_init($sql_esp_name,$sql_esp_n[5],$ki,1,3,5,true,$link);
    $ki=sys_line("Term�k r�szletes le�r�sa",$es_lang,$es_langt,$es_lang_db);
    plugin_search_init($sql_esp_name,$sql_esp_n[4],$ki,1,3,7,true,$link);
    $ki=sys_line("Term�k r�vid le�r�sa",$es_lang,$es_langt,$es_lang_db);
    plugin_search_init($sql_esp_name,$sql_esp_n[3],$ki,1,3,7,true,$link);
    $ki=sys_line("Term�k neve",$es_lang,$es_langt,$es_lang_db);
    plugin_search_init($sql_esp_name,$sql_esp_n[1],$ki,1,3,7,true,$link);
  }

  // plugins close

  function eshop_end(){
  }


?>
