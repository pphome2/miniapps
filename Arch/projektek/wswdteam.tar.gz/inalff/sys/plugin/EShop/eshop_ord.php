<?php

// EShop plugin --- PHP portalrobot
// (verzioadatok a konfiguracios fajlban)
//
// fejleszto: InalR Fejlesztoi Iroda

// plugin


  function es_order($cim){
    global $es_order_status,$es_money_code,
           $sql_est_name,$sql_est_n,$sql_est_t,
           $sql_eso_name,$sql_eso_n,$sql_eso_t,
           $sql_esp_name,$sql_esp_n,$sql_esp_t,
           $es_lang,$es_langt,$deldata,$delkod,
           $s_program,$sitepos,$usercode,
           $es_admin_email;

    $uc=sys_env_find($usercode);
    $ok=sys_data_post($db,$tkx,$tex);
    $utomb=site_user_data_all($uc);
    if ($ok){
      $t[0]=$tex[0];
      $t[1]=$tex[1];
      $t[2]=$tex[2];
      $t[3]=$tex[3];
      $t[4]=$tex[4];
      $t[5]=$tex[5];
      $es_cart_line=es_cart_getlist($uc);
      es_cart_close($uc,$t[0]);
      sql_data_add($sql_eso_name,$t);
      $ki=sys_line("A megrendel�s r�gz�tve lett",$es_lang,$es_langt,$es_lang_db);
      echo("<br />$ki.<br /><br />");
      $add=$utomb[7];
      $rep=$es_admin_email;
      $bcc=$es_admin_email;
      $ki=sys_line("A megrendel�s meg�rkezett",$es_lang,$es_langt,$es_lang_db);
      $sub=$ki;
      $ki=sys_line("Tisztelt V�s�rl�nk",$es_lang,$es_langt,$es_lang_db);
      $mess="$ki! \r\n \r\n";
      $ki=sys_line("Az �n megrendel�se meg�rkezett, az al�bbi tartalommal",$es_lang,$es_langt,$es_lang_db);
      $mess=$mess."$ki: \r\n \r\n";
      $ki=sys_line("Azonos�t�",$es_lang,$es_langt,$es_lang_db);
      $mess=$mess."$ki: $t[0]\r\n \r\n";
      $co=count($es_cart_line);
      $x=0;
      while($x<$co){
        $mess=$mess."$es_cart_line[$x] \r\n";
        $x++;
      }
      $mess=$mess." \r\n";
      $ki=sys_line("Weboldalunkon figyelemmel kis�rheti a megrendel�se alakul�s�t",$es_lang,$es_langt,$es_lang_db);
      $mess=$mess."$ki. \r\n \r\n";
      $ki=sys_line("K�sz�nj�k bizalm�t",$es_lang,$es_langt,$es_lang_db);
      $mess=$mess."$ki. \r\n \r\n";
      site_send_mail($add,$rep,"",$bcc,$sub,$mess);
      $rse=sql_data_get($sql_est_name,$sql_est_n[1],$t[0]);
      $db=sql_result_db($rse);
      if ($db>0){
        $x=0;
        while ($x<$db){
          $tomb=sql_get_result_data($rse,$x);
          if ($tomb[0]<>""){
            $rs=sql_data_get($sql_esp_name,$sql_esp_n[0],$tomb[2]);
            $dob=sql_result_db($rs);
            if ($dob>0){
              $to=sql_get_result_data($rs,0);
              if ($to[7]>0){
                $to[7]=$to[7]-1;
                sql_data_update($sql_esp_name,$sql_esp_n,$sql_esp_n[0],$to[0],$to);
              }
            }
          }
          $x++;
        }
      }

      $res=sql_data_get_desc($sql_eso_name,$sql_eso_n[1],$uc);
      $db=sql_result_db($res);
      if ($db>0){
        $ki=sys_line("Eddigi megrendel�sek",$es_lang,$es_langt,$es_lang_db);
        echo("<div class='div_p'><b>$ki</b></div><br />");
        $ki=sys_line("St�tusz",$es_lang,$es_langt,$es_lang_db);
        $ki1=sys_line("�r",$es_lang,$es_langt,$es_lang_db);
        $x=0;
        while ($x<$db){
          $tomb=sql_get_result_data($res,$x);
          if ($tomb[0]<>""){
            echo("<div href='es_table'>");
            echo("<div class='div_a1'>");
            $ido=sys_time_code_to_date("Y.m.d.",$tomb[0]);
            echo("$ido");
            echo("</div>");
            echo("<div class='div_a2'>");
            echo("$ki1: <b>$tomb[3] $es_money_code</b>");
            echo("</div>");
            echo("<div class='div_a3'>");
            echo("$ki: <b>$tomb[2]</b>");
            echo("</div>");
            echo("</div>");
          }
          $x++;
        }
        echo("<br /><br />");
      }
    }else{
      $price=es_cart_display($cim,false);
      if (($price<>0)and($uc<>"")){
        $t[0]=sys_time_code();
        $t[1]=$uc;
        $t[2]=$es_order_status[0];
        $t[3]=$price;
        $t[4]=$utomb[6];
        $t[5]="";
        echo("<br />");
        echo("<br />");
        echo("<br />");
        $ki=sys_line("Megrendel�s",$es_lang,$es_langt,$es_lang_db);
        echo("<div class='div_p'><b>$ki</b></div>");
        echo("<br />");
        echo("<div class='es_table'>");
        sys_env_new($sitepos,$cim);
        $e=sys_env_pack();

        $ki=sys_line("N�v",$es_lang,$es_langt,$es_lang_db);
        echo("<div class='div_r1'>$ki: </div>");
        echo("<input class='input_r1' type='text' id='u0' name='u0' value='$utomb[5]' size='120' maxlength='150' readonly /><br />");
        $ki=sys_line("C�m",$es_lang,$es_langt,$es_lang_db);
        echo("<div class='div_r1'>$ki: </div>");
        echo("<input class='input_r1' type='text' id='u1' name='u1' value='$utomb[6]' size='120' maxlength='150' readonly /><br />");
        $ki=sys_line("E-mail",$es_lang,$es_langt,$es_lang_db);
        echo("<div class='div_r1'>$ki: </div>");
        echo("<input class='input_r1' type='text' id='u2' name='u2' value='$utomb[7]' size='120' maxlength='150' readonly /><br />");
        $ki=sys_line("Fizetend�",$es_lang,$es_langt,$es_lang_db);
        echo("<div class='div_r1'>$ki: </div>");
        $sor="$price $es_money_code";
        echo("<input class='input_r1' type='text' id='u3' name='u3' value='$sor' size='120' maxlength='150' readonly /><br />");

        echo("<form method='post' enctype='multipart/form-data' action='./$s_program?$e'>");
        echo("<input class='input_r1' type='hidden' id='ucat1' name='ucat1' value='$t[0]' />");
        echo("<input class='input_r1' type='hidden' id='ucat2' name='ucat2' value='$t[1]' />");
        echo("<input class='input_r1' type='hidden' id='ucat3' name='ucat3' value='$t[2]' />");
        echo("<input class='input_r1' type='hidden' id='ucat4' name='ucat4' value='$t[3]' />");
        $ki=sys_line("Kisz�ll�t�si c�m",$es_lang,$es_langt,$es_lang_db);
        echo("<div class='div_r1'>$ki: </div>");
        echo("<input class='input_r1' type='text' id='ucat5' name='ucat5' value='$t[4]' size='120' maxlength='150' /><br />");
        $ki=sys_line("El�rhet�s�g (megjegyz�s)",$es_lang,$es_langt,$es_lang_db);
        echo("<div class='div_r1'>$ki: </div>");
        echo("<textarea class='textarea_e1' id='ucat6' name='ucat6' cols='70' rows='5'>");
        echo("$t[5]</textarea><br />");
        echo("<br />");
        $ki=sys_line("A kos�rban l�v� term�keket megrendelem",$es_lang,$es_langt,$es_lang_db);
        echo("<button class='button_1' type='submit' id='b01' name='b01' value='$ki'>$ki</button>");
        echo("</form>");
        echo("<br /></div></center><br />");
      }else{
        if ($uc==""){
          $ki=sys_line("Be kell jelentkeznie",$es_lang,$es_langt,$es_lang_db);
        }else{
          $ki=sys_line("A kos�r �res",$es_lang,$es_langt,$es_lang_db);
        }
        //echo("<br /><br /><b>$ki.</b>");
      }
    }
  }


  function es_order_all($cim){
    global $es_money_code,$es_list_db,
           $sql_eso_name,$sql_eso_n,$sql_eso_t,
           $es_lang,$es_langt,
           $usercode;

    $uc=sys_env_find($usercode);
    $ki=sys_line("Kor�bbi megrendel�sek",$es_lang,$es_langt,$es_lang_db);
    echo("<br /><b>$ki</b><br /><br />");
    if ($uc<>""){
      $res=sql_data_get_desc($sql_eso_name,$sql_eso_n[1],$uc);
      $db=sql_result_db($res);
      if ($db>0){
        $ki=sys_line("St�tusz",$es_lang,$es_langt,$es_lang_db);
        $ki1=sys_line("�r",$es_lang,$es_langt,$es_lang_db);
        $x=0;
        $sok=false;
        if ($db>$es_list_db){
          $db=$es_list_db;
          $sok=true;
        }
        while ($x<$db){
          $tomb=sql_get_result_data($res,$x);
          if ($tomb[0]<>""){
            echo("<div href='es_table'>");
            echo("<div class='div_a1'>");
            $b=$x+1;
            $ido=sys_time_code_to_date("Y.m.d.",$tomb[0]);
            echo("<b>$b.</b> - $ido");
            echo("</div>");
            echo("<div class='div_a2'>");
            $ido=$tomb[0];
            echo("$ido");
            echo("</div>");
            echo("<div class='div_a3'>");
            echo("$ki1: <b>$tomb[3] $es_money_code</b> - ");
            echo("$ki: <b>$tomb[2]</b>");
            echo("</div>");              
            echo("</div>");
          }
          $x++;
        }
        echo("<br /><br />");
        if ($sok){
          $ki=sys_line("Utols�",$es_lang,$es_langt,$es_lang_db);
          $ki2=sys_line("db megrendel�s",$es_lang,$es_langt,$es_lang_db);
          echo("$ki $es_list_db $ki2.<br /><br />");
        }
      }else{
        $ki2=sys_line("Nincs adat",$es_lang,$es_langt,$es_lang_db);
        echo("<br /><br />$ki2.<br /><br />");
      }
    }else{
      $ki=sys_line("Nincs bejelentkezve",$es_lang,$es_langt,$es_lang_db);
      echo("<b>$ki.</b>");
    }
  }


?>
