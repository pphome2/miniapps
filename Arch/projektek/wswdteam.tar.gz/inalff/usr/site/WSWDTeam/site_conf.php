<?php

  //Fejleszt� neve
  $developer="WSWDTeam";
  //Fejleszt� e-mail c�me
  $developer_email="wswdteam@gmail.com";
  //Liszensz megjegyz�s
  $licence="[-] 2012. WSWDTeam";
  //Adminisztr�tor e-mail c�me
  $site_admin_email="wswdteam@gmail.com";
  //Kulcsszavak webkeres�k r�sz�re
  $keyword="fejleszt�s h�l�zat szerviz szoftver hardver informatika sz�m�t�stechnika CMS";
  //Weboldal r�vid le�r�sa
  $description="sz�m�t�stechnika fejleszt�s CMS";
  //SQL-azonos�t�
  $sql_site_name="wswdteam";
  //SQL-szerver neve (c�me)
  $sql_site_server="mysql15.000webhost.com";
  //SQL-szerver port
  $sql_site_port="3306";
  //SQL-szerver felhaszn�l�i n�v
  $sql_site_user="a8438986_admin";
  //SQL-szerver jelsz�
  $sql_site_pass="Admin01";
  //SQL-szerver adatb�zis neve
  $sql_site_db="a8438986_inalff";
  //SQL adatt�bl�k egyedi kezd�bet�je
  $sql_table_letter="t";
  //Levelez� szerver neve (c�me)
  $smtp_host="";
  //Levelez� szerver port
  $smtp_port="";
  //Levelelz� szerver felhaszn�l�i n�v
  $smtp_user="";
  //Levelez� szerver jelsz�
  $smtp_password="";
  //Nyelvi be�ll�t�s (pl.: hu)
  $site_lang_system="hu";
  //D�tum form�tum (PHP form�tum)
  $site_date_format="";
  //Id� form�tum (PHP form�tum)
  $site_time_format="";
  //Fejleszt�i logo
  $dev_logo="wswdteam_logo.png";
  //Weboldal logo
  $site_logo="inalff_logo.png";
  //Weboldal c�msora
  $site_title="WSWDTeam honlap";
  //Weboldal jelmondat
  $motto="Informatika - minden.";
  //Alap�rtelmezett felsz�n
  $default_template="WSWDTeam";
  //Els� oldal felsz�n
  $first_page_template="";
  //Saj�t men� elemei
  $local_menu_plus=array();
  //Bejelentkezett men� elemei
  $reg_menu_plus=array();
  //Adminisztr�tori men� elemei
  $admin_menu_plus=array();
  //Minden kereshet�
  $search_all=false;
  //Be�p�l� modul kereshet� el�ssz�r
  $search_plugin_first=true;
  //Csak be�p�l� modul kereshet�
  $search_plugin_only=false;
  //Cikk �r�j�nak ki�r�sa
  $show_writer=false;
  //Wiki st�lus� men�
  $wiki_style=true;
  //Minden cikkhez megjegyz�s
  $comment_all=false;
  //F�oldalhoz megjegyz�s
  $comment_1_page=false;
  //Cikkek pontozhat�ak
  $comment_rate=false;
  //Regisztr�ci� enged�lyez�s
  $enable_new_reg=false;
  //Lap megjelen�t�se
  $enable_view=true;
  //Szerkeszt�s
  $enable_edit=false;
  //Regisztr�ci� szerkeszt�se
  $enable_reg_edit=false;
  //Lap t�rt�nete
  $enable_history=true;
  //Nyomtat�s
  $enable_print=true;
  //Cikkek list�ja
  $enable_alist=true;
  //Let�lt�s
  $enable_files=true;
  //Keres�s
  $enable_search=true;
  //�zen�fal
  $enable_messagewall=true;
  //Bejelentkez�s
  $enable_login=false;
  //Seg�ts�g
  $enable_help=true;
  //K�p gal�ria
  $enable_image_gallery=true;
  //Minden oldalhoz program (szkript)
  $include_site_script="";
  //Enged�lyezett be�p�l� modulok
  $enable_plugin=array();
  //V�zszintes h�rdet�sek k�pei
  $banners_h=array("bh1.png");
  //V�zszintes h�rdet�sek linkjei
  $banners_h_link=array("http://www.debian.org");
  //F�gg�leges h�rdet�sek k�pei
  $banners_v=array("bv1.gif");
  //F�gg�leges h�rdet�sek linkjei
  $banners_v_link=array("http://www.debian.org");


?>
