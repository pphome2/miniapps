<?php

  //Fejleszt� neve
  $developer="Developer name";
  //Fejleszt� e-mail c�me
  $developer_email="developeremail@gmail.com";
  //Liszensz megjegyz�s
  $licence="[-] 2012. Developer";
  //Adminsiztr�tor e-mail c�me
  $site_admin_email="";
  //Kulcsszavak webkeres�k r�sz�re
  $keyword="meta keywords for search engine";
  //Weboldal le�r�sa
  $description="";
  //SQL-azonos�t�
  $sql_site_name="";
  //SQL-szerver neve (c�me)
  $sql_site_server="";
  //SQL-szerver port
  $sql_site_port="";
  //SQL-szerver felhaszn�l�i n�v
  $sql_site_user="";
  //SQL-szerver jelsz�
  $sql_site_pass="";
  //SQL-szerver adatb�tis neve
  $sql_site_db="";
  //SQL adatt�bl�k egyedi kezd�bet�je
  $sql_table_letter="d";
  //Leveklez� szerver neve
  $smtp_host="";
  //Levelez� szerver port
  $smtp_port="";
  //Levelez� szerver felhaszn�l�
  $smtp_user="";
  //Levelez� szerver jelsz�
  $smtp_password="";
  //Nyelvi be�ll�t�s (pl.: hu)
  $site_lang_system="hu";
  //D�tum form�tum (PHP form�tum)
  $site_date_format="";
  //Id� form�tum (PHP form�tum)
  $site_time_format="";
  //Fejleszt� logo
  $dev_logo="devlogo.png";
  //Weboldal logo
  $site_logo="sitelogo.png";
  //Weboldal c�msor
  $site_title="Site title";
  //Weboldal jelmondat
  $motto="Motto";
  //Alap�rtelmezett felsz�n
  $default_template="Devel";
  //Els� oldal felsz�n
  $first_page_template="";
  //Saj�t men� elemei
  $local_menu_plus=array();
  //Bejelentkezett men� elemei
  $reg_menu_plus=array();
  //Adminisztr�tori men� elemei
  $admin_menu_plus=array();
  //Minden kereshet�
  $search_all=false;
  //Be�p�l� modul el�l a keres�sben
  $search_plugin_first=true;
  //Csak be�p�l� modul keres�se
  $search_plugin_only=false;
  //A cikk �r�j�nak ki�r�sa
  $show_writer=false;
  //Wiki st�lus� men�
  $wiki_style=true;
  //Minden cikkhez megjegyz�s
  $comment_all=false;
  //F�oldalhoz megjegyz�s
  $comment_1_page=false;
  //Cikkek pontozhat�k
  $comment_rate=false;
  //Regisztr�ci� enged�lyez�s
  $enable_new_reg=true;
  //Lap megn�zhet�
  $enable_view=true;
  //Cikk szerkeszthet�
  $enable_edit=false;
  //Regisztr�ci� szerkeszthet�
  $enable_reg_edit=false;
  //Cikk t�rt�nete
  $enable_history=true;
  //Nyomtat�s
  $enable_print=true;
  //Cikkek list�ja
  $enable_alist=true;
  //Let�lt�sek
  $enable_files=true;
  //Keres�s
  $enable_search=true;
  //�zen�fal
  $enable_messagewall=true;
  //Bejelentkez�s
  $enable_login=true;
  //Seg�ts�g
  $enable_help=true;
  //K�pgal�ria
  $enable_image_gallery=true;
  //Enged�lyezett be�p�l� modulok
  $enable_plugin=array();
  //Minden oldalhoz program (szkript)
  $include_site_script="";
  //V�zszintes h�rdet�s k�pei
  $banners_h=array("");
  //V�zszintes h�rdet�s linkjei
  $banners_h_link=array("");
  //F�gg�leges h�rdet�s k�pei
  $banners_v=array("");
  //F�gg�leges h�rdet�s linkjei
  $banners_v_link=array("");


?>
