<?php

  //Fejleszt� neve
  $developer="WSWDTeam";
  //Fejleszt� e-mail c�me
  $developer_email="wswdteam@gmail.com";
  //Liszensz megjegyz�s
  $licence="[-] 2012. WSWDTeam";
  //Adminisztr�tor e-mail c�me
  $site_admin_email="wswdteam@gmail.com";
  //Kulcsszavak webkeres�k r�sz�re
  $keyword="Default";
  //Weboldal r�vid le�r�sa
  $description="Default";
  //SQL-szerver azonos�t�ja
  $sql_site_name="";
  //SQL-szerver neve (c�me)
  $sql_site_server="";
  //SQL-szerver port
  $sql_site_port="";
  //SQL-szerver felhaszn�li n�v
  $sql_site_user="";
  //SQL-szerver jelsz�
  $sql_site_pass="";
  //SQL-szerver adatb�zis neve
  $sql_site_db="";
  //SQL adatt�bl�k egyedi kezd�bet�je
  $sql_table_letter="t";
  //Levelez� szerver neve (c�me)
  $smtp_host="";
  //Levelez� szerver port
  $smtp_port="";
  //Levelez� szerver felhaszn�l�i n�v
  $smtp_user="";
  //Levelez� szerver jelsz�
  $smtp_password="";
  //Nyelvi be�ll�t�sok (pl.: hu)
  $site_lang_system="hu";
  //D�tum form�tum (PHP form�tum)
  $site_date_format="";
  //Id� form�tum (PHP form�tum)
  $site_time_format="";
  //Fejleszt�i logo
  $dev_logo="wswdteam_logo.png";
  //Weboldal logo
  $site_logo="inalff_logo.png";
  //Weboldal neve
  $site_title="EWikiPort";
  //Weboldal jelmondata
  $motto="Haj ne h�tra, haj el�re";
  //Alap�rtelmezett felsz�n
  $default_template="V42";
  //Els� oldal felsz�n
  $first_page_template="";
  //Saj�t men� elemei
  $local_menu_plus=array("l1","l2","l3");
  //Bejelentkezett men� elemei
  $reg_menu_plus=array("r1","r2","r3");
  //Adminisztr�roi men� elemei
  $admin_menu_plus=array("a1","a2","a3");
  //Minden kereshet�
  $search_all=false;
  //Be�p�l� modul kereshet� el�ssz�r
  $search_plugin_first=true;
  //Be�p�l� modul kereshet� csak
  $search_plugin_only=false;
  //Cikk �r�j�nak ki�r�sa
  $show_writer=true;
  //Wiki st�lus� men�
  $wiki_style=true;
  //Minden laphoz megjegyz�s
  $comment_all=true;
  //Els� laphoz megjegyz�s
  $comment_1_page=true;
  //Cikkek pontozhat�k
  $comment_rate=false;
  //Regisztr�ci� enged�lyez�s
  $enable_new_reg=true;
  //Lap megtekint�s
  $enable_view=true;
  //Szerkeszt�s
  $enable_edit=false;
  //Regisztr�ci� szerkeszt�s
  $enable_reg_edit=false;
  //Lap t�rt�nete
  $enable_history=true;
  //Nyomtat�s
  $enable_print=true;
  //Cikkek list�ja
  $enable_alist=true;
  //Let�lt�sek
  $enable_files=true;
  //Keres�s
  $enable_search=true;
  //�zen�fal
  $enable_messagewall=true;
  //Bejelentkez�s
  $enable_login=true;
  //Seg�ts�g
  $enable_help=true;
  //K�p gal�ria
  $enable_image_gallery=true;
  //Minden oldalhoz program (szkript)
  $include_site_script="";
  //Be�p�l� modulok enged�lyez�se
  $enable_system_plugin=array(true,true);
  //v�zszintes h�rdet�s k�pei
  $banners_h=array("bh1.png");
  //v�zszintes h�rdet�s linkjei
  $banners_h_link=array("http://www.debian.org");
  //F�gg�leges h�rdet�s k�pei
  $banners_v=array("bv1.gif");
  //F�gg�leges h�rdet�s linkjei
  $banners_v_link=array("http://www.debian.org");


?>
