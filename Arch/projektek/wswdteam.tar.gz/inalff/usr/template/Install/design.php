<?php

  // w_robot --- PHP portalrobot
  // (verzioadatok a konfiguracios fajlban)
  //
  // fejleszto: InalR Fejlesztoi Iroda


  // fej, menuoldal, jobboldal, kozepresz nyitas
  // itt lehet megv�ltoztatni a portal felepiteset


  function design(){
    global $site_data_css_container,
           $dev_logo,$sitepos,$lang_system;

    $site_data_css_container="";

    switch ($lang_system){
      case "hu":
        $local_lang_divs=array("Telep�t�");
        break;
      case "en":
        $local_lang_divs=array("Install");
        break;
      default:
        $local_lang_divs=array("Telep�t�");
        break;
    }

    echo("<div class='head'>");
      echo("<div class='headlogin'>");
      echo("</div>");
      echo("<div class='headbox'>");
        echo("<div class='slogo'>");
          echo("<br />");
          echo("<div class='sdiv0'>InalFF<br />Fejleszt�i Fel�let</div>");
          echo("<br />");
          echo("<div class='sdiv1'>Inet Alkalmaz�s �s<br />Rendszer Fejleszt�i Iroda</div>");
        echo("</div>");
        echo("<div class='smotto'>");
          echo("<br />");
          echo("<br />");
          echo("<br />");
          echo("<br />");
          echo("<br />");
          echo("<br />");
          echo("<br />");
          echo("<div class='sdiv'>$local_lang_divs[0]</div>");
        echo("</div>");
      echo("</div>");
    echo("</div>");

    echo("<div class='full_center'>");
      echo("<div class='col_left'>");
      echo("</div>");

      echo("<div class='col_center'>");
        //site_page_menu_wiki("");
        echo("<div class='wcontainer'>");

    // display page
  }


  // kozep zar, lab

  function design_end(){
    global $dir_img,$template_path;

        echo("</div>");
        echo("<div class='wcontainer'>");
          echo("<div class='hiddendiv'></div>");
        echo("</div>");
    // center zar
      echo("</div>");
    echo("</div>");

    echo("<div class='full'>");
      echo("<div class='footer'>");
        echo("<div class='bottom1'>");
          $l0=$template_path."/".$dir_img."/logo.png";
          $l1=$template_path."/".$dir_img."/inalff_logo.png";
          $l2=$template_path."/".$dir_img."/inalrfi_logo.png";
          echo("<img src=$l2 />");
          echo("<br />");
          echo("Inet Alkalmaz�s<br />");
          echo("�s Rendszer<br />");
          echo("Fejleszt�i Iroda<br />");
        echo("</div>");
        echo("<div class='bottom2'>");
          echo("<img src=$l1 />");
          echo("<br />");
          echo("InalR Fejleszt�i Fel�let<br />");
        echo("</div>");
        echo("<div class='bottom3'>");
          echo("<img src=$l0 />");
          echo("<br />");
          echo("WServer Website<br />");
          echo("Developer Team<br />");
          echo("<br />");
        echo("</div>");
          echo("<div class='wcontainer'>");
            echo("<div class='hiddendiv'></div>");
          echo("</div>");
      echo("</div>");
      //site_page_sig("container");
    echo("</div>");
  }



?>
