<?php

  // w_robot --- PHP portalrobot
  // (verzioadatok a konfiguracios fajlban)
  //
  // fejleszto: InalR Fejlesztoi Iroda


  // fej, menuoldal, jobboldal, kozepresz nyitas
  // itt lehet megv�ltoztatni a portal felepiteset


  function design(){
    global $site_data_css_container,
           $motto,$dir_site,$default_site,$dir_img,$site_logo,
           $dir_template,$default_template,
           $dev_logo,$sitepos,$lang_system,
           $site_server_name;

    $site_data_css_container="wcontainer";

    switch ($lang_system){
      case "hu":
        $local_lang_divs=array("Rekl�m","Kapcsolat","Aj�nlott oldalak");
        break;
      case "en":
        $local_lang_divs=array("Ads","Contact","Links");
        break;
      default:
        $local_lang_divs=array("Rekl�m","Kapcsolat","Aj�nlott oldalak");
        break;
    }

    echo("<script type='text/javascript' language='JavaScript'>");
      echo("window.___gcfg = {lang: 'hu'};");
      echo("(function() {");
      echo("var po = document.createElement('script'); po.type = 'text/javascript'; po.async = true;");
      echo("po.src = 'https://apis.google.com/js/plusone.js';");
      echo("var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(po, s);");
      echo("})();");
      echo("");
      echo("function color_in(th){");
      echo("  th.style.borderColor='#c0c0c0';");
      echo("}");
      echo("function color_out(th){");
      echo("  th.style.borderColor='#f0f0f0';");
      echo("}");
    echo("</script>");

    echo("<div class='head'>");
      echo("<div class='headlogin'>");
        echo("<div class='searchh'>");
          site_page_search_hor("");
        echo("</div>");
        echo("<div class='loginh'>");
          site_page_login_hor("");
        echo("</div>");
        echo("<div class='linemenu'>");
          $menu=array('F�oldal',
                   'Kapcsolat'
                   );
          $p=sys_env_find($sitepos);
          sys_env_new($sitepos,$default_site);
          $e=sys_env_pack();
          sys_env_new($sitepos,$p);
          $link=array($e,
                   ''
                   );
          //site_page_menu_link("","","","",$menu,$link,true);
        echo("</div>");

        echo("<div class='linepagemenu'>");
          site_menu_global_txt($txt);
          $x2=count($txt);
          while ($x2>0){
            $x2--;
            //echo("<div class='linepmenuw'>$txt[$x2]</div>");
            echo("<div id='linepmenuw' class='linepmenuw' onmouseover='color_in(this)' onmouseout='color_out(this)'>$txt[$x2]</div>");
          }
        echo("<br /></div>");

      echo("</div>");
      echo("<div class='headbox'>");
        echo("<div class='slogo'>");
          $l=$dir_site."/".$default_site."/".$dir_img."/".$site_logo;
          //echo("<img class='imgclass' src=$l />");
          echo("<br />");
          echo("<div class='sdiv0'>InalFF<br />Fejleszt�i Fel�let</div>");
          echo("<br />");
          $l=$dir_site."/".$default_site."/".$dir_img."/".$dev_logo;
          //echo("<img class='imgclass' src=$l />");
          echo("<div class='sdiv1'>Inet Alkalmaz�s �s<br />Rendszer Fejleszt�i Iroda</div>");
        echo("</div>");
        echo("<div class='smotto'>");
          echo("<br />");
          echo("<br />");
          echo("<br />");
          echo("<br />");
          echo("<br />");
          echo("<br />");
          echo("<br />");
          echo("<div class='sdiv'>$motto</div>");
        echo("</div>");
      echo("</div>");
    echo("</div>");

    echo("<div class='full_center'>");
      echo("<div class='col_left'>");
        site_page_menu_global("menu_head","menu_block");
        site_page_menu_plugin("menu_head","menu_block","add_line");
        site_page_menu_reg("menu_head","menu_block","add_line",false);
        site_page_menu_reg_admin("menu_head","menu_block","add_line");
        site_page_menu_plus("menu_head","menu_block","add_line");
        site_page_menu_link("menu_head","menu_block","add_line","Design men�",$menu,$link,false);
        site_page_last_article_list("menu_head","menu_block","add_line",2,false,false);
        site_page_last_article_list("menu_head","menu_block","add_line",2,true,true);
        site_page_banner_vert("hbanner");
        site_page_box_open("menu_head","menu_block","add_line","Szavaz�s");
        mv_aktpoll();
        site_page_box_end();
        //google_facebook($site_server_name);
      echo("</div>");

      echo("<div class='col_center'>");
        echo("<div class='wcontainer'>");
          site_page_menu_wiki("");
    // display page
  }


  // kozep zar, lab

  function design_end(){
    global $dir_site,$default_site,$dir_img,$dev_logo,
           $developer,$developer_email,$licence,
           $template_path;

        echo("</div>");
        echo("<div class='wcontainer'>");
          site_page_banner_hor("");
        echo("</div>");
    // center zar
      echo("</div>");
    echo("</div>");

    echo("<div class='full'>");
      echo("<div class='footer'>");
        echo("<div class='bottom1'>");
          $l=$dir_site."/".$default_site."/".$dir_img."/".$dev_logo;
          $l2=$template_path."/".$dir_img."/inalfi_logo.png";
          echo("<img src=$l />");
          echo("<br />");
          echo("<div class='adiv_sig'>$licence</div>");
          echo("<br />");
          echo("<div class='adiv_sig'><a class='href' href='mailto:$developer_email'>$developer_email</a></div>");
          echo("<br />");
          echo("<br />");
        echo("</div>");
        echo("<div class='bottom2'>");
          site_page_last_article_list("","","",1,true,false);
        echo("</div>");
        echo("<div class='bottom3'>");
          site_page_last_article_list("","","",2,false,false);
        echo("</div>");
        echo("<div class='wcontainer'>");
        echo("</div>");
      echo("</div>");
      //site_page_sig("container");
    echo("</div>");
  }


  function google_facebook($sitesname){
    echo("<div class='container'>");
    echo("<br />");
    echo("<br />");
    echo("<div class='g_fb'>");
    echo("<g:plusone size=medium annotation='box_count' href=$sitesname></g:plusone>");
    echo("<br /><br />");
    //echo("</div>");
    //echo("<div class='g_fb'>");
    echo("<iframe src='//www.facebook.com/plugins/like.php?href=$sitesname");
    echo("&amp;send=false&amp;layout=button_count&amp;width=250&amp;show_faces=false&amp;action=like");
    echo("&amp;colorscheme=light&amp;font&amp;height=30' scrolling='no' frameborder='0' ");
    echo("style='border:none; overflow:hidden; width:auto; height:30px;' allowTransparency='true'>");
    echo("</iframe>");
    echo("</div>");
    echo("<div class='wcontainer'>");
    echo("</div>");
    echo("</div>");
  }                

?>
