<?php

  // w_robot --- PHP portalrobot
  // (verzioadatok a konfiguracios fajlban)
  //
  // fejleszto: InalR Fejlesztoi Iroda


  // fej, menuoldal, jobboldal, kozepresz nyitas
  // itt lehet megv�ltoztatni a portal felepiteset


  function design(){
    global $site_data_css_container,
           $motto,$dir_site,$default_site,$dir_img,$site_logo,
           $dir_template,$default_template,
           $dev_logo,$sitepos,$lang_system;

    $site_data_css_container="wcontainer";

    switch ($lang_system){
      case "hu":
        $local_lang_divs=array("Rekl�m","Kapcsolat","Aj�nlott oldalak","T�mogat� (t�rhely)");
        break;
      case "en":
        $local_lang_divs=array("Ads","Contact","Links","Powered by");
        break;
      default:
        $local_lang_divs=array("Rekl�m","Kapcsolat","Aj�nlott oldalak","T�mogat� (t�rhely)");
        break;
    }

    echo("<div class='head'>");
      echo("<div class='headlogin'>");
        echo("<div class='searchh'>");
          site_page_search_hor("");
        echo("</div>");
        echo("<div class='loginh'>");
          site_page_login_hor("");
        echo("</div>");

        echo("<script language='JavaScript'>");
          echo("function color_in(th){");
          echo("  th.style.borderColor='#000000';");
          echo("}");
          echo("function color_out(th){");
          echo("  th.style.borderColor='#cccccc';");
          echo("}");
        echo("</script>");
        echo("<div class='linepagemenu'>");
          site_menu_global_txt($txt);
          $x2=count($txt);
          while ($x2>0){
            $x2--;
            //echo("<div class='linepmenuw'>$txt[$x2]</div>");
            echo("<div id='linepmenuw' class='linepmenuw' onmouseover='color_in(this)' onmouseout='color_out(this)'>$txt[$x2]</div>");
          }
        echo("<br /></div>");

      echo("</div>");
      echo("<div class='headbox'>");
        echo("<div class='slogo'>");
          //$l=$dir_site."/".$default_site."/".$dir_img."/".$site_logo;
          //echo("<img class='imgclass' src=$l />");
          echo("<br />");
          echo("<div class='sdiv0'>InalFF<br />Inet Alkalmaz�s<br />Fejleszt�i Fel�let</div>");
          //echo("<br />");
          $l=$dir_site."/".$default_site."/".$dir_img."/".$dev_logo;
          echo("<img class='imgclass' src=$l />");
        echo("</div>");
        echo("<div class='smotto'>");
          echo("<br />");
          echo("<br />");
          echo("<br />");
          echo("<br />");
          echo("<br />");
          echo("<br />");
          echo("<br />");
          echo("<div class='sdiv'>$motto</div>");
        echo("</div>");
      echo("</div>");
    echo("</div>");

    echo("<div class='full_center'>");
      echo("<div class='col_left'>");
        site_page_menu_global("menu_head","menu_block");
        site_page_menu_plugin("menu_head","menu_block","add_line");
        site_page_menu_reg("menu_head","menu_block","add_line",false);
        site_page_menu_reg_admin("menu_head","menu_block","add_line");
        site_page_menu_plus("menu_head","menu_block","add_line");
        //site_page_last_article_list("menu_head","menu_block","add_line",2,false,false);
        //site_page_last_article_list("menu_head","menu_block","add_line",2,true,true);
        site_page_banner_vert("hbanner");
        sponsor($local_lang_divs[3]);
        iadsense($local_lang_divs[0]);
      echo("</div>");

      echo("<div class='col_center'>");
        echo("<div class='wcontainer'>");
          site_page_menu_wiki("");

    // display page
  }


  // kozep zar, lab

  function design_end(){
    global $dir_site,$default_site,$dir_img,$dev_logo,
           $developer,$developer_email,$licence,$template_path;

        echo("</div>");
        echo("<div class='wcontainer'>");
          site_page_banner_hor("");
        echo("</div>");
    // center zar
      echo("</div>");
        echo("<div class='wcontainer'>");
        echo("</div>");
    echo("</div>");

    echo("<div class='full'>");
      echo("<div class='footer'>");
        echo("<div class='bottom1'>");
          $l=$template_path."/".$dir_img."/inalfi_logo.png";
          $l=$dir_site."/".$default_site."/".$dir_img."/".$dev_logo;
          echo("<img src=$l />");
          echo("<br />");
          echo("<div class='adiv_sig'>$licence</div>");
          echo("<br />");
          echo("<div class='adiv_sig'><a class='href' href='mailto:$developer_email'>$developer_email</a></div>");
          echo("<br />");
          echo("<br />");
        echo("</div>");
        echo("<div class='bottom2'>");
          site_page_last_article_list("","","",0,true,false);
        echo("</div>");
        echo("<div class='bottom3'>");
          site_page_last_article_list("","","",1,false,false);
        echo("</div>");
          echo("<div class='wcontainer'>");
            echo("<div class='hiddendiv'></div>");
          echo("</div>");
      echo("</div>");
      //site_page_sig("container");
    echo("</div>");
  }


  function sponsor($cim){
    echo("<div class='menu_head'>");
    echo("<center><div class='add_line'><b>$cim</b></div></center>");
    echo("<div class='menu_block'><center>");
    echo("<br /><center>");
    echo("<a href='http://www.000webhost.com/' target='_blank'><img src='http://www.000webhost.com/images/120x60_powered.gif' ");
    echo(" alt='Web Hosting' width='120' height='60' border='0' /></a><br />");
    echo("</div>");
    echo("</div>");
  }

  function iadsense($cim){
    echo("<div class='menu_head'>");
    echo("<center><div class='add_line'><b>$cim</b></div></center>");
    echo("<div class='menu_block'><center>");

    echo("

         <script type='text/javascript'>
           <!--
           google_ad_client = 'pub-1145041375849096';
           /* 120x240, l�trehozva 2009.03.11. */
           google_ad_slot = '9782466081';
           google_ad_width = 120;
           google_ad_height = 240;
           -->
         </script>
        <script type='text/javascript'
          src='http://pagead2.googlesyndication.com/pagead/show_ads.js'>
        </script>

    ");

    echo("</center>");
    echo("</div>");
    echo("</div>");
  }


?>
