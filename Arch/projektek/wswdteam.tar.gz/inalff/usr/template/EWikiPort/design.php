<?php

  // w_robot --- PHP portalrobot
  // (verzioadatok a konfiguracios fajlban)
  //
  // fejleszto: InalR Fejlesztoi Iroda


  // fej, menuoldal, jobboldal, kozepresz nyitas
  // itt lehet megv�ltoztatni a portal felepiteset


  function design(){
    global $site_data_css_container,$lang_system;

    // menu fejlecek es forditasuk
    switch ($lang_system){
      case "hu":
        $local_lang_labels=array("Rekl�m","Kapcsolat","Aj�nlott oldalak");
        break;
      case "en":
        $local_lang_labels=array("Ads","Contact","Links");
        break;
      default:
        $local_lang_labels=array("Rekl�m","Kapcsolat","Aj�nlott oldalak");
        break;
    }
    //site_lang_move($local_lang_labels);

    $site_data_css_container="container";


    echo("<div class='col_left'>");

    site_page_logo("logo");
    site_page_menu_global("menu_head","menu_block");
    site_page_menu_plugin("menu_head","menu_block","add_line");
    site_page_menu_reg("menu_head","menu_block","add_line",true);
    site_page_search("menu_head","menu_block","add_line");
    //site_page_lang("menu_head","menu_block","add_line");

    site_page_menu_reg_admin("menu_head","menu_block","add_line");
    site_page_menu_plus("menu_head","menu_block","add_line");

    //i_left_contact($local_lang_labels[1]);
    //i_left_link($local_lang_labels[2]);
    //i_left_valid("");

    //site_page_banner_vert("logo");

    //i_left_adsense($local_lang_labels[0]);

    echo("</div>");
    echo("<div class='col_center'>");

    site_page_banner_hor("hbanner");
    site_page_menu_wiki("container");

    echo("<div class='container'>");

    // display page
  }


  // kozep zar, lab

  function design_end(){
    echo("</div>");
    site_page_sig("container");
  }


  // sajat elemek

  function i_left_contact($cim){
    global $local_lang_labels;

    echo("<div class='menu_head'>");
    echo("<center><div class='add_line'><b>$cim</b></div></center>");
    echo("<div class='menu_block'>");
    echo("<a class='href' href='mailto:wswdteam@gmail.com'>E-mail: wswdteam@gmail.com</a><br />");
    //echo("<br />");
    echo("<a class='href' href='http://wswdteam.vacau.com'>Weblap: wswdteam.vacau.com</a><br />");
    echo("</div>");
    echo("</div>");
  }


  function i_left_valid($cim){
    echo("<div class='menu_head'>");
    echo("<div class='menu_block'><center>");
    echo("<p><a href='http://jigsaw.w3.org/css-validator/check/referer'>");
    echo("<img style='border:0;width:88px;height:31px' src='http://jigsaw.w3.org/css-validator/images/vcss' alt='Valid CSS!' />");
    echo("</a></p><p>");
    echo("<a href='http://validator.w3.org/check?uri=referer'>");
    echo("<img src='http://www.w3.org/Icons/valid-xhtml10' alt='Valid XHTML 1.0 Transitional' height='31' width='88' />");
    echo("</a></p></center>");
    echo("</div>");
    echo("</div>");
  }


  function i_left_link($cim){
    global $local_lang_labels;

    echo("<div class='menu_head'>");
    echo("<center><div class='add_line'><b>$cim</b></div></center>");
    echo("<div class='menu_block'>");
    echo("Debian GNU/Linux project<br />");
    echo("<a class='href' href='http://www.debian.org'>Debian weblap</a><br /><br />");
    echo("Lighttpd project<br />");
    echo("<a class='href' href='http://www.lighttpd.org'>Lighttpd weblap</a><br /><br />");
    echo("PHP project<br />");
    echo("<a class='href' href='http://www.php.net'>PHP weblap</a><br />");
    echo("</div>");
    echo("</div>");
  }


  function i_left_adsense($cim){
    global $local_lang_labels;

    echo("<div class='menu_head'>");
    echo("<center><div class='add_line'><b>$cim</b></div></center>");
    echo("<div class='menu_block'><center>");

    echo("

         <script type='text/javascript'>
           <!--
           google_ad_client = 'pub-1145041375849096';
           /* 120x240, l�trehozva 2009.03.11. */
           google_ad_slot = '9782466081';
           google_ad_width = 120;
           google_ad_height = 240;
           -->
         </script>
        <script type='text/javascript'
          src='http://pagead2.googlesyndication.com/pagead/show_ads.js'>
        </script>

    ");

    echo("</center>");
    echo("</div>");
    echo("</div>");
  }

?>
