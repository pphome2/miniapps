<?php

  // w_robot --- PHP portalrobot
  // (verzioadatok a konfiguracios fajlban)
  //
  // fejleszto: InalR Fejlesztoi Iroda


  // fej, menuoldal, jobboldal, kozepresz nyitas
  // itt lehet megv�ltoztatni a portal felepiteset


  function design(){
    global $motto,$dir_site,$default_site,$dir_img,$site_logo,
           $dir_template,$default_template,
           $dev_logo,$sitepos,$lang_system;

    $site_data_css_container="";

    switch ($lang_system){
      case "hu":
        $local_lang_divs=array();
        break;
      case "en":
        $local_lang_divs=array();
        break;
      default:
        $local_lang_divs=array();
        break;
    }

    echo("<div class='head'>");
      echo("<div class='headlogin'>");
        echo("<div class='searchh'>");
          site_page_search_hor("");
        echo("</div>");
        echo("<div class='loginh'>");
          site_page_login_hor("");
        echo("</div>");
      echo("</div>");
      echo("<div class='headbox'>");
        echo("<div class='slogo'>");
          echo("<div class='sdiv0'>InalFF<br />Fejleszt�i Fel�let</div>");
          echo("<br />");
          echo("<div class='sdiv1'>Inet Alkalmaz�s �s<br />Rendszer Fejleszt�i Iroda</div>");
        echo("</div>");
        echo("<div class='smotto'>");
          echo("<br />");
          echo("<br />");
          echo("<br />");
          echo("<br />");
          echo("<br />");
          echo("<br />");
          echo("<br />");
          echo("<div class='sdiv'>Site motto</div>");
        echo("</div>");
      echo("</div>");
    echo("</div>");

    echo("<div class='full_center'>");
      echo("<div class='col_left'>");
        site_page_menu_global("menu_head","menu_block");
        site_page_menu_reg("menu_head","menu_block","add_line",true);
        site_page_search("menu_head","menu_block","add_line");
        site_page_menu_reg_admin("menu_head","menu_block","add_line");
      echo("</div>");

      echo("<div class='col_center'>");
        site_page_menu_wiki("");
        echo("<div class='wcontainer'>");

    // display page
  }


  // kozep zar, lab

  function design_end(){
    global $dir_site,$default_site,$dir_img,$dev_logo,
           $developer,$developer_email,$licence,
           $template_path;

        echo("</div>");
        echo("<div class='wcontainer'>");
        echo("</div>");
        echo("<div class='wcontainer'>");
          echo("<div class='hiddendiv'></div>");
        echo("</div>");
    // center zar
      echo("</div>");
    echo("</div>");

    echo("<div class='full'>");
      echo("<div class='footer'>");
        echo("<div class='bottom1'>");
          $l="$dir_site/$default_site/$dir_img/$dev_logo";
          echo("<img src=$l />");
          echo("<br />");
          echo("<div class='adiv_sig'>$licence</div>");
          echo("<br />");
          echo("<div class='adiv_sig'><a class='href' href='mailto:$developer_email'>$developer_email</a></div>");
          echo("<br />");
          echo("<br />");
        echo("</div>");
        echo("<div class='bottom2'>");
          site_page_last_article_list("","","",0,true,false);
        echo("</div>");
        echo("<div class='bottom3'>");
          site_page_last_article_list("","","",2,false,false);
        echo("</div>");
          echo("<div class='wcontainer'>");
            echo("<div class='hiddendiv'></div>");
          echo("</div>");
      echo("</div>");
      //site_page_sig("container");
    echo("</div>");
  }



?>
