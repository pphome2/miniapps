<?php

$default_site="V42";
$default_template="Default";
$sql_name="ewikiport";
$sql_server="localhost";
$sql_port="3306";
$sql_user="root";
$sql_pass="debianlinux";

$smtp_system_host="192.168.200.252";
$smtp_system_port="25";
$smtp_system_user="";
$smtp_system_password="";

$system_administrator_email="wswdteam@gmail.com";

?>

