<?php

  // w_robot --- PHP portalrobot
  // (verzioadatok a konfiguracios fajlban)
  //
  // fejleszto: InalR Fejlesztoi Iroda


  $sql_table_article_name="_article";
  $sql_table_article_n=array(
                         'acode',
                         'aadress', 
                         'date',
                         'user',
                         'category',
                         'abrief',
                         'article',
                         'history'
                       );
  $sql_table_article_t=array(
                         'varchar (50)',
                         'varchar (50)',
                         'varchar (50)',
                         'varchar (50)',
                         'varchar (50)',
                         'varchar (250)',
                         'text',
                         'text'
                       );

  $sql_table_users_name="_users";
  $sql_table_users_n=array(
                       'ucode',
                       'loginstartdate',
                       'loginanddate',
                       'username',
                       'password',
                       'name',
                       'address',
                       'email',
                       'newsletter'
                     );
  $sql_table_users_t=array(
                       'varchar (50)',
                       'varchar (50)',
                       'varchar (50)',
                       'varchar (50)',
                       'varchar (50)',
                       'varchar (250)',
                       'varchar (250)',
                       'varchar (150)',
                       'varchar (1)'
                     );

  $sql_table_category_name="_category";
  $sql_table_category_n=array(
                          'ccode',
                          'cname'
                        );
  $sql_table_category_t=array(
                          'varchar (50)',
                          'varchar (150)'
                        );

  $sql_table_mwall_name="_mwall";
  $sql_table_mwall_n=array(
                         'wcode',
                         'date',
                         'user',
                         'text'
                       );
  $sql_table_mwall_t=array(
                         'varchar (50)',
                         'varchar (50)',
                         'varchar (50)',
                         'text'
                       );

  $sql_table_comment_name="_comment";
  $sql_table_comment_n=array(
                         'cacode',
                         'code',
                         'date',
                         'user',
                         'rate',
                         'text'
                       );
  $sql_table_comment_t=array(
                         'varchar (50)',
                         'varchar (50)',
                         'varchar (50)',
                         'varchar (50)',
                         'varchar (2)',
                         'text'
                       );
  $sql_table_list=array();


?>
