<?php

  // w_robot --- PHP portalrobot
  // (verzioadatok a konfiguracios fajlban)
  //
  // fejleszto: InalR Fejlesztoi Iroda


  $site_404_error_file="../i_404.html";

  // site variable, if site not found

  $developer="";
  $developer_email="";
  $licence="";
  $site_admin_email="";
  $keyword="";
  $description="";
  $site_lang_system="hu";
  $site_date_format="";
  $site_time_format="";
  $dev_logo="";
  $site_logo="";
  $site_title="";
  $motto="";
  $local_menu_plus=array();
  $reg_menu_plus=array();
  $admin_menu_plus=array();
  $search_all=false;
  $search_plugin_first=false;
  $search_plugin_only=false;
  $show_writer=false;
  $wiki_style=true;
  $comment_all=false;
  $comment_1_page=false;
  $comment_rate=false;
  $enable_new_reg=true;
  $enable_view=true;
  $enable_edit=false;
  $enable_reg_edit=false;
  $enable_history=true;
  $enable_print=true;
  $enable_alist=true;
  $enable_files=true;
  $enable_search=true;
  $enable_messagewall=true;
  $enable_login=true;
  $enable_help=true;
  $enable_image_gallery=true;
  $enable_plugin=array();
  $banners_h=array("");
  $banners_h_link=array("");
  $banners_v=array("");
  $banners_v_link=array("");
  $meta=array('<meta http-equiv="content-type" content="application/xhtml+xml; charset=iso-8859-2" />',
              '<meta http-equiv="content-language" content="hu" />',
              '<meta http-equiv="content-style-type" content="text/css" />'
              );


  // article markup language
  // change this your language
  $s_menu="-";
  $s_submenu="+";
  $s_plugin="=";
  $s_language="#";
  $s_nocomment="hozz�sz�l�s-";
  $s_comment="hozz�sz�l�s+";
  $s_commentrate="hozz�sz�l�s++";
  $s_link="link";
  $s_mail="lev�l";
  $s_img="img";
  $s_sys="sys";
  $s_cent="k�z�pre";
  $s_ecent="/k�z�pre";
  $s_nline="�j";
  $s_line="vonal";
  $s_h="c�m";
  $s_eh="/c�m";
  $s_bold="vastag";
  $s_ebold="/vastag";
  $s_ita="d�lt";
  $s_eita="/d�lt";
  $s_und="al�";
  $s_eund="/al�";
  $s_par="bekezd�s";
  $s_epar="/bekezd�s";
  $s_pos="u";
  $s_posp="up";
  $s_col="oszlop";
  $s_ecol1="/o";
  $s_ecol="/oszlop";
  $s_table="t�bl�zat";
  $s_etable="/t�bl�zat";
  $s_row="sor";
  $s_erow="/sor";
  $s_data="adat";
  $s_edata="/adat";
  $s_kgal="gal�ria";
  $s_embed="beilleszt";
  $s_modul="modul";
  $s_div="div";
  $s_ediv="/div";
  $s_go="lep";
  $s_ego="/lep";

  $l_open="[";
  $l_end="]";

  // system parameters (URL)
  $sitename="site";
  $sitepage="lap";
  $usercode="ureg";
  $sitepos="poz";
  $deldata="ddel";
  $menupos="menu";
  $messpage="mlap";
  $validpage="llap";
  $dirpos="dir";
  $imgpos="img";
  $language="l";
  $searchpar="sp";
  $cookie="co";
  $pluginenv1="pin";
  $pluginenv2="pin2";

  // inside functions
  $k_message="u";
  $k_enter="b";
  $k_regist="r";
  $k_edit="e";
  $k_privat="v";
  $k_history="t";
  $k_print="p";
  $k_alist="d";
  $k_admin_1="a1";
  $k_admin_2="a2";
  $k_admin_3="a3";
  $k_admin_4="a4";
  $k_admin_5="a5";
  $k_admin_6="a6";
  $k_admin_7="a7";
  $k_admin_8="a8";
  $k_admin_9="a9";
  $k_delreg="ud";
  $k_files="f";
  $k_bigpic="bp";
  $k_bigimg="bi";
  $k_search="s"; 
  $k_feed="rssatom";
  $k_plugin="pin";
  $k_login="lin"; 
  $k_alogin="alin";
  $k_help="h";
  $k_gallery="g";
  $k_gallery_list="gl";
  $k_install="ins";
  $k_error="error";
  $k_uout="uout";
  $k_newsletter="nl";

  // rendszervaltozok
  $guest_user="Vend�g";
  $help_main_page="Seg�ts�g";
  $cat_view="Kateg�ria n�zet";

  // system def
  $s_program="";
  $s_full_program="";
  $s_full_path="";
  $plugin_menu=array();
  $plugin_func=array();
  $plugin_page="plugin-";
  $plugin_return_embed_line="";


  // select language variable
  $lang_file="lang_";
  $help_file="help_";
  //$lang_desc= array("Magyar","English");
  //$lang_label=array("hu",    "en"   );
  $lang_desc= array();
  $lang_label=array();
  $lang_system="hu";


  // feed tamogatas, ha atom=false, akkor rss
  // if atom=false then rss
  $feed=true;
  $atom=true;
  $feed_out_db=10;


  // article variable
  $article_text=array("");
  $article_brief=array("");
  $article_category="";
  $article_user="";
  $article_date="";
  $article_history=array("");
  $article_list_db=20;
  $last_article_list_db=10;
  $rate_point=5;
  $menu_out_in_page=false;

  // default parameters (history, messages)
  $hist_db=10;
  $mess_per_page=20;

  // system
  $date_format="Y.m.d.";
  $time_format="H:i";
  $full_date_format="";
  $date_time_nodot="YmdHi";
  $specchar="
";
  $specchar2="\n";
  $specchar3="\r";
  $site_adm=true;
  $lockext="_lock";
  $site_data_css_container="";
  $try_open=100;
  $user_admin=false;
  $tk=array("");
  $td=array("");

  // search engine variable
  $search_all=false;
  $search_table=array("");
  $search_name=array("");
  $search_field=array("");
  $search_view_field_1=array();
  $search_view_field_2=array();
  $search_view_field_3=array();
  $search_view_link=array();
  $search_link=array();
  $search_plugin_insert=false;
  $max_search=20;
  $searchdata="";

  // error-log system
  $site_system_error=false;
  $error_log_file="error.log";
  $error_all_mess=true;

  // system inside variable
  // rendszervaltozok - alapadatok beallitasa
  // nem valtoztathato !!!
  // no touch this!!!
  $site_server_name="";
  $default_page="";
  $post_empty=false;
  $menu="";
  $divdb=0;
  $newmenu="";
  $delkod="";
  $dirdata="";
  $imgdata="";
  $backupext=".backup";
  $plugindb=0;
  $plugin_start=false;
  $plugin_data_1="";
  $plugin_data_2="";
  $plugin_default_function_name="";
  $printed=false;
  $editor=false;
  $write_out=true;
  $mess_akt_page=1;
  $sep_at="&";
  $sep_eq="=";
  $separator="*";
  $separator2="|";
  $separator3="~";
  $separator4=":";
  $separator5="*";
  $run_time_show=true;
  $fh="";
  $aktrow=1;
  $col_number=33;
  $open_page=false;
  $page_num_out=10;
  $xmltype="";
  $doctype="<!DOCTYPE html PUBLIC '-//W3C//DTD XHTML 1.0 Transitional//EN' 'http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd'>";
  $htmlpar="xmlns='http://www.w3.org/1999/xhtml' xml:lang='en' lang='en'";
  $param_separator="&amp;";
  $list_img_ext=array(".jpg",".gif",".png");
  $text_ext=".txt";
  $char_old=array("�",   "�",  "�", "�",   "�",  "�", "�", "�", "�", " ","�",   "�",  "�", "�",   "�",  "�", "�", "�", "�", ".", ":");
  $char_new=array("oooo","ooo","oo","uuuu","uuu","uu","ee","aa","ii","|","OOOO","OOO","OO","UUUU","UUU","UU","EE","AA","II","--","---");

?>
