<?php

  // w_robot --- PHP portalrobot
  // (verzioadatok a konfiguracios fajlban)
  //
  // fejleszto: InalR Fejlesztoi Iroda
  //
  // eredeti otlet: Zebulon_hu Team
  // elso megjelenes: WSWDTeam
  // eredeti termeknev: E-WikiPort
  // felesztes kezdete: 2009.


  // nev (codename): 42

  $s_dev_program="InalFF \"42\"";
  $s_dev_version="1.0.2";
  $s_dev_copyright="(-) 2012.";
  $s_dev_team="InalRFI";
  $s_dev_mail="wswdteam@gmail.com";
  $s_dev_web="http://wswdteam.vacau.com";

  $s_gpl_dev_program="E-WikiPort";
  $s_gpl_dev_version="1.0.2";
  $s_gpl_dev_copyright="2012. GPL";
  $s_gpl_dev_team="WSWDTeam";
  $s_gpl_dev_mail="wswdteam@gmail.com";
  $s_gpl_dev_web="http://wswdteam.vacau.com";

  $s_licence="InalRFI";

  $s_dev_modules=array();

  // default site name
  $default_site="";
  $default_site_source="Devel";
  $default_template="";
  $default_template_install="Install";
  $default_template_source="Devel";

  $install_config_file="../etc/w_config_ins.php";

  //sql parameters
  $sql_driver="mysql";
  $sql_show_messages=true;
  $sql_name="wswdteam";
  $sql_server="localhost";
  $sql_port="3306";
  $sql_user="dbadmin";
  $sql_pass="DBAdmin";
  $sql_db="inalff";
  $sql_db_gpl="ewikiport";
  $sql_okinstall_file="sql_okinstall.sqldb";
  $sql_uninstall_file="sql_uninstall.sqldb";
  $sql_table_okinstall_ext=".instable";
  $sql_table_uninstall_ext=".unstable";
  $sql_config_file="w_sql_config.php";

  // e-mail
  $mail_system_available=true;
  $smtp_host="";
  $smtp_port="";
  $smtp_user="";
  $smtp_password="";
  $enable_smtp_messages=true;

  $system_administrator_email="";

  // system directorys
  $dir_template="usr/template";
  $dir_plugin="sys/plugin";
  $dir_site="usr/site";
  $dir_system="sys";
  $dir_include="lib";
  $dir_bin="bin";
  $dir_lang="sys/lang";
  $dir_log="sys/log";
  $dir_driver="sys/driver";
  $dir_guest_code="sys/guest";
  $dir_conf="etc";

  // site directorys and files
  $dir_img="img";
  $dir_data="sitedata";
  $dir_file="files";
  $dir_siteinc="inc";
  $file_user_config="site_conf.php";

  $dir_controllers="controllers";
  $dir_models="models";
  $dir_views="views";

  // template directorys and files
  $file_template_css_page="design_page.css";
  $file_template_css="design_panel.css";
  $file_template_main="design.php";
  // include design() and design_end() function !!!!!

  // admin username
  $administrator="Admin";

  // system variables
  $file_sysvar="w_sysvar.php";

  // system files
  $file_lib=array("$dir_views/w_admin_akt.php",
                  "$dir_views/w_admin_disp_1.php",
                  "$dir_views/w_admin_disp_2.php",
                  "$dir_views/w_admin_menu.php",
                  "$dir_views/w_admin_out.php",
                  "$dir_views/w_article.php",
                  "$dir_views/w_design.php",
                  "$dir_views/w_design_menu.php",
                  "$dir_views/w_display.php",
                  "$dir_views/w_feed.php",
                  "$dir_views/w_html.php",
                  "$dir_views/w_install.php",
                  "$dir_views/w_menu.php",
                  "$dir_views/w_menu_page.php",
                  "$dir_views/w_message.php",
                  "$dir_views/w_page_edit.php",
                  "$dir_views/w_page_help.php",
                  "$dir_views/w_user.php",
                  "$dir_views/w_user_edit.php",
                  "$dir_views/w_user_menu.php",
                  "$dir_controllers/w_cookie.php",
                  "$dir_controllers/w_dir.php",
                  "$dir_controllers/w_email.php",
                  "$dir_controllers/w_file.php",
                  "$dir_controllers/w_form.php",
                  "$dir_controllers/w_lang.php",
                  "$dir_controllers/w_local.php",
                  "$dir_controllers/w_operator.php",
                  "$dir_controllers/w_page.php",
                  "$dir_controllers/w_page_lang.php",
                  "$dir_controllers/w_pageing.php",
                  "$dir_controllers/w_plugin.php",
                  "$dir_controllers/w_search.php",
                  "$dir_controllers/w_site.php",
                  "$dir_controllers/w_system.php",
                  "$dir_controllers/w_user_sys.php",
                  "$dir_models/w_sql_article.php",
                  "$dir_models/w_sql_backup.php",
                  "$dir_models/w_sql_init.php",
                  "$dir_models/w_sql_std.php",
                  "$dir_models/w_sql_system.php"
                  );


  // plugins operator
  $file_plugins="plugins.php";

  // system css
  $file_system_css="w_site.css";

  // GPL system
  $gpl_system=false;
  $gpl_string="GPL";

?>
