<?php

  // w_robot --- PHP portalrobot
  // (verzioadatok a konfiguracios fajlban)
  //
  // fejleszto: InalR Fejlesztoi Iroda



  function sql_article_del($code){
    global $sql_name,$sql_server,$sql_port,$sql_user,
           $sql_pass,$sql_db,$sql_table_article_name,
           $sql_show_messages,$sql_table_article_n;

    sql_table_delete_data($sql_show_messages,$sql_server,$sql_user,$sql_pass,$sql_db,$sql_table_article_name,$sql_table_article_n[0],$code);
  }

  function sql_article_get_result($address){
    global $sql_name,$sql_server,$sql_port,$sql_user,
           $sql_pass,$sql_db,$sql_table_article_name,
           $sql_table_article_n,$sql_show_messages;

    $t=sql_table_select($sql_show_messages,$sql_server,$sql_user,$sql_pass,$sql_db,$sql_table_article_name,$sql_table_article_n[1],$address,"","");
    return($t);
  }


  function sql_article_all_result(){
    global $sql_name,$sql_server,$sql_port,$sql_user,
           $sql_pass,$sql_db,$sql_table_article_name,
           $sql_table_article_n,$sql_show_messages;

    $t=sql_table_select($sql_show_messages,$sql_server,$sql_user,$sql_pass,$sql_db,$sql_table_article_name,"","","","");
    return($t);
  }


  function sql_article_all_result_l(){
    global $sql_name,$sql_server,$sql_port,$sql_user,
           $sql_pass,$sql_db,$sql_table_article_name,
           $sql_table_article_n,$sql_show_messages;

    $t=sql_table_select($sql_show_messages,$sql_server,$sql_user,$sql_pass,$sql_db,$sql_table_article_name,"","",$sql_table_article_n[0],"1");
    return($t);
  }


  function sql_article_cat_get_result($cat){
    global $sql_name,$sql_server,$sql_port,$sql_user,
           $sql_pass,$sql_db,$sql_table_article_name,
           $sql_table_article_n,$sql_show_messages;

    $t=sql_table_select($sql_show_messages,$sql_server,$sql_user,$sql_pass,$sql_db,$sql_table_article_name,$sql_table_article_n[4],$cat,$sql_table_article_n[2],"1");
    return($t);
  }


  function sql_article_add($user,$address,$cat,$bri,$datat){
    global $sql_name,$sql_server,$sql_port,$sql_user,
           $sql_pass,$sql_db,$sql_table_article_name,
           $sql_table_article_n,$sql_show_messages,
           $separator,$full_date_format;

    $t=sql_table_select($sql_show_messages,$sql_server,$sql_user,$sql_pass,$sql_db,$sql_table_article_name,$sql_table_article_n[1],$address,"","");
    $x=sql_result_db($t);
    $date=date($full_date_format);
    $out=sql_get_result_data($t,0);
    if ($x>0){
      $outdata[0]=$out[0];
      $outdata[1]=$out[1];
      $outdata[2]=$out[2];
      $outdata[3]=$out[3];
      $outdata[4]=$cat;
      $outdata[5]=implode(" ",$bri);;
      $outdata[6]=implode(" ",$datat);
      $h=explode($separator,$out[7]);
      $x=count($h);
      if ($x>9){
        $out[7]="";
        $y=0;
        while ($y<9){
          if ($y<>0){
            $out[7]=$out[7].$separator;
          }
          $out[7]=$out[7].$h[$y];
          $y++;
        }
      }
      $outdata[7]=$date." ".$user.$separator.$out[7];
      sql_table_update_data($sql_show_messages,$sql_server,$sql_user,$sql_pass,$sql_db,$sql_table_article_name,$outdata,$sql_table_article_n,$sql_table_article_n[1],$address);
    }else{
      $outdata[0]=sys_time_code();
      $outdata[1]=$address;
      $outdata[2]=$date;
      $outdata[3]=$user;
      $outdata[4]=$cat;
      $outdata[5]=implode(" ",$bri);;
      $outdata[6]=implode(" ",$datat);
      $outdata[7]=$date." ".$user;
      sql_table_insert_data($sql_show_messages,$sql_server,$sql_user,$sql_pass,$sql_db,$sql_table_article_name,$outdata);
    }
  }


?>
