<?php

  // w_robot --- PHP portalrobot
  // (verzioadatok a konfiguracios fajlban)
  //
  // fejleszto: InalR Fejlesztoi Iroda



  // sql t�rol� kezel�se


  // sql mentes viszzaallitas

  function sql_backup($dir){
    global $sql_table_list,$backupext,$separator2,$separator3,
           $sql_name,$sql_server,$sql_port,$sql_user,
           $sql_show_messages,$sql_pass,$sql_db;

    $x=count($sql_table_list);
    $outtomb=array();
    $c=0;
    $y=0;
    echo("<div class='label_hidden'>");
    while ($y<$x){
      if ($sql_table_list[$y]<>""){
        echo("<br />$sql_table_list[$y]");
        $t=sql_table_select($sql_show_messages,$sql_server,$sql_user,$sql_pass,$sql_db,$sql_table_list[$y],"","","","");
        $db=sql_result_db($t);
        $outtomb[$c]=$separator2.$separator2.$sql_table_list[$y];
        $c++;
        $i=0;
        $l=sql_result_fields_db($t);
        while ($i<$db){;
          echo(".");
          $tomb=sql_get_result_data($t,$i);
          $outtomb[$c]=$separator3;
          $k=0;
          while ($k<$l){
            $outtomb[$c]=$outtomb[$c].$separator2.$tomb[$k];
            $k++;
          }
          $c++;
          $i++;
        }
      }
      $y++;
    }
    echo("</div>");
    $ido=date("Y-m-d-H-i");
    $out=$dir."/".$ido.$backupext;
    sys_file_out($out,$outtomb);
  }


  function sql_restore($file,$table){
    global $sql_table_list,$backupext,$separator2,$separator3,
           $sql_name,$sql_server,$sql_port,$sql_user,
           $sql_show_messages,$sql_pass,$sql_db;

    if ($table==""){
      $all=true;
    }else{
      $all=false;
    }
    $del=false;
    sys_file_in($file,$tomb);
    $c=count($tomb);
    $vissza=false;
    $elso=false;
    $t2="";
    $x=0;
    while ($x<$c){
      if ((substr($tomb[$x],0,1)==$separator2)and(substr($tomb[$x],1,1)==$separator2)){
        $vissza=false;
        if (substr($tomb[$x],2,strlen($tomb[$x]))==$table){
          $vissza=true;
          $elso=true;
          if ($all){
            $del=false;
            $table=substr($tomb[$x],2,strlen($tomb[$x]));
          }
        }else{
          if ($t2<>""){
            $t=explode($separator2,$t2);
            sql_insert_data($t,$table);
            $t2="";
          }
        }
      }else{
      }
      if ($vissza){
        if (!$del){
          sql_delete_data($table);
          $del=true;
        }
        if (!$elso){
          if ((substr($tomb[$x],0,1)==$separator3)and($t2<>"")){
            $t=explode($separator2,$t2);
            sql_insert_data($t,$table);
            $tomb[$x]=substr($tomb[$x],2,strlen($tomb[$x]));
            $t2=$tomb[$x]." \n";
          }else{
            if (substr($tomb[$x],0,1)==$separator3){
              $tomb[$x]=substr($tomb[$x],2,strlen($tomb[$x]));
            }
            $t2=$t2.$tomb[$x]." \n";
          }
        }else{
          $elso=false;
        }
      }
      $x++;
    }
    if ($t2<>""){
      $t=explode($separator2,$t2);
      sql_insert_data($t,$table);
      $t2="";
    }
  }


?>
