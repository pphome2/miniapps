<?php

  // w_robot --- PHP portalrobot
  // (verzioadatok a konfiguracios fajlban)
  //
  // fejleszto: InalR Fejlesztoi Iroda



  function sql_insert_data($tomb,$tname){
    global $sql_name,$sql_server,$sql_port,$sql_user,
           $sql_show_messages,$sql_pass,$sql_db;

    sql_insert_data_table($sql_show_messages,$sql_server,$sql_user,$sql_pass,$sql_db,$tomb,$tname);
  }


  function sql_mwall_add($c,$d,$u,$t){
    global $sql_name,$sql_server,$sql_port,$sql_user,
           $sql_show_messages,$sql_pass,$sql_db,$sql_table_mwall_name;

    $dt[0]=$c;
    $dt[1]=$d;
    $dt[2]=$u;
    $dt[3]=$t;
    sql_table_insert_data($sql_show_messages,$sql_server,$sql_user,$sql_pass,$sql_db,$sql_table_mwall_name,$dt);
  }


  function sql_mwall_del($c){
    global $sql_name,$sql_server,$sql_port,$sql_user,
           $sql_show_messages,$sql_pass,$sql_db,
           $sql_table_mwall_name,$sql_table_mwall_n;


    sql_table_delete_data($sql_show_messages,$sql_server,$sql_user,$sql_pass,$sql_db,$sql_table_mwall_name,$sql_table_mwall_n[0],$c);
  }


  function sql_mwall_get_result(){
    global $sql_name,$sql_server,$sql_port,$sql_user,$sql_table_mwall_n,
           $sql_show_messages,$sql_pass,$sql_db,$sql_table_mwall_name;

    $t=sql_table_select($sql_show_messages,$sql_server,$sql_user,$sql_pass,$sql_db,$sql_table_mwall_name,"","",$sql_table_mwall_n[0],"1");
    return($t);
  }


  function sql_comment_add($a,$c,$d,$u,$p,$t){
    global $sql_name,$sql_server,$sql_port,$sql_user,
           $sql_show_messages,$sql_pass,$sql_db,$sql_table_comment_name;

    $dt[0]=$a;
    $dt[1]=$c;
    $dt[2]=$d;
    $dt[3]=$u;
    $dt[4]=$p;
    $dt[5]=$t;
    sql_table_insert_data($sql_show_messages,$sql_server,$sql_user,$sql_pass,$sql_db,$sql_table_comment_name,$dt);
  }


  function sql_comment_del($c){
    global $sql_name,$sql_server,$sql_port,$sql_user,
           $sql_show_messages,$sql_pass,$sql_db,
           $sql_table_comment_name,$sql_table_comment_n;


    sql_table_delete_data($sql_show_messages,$sql_server,$sql_user,$sql_pass,$sql_db,$sql_table_comment_name,$sql_table_comment_n[0],$c);
  }


  function sql_comment_get_result($code){
    global $sql_name,$sql_server,$sql_port,$sql_user,
           $sql_show_messages,$sql_pass,$sql_db,
           $sql_table_comment_name,$sql_table_comment_n;


    $t=sql_table_select($sql_show_messages,$sql_server,$sql_user,$sql_pass,$sql_db,$sql_table_comment_name,$sql_table_comment_n[1],$code,$sql_table_comment_n[0],"1");
    return($t);
  }


  function sql_user_add($datat){
    global $sql_name,$sql_server,$sql_port,$sql_user,
           $sql_show_messages,$sql_pass,$sql_db,$sql_table_users_name;

    sql_table_insert_data($sql_show_messages,$sql_server,$sql_user,$sql_pass,$sql_db,$sql_table_users_name,$datat);
  }


  function sql_user_update($code,$datat){
    global $sql_name,$sql_server,$sql_port,$sql_user,
           $sql_pass,$sql_db,$sql_table_users_name,
           $sql_show_messages,$sql_table_users_n;

    sql_table_update_data($sql_show_messages,$sql_server,$sql_user,$sql_pass,$sql_db,$sql_table_users_name,$datat,$sql_table_users_n,$sql_table_users_n[0],$code);
  }


  function sql_user_del($code){
    global $sql_name,$sql_server,$sql_port,$sql_user,
           $sql_pass,$sql_db,$sql_table_users_name,
           $sql_show_messages,$sql_table_users_n;

    sql_table_delete_data($sql_show_messages,$sql_server,$sql_user,$sql_pass,$sql_db,$sql_table_users_name,$sql_table_users_n[0],$code);
  }


  function sql_user_getdata($code){
    global $sql_name,$sql_server,$sql_port,$sql_user,
           $sql_pass,$sql_db,$sql_table_users_name,
           $sql_show_messages,$sql_table_users_n;

    $t=sql_table_select($sql_show_messages,$sql_server,$sql_user,$sql_pass,$sql_db,$sql_table_users_name,$sql_table_users_n[0],$code,"","");
    $t2=sql_result($t,0,3);
    return($t2);
  }

  function sql_user_getdata_name($name){
    global $sql_name,$sql_server,$sql_port,$sql_user,
           $sql_pass,$sql_db,$sql_table_users_name,
           $sql_show_messages,$sql_table_users_n;

    $t=sql_table_select($sql_show_messages,$sql_server,$sql_user,$sql_pass,$sql_db,$sql_table_users_name,$sql_table_users_n[3],$name,"","");
    $t2=sql_result($t,0,0);
    return($t2);
  }


  function sql_user_getdata_all($code){
    global $sql_name,$sql_server,$sql_port,$sql_user,
           $sql_pass,$sql_db,$sql_table_users_name,
           $sql_show_messages,$sql_table_users_n;

    $t=sql_table_select($sql_show_messages,$sql_server,$sql_user,$sql_pass,$sql_db,$sql_table_users_name,$sql_table_users_n[0],$code,"","");
    $t2=sql_result_all($t,0);
    return($t2);
  }


  function sql_user_get_result(){
    global $sql_name,$sql_server,$sql_port,$sql_user,
           $sql_pass,$sql_db,$sql_table_users_name,
           $sql_show_messages;

    $t=sql_table_select($sql_show_messages,$sql_server,$sql_user,$sql_pass,$sql_db,$sql_table_users_name,"","","","");
    return($t);
  }


  function sql_user_enter($name,$pass){
    global $sql_name,$sql_server,$sql_port,$sql_user,
           $sql_pass,$sql_db,$sql_table_users_name,
           $sql_show_messages,$sql_table_users_n,
           $separator;

    $t=sql_table_select($sql_show_messages,$sql_server,$sql_user,$sql_pass,$sql_db,$sql_table_users_name,$sql_table_users_n[4],$pass,"","");
    $t2=sql_result_all($t,0);
    if (isset($t2[0])){
      $tname=$t2[0];
      $uname=$t2[3];
      if ($uname==$name){
        $rtime=$t2[1];
        $itime=$t2[2];
        if ($itime<>$separator){
          $d=time();
          $entertime=intval($rtime)+intval($itime);
          if ($entertime<$d){
            $tname="";
          }
        }
      }else{
        $tname="";
      }
    }else{
      $tname="";
    }
    return($tname);
  }


  function sql_category_get_result(){
    global $sql_name,$sql_server,$sql_port,$sql_user,
           $sql_pass,$sql_db,$sql_table_category_name,
           $sql_show_messages;

    $t=sql_table_select($sql_show_messages,$sql_server,$sql_user,$sql_pass,$sql_db,$sql_table_category_name,"","","","");
    return($t);
  }


  function sql_category_del($code){
    global $sql_name,$sql_server,$sql_port,$sql_user,
           $sql_pass,$sql_db,$sql_table_category_name,
           $sql_show_messages,$sql_table_category_n;

    sql_table_delete_data($sql_show_messages,$sql_server,$sql_user,$sql_pass,$sql_db,$sql_table_category_name,$sql_table_category_n[0],$code);
  }


  function sql_category_add($datat){
    global $sql_name,$sql_server,$sql_port,$sql_user,
           $sql_show_messages,$sql_pass,$sql_db,$sql_table_category_name;

    sql_table_insert_data($sql_show_messages,$sql_server,$sql_user,$sql_pass,$sql_db,$sql_table_category_name,$datat);
  }


?>
