<?php

  // w_robot --- PHP portalrobot
  // (verzioadatok a konfiguracios fajlban)
  //
  // fejleszto: InalR Fejlesztoi Iroda



  function sql_search($table,$field,$q){
    global $sql_name,$sql_server,$sql_port,$sql_user,
           $sql_show_messages,$sql_pass,$sql_db;

    $r=sql_table_search($sql_show_messages,$sql_server,$sql_user,$sql_pass,$sql_db,$table,$field,$q);
    return($r);
  }


  function sql_delete_data($tname){
    global $sql_name,$sql_server,$sql_port,$sql_user,
           $sql_show_messages,$sql_pass,$sql_db;

    sql_delete_alldata_table($sql_show_messages,$sql_server,$sql_user,$sql_pass,$sql_db,$tname);
  }


  function sql_result_db($r){
    $db=sql_result_num($r);
    return($db);
  }


  function sql_result_fields_db($r){
    $db=sql_result_fields($r);
    return($db);
  }


  function sql_get_result_data($r,$y){
    $t=sql_result_all($r,$y);
    return($t);
  }


  function sql_data_del($tname,$fname,$code){
    global $sql_name,$sql_server,$sql_port,$sql_user,
           $sql_pass,$sql_db,$sql_show_messages;

    sql_table_delete_data($sql_show_messages,$sql_server,$sql_user,$sql_pass,$sql_db,$tname,$fname,$code);
  }


  function sql_data_del_rec($tname,$fname,$num,$code){
    global $sql_name,$sql_server,$sql_port,$sql_user,
           $sql_pass,$sql_db,$sql_show_messages;

    $tx=sql_data_allget($tname);
    $x=0;
    $ddb=sql_result_db($tx);
    while($x<$ddb){
      $tomb=sql_get_result_data($tx,$x);
      if ($tomb[$num]==$code){
        sql_table_delete_data($sql_show_messages,$sql_server,$sql_user,$sql_pass,$sql_db,$tname,$fname,$tomb[0]);
      }
      $x++;
    }
  }


  function sql_data_get($tname,$fname,$code){
    global $sql_name,$sql_server,$sql_port,$sql_user,
           $sql_pass,$sql_db,$sql_show_messages;

    $t=sql_table_select($sql_show_messages,$sql_server,$sql_user,$sql_pass,$sql_db,$tname,$fname,$code,"","");
    return($t);
  }


  function sql_data_get_desc($tname,$fname,$code){
    global $sql_name,$sql_server,$sql_port,$sql_user,
           $sql_pass,$sql_db,$sql_show_messages;

    $t=sql_table_select($sql_show_messages,$sql_server,$sql_user,$sql_pass,$sql_db,$tname,$fname,$code,$fname,"1");
    return($t);
  }


  function sql_data_allget($tname){
    global $sql_name,$sql_server,$sql_port,$sql_user,
           $sql_pass,$sql_db,$sql_show_messages;

    $t=sql_table_select($sql_show_messages,$sql_server,$sql_user,$sql_pass,$sql_db,$tname,"","","","");
    return($t);
  }


  function sql_data_allget_desc($tname,$field){
    global $sql_name,$sql_server,$sql_port,$sql_user,
           $sql_pass,$sql_db,$sql_show_messages;

    $t=sql_table_select($sql_show_messages,$sql_server,$sql_user,$sql_pass,$sql_db,$tname,"","",$field,"1");
    return($t);
  }


  function sql_data_add($tname,$tomb){
    global $sql_name,$sql_server,$sql_port,$sql_user,
           $sql_show_messages,$sql_pass,$sql_db;

    sql_insert_data_table($sql_show_messages,$sql_server,$sql_user,$sql_pass,$sql_db,$tomb,$tname);
  }


  function sql_data_update($tname,$tablef,$field,$code,$datat){
    global $sql_name,$sql_server,$sql_port,$sql_user,
           $sql_pass,$sql_db,$sql_show_messages;

    sql_table_update_data($sql_show_messages,$sql_server,$sql_user,$sql_pass,$sql_db,$tname,$datat,$tablef,$field,$code);
  }


?>
