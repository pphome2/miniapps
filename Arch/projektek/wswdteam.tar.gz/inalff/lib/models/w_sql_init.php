<?php

  // w_robot --- PHP portalrobot
  // (verzioadatok a konfiguracios fajlban)
  //
  // fejleszto: Inal Fejlesztoi Iroda



  // sql t�rol� kezel�se

  function sql_close(){
    sql_server_close();
  }


  function sql_open(){
    sql_server_open();
    sql_init();
  }


  function sql_init(){
    global $sql_okinstall_file,$sql_uninstall_file,
           $sql_name,$sql_server,$sql_port,$sql_user,
           $sql_pass,$sql_db,$dir_log,$sql_show_messages,
           $sql_table_article_name,$sql_table_article_n,$sql_table_article_t,
           $sql_table_users_name,$sql_table_users_n,$sql_table_users_t,
           $sql_table_category_name,$sql_table_category_n,$sql_table_category_t,
           $sql_table_mwall_name,$sql_table_mwall_n,$sql_table_mwall_t,
           $sql_table_comment_name,$sql_table_comment_n,$sql_table_comment_t,
           $administrator,$separator,$sql_table_letter,$default_site,
           $sql_table_okinstall_ext,$sql_table_uninstall_ext,$sql_table_list,
           $sql_site_name,$sql_site_server,$sql_site_port,$sql_site_user,
           $sql_site_pass,$sql_site_db,$gpl_system,$sql_db_gpl;

    if ($gpl_system){
      $sql_db=$sql_db_gpl;
    }
    if ($sql_site_name<>""){
      $sql_name=$sql_site_name;
    }
    if ($sql_site_server<>""){
      $sql_server=$sql_site_server;
    }
    if ($sql_site_port<>""){
      $sql_port=$sql_site_port;
    }
    if ($sql_site_user<>""){
      $sql_user=$sql_site_user;
    }
    if ($sql_site_pass<>""){
      $sql_pass=$sql_site_pass;
    }
    if ($sql_site_db<>""){
      $sql_db=$sql_site_db;
    }

    $sql_table_article_name=$sql_table_letter.$sql_table_article_name;
    $sql_table_users_name=$sql_table_letter.$sql_table_users_name;
    $sql_table_category_name=$sql_table_letter.$sql_table_category_name;
    $sql_table_comment_name=$sql_table_letter.$sql_table_comment_name;
    $sql_table_mwall_name=$sql_table_letter.$sql_table_mwall_name;

    $sql_okinstall_nfile=$dir_log."/".$sql_okinstall_file;
    $sql_uninstall_nfile=$dir_log."/".$sql_uninstall_file;
    $table_ins_file=$dir_log."/".$sql_table_letter."_".$default_site.$sql_table_okinstall_ext;
    $table_unins_file=$dir_log."/".$sql_table_letter."_".$default_site.$sql_table_uninstall_ext;

    $sql_table_list[0]=$sql_table_article_name;
    $sql_table_list[1]=$sql_table_users_name;
    $sql_table_list[2]=$sql_table_category_name;
    $sql_table_list[3]=$sql_table_comment_name;
    $sql_table_list[4]=$sql_table_mwall_name;

    $data=array("");
    $okdb=true;
    if (!file_exists($sql_okinstall_nfile)){
      sql_db_create($sql_show_messages,$sql_server,$sql_user,$sql_pass,$sql_db,"");
      $data[0]="SQL DB created: $sql_db.\n";
      sys_file_out($sql_okinstall_nfile,$data);
    }else{
      if (file_exists($sql_uninstall_nfile)){
        sql_db_delete($sql_show_messages,$sql_server,$sql_user,$sql_pass,$sql_db,"");
        sys_file_del($sql_okinstall_nfile);
        sys_file_del($sql_uninstall_nfile);
        sys_dir_list($dir_log,$dl);
        $x=count($dl);
        $y=0;
        while ($y<$x){
          $kite=explode('.',$dl[$y]);
          $kit=".".$kite[1];
          if (($kit==$sql_table_okinstall_ext)or($sql_table_uninstall_uninstall_ext)){
            $f=$dir_log."/".$dl[$y];
            sys_file_del($f);
          }
          $y++;
        }
        $okdb=false;
      }
    }
    if ($okdb){
      if ((!file_exists($table_ins_file))and(!file_exists($table_unins_file))){
        $tname=$sql_table_article_name;
        sql_table_create($sql_show_messages,$sql_server,$sql_user,$sql_pass,$sql_db,$tname,$sql_table_article_n,$sql_table_article_t,"");
        $data[1]="SQL table created: $tname.\n";
        $tname=$sql_table_users_name;
        sql_table_create($sql_show_messages,$sql_server,$sql_user,$sql_pass,$sql_db,$tname,$sql_table_users_n,$sql_table_users_t,"");
        $data[2]="SQL table created: $tname.\n";
        $tname=$sql_table_category_name;
        sql_table_create($sql_show_messages,$sql_server,$sql_user,$sql_pass,$sql_db,$tname,$sql_table_category_n,$sql_table_category_t,"");
        $data[3]="SQL table created: $tname.\n";
        $tname=$sql_table_comment_name;
        sql_table_create($sql_show_messages,$sql_server,$sql_user,$sql_pass,$sql_db,$tname,$sql_table_comment_n,$sql_table_comment_t,"");
        $data[4]="SQL table created: $tname.\n";
        $tname=$sql_table_mwall_name;
        sql_table_create($sql_show_messages,$sql_server,$sql_user,$sql_pass,$sql_db,$tname,$sql_table_mwall_n,$sql_table_mwall_t,"");
        $data[5]="SQL table created: $tname.\n";
        sys_file_out($table_ins_file,$data);
        $t[0]=sys_time_code();
        $t[1]=time();
        $t[2]=$separator;
        $t[3]=$administrator;
        $t[4]=md5($administrator);
        $t[5]="-";
        $t[6]="-";
        $t[7]="-";
        $t[8]=$separator;
        sql_user_add($t);
      }else{
        if (file_exists($table_unins_file)){
          $sql_table_article_name=$sql_table_letter.$sql_table_article_name;
          $tname=$sql_table_article_name;
          sql_table_delete($sql_show_messages,$sql_server,$sql_user,$sql_pass,$sql_db,$tname,"");
          $sql_table_user_name=$sql_table_letter.$sql_table_user_name;
          $tname=$sql_table_users_name;
          sql_table_delete($sql_show_messages,$sql_server,$sql_user,$sql_pass,$sql_db,$tname,"");
          $sql_table_category_name=$sql_table_letter.$sql_table_category_name;
          $tname=$sql_table_category_name;
          sql_table_delete($sql_show_messages,$sql_server,$sql_user,$sql_pass,$sql_db,$tname,"");
          $sql_table_comment_name=$sql_table_letter.$sql_table_comment_name;
          $tname=$sql_table_comment_name;
          sql_table_delete($sql_show_messages,$sql_server,$sql_user,$sql_pass,$sql_db,$tname,"");
          $sql_table_mwall_name=$sql_table_letter.$sql_table_mwall_name;
          $tname=$sql_table_mwall_name;
          sql_table_delete($sql_show_messages,$sql_server,$sql_user,$sql_pass,$sql_db,$tname,"");
          sys_file_del($table_ins_file);
          sys_file_del($table_unins_file);
        }
      }
    }
  }


  function sql_plugin_init(&$tname,$table_name,$table_type){
    global $sql_name,$sql_server,$sql_port,$sql_user,
           $sql_pass,$sql_db,$sql_show_messages,
           $sql_table_letter,$default_site,$dir_log,
           $sql_table_okinstall_ext,$sql_table_uninstall_ext,$sql_table_list;

    $tname=$sql_table_letter.$tname;
    $table_ins_file=$dir_log."/".$tname.$sql_table_okinstall_ext;
    $table_unins_file=$dir_log."/".$tname.$sql_table_uninstall_ext;
    $c=count($sql_table_list);
    $sql_table_list[$c]=$tname;

    if ((!file_exists($table_ins_file))and(!file_exists($table_unins_file))){
        sql_table_create($sql_show_messages,$sql_server,$sql_user,$sql_pass,$sql_db,$tname,$table_name,$table_type,"");
        $data[0]="SQL table created: $tname.\n";
        sys_file_out($table_ins_file,$data);
    }else{
      if (file_exists($table_unins_file)){
        sql_table_delete($sql_show_messages,$sql_server,$sql_user,$sql_pass,$sql_db,$tname,"");
        sys_file_del($table_ins_file);
        sys_file_del($table_unins_file);
        $c=count($sql_table_list);
        $y=0;
        while ($y<$c){
          if ($sql_table_list[$y]==$tname){
            $sql_table_list[$y]="";
            $y=$c;
          }
          $y++;
        }
      }
    }
  }



?>
