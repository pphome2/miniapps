<?php

  // w_robot --- PHP portalrobot
  // (verzioadatok a konfiguracios fajlban)
  //
  // fejleszto: InalR Fejlesztoi Iroda




  // bejelentkezes, uj felhasznalo

  function site_enter_in(){
    global $usercode,$sitepage,$administrator,
           $default_site,$cookie,
           $separator,$separator2;

    $ok=sys_data_post($dbx,$tkx,$tex);
    $unev=sql_user_enter($tex[0],md5($tex[1]));
    $kic="";
    if ($unev<>""){
      sys_env_del($sitepage);
      sys_env_new($usercode,$unev);
      $time=2678400;
      if (count($tex)>3){
        if ($tex[2]=="on"){
          $kic="$default_site.$usercode".$separator.$unev.$separator.$time;
        }
      }
      if ($kic<>""){
        $kic=$kic.$separator2.$default_site.$separator.$unev.$separator.$time;
      }else{
        $kic=$default_site.$separator.$unev.$separator.$time;
      }
      sys_env_new($cookie,$kic);
    }
    return($unev);
  }

  // user nevenek visszaadasa

  function site_user($kod){
    global $usercode;

    $unev="";
    if ($kod==""){
      $kod=sys_env_find($usercode);
    }
    if ($kod<>""){
      $unev=sql_user_getdata($kod);
    }
    return($unev);
  }

  // user nevenek visszaadasa

  function site_user_name($n){
    $kod="";
    if ($n<>""){
      $kod=sql_user_getdata_name($n);
    }
    return($kod);
  }

  // user adatai

  function site_user_data(){
    global $usercode;

    $kod=sys_env_find($usercode);
    $unev="";
    $unev=sql_user_getdata($kod);
    return($unev);
  }


  function site_user_data_all($code){
    global $usercode;

    $ut=array();
    if ($code<>""){
      $kod=$code;
    }else{
      $kod=sys_env_find($usercode);
    }
    $ut=sql_user_getdata_all($kod);
    return($ut);
  }

  // user torlese

  function site_user_del($kod){
    if ($kod<>""){
      sql_user_del($kod);
    }
  }

  // uj felhasznalo felvitele

  function site_new_reg(){
    global $separator,$site_admin_email,
           $default_site,$developer,
           $s_full_program,$user_admin;

    $ok2=sys_data_post($dbx,$tkx,$tex);
    if ($ok2){
      $ok=1;
      $d=sys_unix_time();
      $nuser="";
      $x=0;
      while ($x<$dbx-1){
        if ($x==3){
          $nuser=$tex[$x];
        }
        if ($x==4){
          $tex[$x]=md5($tex[$x]);
        }
        if ($tex[$x]==""){
          $ok=0;
        }
        $t[$x]=$tex[$x];
        $x+=1;
      }
      if ($tex[$x]=="on"){
        $tex[$x]="X";
        $t[$x]="X";
      }else{
        $tex[$x]=$separator;
        $t[$x]=$separator;
      }
      if ($ok==1){
        $n=site_user_name($nuser);
        if ($n==""){
          sql_user_add($t);
          if (!$user_admin){
            $ki=sys_line_local("Sikeres regisztr�ci� a");
            $ki2=sys_line_local("weboldalon");
            $ki3=sys_line_local("Kedves");
            $ki4=sys_line_local("K�sz�ntj�k a");
            $ki5=sys_line_local("A regisztr�ci� a k�vetkez� adatokal t�rt�nt");
            $ki6=sys_line_local("Amennyiben az �n adataival m�s regisztr�lt, k�rj�k jelezze a");
            $ki7=sys_line_local("e-mail c�men");
            $ki8=sys_line_local("Weboldalunk");
            $to=$t[7];
            $re=$site_admin_email;
            $cc="";
            $bcc=$site_admin_email;
            $sub="$ki $default_site $ki2";
            $mess="$ki3 $t[5]! \r\n \r\n";
            $mess=$mess."$ki4 $default_site $ki2.\r\n \r\n";
            $mess=$mess."$ki5:\r\n \r\n";
            $mess=$mess."$t[3] - $t[5], $t[6], $t[7].\r\n \r\n";
            $mess=$mess."$ki8: $s_full_program \r\n \r\n";
            $mess=$mess."$ki6 $site_admin_email $ki7\r\n \r\n";
            $mess=$mess."$developer\r\n \r\n";
            //echo("$to,$re,$cc,$bcc,$sub,$mess");
            site_send_mail($to,$re,$cc,$bcc,$sub,$mess);
          }
          $ki=sys_line_local("A regisztr�ci� siker�lt. Jelentkezzen be");
          echo("<br />$ki.<br /><br />");
        }else{
          $ki=sys_line_local("Ezen a n�ven m�r l�tezik regisztr�ci�. K�rem haszn�ljon m�s nevet");
          echo("<br />$ki.<br /><br />");
          site_privat_edit("");
        }
      }else{
        $ki=sys_line_local("A regisztr�ci�s adatok nincsenek megfelel�en kit�ltve");
        echo("<br /><br />$ki.<br />");
        $ki=sys_line_local("K�rem, minden adatot adjon meg");
        echo("$ki.<br /><br />");
        site_privat_edit("");
      }
    }else{
      site_privat_edit("");
    }
  }


  // felhasznalo torlese

  function site_del_reg(){
    global $delkod,$sitepos,$sitepage;

    if ($delkod<>""){
      site_user_del($delkod);
      sys_env_del($sitepos);
      sys_env_del($sitepage);
      $ki=sys_line_local("Felhaszn�l� adatai t�r�lve lettek");
      echo("<br />$ki.");
      $ki=sys_line_local("A t�r�lt felhaszn�l� �ltal l�trehozott tartalmak (�r�sok, hozz�sz�l�sok) nem t�rl�dnek");
      echo("<br />$ki.<br /><br /> ");
    }
  }

  // sajat adatok szerkesztese

  function site_privat($ukod){
    global $usercode,$separator;

    if ($ukod==""){
      $ukod=sys_env_find($usercode);
    }
    $dbx=0;
    $ok=sys_data_post($dbx,$tkx,$tex);
    if ($ok){
      $tomb=sql_user_getdata_all($ukod);
      $tomb[0]=$tex[0];
      $tomb[1]=$tex[1];
      $tomb[2]=$tex[2];
      $tomb[3]=$tex[3];
      if (strlen($tex[4])<32){
        $tomb[4]=md5($tex[4]);
      }else{
        $tomb[4]=$tex[4];
      }
      $tomb[5]=$tex[5];
      $tomb[6]=$tex[6];
      $tomb[7]=$tex[7];
      if ($tex[8]=="on"){
        $tomb[8]="X";
      }else{
        $tomb[8]=$separator;
      }
      sql_user_update($ukod,$tomb);
      $ki=sys_line_local("Adatok ment�se megt�rt�nt");
      echo("$ki.");
      echo("<br /><br />");
    }
    site_privat_edit($ukod);
  }


?>
