<?php

  // w_robot --- PHP portalrobot
  // (verzioadatok a konfiguracios fajlban)
  //
  // fejleszto: InalR Fejlesztoi Iroda



  // directory, file name conversion

  function sys_site_error(){
    global $site_404_error_file;

    if (file_exists($site_404_error_file)){
      include($site_404_error_file);
    }else{
    }
  }


  // error handler

  function sys_error($errno,$errstr,$errfile,$errline){
    global $error_log_file,$error_all_mess,$full_date_format,
           $error_div;

    if (($error_all_mess)or($errno<>E_NOTICE)){
      $line=date($full_date_format)." --- ";
      $line=$line."Error: $errno ($errstr). File: $errfile. Line: $errline.\n";
      if (substr($error_log_file,0,1)=="."){
        $day=date("Ymd");
        $ef=$error_log_file."-".$day;
      }else{
        $ef=$error_log_file;
      }
      sys_file_line_out($ef,$line);
      echo("<div class=$error_div>$line</div>");
    }
  }

  // include es futtatas

  function sys_load_run($incfile,$runfunc,$t){
    if (!function_exists($runfunc)){
      if (file_exists($incfile)){
        include($incfile);
      }
    }
    if (($runfunc<>"")and(function_exists($runfunc))){
      call_user_func_array($runfunc,$t);
    }
  }

  // include es futtatas

  function sys_load_run_parx($incfile,$runfunc,$a0,$a1,$a2,$a3,$a4,$a5,$a6,$a7,$a8,$a9){
    if (!function_exists($runfunc)){
      if (file_exists($incfile)){
        include($incfile);
      }
    }
    if (($runfunc<>"")and(function_exists($runfunc))){
      call_user_func($runfunc,$a0,$a1,$a2,$a3,$a4,$a5,$a6,$a7,$a8,$a9);
    }
  }

  // adat beolvasas get

  function sys_data_get(&$db,&$dtk,&$dte){
    $ok=false;
    $db=0;
    foreach ($_GET as $key => $data) {
      if ($data<>""){
        $dtk[$db]=$key;
        $dte[$db]=$data;
        if ($data<>""){
          $ok=true;
        }
        $db+=1;
      }
    }
    return($ok);
  }

  // adat beolvasas post

  function sys_data_post(&$db,&$dtk,&$dte){
    $ok=false;
    $db=0;
    foreach ($_POST as $key => $data) {
      $dtk[$db]=$key;
      $dte[$db]=$data;
      if ($data<>""){
        $ok=true;
      }
      $db+=1;
    }
    $db-=1;
    return($ok);
  }

  // nomalizalt nev

  function sys_standard_name($s){
    global $char_old,$char_new;

    //$t=str_replace($char_old,$char_new,trim($s));
    $t=urlencode($s);
    return($t);
  }


  function sys_unstandard_name($s){
    global $char_old,$char_new;

    //$t=str_replace($char_new,$char_old,$s);
    $t=urldecode($s);
    return($t);
  }

  // parancssor kezelese --- 4 fuggveny

  function sys_site_open(){
    global $delkod,$imgdata,$imgpos,
           $deldata,$sitepage,$printed,
           $k_print,$k_edit,$editor,$dirpos,
           $dirdata,$messpage,$mess_akt_page,
           $lang_file,$lang_system,$dir_lang;

    $lang_file=$lang_file.$lang_system;
    $lang_file="../$dir_lang/$lang_file";
    sys_lang_in_local();
    $delkod=sys_env_find($deldata);
    if ($delkod<>""){
      sys_env_del($deldata);
    }
    $dirdata=sys_env_find($dirpos);
    if ($dirdata<>""){
      sys_env_del($dirpos);
    }
    $imgdata=sys_env_find($imgpos);
    if ($imgdata<>""){
      sys_env_del($imgpos);
    }
    $mess_akt_page=sys_env_find($messpage);
    sys_env_del($messpage);
    if (($mess_akt_page=="")or($mess_akt_page<1)){
      $mess_akt_page=1;
    }
    $p=sys_env_find($sitepage);
    if ($p==$k_print){
      $printed=true;
    }
    if ($p==$k_edit){
      $editor=true;
    }
  }


  function sys_site_end(){
  }


  function sys_style($f){
    echo("<style type='text/css' media='screen'>");
    echo("<!--");
    sys_file_in($f,$t);
    $x=count($t);
    $y=0;
    while ($y<$x) {
      echo($t[$y]);
      $y+=1;
    }
    echo("--></style>");
  }


  function sys_style_in($dir,$tl){
    $x=0;
    $y=count($tl);
    while ($x<$y){
      if ($tl[$x]!=""){
        sys_style("$dir/$tl[$x]");
      }
      $x+=1;
    }
  }


  function sys_meta($key,$desc){
    global $meta;


    echo("<meta name='Keywords' content='$key' />");
    echo("<meta name='Description' content='$desc' />");
    $x=0;
    $y=count($meta);
    while ($x<$y){
      echo($meta[$x]);
      $x++;
    }
  }


  function sys_env_pack(){
    global $envdb,$tk,$te,$param_separator;

    $x=0;
    $env="";
    while ($x<$envdb){
      if (($tk[$x]<>"")and($te[$x]<>"")){
        if ($env==""){
          $env="$tk[$x]=$te[$x]";
        }else{
          $env=$env.$param_separator."$tk[$x]=$te[$x]";
        }
      }
      $x+=1;
    }
    $env=str_replace("?","_",$env);
    return("$env");
  }

  function sys_env_find($kulcs){
    global $envdb,$tk,$te;

    $dat="";
    $x=0;
    while (($x<$envdb)and($tk[$x]<>$kulcs)){
      $x+=1;
    }
    if ($x<$envdb){
      $dat=$te[$x];
    }
    $dat=sys_unstandard_name($dat);
    return($dat);
  }

  function sys_env_del($kulcs){
    global $envdb,$tk,$te;

    $x=0;
    while (($x<$envdb)and($tk[$x]<>$kulcs)){
      $x+=1;
    }
    if (($x<$envdb)and($tk[$x]==$kulcs)){
      $tk[$x]="";
      $te[$x]="";
    }
  }

  function sys_env_new($kulcs,$ertek){
    global $envdb,$tk,$te;

    $ertek=sys_standard_name($ertek);
    $x=0;
    while (($x<$envdb)and($tk[$x]<>$kulcs)){
      $x+=1;
    }
    if (($x<$envdb)and($tk[$x]==$kulcs)){
      $te[$x]=$ertek;
    }else{
      $tk[$envdb]=$kulcs;
      $te[$envdb]=$ertek;
      $envdb+=1;
    }
  }

  function sys_env_in(){
    global $envdb,$tk,$te;

    $ok=sys_data_get($envdb,$tk,$te);
  }

  // nyelvi kiiras, vagy mentes

  function sys_line_local($sor){
    global $lang,$langdb,$lang_file;

    $s=sys_line($sor,$lang_file,$lang,$langdb);
    return($s);
  }


  // ures sorok kiuritese

  function sys_empty(&$t){
    $xx=count($t);
    if ($xx>0){
      $x=0;
      $y=0;
      $t2=array();
      while($x<$xx){
        if ($t[$x]<>""){
          $t2[$y]=$t[$x];
          $y+=1;
        }
        $x+=1;
      }
      $t=$t2;
    }
  }

  // ures sorok kiuritese

  function sys_empty_db(&$t,&$db){
    $xx=$db;
    $x=0;
    $y=0;
    while($x<$xx){
      if ($t[$x]<>""){
        $t2[$y]=$t[$x];
        $y+=1;
      }
      $x+=1;
    }
    $t=$t2;
    $db=count($t);
  }

  // new line

  function sys_new_line(&$t){
    $x=0;
    $y=count($t);
    while ($x<$y){
      $c=0;
      $cc=strlen($t[$x]);
      while ($c<$cc){
        if (substr($t[$x],$c,1)=="\n"){
          $t[$x]=substr($t[$x],0,$c-1)."<br />".substr($t[$x],$c+1,strlen($t[$x])-$c);
        }
        $c+=1;
      }
      $x+=1;
    }
  }

  // sor elejerol, vegerol szokoz leszedese

  function sys_nospace($l){
    $szokoz=" ";
    trim($l,$szokoz);
    return($l);
  }

  //  tombbol kivalaszt egy sort tobb metodus alapjan

  function sys_random_line($t,$method){
    $line="";
    switch ($method){
      case 0:
        $c=count($t);
        $s=rand(0,$c-1);
        $line=$s;
        break;
      case 1:
        $c=count($t);
        $s=date("s");
        $line=$t[$s];
        //$line="";
        break;
      default:
        $c=count($t);
        $s=rand(0,$c-1);
        $line=$t[$s];
        break;
    }
    return($line);
  }

  // system code from time

  function sys_time_code(){
    $dt=microtime();
    $t=explode(" ",$dt);
    $dret=$t[1].substr($t[0],2,strlen($t[0]));
    return($dret);
  }


  function sys_time_code_to_date($str,$code){
    $dt=microtime();
    $t=explode(" ",$dt);
    $time_size=strlen($t[1]);
    $d=substr($code,0,$time_size);
    $d=date($str,$d);
    return($d);
  }

  // unix ido

  function sys_unix_time(){
    $dt=date("U");
    return($dt);
  }

?>
