<?php

  // w_robot --- PHP portalrobot
  // (verzioadatok a konfiguracios fajlban)
  //
  // fejleszto: InalR Fejlesztoi Iroda



  // form generator

  function site_form_work_php($kex,$kin){
    $out=site_form_work($kex,$kin);
    $kco=count($out);
    $kc=$kco-1;
    while($kc>=0){
      $out[$kc+1]=$out[$kc];
      $kc--;
    }
    $out[0]="<?php";
    $out[$kco+1]="?>";
    return($out);
  }


  function site_form_work($key,$in){
    $out=array();
    $outline=0;
    $inline=count($in);
    $bool=array("true","false");
    $x=0;
    while ($x<$inline){
      $char=substr($in[$x],0,1);
      switch ($char){
        case "/":
          $out[$outline]=$in[$x];
          $outline++;
          break;
        case "$":
          $out[$outline]=$in[$x]."=";
          if ($x<$inline){
            $x++;
            if (substr($key[$x],0,2)=="ma"){
              $out[$outline]=$out[$outline]."array(";
              $ct=explode("\r\n",$in[$x]);
              $co=count($ct);
              $cx=0;
              while($cx<$co){
                if ($ct[$cx]<>""){
                  if ($cx>0){
                    $out[$outline]=$out[$outline].",";
                  }
                  $out[$outline]=$out[$outline]."\"".$ct[$cx]."\"";
                }
                $cx++;
              }
              $out[$outline]=$out[$outline].");";
            }else{
              if (in_array($in[$x],$bool)){
                $out[$outline]=$out[$outline].$in[$x].";";
              }else{
                $out[$outline]=$out[$outline]."\"".$in[$x]."\";";
              }
            }
          }else{
            $out[$outline]=$out[$outline]."\"\";";
          }
          $outline++;
          $out[$outline]="";
          $outline++;
          break;
      }
      $x++;
    }
    //$x=0;
    //$y=count($out);
    //while($x<$y){
      //echo("$out[$x]<br />");
      //$x++;
    //}
    return($out);
  }


  function site_form_generator($in){
    global $s_program,
           $file_user_config;


    $ok=sys_data_post($db,$tkx,$tex);
    if ($ok){
      $in=site_form_work($tkx,$tex);
    }
    echo("<center>");
    $e=sys_env_pack();
    echo("<form method='post' action='./$s_program?$e'>");
    $readonly="";
    $cimout="";
    $sel=array("true","false");
    $ki1=sys_line_local("Enged�lyezve");
    $ki2=sys_line_local("Letiltva");
    $selcim=array($ki1,$ki2);
    $x=0;
    $c=count($in);
    while  ($x<$c){
      $in[$x]=trim($in[$x]);
      $char=substr($in[$x],0,1);
      switch ($char){
        case "/":
          $cimout=substr($in[$x],2,strlen($in[$x]));
          break;
        case "$":
          $chpos=strpos($in[$x],"=");
          $t[0]=substr($in[$x],0,$chpos);
          $t[1]=substr($in[$x],$chpos+1,strlen($in[$x]));
          $tdata=trim($t[1],"\";");
          echo("<input type='hidden' id='m1$x' name='m1$x' value='//$cimout'  />");
          echo("<input type='hidden' id='m2$x' name='m2$x' value='$t[0]'  />");
          $ki=sys_line_local($cimout);
          echo("<div class='div_r1'>$ki: <br/>($t[0])</div>");
          if (in_array($tdata,$sel)){
            echo("<select class='select_r1' id='m3$x' name='m3$x' $readonly>");
            $kisel1="";
            $kisel2="";
            if ($tdata==$sel[0]){
              $kisel1="selected='selected'";
            }else{
              $kisel2="selected='selected'";
            }
            echo("<option $kisel1 value='$sel[0]'> $selcim[0] </option>");
            echo("<option $kisel2 value='$sel[1]'> $selcim[1] </option>");
            echo("</select>");
            echo("<br />");
            echo("<br />");
          }else{
            if (substr($t[1],0,5)=="array"){
              echo("<textarea class='textarea_e1' id='ma$x' name='ma$x' wrap='off' cols='200' rows='3' $readonly>");
              $o=substr($t[1],6,strlen($t[1]));
              $o=trim($o,"();");
              $ochar="\"";
              if (substr($o,0,1)=="'"){
                $ochar="'";
              }
              $oo=explode(",",$o);
              $coo=count($oo);
              $cxx=0;
              while ($cxx<$coo){
                $kioo=trim($oo[$cxx],$ochar);
                if ($kioo<>""){
                  echo("$kioo\n");
                }
                $cxx++;
              }
              echo("</textarea><br />");
            }else{
              $tdata=trim($t[1],"\";");
              echo("<input class='input_r1' type='text' id='m3$x' name='m3$x' value='$tdata' size='120' maxlength='100' $readonly /><br />");
            }
            echo("<br />");
          }
          break;
        default:
          break;
      }
      $x++;
    }
    echo("<br />");
    $ki=sys_line_local("Mehet");
    echo("<button class='button_1' type='submit' id='m10000' name='m10000' value='$ki'>$ki</button>");
    echo("</form>");
    echo("</center>");
  }
  
  
  function sie_form_out($in){
    $out=array();
    return($out);
  }



?>
