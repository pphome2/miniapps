<?php

  // w_robot --- PHP portalrobot
  // (verzioadatok a konfiguracios fajlban)
  //
  // fejleszto: InalR Fejlesztoi Iroda




  // nyelvi elemek feldolgozasa

  function site_lang($p){
    global $sitepos,$s_program,
           $s_link,$s_img,$s_sys,
           $s_cent,$s_ecent,$s_nline,
           $s_line,$s_plugin,
           $s_h,$s_eh,$s_bold,$s_ebold,
           $s_ita,$s_eita,$k_gallery,
           $s_und,$s_eund,$s_par,$s_epar,
           $s_submenu,$s_kgal,
           $s_menu,$k_bigpic,
           $s_pos,$s_posp,$s_col,$s_ecol1,
           $s_ecol,$s_table,$s_etable,
           $s_row,$s_erow,$s_data,
           $s_edata,$col_number,
           $s_language,$s_comment,
           $s_commentrate,$s_mail,$aktrow,
           $lang_system,$write_out,
           $s_nocomment,$comment_all,
           $comment_1_page,$comment_rate,
           $editor,$menu_out_in_page,$dirpos,
           $k_bigimg,$s_embed,$s_modul,
           $s_div,$s_ediv,$s_go,$s_ego,
           $plugin_start,$sitepage,$open_page,
           $default_site,$dir_site,$dir_img,
           $dir_siteinc,$imgpos,
           $divdb,
           $plugin_return_embed_line;

    $t=explode(" ",$p);
    $tdb=count($t);
    $lap=sys_env_find($sitepos);
    $sp=sys_env_find($sitepage);
    switch ($t[0]){
      case $s_menu:
        if ((!$open_page)and($menu_out_in_page)){
          $p=substr($p,strlen($s_menu)+1,strlen($p));
          $v=$p;
          sys_env_new($sitepos,$p);
          $e=sys_env_pack();
          $p=" <div class='div_me1'>";
          $p=$p."<a class='href' href='./$s_program?$e'>$v</a></div>";
        }else{
          $p="";
        }
        break;
      case $s_submenu:
        if ((!$open_page)and($menu_out_in_page)){
          $p=substr($p,strlen($s_submenu)+1,strlen($p));
          $v=$p;
          sys_env_new($sitepos,$p);
          $e=sys_env_pack();
          $p=" <div class='div_me2'>";
          $p=$p."<a class='href' href='./$s_program?$e'>  $v</a></div>";
        }else{
          $p="";
        }
        break;
      case $s_pos:
        $p="";
        break;
      case $s_posp:
        $p="";
        break;
      case $s_cent:
        $p=" <center>";
        break;
      case $s_ecent:
        $p=" </center>";
        break;
      case $s_nline:
        $p=" <br />";
        break;
      case $s_line:
        $p="<hr class='hrcl' />";
        break;
      case $s_h:
        $p=" <h".$t[1].">";
        break;
      case $s_eh:
        $p=" </h".$t[1].">";
        break;
      case $s_bold:
        $p=" <b>";
        break;
      case $s_ebold:
        $p=" </b>";
        break;
      case $s_ita:
        $p=" <i>";
        break;
      case $s_eita:
        $p=" </i>";
        break;
      case $s_und:
        $p=" <u>";
        break;
      case $s_eund:
        $p=" </u>";
        break;
      case $s_par:
        $p=" <p>";
        break;
      case $s_epar:
        $p=" </p>";
        break;
      case $s_div:
        $p="<div class='".$t[1]."'>";
        $divdb++;
        break;
      case $s_ediv:
        if ($divdb>0){
          $p="</div>";
          $divdb--;
        }
        break;
      case $s_go:
        sys_env_new($sitepos,$t[1]);
        $e=sys_env_pack();
        $p="<a class='href' href='$s_program?$e'>";
        break;
      case $s_ego:
        $p="</a>";
        break;
      case $s_link:
        $c=strlen($s_link)+strlen($t[1])+2;
        $v=substr($p,$c,strlen($p)-$c);
        if (substr($t[1],0,1)=="."){
            $p=" <a class='href' href='$t[1]'>$v</a> ";
        }else{
          if (substr($t[1],0,4)=="http"){
            $p=" <a class='href' href='$t[1]'>$v</a> ";
          }else{
            $p=" <a class='href' href='http://$t[1]'>$v</a> ";
          }
        }
        break;
      case $s_mail:
        $p=" <a class='href' href='mailto:$t[1]'>$t[1]</a> ";
        break;
      case $s_img:
        $p=" <center>";
        $h="";
        if ($tdb>3){
          $h=$t[3];
        }
        if (($tdb>2)and($t[2]<>"")){
          $ki=sys_line_local("Nagy�t");
          sys_env_new($sitepage,$k_bigimg);
          sys_env_new($imgpos,$t[2]);
          $e=sys_env_pack();
          $p=$p."<img class='imgclass1' src=$dir_site/$default_site/$dir_img/$t[1] value='$h' />";
          $p=$p."<br /><a class='href' href='./$s_program?$e'> ";
          $p=$p."$ki</a> ";
          sys_env_del($imgpos);
        }else{
          $p=$p."<img class='imgclass1' src=$dir_site/$default_site/$dir_img/$t[1] value='$h' /> ";
        }
        $p=$p."</center> ";
        break;
      case $s_kgal:
        if ($t[1]<>""){
          $ki=sys_line_local("K�p gal�ria");
          sys_env_new($dirpos,"$t[1]");
          sys_env_new($sitepage,$k_gallery);
          $e=sys_env_pack();
          sys_env_del($dirpos);
          $p="<br /><a class='href' href='./$s_program?$e'> ";
          $p=$p."$ki: $t[1]</a><br />";
        }else{
        }
        break;
      case $s_embed:
        if (!$editor){
          if ($t[1]<>""){
            $tf="$dir_site/$default_site/$dir_siteinc/$t[1]";
            if (file_exists($tf)){
              sys_file_in($tf,$to);
              $p="";
              $i=0;
              $y=count($to);
              while ($i<$y){
                $p=$p.$to[$i];
                $i++;
              }
            }
          }else{
          }
        }else{
          $p="";
        }
        break;
      case $s_modul:
        if (!$editor){
          if ($t[1]<>""){
            $p="<center>";
            $p=$p."<iframe title='Modul' type='text/html' ";
            $p=$p."src='$t[1]' width='$t[2]' height='$t[3]'>";
            $p=$p."</iframe>";
            $p=$p."</center>";
          }else{
          }
        }else{
          $p="";
        }
        break;
      case $s_sys:
        $p=" ";
        break;
      case $s_plugin:
        if (!$editor){
          $i=0;
          $p2="";
          foreach ($t as $k){
            $i+=1;
            if ($i>2){
              $p2=$p2." ".$k;
            }
          }
          site_load_run($t);
          $plugin_start=true;
        }
        if ($plugin_return_embed_line<>""){
          $p=$plugin_return_embed_line;
          $plugin_return_embed_line="";
        }else{
          $p="";
        }
        break;
      case $s_col:
        $p="<center><table class='table_2' ><tr>";
        if ($t[1]<>""){
          $col_number=100/$t[1];
        }else{
          $col_number=100/3;
        }
        $col_number=round($col_number,0);
        $p=$p."<td width='$col_number%' class='t_data' valign='top'>";
        break;
      case $s_ecol1:
        $p=" </td><td width='$col_number%' class='t_data' valign='top'>";
        break;
      case $s_ecol:
        $p=" </td></tr></table></center>";
        break;
      case $s_table:
        //$p=" <center><table class=table_1  border=1>";
        $p=" <center><table class='table_d1'>";
        break;
      case $s_etable:
        $p=" </table></center>";
        break;
      case $s_row:
        if ($aktrow==1){
          $aktrow=2;
          $p=" <tr class='row_d1'>";
        }else{
          $aktrow=1;
          $p=" <tr class='row_d2'>";
        }
        break;
      case $s_erow:
        $p=" </tr>";
        break;
      case $s_data:
        //$p=" <td class=t_data>";
        $p=" <td class='data_d1'>";
        break;
      case $s_edata:
        $p=" </td>";
        break;
      case $s_language:
        if ($t[1]==$lang_system){
          $write_out=true;
        }else{
          $write_out=false;
        }
        $p="";
        break;
      case $s_nocomment:
        $comment_all=false;
        //$comment_1_page=false;
        $comment_rate=false;
        $p="";
        break;
      case $s_comment:
        $comment_all=true;
        //$comment_1_page=true;
        $comment_rate=false;
        $p="";
        break;
      case $s_commentrate:
        $comment_all=true;
        //$comment_1_page=true;
        $comment_rate=true;
        $p="";
        break;
      default:
        $v=$p;
        sys_env_new($sitepos,$p);
        $e=sys_env_pack();
        $p=" <a class='href' href='./$s_program?$e'>$v</a> ";
        break;
    }
    sys_env_new($sitepos,$lap);
    sys_env_new($sitepage,$sp);
    return($p);
  }


?>
