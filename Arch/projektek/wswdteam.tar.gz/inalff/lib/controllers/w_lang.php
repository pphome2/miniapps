<?php

  // w_robot --- PHP portalrobot
  // (verzioadatok a konfiguracios fajlban)
  //
  // fejleszto: InalR Fejlesztoi Iroda


  // lang system



  // nyelvi adatok beolvasasa

  function sys_lang_in_local(){
    global $lang,$langdb,$lang_file;

    sys_lang_in($lang_file,$lang,$langdb);
    $x=count($lang);
  }

  // nyelvi kiiras, vagy mentes

  function sys_line($sor,$lf,&$lt,&$ltdb){
    $ltdb=count($lt);
    if ($ltdb==0){
      sys_lang_in($lf,$lt,$ltdb);
      $ltdb=count($lt);
    }
    $ltdb=count($lt);
    $x=0;
    $ok=false;
    while (($x<$ltdb)and(!$ok)){
      if ((isset($lt[$x][0]))and($lt[$x][0]==$sor)){
        $ok=true;
      }else{
        $x+=1;
      }
    }
    if ($ok){
        $sor=$lt[$x][1];
    }else{
      $ki="$sor=$sor\n";
      sys_file_line_out($lf,$ki);
      $ltdb+=1;
      $lt[$ltdb][0]=$sor;
      $lt[$ltdb][1]=$sor;
    }
    $sor=trim($sor,"\n");
    return($sor);
  }


  // nyelvi adatok beolvasasa

  function sys_lang_in($lf,&$lt,&$ltdb){
    global $specchar2;

    $ltdb=0;
    if (file_exists($lf)) {
      if (sys_file_open($lf,$fh,"r")){
        $lock=sys_file_lock_read($fh);
        if ($lock){
          while (!feof($fh)) {
            $sor=fgets($fh);
            $sor=trim($sor,$specchar2);
            if ($sor!=""){
              $x=strpos($sor,"=");
              $lt[$ltdb][0]=substr($sor,0,$x);
              $lt[$ltdb][1]=substr($sor,$x+1,strlen($sor));
              $ltdb+=1;
            }
          }
          sys_file_unlock($fh);
          sys_file_close($fh);
        }
      }
    }
  }


?>
