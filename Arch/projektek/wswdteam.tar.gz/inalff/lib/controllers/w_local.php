<?php

  // w_robot --- PHP portalrobot
  // (verzioadatok a konfiguracios fajlban)
  //
  // fejleszto: InalR Fejlesztoi Iroda



  // include es futtatas

  function site_load_run($tomb){
    global $dir_plugin;

    $incfile="$dir_plugin/$tomb[1]/$tomb[2].php";
    $t2=array();
    $c=count($tomb);
    $i=0;
    while ($i<$c-4){
      $t2[$i]=$tomb[$i+4];
      $i++;
    }
    sys_load_run($incfile,$tomb[3],$t2);
  }



  function site_lang_init(){
    global $guest_user,$help_main_page,$cat_view;

    $guest_user=sys_line_local($guest_user);
    $help_main_page=sys_line_local($help_main_page);
    $cat_view=sys_line_local($cat_view);
  }


  function site_lang_move($tomb){
    $i=0;
    $y=count($tomb);
    while ($i<$y){
      $tomb[$i]=sys_line_local($tomb[$i]);
      $i+=1;
    }
  }

  // a site zarasa

  function site_end(){
  }


  // adatok beolvasasa

  function site_file_in($f,&$tomb,&$tindex){
    sys_file_in($f,$tomb);
    $tindex=count($tomb);
  }

  // adatok kiirasa

  function site_file_out($f,$tomb,$tindex){
    sys_empty($tomb);
    sys_file_out($f,$tomb);
  }

  // adatok beolvasasa

  function site_file_in_lock($f,&$tomb,&$tindex){
    sys_file_in_lock($f,$tomb);
    $tindex=count($tomb);
  }

  // adatok kiirasa

  function site_file_out_lock($f,$tomb,$tindex){
    sys_empty($tomb);
    sys_file_out_lock($f,$tomb);
  }

  // site adatok beolvasasa

  function site_in($name){
    global $article_text,$article_history,$article_brief,
           $article_category,$article_user,$article_date;

    $r=sql_article_get_result($name);
    $x=sql_result_db($r);
    if ($x>0){
      $in=sql_get_result_data($r,0);
      $article_date=$in[2];
      $article_user=$in[3];
      $article_category=$in[4];
      $article_brief[0]=$in[5];
      $article_text[0]=$in[6];
      $article_history[0]=$in[7];
    }else{
    }
  }


  // site menu beolvasasa

  function site_menu_in($name){
    $menu="";
    $r=sql_article_get_result($name);
    $x=sql_result_db($r);
    if ($x>0){
      $in=sql_get_result_data($r,0);
      $menu=$in[6];
    }else{
    }
    return($menu);
  }

  // site adatok kiirasa

  function site_out($name){
    global $article_text,$article_brief,
           $article_category,
           $usercode;

    $uc=sys_env_find($usercode);
    $n=site_user($uc);
    sql_article_add($n,$name,$article_category,$article_brief,$article_text);
  }

  // egy lap nev visszaadasa

  function site_page_name(){
    global $sitepos;

    $lap=sys_env_find($sitepos);
    return($lap);
  }




?>
