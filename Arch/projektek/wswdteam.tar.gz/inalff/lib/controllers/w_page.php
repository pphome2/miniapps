<?php

  // w_robot --- PHP portalrobot
  // (verzioadatok a konfiguracios fajlban)
  //
  // fejleszto: InalR Fejlesztoi Iroda



  function site_page_out(){
    global $sitepos,$article_text,$article_brief,
           $article_category,$article_user,$article_date,
           $default_site,$printed,
           $l_open,$l_end,$s_ita,$s_eita,$s_nline,
           $k_edit,$l_open,$l_end,$s_program,$open_page,
           $s_program,$sitepage,$plugin_start,
           $comment_all,$comment_1_page,$cat_view,
           $write_out,$editor,$show_writer,
           $include_site_script,$s_embed,
           $divdb;

    $lap=sys_env_find($sitepos);
    if (($lap=="")or(substr($lap,0,2)=="..")){
      $lap=$default_site;
    }
    $sp=sys_env_find($sitepage);
    sys_env_del($sitepage);
    site_in($lap);
    if ($article_category==$cat_view){
      site_page_cat_out($lap);
    }else{
      echo("<br /><div class='div_paddress'>$lap</div><br /><br />");
      $x=count($article_brief);
      $y=0;
      while ($y<$x){
        $article[$y]=$article_brief[$y];
        $y++;
      }
      $article[0]="$l_open$s_ita$l_end ".$article[0];
      $article[$y]="$l_open$s_eita$l_end";
      $y++;
      $article[$y]="$l_open$s_nline$l_end$l_open$s_nline$l_end$l_open$s_nline$l_end";
      $y++;
      if ($include_site_script<>""){
        $article[$y]="$l_open$s_embed $include_site_script $l_end";
        $y++;
      }
      $x=count($article_text);
      $y2=0;
      while ($y2<$x){
        $article[$y]=$article_text[$y2];
        $y++;
        $y2++;
      }
      $siteline=count($article);
      if (($editor)and($siteline>=25)){
        $maxline=25;
      }else{
        $maxline=$siteline;
      }
      if (($show_writer)and($article_user<>"")){
        $ki=sys_line_local("K�sz�tette");
        $ki2=sys_line_local("Kateg�ria");
        //echo("<br />");
        echo("<div class='div_u'>( $ki: $article_user, $article_date, $ki2: $article_category )</div>");
        echo("<br /><br />");
      }
      $x=0;
      while ($x<$maxline) {
        $s=$article[$x];
        $sx="";
        $v0=0;
        $vve=strlen($s);
        while ($v0<$vve){
          if (substr($s,$v0,1)==$l_open){
            $v1=$v0+1;
            while (($v1<strlen($s))and(substr($s,$v1,1)<>$l_end)){
              $v1+=1;
            }
            if (substr($s,$v1,1)==$l_end){
              $s2=substr($s,$v0+1,$v1-$v0-1);
              $la=site_lang($s2);
              $s=substr($s,0,$v0).$la.substr($s,$v1+1,strlen($s));
              $vve=strlen($s);
            }
          }
          $v0+=1;
        }
        if (($s<>"")and($write_out)){
          echo("$s ");
        }
        $x+=1;
      }
      while($divdb>0){
        echo("</div>");
        $divdb--;
      }
      echo("<br /><br />");
      if ($comment_1_page){
        $open_page=false;
      }
      if (($comment_all)and(!$open_page)and(!$editor)and(!$printed)and(!$plugin_start)){
        $spos=$lap;
        if ($spos==""){
          $spos=$default_site;
        }
        site_comment($lap,"");
      }
    }
    sys_env_new($sitepos,$lap);
    sys_env_new($sitepage,$sp);
  }


  function site_text_out($text){
    global $l_open,$l_end,$divdb;

    if ($text<>""){
      $s=$text;
      $sx="";
      $v0=0;
      $vve=strlen($s);
      while ($v0<$vve){
        if (substr($s,$v0,1)==$l_open){
          $v1=$v0+1;
          while (($v1<strlen($s))and(substr($s,$v1,1)<>$l_end)){
            $v1+=1;
          }
          if (substr($s,$v1,1)==$l_end){
            $s2=substr($s,$v0+1,$v1-$v0-1);
            $la=site_lang($s2);
            $s=substr($s,0,$v0).$la.substr($s,$v1+1,strlen($s));
            $vve=strlen($s);
          }
        }
        $v0+=1;
      }
      echo("$s ");
      while($divdb>0){
        echo("</div>");
        $divdb--;
      }
    }
  }


  function site_page_out_2($data){
    global $l_open,$s_sys,$specchar2,
           $article_text;

    $siteline=count($data);
    if ($siteline>0){
      $x=0;
      while ($x<$siteline) {
        echo("$data[$x]");
        if ($x<$siteline-1){
          echo("$specchar2");
        }
        $x+=1;
      }
    }
  }



?>
