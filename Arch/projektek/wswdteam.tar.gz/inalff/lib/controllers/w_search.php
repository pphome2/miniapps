<?php

  // w_robot --- PHP portalrobot
  // (verzioadatok a konfiguracios fajlban)
  //
  // fejleszto: InalR Fejlesztoi Iroda



  // search

  function search_init(){
    global $search_name,$search_field,
           $search_table,$search_view_link,
           $search_view_field_1,$search_view_field_2,
           $search_view_field_3,
           $search_link,$search_all,
           $sql_table_list,
           $sql_table_article_n,
           $sql_table_users_n,
           $sql_table_category_n,
           $user_admin;

    $search_table[0]=$sql_table_list[0];
    $search_table[1]=$sql_table_list[0];
    $search_table[2]=$sql_table_list[0];
    if (($search_all)or($user_admin)){
      $search_table[3]=$sql_table_list[1];
      $search_table[4]=$sql_table_list[2];
    }

    $search_field[0]=$sql_table_article_n[1];
    $search_field[1]=$sql_table_article_n[5];
    $search_field[2]=$sql_table_article_n[6];
    if (($search_all)or($user_admin)){
      $search_field[3]=$sql_table_users_n[3];
      $search_field[4]=$sql_table_category_n[1];
    }

    $search_name[0]=sys_line_local("�r�sok c�mei k�z�tt");
    $search_name[1]=sys_line_local("�r�sok bevezet�i k�z�tt");
    $search_name[2]=sys_line_local("�r�sok sz�veg�ben");
    if (($search_all)or($user_admin)){
      $search_name[3]=sys_line_local("Felhaszn�l�k nevei k�z�tt");
      $search_name[4]=sys_line_local("Kateg�ri�k k�z�tt");
    }

    $search_view_field_1[0]=1;
    $search_view_field_1[1]=1;
    $search_view_field_1[2]=1;
    if (($search_all)or($user_admin)){
      $search_view_field_1[3]=3;
      $search_view_field_1[4]=1;
    }

    $search_view_field_2[0]=3;
    $search_view_field_2[1]=3;
    $search_view_field_2[2]=3;
    if (($search_all)or($user_admin)){
      $search_view_field_2[3]=5;
      $search_view_field_2[4]=0;
    }

    $search_view_field_3[0]=5;
    $search_view_field_3[1]=5;
    $search_view_field_3[2]=5;
    if (($search_all)or($user_admin)){
      $search_view_field_3[3]=7;
      $search_view_field_3[4]=0;
    }

    $search_view_link[0]=true;
    $search_view_link[1]=true;
    $search_view_link[2]=true;
    if (($search_all)or($user_admin)){
      $search_view_link[3]=false;
      $search_view_link[4]=false;
    }

    $search_link[0]="";
    $search_link[1]="";
    $search_link[2]="";
    if (($search_all)or($user_admin)){
      $search_link[3]="";
      $search_link[4]="";
    }
  }


  function site_search(){
    global $default_site,$max_search,
           $s_program,$sitepos,
           $sitepage,$k_search,
           $search_name,$search_field,
           $sitepage,$k_bigpic,$search_table,
           $search_view_link,
           $search_view_field_1,
           $search_view_field_2,
           $search_view_field_3,
           $search_link,
           $sep_at,$sep_eq,
           $searchpar,$searchdata,$separator,
           $mess_per_page,$mess_akt_page,$messpage;

    echo("<br />");
    $ok=sys_data_post($db,$tk,$te);
    if (!$ok){
      $sor=$searchdata;
      if ($sor<>""){
        $t=explode($separator,$sor);
        $te[0]=$t[0];
        $te[1]=$t[1];
        $ok=true;
      }
    }
    if ($ok){
      site_find_local_h($te[0],$te[1]);
    }else{
      site_find_local_h("","");
    }
    if ($ok){
      $l=sys_env_find($sitepos);
      $ki=sys_line_local("Keresett kifejez�s");
      echo("<br />");
      echo("<div class='div_address'>$ki: $te[0]</div>");
      echo("<br />");
      $db=0;
      $y=0;
      $x=count($search_name);
      $ez=false;
      while (($y<$x)and(!$ez)){
        if ($search_name[$y]<>""){
          $ki=sys_line_local($search_name[$y]);
          if ($ki==$te[1]){
            $ez=true;
          }
        }
        $y+=1;
      }
      if ($ez){
        $y--;
      }else{
        $y=0;
      }
      $res=sql_search($search_table[$y],$search_field[$y],$te[0]);
      $db=sql_result_db($res);
      if ($db>0){
        $ki=sys_line_local("Tal�latok");
        echo("<br />$ki:<br /><br />");
        site_pageing_init($db,$tol,$ig,$max_search,$mess_akt_page);
        $s=$tol;
        while ($s<$ig){
          $tomb=array();
          $tomb=sql_get_result_data($res,$s);
          $c=count($tomb);
          if ($c>1){
            $sor=$s+1;
            $o=$tomb[$search_view_field_1[$y]];
            echo("<div class='div_se1'>");
            if ($search_view_link[$y]){
              if ($search_link[$y]==""){
                sys_env_new($sitepos,$o);
                $e=sys_env_pack();
                sys_env_del($sitepos);
                echo("$sor. <a class='href' href='./$s_program?$e'>$o</a>");
              }else{
                $search_link[$y]=$search_link[$y].$o;
                $tox=array();
                $tox=explode($sep_at,$search_link[$y]);
                $env=array();
                $yc=count($tox);
                $yc2=0;
                while ($yc2<$yc){
                  $tox2=explode($sep_eq,$tox[$yc2]);
                  if ($tox2[0]<>""){
                    sys_env_new($tox2[0],$tox2[1]);
                  }
                  $env[$yc2]=$tox2[0];
                  $yc2++;
                }
                $e=sys_env_pack();
                echo("$sor. <a class='href' href='./$s_program?$e'>$o</a>");
                while ($yc2>0){
                  if ($env[$yc2-1]<>""){
                    sys_env_del($env[$yc2-1]);
                  }
                  $yc2--;
                }
              }
            }else{
              echo("$sor. $o");
            }
            echo("</div><br />");
            echo("<div class='div_se2'>");
            if ($search_view_field_2[$y]<>0){
              $o=$tomb[$search_view_field_2[$y]];
              echo("$o<br />");
            }else{
              $o="";
            }
            if ($search_view_field_3[$y]<>0){
              $o=$tomb[$search_view_field_3[$y]];
              echo("$o<br />");
            }else{
              $o="";
            }
            echo("</div><br />");
          }
          echo("<br /><br />");
          $s++;
        }
        $ki=sys_line_local("�sszesen");
        echo("<div class='div_u'>$ki: $db.</div><br /><br />");
        $sor=$te[0].$separator.$te[1];
        sys_env_new($searchpar,$sor);
        sys_env_new($sitepage,$k_search);
        site_pageing($db,$mess_per_page,$mess_akt_page,$messpage);
        sys_env_del($searchpar);
        sys_env_del($sitepage);
      }else{
        $ki=sys_line_local("Pr�b�ljon m�dos�tani a felt�teleken");
        echo("<br /><br />$ki.<br /><br />");
      }
    }else{
      $ki=sys_line_local("Adja meg a keres�si felt�telt");
      echo("<br />$ki.<br /><br />");
    }
  }


  function site_find_local($hor){
    global $k_search,$sitepage,$s_program;

    $sp=sys_env_find($sitepage);
    sys_env_new($sitepage,$k_search);
    $e=sys_env_pack();
    sys_env_new($sitepage,$sp);
    $ki=sys_line_local("Mehet");
    echo("<form method='post' action='./$s_program?$e'>");
    if (!$hor){
      echo("<center>");
      echo("<input class='input_k1' type='text' id='qc' name='qc' size='20' maxlength='255' /> ");
      echo("<br />");
      echo("<button class='button_1' type='submit' id='b0' name='b0' value='$ki'>$ki</button>");
      echo("</center>");
    }else{
      $ki=sys_line_local("Keres�s");
      echo("<input class='input_k2' type='text' id='qc' value=$ki name='qc' size='20' maxlength='255' /> ");
      $ki=sys_line_local("Mehet");
      echo("<button class='button_1' type='submit' id='b0' name='b0' value='$ki'>$ki</button>");
    }
    echo("</form>");
  }


  function site_find_local_h($s,$v){
    global $k_search,$sitepage,$s_program,
           $search_name,$search_field;

    $sp=sys_env_find($sitepage);
    sys_env_new($sitepage,$k_search);
    $e=sys_env_pack();
    sys_env_new($sitepage,$sp);
    $ki=sys_line_local("Keresett kifejez�s");
    echo("<br /><center><form method='post' action='./$s_program?$e'>");
    echo("<div class='div_r1'>$ki:</div>");
    echo("<input class='input_r1' type='text' id='q0' name='q0' size='30' maxlength='255' value='$s' /><br />");
    $ki=sys_line_local("Keres�s helye");
    echo("<div class='div_r1'>$ki:</div>");
    echo("<div class='div_s1'> ");
    echo("<select id='q1' name='q1' class='select_r1'>");
    $y=0;
    $x=count($search_name);
    while ($y<$x){
      if ($search_name[$y]<>""){
        $ki=sys_line_local($search_name[$y]);
        if ($ki==$v){
          echo("<option selected='selected'>$ki</option>");
        }else{
          echo("<option>$ki</option>");
        }
      }
      $y+=1;
    }
    echo("</select></div><br />");
    $ki=sys_line_local("Mehet");
    echo("<button class='button_1' type='submit' id='b1' name='b1' value='$ki'>$ki</button>");
    echo("</form><br />");
    echo("<hr class='hrcl' />");
    echo("</center>");
  }



?>
