<?php

  // w_robot --- PHP portalrobot
  // (verzioadatok a konfiguracios fajlban)
  //
  // fejleszto: InalR Fejlesztoi Iroda




  function site_pageing_init($db,&$tol,&$ig,$per_page,$akt_page){
    if ($db<$per_page){
      $tol=0;
      $ig=$db;
    }else{
      $tol=($akt_page-1)*$per_page;
      if ($tol<0){
        $tol=0;
      }
      if ($tol>=$db){
        $akt_page-=1;
        $tol=($akt_page-1)*$per_page;
        if ($tol<0){
          $tol=0;
        }
      }
      $ig=$tol+$per_page;
      if ($ig>$db){
        $ig=$db+1;
      }
    }
  }


// lapozas

function site_pageing($alldb,$pagedb,$page,$param){
  global $printed,$editor,$s_program,$page_num_out;

  //echo("page");
  if ((!$printed)and(!$editor)){
    if ($alldb>0){
      $maxlap=round($alldb/$pagedb+0.4);
      //echo("$alldb-$pagedb");
      if ($maxlap<1){
        $maxlap=1;
      }
      //echo("$maxlap");
      if ($maxlap>=1){
        $ki=sys_line_local("Lap");
        //echo("$ki: $page/$maxlap.</div>");
        echo("<div class='div_page0'>");
        if ($maxlap<$page_num_out){
          $tol=0;
          $ig=$page_num_out+5;
        }else{
          if ($page>$maxlap-2){
            $tol=$maxlap-$page_num_out+1;
            $ig=$maxlap;
          }else{
            if ($page<$page_num_out){
              $tol=0;
              $ig=$page_num_out;
            }else{
              $tol=round($page-($page_num_out/2));
              $ig=round($page+($page_num_out/2)-0.6);
            }
          }
        }
        $kis="";
        if (($maxlap>$page_num_out)and($tol>1)){
          $ki=sys_line_local("Els�");
          sys_env_new($param,1);
          $e=sys_env_pack();
          $kis=$kis."<div class='div_page1'><a class='href' href='$s_program?$e'>$ki</a></div> ";
        }
        if ($page>1){
          $ki=sys_line_local("El�z�");
          sys_env_new($param,$page-1);
          $e=sys_env_pack();
          $kis=$kis."<div class='div_page1'><a class='href' href='$s_program?$e'>$ki</a></div> ";
        }
        $x=0;
        $y=1;
        while ($x<$alldb){
          if (($y>=$tol)and($y<=$ig)){
            sys_env_new($param,$y);
            $e=sys_env_pack();
            if ($y<>$page){
              $kis=$kis."<div class='div_page1'><a class='href' href='$s_program?$e'>$y</a></div> ";
            }else{
              $kis=$kis."<div class='div_page2'>$y</div> ";
            }
          }
          $x+=$pagedb;
          $y+=1;
        }
        if ($page<$y-1){
          $ki=sys_line_local("K�vetkez�");
          sys_env_new($param,$page+1);
          $e=sys_env_pack();
          $kis=$kis."<div class='div_page1'><a class='href' href='$s_program?$e'>$ki</a></div> ";
        }
        if (($maxlap>$page_num_out)and($ig<$maxlap)){
          $ki=sys_line_local("Utols�");
          sys_env_new($param,$maxlap);
          $e=sys_env_pack();
          $kis=$kis."<div class='div_page1'><a class='href' href='$s_program?$e'>$ki</a></div>";
        }
        echo("$kis");
        echo("<br /></div>");
      }
    }
  }
}


?>
