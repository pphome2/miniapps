<?php

  // w_robot --- PHP portalrobot
  // (verzioadatok a konfiguracios fajlban)
  //
  // fejleszto: InalR Fejlesztoi Iroda


  // cookie system


  function site_cookie_init(){
    ini_set("output_buffering","1");
  }


  function site_cookie_send($name,$value,$time){
    $ok=false;
    site_cookie_init();
    ob_start();
    $ok=setcookie($name,$value,time()+$time);
    ob_flush();
    return($ok);
  }


  function site_cookie_read($name){
    $cookie_value="";
    if (isset($_COOKIE[$name])) {
      $cookie_value=$_COOKIE["$name"];
    }
    return($cookie_value);
  }


  function site_cookie_change($name,$value,$time){
    if (isset($_COOKIE["$name"])) {
      site_cookie_send($name,$value,$time);
    }
  }


  function site_cookie_del($name){
    site_cookie_send($name,"",-1);
  }


  function site_cookie_read_test($name){
    $nc=site_cookie_read($name);
    if ($nc<>""){
      echo($nc);
    }else{
      echo("?");
    }
  }



?>
