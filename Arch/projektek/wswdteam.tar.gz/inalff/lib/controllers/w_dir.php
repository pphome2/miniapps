<?php

  // w_robot --- PHP portalrobot
  // (verzioadatok a konfiguracios fajlban)
  //
  // fejleszto: InalR Fejlesztoi Iroda





  // directosy kiirasa

  function site_directory_list($dirname,$admin,$dload){
    global $sitepos,$sitepage,$deldata,
           $k_bigpic,$dirdata,$date_format,
           $imgpos,$separator5,
           $dir_site,$default_site,
           $dir_data,$list_img_ext,$delkod,
           $s_program,$delkod,$dirpos,
           $user_admin;

    $lap=sys_env_find($sitepos);
    $sp=sys_env_find($sitepage);
    $dirn=$dirname;
    if (($dirdata<>"")and($dirdata<>"/")){
      $dirname=$dirname.$dirdata;
    }
    $startdir=$dirname;
    sys_dir_list($dirname,$files);
    echo("<br /><br /><center>");
    echo("<div class='page_dir'>");
    site_folder_head($dirn,$startdir,$files);
    echo("</div>");
    echo("<br /><br />");
    echo("<div class='page_dir'>");
    $fdb=count($files);
    if ($fdb>0){
      sort($files);
      $x=0;
      $ki=sys_line_local("T�r�l");
      $kinu=sys_line_local("Nem �res");
      $kidir=sys_line_local("K�nyvt�r");
      while ($x<$fdb){
        sys_env_del($sitepage);
        $fn=$files[$x];
        if ($fn<>""){
          echo("<div class='page_table'>");
          sys_env_del($deldata);
          $code=substr($fn,strlen($fn)-4,4);
          $dir=false;
          $down=false;
          $pic=false;
          if (in_array($code,$list_img_ext)){
            $pic=true;
          }else{
            $fn2="$dirname/$fn";
            if (is_dir($fn2)){
              $down=false;
              $dir=true;
            }else{
              $down=true;
              $dir=false;
            }
          }
          echo("<div class='div_dir1'>");
          if (($dload)and($down)and(!$dir)){
            $file="$dirname/$fn";
            echo("<a class='href' href='$file'>$fn</a>");
          }else{
            //$f=substr($dirname,3,strlen($dirname))."/".$fn;
            $f=substr($dirname,strlen($dirn),strlen($dirname))."/".$fn;
            if (!$pic){
              sys_env_new($dirpos,$f);
              sys_env_new($sitepage,$sp);
              $e=sys_env_pack();
            }else{
              sys_env_new($sitepage,$k_bigpic);
              $fx=substr($dirname,strlen($dirn),strlen($dirname));
              $fx=$fx.$separator5.$sp;
              sys_env_new($dirpos,$fx);
              $f=$dirn.$f;
              sys_env_new($imgpos,$f);
              $e=sys_env_pack();
              sys_env_del($imgpos);
            }
            echo("<a class='href' href='./$s_program?$e'>$fn</a>");
          }
          echo("</div>");
          if ($admin){
            if ($dir){
              $ttt=array();
              sys_dir_list("$startdir/$fn",$ttt);
              $c=count($ttt);
              if ($c==0){
                sys_env_new($deldata,$fn);
                $del=true;
              }else{
                $del=false;
              }
            }else{
              $f=substr($dirname,strlen($dirn),strlen($dirname))."/".$fn;
              sys_env_new($deldata,$f);
              $del=true;
            }
            if ($del){
              sys_env_new($sitepage,$sp);
              sys_env_new($sitepos,$lap);
              //$d=substr($dirname,3,strlen($dirname));
              $d=substr($dirname,strlen($dirn),strlen($dirname));
              sys_env_new($dirpos,$d);
              $e=sys_env_pack();
              echo("<div class='div_dir3'><a class='href' href='./$s_program?$e'>$ki</a></div>");
              sys_env_del($deldata);
              sys_env_del($sitepage);
            }else{
              echo("<div class='div_dir3'>$kinu</div>");
            }
          }else{
            if ($dir){
              $li=$kidir;
            }else{
              $li=date($date_format,filemtime("$dirname/$fn"));
            }
              echo("<div class='div_dir3'>$li</div>");
          }
          echo("</div>");
        }
        $x+=1;
      }
      $ki1=sys_line_local("�sszesen");
      $ki2=sys_line_local("db");
      echo("<div class='div_u'>$ki1: $fdb $ki2.</div>");
    }else{
      $ki=sys_line_local("A t�rol� �res");
      echo("<br /><br />$ki.<br /><br />");
    }
    echo("</div>");
    echo("</center>");
    echo("<br />");
    sys_env_new($sitepos,$lap);
    sys_env_new($sitepage,$sp);
  }



  function site_folder_head($dirname,$startdir,$files){
    global $s_program,$dirpos;

    if (substr($dirname,0,2)==".."){
      $dirn=substr($startdir,strlen($dirname),strlen($startdir))."/";
      $x=0;
      $l="";
      $elso=true;
      $n="";
      $ki=sys_line_local("T�rol�");
      while ($x<strlen($dirn)){
        $ch=substr($dirn,$x,1);
        if ($ch=="/"){
          echo(" / ");
          $sdir=$l;
          if (substr($sdir,strlen($sdir)-1,1)=="/"){
            $sdir=substr($sdir,0,strlen($sdir)-1);
          }
          if ($sdir==""){
            $sdir="/";
          }
          sys_env_new($dirpos,$sdir);
          $e=sys_env_pack();
          if ($elso){
            $elso=false;
          }else{
            $ki=$n;
          }
          echo(" <a class='href' href='./$s_program?$e'>$ki</a> ");
          $n="";
        }else{
          $n=$n.$ch;
        }
        $l=$l.$ch;
        $x+=1;
      }
    }
  }


?>
