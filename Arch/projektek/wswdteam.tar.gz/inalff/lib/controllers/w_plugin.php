<?php

  // w_robot --- PHP portalrobot
  // (verzioadatok a konfiguracios fajlban)
  //
  // fejleszto: InalR Fejlesztoi Iroda


  // directory, file name conversion



  function plugin_load($mit){
    global $enable_system_plugin,$plugindb,
           $gpl_system;

    $x=count($enable_system_plugin);
    $t=array();
    if ($plugindb<$x){
      if ($enable_system_plugin[$plugindb]){
        sys_load_run($mit,"",$t);
      }
    }else{
      sys_load_run($mit,"",$t);
    }
    $plugindb++;
  }


  function plugin_run($mit,$poz){
    global $enable_system_plugin,$plugindb;

    $x=count($enable_system_plugin);
    $t=array();
    if ($poz<$x){
      if ($enable_system_plugin[$poz]){
        sys_load_run("",$mit,$t);
      }
    }else{
      sys_load_run("",$mit,$t);
    }
  }


  function plugin_menu_out(){
    global $plugin_menu,$plugin_page,
           $sitepos,$s_program,$menupos,
           $sitepage;

    $x=count($plugin_menu);
    if ($x>0){
      $spage=sys_env_find($sitepage);
      sys_env_del($sitepage);
      $mp=sys_env_find($menupos);
      sys_env_del($menupos);
      $sp=sys_env_find($sitepos);
      $p2=substr($sp,strlen($plugin_page),strlen($sp));
      $y=0;
      while ($y<$x){
        $line=$plugin_page.$plugin_menu[$y];
        sys_env_new($sitepos,$line);
        $e=sys_env_pack();
        //$ki=sys_line_local("$plugin_menu[$y]");
        $ki=$plugin_menu[$y];
        if ($ki==$p2){
          echo("<a class='menuahref' href='./$s_program?$e'>$ki</a><br />");
        }else{
          echo("<a class='menuhref' href='./$s_program?$e'>$ki</a><br />");
        }
        $y++;
      }
      sys_env_new($sitepos,$sp);
      sys_env_new($sitepage,$spage);
      sys_env_new($menupos,$mp);
    }
  }


  function plugin_starter($cim){
    global $plugin_menu,$plugin_func,
           $plugin_default_function_name;

    $x=count($plugin_menu);
    $y=0;
    $s=1000;
    while ($y<$x){
      if ($cim==$plugin_menu[$y]){
        $s=$y;
        $y=$x;
      }
      $y++;
    }
    $t=array("$cim");
    if ($s<1000){
      //echo("$cim");
      sys_load_run("",$plugin_func[$s],$t);
    }else{
      if ($plugin_default_function_name<>""){
        sys_load_run("",$plugin_default_function_name,$t);
      }
    }
  }


  function plugin_default_function($func){
    global $plugin_default_function_name;

    $plugin_default_function_name=$func;
  }


  function plugin_get_menu($f){
    global $plugin_menu,$plugin_page;

    $p=urlencode($plugin_page.$plugin_menu[$f]);
    return($p);
  }


  function plugin_menu($menu,$func){
    global $plugin_menu,$plugin_func,
           $plugin_default_function_name;

    $c=count($plugin_menu);
    if ($c<>0){
      $plugin_menu[$c]="";
      $plugin_func[$c]="";
      $c++;
    }
    $menu_start=$c;
    $x=count($menu);
    $y=0;
    while ($y<$x){
      $yy=$menu_start+$y;
      $plugin_menu[$yy]=$menu[$y];
      if ($func[$y]==""){
        $plugin_func[$yy]=$plugin_default_function_name;
      }else{
        $plugin_func[$yy]=$func[$y];
      }
      $y++;
    }
    return($menu_start);
  }


  function plugin_function_start($func,$cim,$ind,$def){
    global $plugin_menu,$plugin_default_function_name,$plugin_page;

    $start=false;
    $y=$ind;
    $ig=$ind+count($func);
    $cim2=$plugin_page.$cim;
    $t=array("$cim2");
    $yy=0;
    while ($y<$ig){
      if ($cim==$plugin_menu[$y]){
        sys_load_run("",$func[$yy],$t);
        $start=true;
      }
      $y++;
      $yy++;
    }
    if (!$start){
      if ($def==""){
      }else{
        sys_load_run("",$def,$t);
        $start=true;
      }
    }
    return($start);
  }



  function plugin_search_init($tname,$field,$name,$f1,$f2,$f3,$vl,$li){
    global $search_name,$search_field,
           $search_table,$search_view_link,
           $search_view_field_1,
           $search_view_field_2,
           $search_view_field_3,
           $search_link,
           $search_plugin_first,
           $search_plugin_only,
           $search_plugin_insert;

    if ($search_plugin_only){
      if (!$search_plugin_insert){
        $search_plugin_insert=true;
        $search_table=array();
        $search_field=array();
        $search_name=array();
        $search_view_field_1=array();
        $search_view_field_2=array();
        $search_view_field_3=array();
        $search_view_link=array();
        $search_link=array();
      }
      $c=count($search_name);
      $search_table[$c]=$tname;
      $search_field[$c]=$field;
      $search_name[$c]=$name;
      $search_view_field_1[$c]=$f1;
      $search_view_field_2[$c]=$f2;
      $search_view_field_3[$c]=$f3;
      $search_view_link[$c]=$vl;
      $search_link[$c]=$li;
    }else{
      if ($search_plugin_first){
        $c=count($search_name);
        $y=0;
        while ($c>0){
          $y=$c-1;
          $search_table[$c]=$search_table[$y];
          $search_field[$c]=$search_field[$y];
          $search_name[$c]=$search_name[$y];
          $search_view_field_1[$c]=$search_view_field_1[$y];
          $search_view_field_2[$c]=$search_view_field_2[$y];
          $search_view_field_3[$c]=$search_view_field_3[$y];
          $search_view_link[$c]=$search_view_link[$y];
          $search_link[$c]=$search_link[$y];
          $c--;
        }
        $search_table[0]=$tname;
        $search_field[0]=$field;
        $search_name[0]=$name;
        $search_view_field_1[0]=$f1;
        $search_view_field_2[0]=$f2;
        $search_view_field_3[0]=$f3;
        $search_view_link[0]=$vl;
        $search_link[0]=$li;
      }else{
        $c=count($search_name);
        $search_table[$c]=$tname;
        $search_field[$c]=$field;
        $search_name[$c]=$name;
        $search_view_field_1[$c]=$f1;
        $search_view_field_2[$c]=$f2;
        $search_view_field_3[$c]=$f3;
        $search_view_link[$c]=$vl;
        $search_link[$c]=$li;
      }
    }


  }




?>
