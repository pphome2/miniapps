<?php

  // w_robot --- PHP portalrobot
  // (verzioadatok a konfiguracios fajlban)
  //
  // fejleszto: InalR Fejlesztoi Iroda


  // e-mail system



  function site_email_init(){
    global $smtp_host,$smtp_port,
           $smtp_user,$smtp_password,
           $smtp_system_host,$smtp_system_port,
           $smtp_system_user,$smtp_system_password,
           $system_administrator_email,
           $site_admin_email;

    if ($smtp_host<>""){
      $smtp_system_host=$smtp_host;
    }
    if ($smtp_port<>""){
      $smtp_system_port=$smtp_port;
    }
    if ($smtp_user<>""){
      $smtp_system_user=$smtp_user;
    }
    if ($smtp_password<>""){
      $smtp_system_password=$smtp_password;
    }
    if ($site_admin_email<>""){
      $system_administrator_email=$site_admin_email;
    }else{
      $site_admin_email=$system_administrator_email;
    } 


  }


  function site_send_mail($address,$reply,$cc,$bcc,$subject,$message){
    global $default_site,$mail_system_available,
           $site_admin_email,
           $smtp_system_host,$smtp_system_port,
           $smtp_system_user,$smtp_system_password,
           $dir_driver,$enable_smtp_messages,
           $user_admin;

    $mailstat=false;
    //echo("$address-$reply-$cc-$bcc-$subject");
    if ($mail_system_available){
      if ($reply==""){
        $reply=$site_admin_email;
      }
      if ($address==""){
        $address=$site_admin_email;
      }
      if ($user_admin){
        $ki=sys_line_local("C�mzett");
        echo("$ki: $address<br />");
        $ki=sys_line_local("V�laszc�m");
        echo("$ki: $reply<br />");
        $ki=sys_line_local("M�solat");
        echo("$ki: $cc<br />");
        $ki=sys_line_local("Rejtett m�solat");
        echo("$ki: $bcc<br />");
        $ki=sys_line_local("T�rgy");
        echo("$ki: $subject<br />");
        echo("<br />");
      }
      $headers="From: <$site_admin_email> \r\n";
      $headers=$headers."Reply-To: <$reply> \r\n";
      $headersx="From: <$site_admin_email> \r\n";
      $headersx=$headers."Reply-To: <$reply> \r\n";
      $bcc2="";
      $cc2="";
      if ($cc<>""){
        $t=explode(",",$cc);
        $tc=count($t);
        if ($tc>0){
          $cc2="";
          $x=0;
          while($x<$tc){
            if ($cc2<>""){
              $cc2=$cc2.",";
            }
            $cc2=$cc2."$t[$x]\r\n";
            $x++;
          }
        }else{
          $cc2="$cc";
        }
        $headers=$headers."Cc: <$cc2> \r\n";
      }
      if ($bcc<>""){
        $t=explode(",",$bcc);
        $tc=count($t);
        if ($tc>0){
          $bcc2="";
          $x=0;
          while($x<$tc){
            if ($bcc2<>""){
              $bcc2=$bcc2.",";
            }
            $bcc2=$bcc2."$t[$x]";
            $x++;
          }
        }else{
          $bcc2="$bcc";
        }
        $headers=$headers."Bcc: <$bcc2> \r\n";
      }
      $phpversion=phpversion();
      $headers=$headers."X-Mailer: PHP/  $phpversion";
      $headers=$headersx."X-Mailer: PHP/  $phpversion";
      if ($smtp_system_host<>""){
        if (file_exists("$dir_driver/smtp.php")){
          include("$dir_driver/smtp.php");
          if ($enable_smtp_messages){
            smtp_message_enable();
          }
          $mailstat=smtp_mail_send($smtp_system_user,$smtp_system_password,
                                   $smtp_system_host,$smtp_system_port,
                                   $reply,$address,$cc2,$bcc2,$subject,$message,$headersx);
        }
      }
      if (!$mailstat){
        if ($enable_smtp_messages){
          $ki=sys_line_local("Helyi lev�lk�ld�s");
          echo("$ki.<br />");
        }
        $mailstat=mail($address,$subject,$message,$headers);
      }
    }
    if ($mailstat){
      $ki=sys_line_local("�zenet elk�ldve");
    }else{
      $ki=sys_line_local("Hiba az �zenet elk�ld�se k�zben");
    }
    echo("<br />$ki.<br /><br />");
    return($mailstat);
  }




?>



