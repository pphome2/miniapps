<?php

  // w_robot --- PHP portalrobot
  // (verzioadatok a konfiguracios fajlban)
  //
  // fejleszto: InalR Fejlesztoi Iroda




  // directory, file name conversion

  function sys_file_upload($uploaddir){
    $ok=false;
    if (isset($_FILES['userfile']['name'])){
      if (basename($_FILES['userfile']['name'])<>""){
        $uploadfile=$uploaddir."/".basename($_FILES['userfile']['name']);
        if (move_uploaded_file($_FILES['userfile']['tmp_name'], $uploadfile)) {
          $ok=true;
        }else{
          $ok=false;
        }
      }
    }
    return($ok);
  }


  // fajl beolvasasa

  function sys_file_in($ofile,&$mibe){
    sys_file_in_work($ofile,$mibe,false);
  }

  // fajl beolvasasa

  function sys_file_in_lock($ofile,&$mibe){
    sys_file_in_work($ofile,$mibe,true);
  }

  // fajl beolvasasa

  function sys_file_in_work($ofile,&$mibe,$lock){
    global $specchar2,$specchar3,$fh;

    $mibe=array();
    if (file_exists($ofile)) {
      if (sys_file_open($ofile,$h,"r")){
        $lock1=sys_file_lock_read($h);
        $fh=$h;
      }
      if ($lock1){
        $db=0;
        while (!feof($h)) {
          $sor=fgets($h);
          $sor=trim($sor,$specchar2);
          $sor=trim($sor,$specchar3);
          $mibe[$db]=$sor;
          $db+=1;
        }
        if (!$lock){
          sys_file_unlock($h);
          sys_file_close($h);
        }
      }
    }
  }

  // fajl kiirasa

  function sys_file_out($ofile,&$mit){
    sys_file_out_work($ofile,$mit,false);
  }

  // fajl kiirasa

  function sys_file_out_lock($ofile,&$mit){
    sys_file_out_work($ofile,$mit,true);
  }

  // fajl kiirasa

  function sys_file_out_work($ofile,&$mit,$lock){
    global $specchar2,$specchar3,$fh;

    if (($lock)and(file_exists($ofile))){
      sys_file_unlock($fh);
      sys_file_close($fh);
    }
    $lock1=false;
    if (sys_file_open($ofile,$h,"w+")){
      $lock1=sys_file_lock_write($h);
    }
    if (($lock1)and($h)){
      $x=count($mit);
      $db=0;
      while($db<$x){
        $ki=$mit[$db];
        $ki=str_replace("\\\"","\"",$ki);
        $ki=str_replace($specchar3,"",$ki);
        $ki=rtrim($ki);
        if (substr($ki,strlen($ki)-1,1)<>$specchar2){
          $ki=$ki.$specchar2;
        }
        fwrite($h, $ki);
        $db+=1;
      }
      sys_file_unlock($h);
      sys_file_close($h);
    }
  }

  // sor kiirasa

  function sys_file_line_out($ofile,$line){
    global $specchar2,$specchar3;

    if (file_exists($ofile)) {
      $jel="a+";
    }else{
      $jel="w+";
    }
    if (sys_file_open($ofile,$h,$jel)){
      $lock1=sys_file_lock_write($h);
      if ($lock1){
        $line=str_replace("\\\"","\"",$line);
        $line=str_replace($specchar3,"",$line);
        fwrite($h, $line);
      }
      sys_file_unlock($fh);
      sys_file_close($fh);
    }
  }

// file nyitasa

  function sys_file_open($file,&$h,$mod){
    global $try_open;

    $f=0;
    while ((!$h=fopen($file,$mod))and($f<$try_open)){
      usleep(200);
      $f+=1;
    }
    if ($f<$try_open){
      $ok=true;
    }else{
      $ok=false;
    }
    return($ok);
  }

  // file zarasa

  function sys_file_close(&$h){
    if ($h){
      $x=fclose($h);
    }
  }

  // fajl unlock

  function sys_file_unlock(&$h){
    if ($h){
      if ($x=flock($h,LOCK_UN)){
        $file_lock=false;
      }
    }
  }

  // file nyitasa

  function sys_file_lock_write(&$h){
    global $try_open;

    $f=0;
    while ((!flock($h,LOCK_EX))and($f<$try_open)){
      usleep(200);
      $f+=1;
    }
    if ($f<$try_open){
      $ok=true;
    }else{
      $ok=false;
    }
    return($ok);
  }

  // file nyitasa

  function sys_file_lock_read(&$h){
    global $try_open;

    $f=0;
    while ((!flock($h,LOCK_SH))and($f<$try_open)){
      usleep(200);
      $f+=1;
    }
    if ($f<$try_open){
      $ok=true;
    }else{
      $ok=false;
    }
    return($ok);
  }

  // fajl torlese

  function sys_file_del($file){
    global $try_open;

    $ok=false;
    if (!is_dir($file)){
      if (file_exists($file)){
        $f=0;
        while ((!unlink($file))and($f<$try_open)){
          usleep(200);
          $f+=1;
        }
        if ($f<$try_open){
          $ok=true;
        }
      }else{
        $ok=true;
      }
    }else{
      $f=0;
      while (!(rmdir($file))and($f<$try_open)){
        usleep(200);
        $f+=1;
      }
      if ($f<$try_open){
        $ok=true;
      }
    }
    return($ok);
  }

  // dir rek torlese

  function sys_dir_del($file){
    global $try_open;

    $ok=false;
    if (!is_dir($file)){
      if (file_exists($file)){
        $f=0;
        while ((!unlink($file))and($f<$try_open)){
          usleep(200);
          $f+=1;
        }
        if ($f<$try_open){
          $ok=true;
        }
      }else{
        $ok=true;
      }
    }else{
      $fl=array();
      sys_dir_list($file,$fl);
      $cfl=count($fl);
      if ($cfl>0){
        $cl=0;
        while($cl>$cfl){
          sys_dir_del($fl[$cl]);
          $cl++;
        }
      }else{
        $f=0;
        while (!(rmdir($file))and($f<$try_open)){
          usleep(200);
          $f+=1;
        }
        if ($f<$try_open){
          $ok=true;
        }
      }
    }
    return($ok);
  }

 
  // konyvtar masolasa

  function sys_dir_copy($src,$dst){
    global $try_open;

    $ok=false;
    if (is_dir($src)) {
      if (file_exists($dst)){
        //rmdir($dst);
        //mkdir($dst);
      }else{
        mkdir($dst);
      }
      $files=scandir($src);
      foreach ($files as $file){
        if (($file!=".")&&($file!="..")){
          if (is_dir("$src/$file")){
            sys_dir_copy("$src/$file","$dst/$file");
          }else{
            $ok=copy("$src/$file","$dst/$file"); 
          }
        }
      }
    }
    return($ok);
  }


  // konyvtar atnevezese

  function sys_dir_rename($file,$file2){
    global $try_open;

    $ok=false;
    if (file_exists($file)){
      $f=0;
      while ((!rename($file,$file2))and($f<$try_open)){
        usleep(200);
        $f+=1;
      }
      if ($f<$try_open){
        $ok=true;
      }
    }else{
      $ok=true;
    }
    return($ok);
  }


  // fajl atnevezese

  function sys_file_rename($file,$file2){
    global $try_open;

    $ok=false;
    if (!is_dir($file)){
      if (file_exists($file)){
        $f=0;
        while ((!rename($file,$file2))and($f<$try_open)){
          usleep(200);
          $f+=1;
        }
        if ($f<$try_open){
          $ok=true;
        }
      }else{
        $ok=true;
      }
    }
    return($ok);
  }

  // fajl masolasa

  function sys_file_copy($file,$file2){
    global $try_open;

    $ok=false;
    if (!is_dir($file)){
      if (file_exists($file)){
        $f=0;
        while ((!copy($file,$file2))and($f<$try_open)){
          usleep(200);
          $f+=1;
        }
        if ($f<$try_open){
          $ok=true;
        }
      }else{
        $ok=true;
      }
    }
    return($ok);
  }

  // fajl link

  function sys_file_link($file,$file2){
    global $try_open;

    $ok=false;
    if (!is_dir($file)){
      if (file_exists($file)){
        $f=0;
        while ((!link($file,$file2))and($f<$try_open)){
          usleep(200);
          $f+=1;
        }
        if ($f<$try_open){
          $ok=true;
        }
      }else{
        $ok=true;
      }
    }
    return($ok);
  }

  // konyvtar letrehozasa

  function sys_mkdir($dir){
    global $try_open;

    if(!is_dir($dir)){
      $f=0;
      while (!mkdir($dir)and($f<$try_open)){
        usleep(200);
        $f+=1;
      }
    }
  }

  // konyvtar listazasa

  function sys_dir_list($dirn,&$t){
    global $try_open;

    if (is_dir($dirn)){
      $f=0;
      while (!($dir=opendir($dirn))and($f<$try_open)){
        usleep(200);
        $f+=1;
      }
      $db=0;
      if ($dir){
        while ($fn=readdir($dir)){
          if (($fn<>".")and($fn<>"..")){
            $t[$db]=$fn;
            $db+=1;
          }
        }
        if (($dir)and($x=closedir($dir))){
        }
      }
    }
  }

?>
