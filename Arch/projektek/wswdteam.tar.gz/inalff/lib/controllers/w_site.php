<?php

  // w_robot --- PHP portalrobot
  // (verzioadatok a konfiguracios fajlban)
  //
  // fejleszto: InalR Fejlesztoi Iroda




  function site_error($site_error_1,$site_error_2){
    site_page_open();
    echo("<br /><br /><b>$site_error_1");
    echo("</b><br /><br />$site_error_2<br /><br />");
    site_page_close();
  }


  // a site inditasa

  function site_open(){
    global $usercode,$sitepos,$default_site,
           $administrator,$site_adm,$s_dev_mail,$user_in,
           $user_admin,$dir_data,$dir_file,$dir_img,
           $search_dir,$search_dir_name,$open_page,
           $template_path,$file_template_css,
           $file_template_css_page,$dir_site,$file_system_css,
           $sitename,$lang_label,$language,
           $dir_system,$dir_lang,$lang_system,$dir_conf,
           $doctype,$xmltype,$htmlpar,$keyword,$description,
           $s_dev_program;

    if (!$site_adm){
      $administrator=$s_dev_mail;
    }
    $user_in=sys_env_find($usercode);
    if ($user_in<>""){
      $n2=site_user("");
      if ($n2==""){
        sys_env_del($usercode);
        $user_in="";
      }
      if ($n2==$administrator){
        $user_admin=true;
      }
    }
    $lap=sys_env_find($sitepos);
    if ($lap==""){
      sys_env_new($sitepos,$default_site);
      $open_page=true;
    }
    $search_dir_name[0]=sys_line_local("Adatt�r");
    $search_dir[0]="$dir_data";
    $search_dir_name[1]=sys_line_local("K�nyvt�r");
    $search_dir[1]="$dir_file";
      //$search_dir_name[2]=sys_line_local("K�pt�r");
      //$search_dir[2]="$dir_img";
    site_lang_init($lang_system);
  }



  function site_page_close(){
    global $s_dev_program,$s_dev_version,
           $s_dev_copyright,$s_dev_team,
           $s_dev_mail,$s_dev_web,$printed,
           $s_program,$k_alogin,$sitepage,
           $start_time,$run_time_show,$dev_moduls;

    if ($printed){
      echo("<br /><br />");
    }
    echo("<div class='div_copyright'>");
    sys_env_new($sitepage,$k_alogin);
    $e=sys_env_pack();
    echo("$s_dev_copyright <a class='a_copyright' href='$s_dev_web'><b>$s_dev_team</b></a>");
    echo(" - $s_dev_program $s_dev_version - ");
    echo("<a class='a_copyright' href='$s_program?$e'>[A]</a>");
    $c=count($dev_moduls);
    if ($c>0){
      echo(" - ");
      $x=0;
      while ($x<$c){
        if ($x>0){
          echo(", ");
        }
        echo($dev_moduls[$x]);
        $x++;
      }
      echo(" ");
    }
    if ($run_time_show){
      $st=explode(" ",microtime());
      $end_time=$st[1]+$st[0];
      $run_time=substr($end_time-$start_time,0,4);
      echo(" - $run_time s");
    }
    echo("</div>");
  }


?>
