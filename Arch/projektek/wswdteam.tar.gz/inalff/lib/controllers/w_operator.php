<?php

  // w_robot --- PHP portalrobot
  // (verzioadatok a konfiguracios fajlban)
  //
  // fejleszto: InalR Fejlesztoi Iroda



  // foprogram - vezerles

  function fmain(){
    global $sitepage,$usercode,
           $default_site,$cookie,
           $separator,$separator2,
           $k_message,$k_enter,$k_regist,
           $k_edit,$k_privat,$k_print,
           $k_history,$k_alist,$k_feed,
           $k_bigpic,$k_bigimg,$k_files,
           $k_admin_1,$k_admin_2,$k_admin_3,
           $k_admin_4,$k_admin_5,$k_admin_6,
           $k_admin_7,$k_admin_8,$k_admin_9,
           $k_error,$install_config_file,
           $k_plugin,$plugin_page,$k_help,
           $k_login,$k_search,$k_gallery,
           $k_gallery_list,$k_alogin,$k_uout,
           $sitepos,$printed,$start_time,
           $pluginenv1,$pluginenv2,
           $plugin_data_1,$plugin_data_2,
           $k_delreg,$deldata,$plugin_start,
           $searchpar,$searchdata,
           $enable_login,$k_install,
           $menu,$menupos,$messpage,$dirpos;

    $cookiedata=sys_env_find($cookie);
    sys_env_del($cookie);
    $bex="";
    sys_site_open();
    if ($cookiedata<>""){
      $ctomb=explode($separator2,$cookiedata);
      $co=count($ctomb);
      $cox=0;
      while($cox<$co){
        $ct=explode($separator,$ctomb[$cox]);
        //echo("$ct[0]-$ct[1]-$ct[2]<br />");
        if ($ct[1]<>""){
          $okcookie=site_cookie_send($ct[0],$ct[1],$ct[2]);
        }else{
          site_cookie_del($ct[0]);
        }
        $cox++;
      }
      if (!$okcookie){
      }else{ 
        sys_env_del($sitepage);
        site_refresh();
      }
    }else{
      $bea=sys_env_find($usercode);
      $best="$default_site.$usercode";
      if ($bea==""){
        //site_cookie_del($default_site);
        //site_cookie_del($best);
      }else{
        if ($bex==""){
          $bex=site_cookie_read($default_site);
        }
        $beu=site_cookie_read($best);
        if ($default_site<>""){
          //echo("+$bex-$beu-$bea");
          if ($bex<>""){
            if ($bea==$bex){
              sys_env_new($usercode,$bex);
            }else{
              sys_env_del($usercode);
              $ki0=sys_line_local("Hiba t�rt�nt az azonos�t�s k�zben");
              $ki1=sys_line_local("A rendszer haszn�lat�hoz sz�ks�ges");
              $ki2=sys_line_local("enged�lyeznie a s�tik (cookie) haszn�lat�t");
              echo("$ki0. $ki1 $ki2.<br />");
            }
          }else{
            sys_env_del($usercode);
            $ki0=sys_line_local("A rendszer haszn�lat�hoz sz�ks�ges");
            $ki1=sys_line_local("enged�lyeznie a s�tik (cookie) haszn�lat�t");
            echo("$ki0 $ki1.<br />");
          }
        }
      }
      $menu=sys_env_find($sitepage);
      if ($default_site<>""){
        sql_open();
      }else{
        if (file_exists($install_config_file)){
          $menu=$k_error;
        }else{
          $menu=$k_install;
        }
        sys_env_del($usercode);
        sys_env_del($sitepos);
      }
      if ($menu==$k_uout){
        sys_env_del($sitepage);
        sys_env_del($sitepos);
        sys_env_del($menupos);
        sys_env_del($dirpos);
        sys_env_del($messpage);
        sys_env_del($usercode);
        site_cookie_del($default_site);
        site_cookie_del($usercode);
      }

      site_email_init();
      $searchdata=sys_env_find($searchpar);
      sys_env_del($searchpar);
      $plugin_data_1=sys_env_find($pluginenv1);
      $plugin_data_2=sys_env_find($pluginenv2);
      sys_env_del($pluginenv1);
      sys_env_del($pluginenv2);
      sys_env_del($sitepage);
      if ($menu<>$k_feed){
        site_html_open();
        if (($menu<>$k_install)and($menu<>$k_error)){
          search_init();
        }
        site_open();
        if ((function_exists("plugin_init"))and($menu<>$k_install)){
          plugin_init();
        }
      }
      $menu2="";
      $alap=sys_env_find($sitepos);
      if ($alap<>""){
        $lap=substr($alap,0,strlen($plugin_page));
        if (($lap==$plugin_page)and($menu=="")){
          $menu2=$menu;
          $menu=$k_plugin;
          //sys_env_del($sitepos);
        }
      }else{
        sys_env_new($sitepos,$default_site);
      }
      switch ($menu){
        case $k_error:
          sys_site_error();
          break;
        case $k_install:
          site_page_open();
          design();
          site_install();
          design_end();
          site_page_close();
          break;
        case $k_feed:
          feed_out();
          break;
        case $k_message:
          site_page_open();
          design();
          site_message_wall_menu();
          design_end();
          site_page_close();
          break;
        case $k_enter:
          sys_env_del($usercode);
          sys_env_del($sitepos);
          if (site_enter_in()==""){
            site_page_open();
            design();
            site_page_out();
            design_end();
            site_page_close();
          }else{
            site_refresh();
          }
          break;
        case $k_regist:
          site_page_open();
          design();
          site_new_reg();
          design_end();
          site_page_close();
          break;
        case $k_delreg:
          if ($deldata<>""){
            sys_env_del($usercode);
          }
          site_page_open();
          design();
          site_del_reg();
          design_end();
          site_page_close();
          break;
        case $k_edit:
          site_page_open();
          design();
          site_edit();
          design_end();
          site_page_close();
          break;
        case $k_help:
          site_page_open();
          design();
          site_help();
          design_end();
          site_page_close();
          break;
        case $k_login:
          site_page_open();
          design();
          site_login();
          design_end();
          site_page_close();
          break;
        case $k_alogin:
          site_page_open();
          design();
          $enable_login=true;
          site_login();
          design_end();
          site_page_close();
          break;
        case $k_admin_1:
        case $k_admin_2:
        case $k_admin_3:
        case $k_admin_4:
        case $k_admin_5:
        case $k_admin_6:
        case $k_admin_7:
        case $k_admin_8:
        case $k_admin_9:
          site_page_open();
          design();
          site_admin($menu);
          design_end();
          site_page_close();
          break;
        case $k_privat:
          site_page_open();
          design();
          site_privat("");
          design_end();
          site_page_close();
          break;
        case $k_gallery:
          site_page_open();
          design();
          site_gallery();
          design_end();
          site_page_close();
          break;
        case $k_gallery_list:
          site_page_open();
          design();
          site_gallery_list();
          design_end();
          site_page_close();
          break;
        case $k_history:
          site_page_open();
          design();
          site_history();
          design_end();
          site_page_close();
          break;
        case $k_print:
          $printed=true;
          site_page_open_print();
          site_page_out();
          site_page_close();
          break;
        case $k_alist:
          site_page_open();
          design();
          site_data_list();
          design_end();
          site_page_close();
          break;
        case $k_files:
          site_page_open();
          design();
          site_files();
          design_end();
          site_page_close();
          break;
        case $k_bigpic:
          site_page_open();
          design();
          site_bigpic();
          design_end();
          site_page_close();
          break;
        case $k_bigimg:
          site_page_open();
          design();
          site_bigimg();
          design_end();
          site_page_close();
          break;
        case $k_search:
          site_page_open();
          design();
          site_search();
          design_end();
          site_page_close();
          break;
        case $k_plugin:
          $plugin_start=true;
          if ($menu2<>$k_print){
            site_page_open();
            design();
          }else{
            $printed=true;
          }
          $lap=substr($alap,strlen($plugin_page),strlen($alap));
          plugin_starter($lap);
          if ($menu2<>$k_print){
            design_end();
            site_page_close();
          }
          break;
        default:
          site_page_open();
          design();
          site_page_out();
          design_end();
          site_page_close();
          break;
      }
      if ($menu<>$k_feed){
        if (function_exists("plugin_end")){
          plugin_end();
        }
        site_end();
        site_html_end();
        sys_site_end();
      }
      if (($menu<>$k_install)and($menu<>$k_error)){
        sql_close();
      }
    }
  }

?>
