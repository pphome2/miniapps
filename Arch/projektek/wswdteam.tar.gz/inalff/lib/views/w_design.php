<?php

  // w_robot --- PHP portalrobot
  // (verzioadatok a konfiguracios fajlban)
  //
  // fejleszto: InalR Fejlesztoi Iroda



  function site_page_sig($container){
    global $developer,$developer_email,$licence;

    if ($container<>""){
      echo("<div class='$container'>");
      echo("<div class='div_sig'>$licence</div>");
      echo("<div class='div_sig'><a class='href' href='mailto:$developer_email'>$developer_email</a></div>");
      echo("</div>");
    }else{
      echo("<br />");
      echo("<div class='div_sig'>$licence</div>");
      echo("<div class='div_sig'><a class='href' href='mailto:$developer_email'>$developer_email</a></div>");
      echo("<br />");
    }
  }


  function site_page_banner_hor($logo){
    global $default_site,$dir_img,$dir_site,
           $banners_h,$banners_h_link;

    $ki=sys_line_local("Hirdet�s");
    if ($logo==""){
      echo("<center>");
      echo("<br />");
      echo("<hr class='hrcl' />");
    }else{
      echo("<div class='$logo'>");
    }
    echo("<div class='div_u'>$ki</div>");
    $n=sys_random_line($banners_h,0);
    $k="$dir_site/$default_site/$dir_img/$banners_h[$n]";
    echo("<a class='hrefclass' href='$banners_h_link[$n]'><img class='imgclass3' src='$k' alt='$k' /></a>");
    if ($logo<>""){
      echo("<br /><br />");
      echo("</div>");
    }else{
      echo("<br /><br />");
      echo("<hr class='hrcl' />");
      echo("<br /><br />");
      echo("</center>");
    }
  }

  function site_page_banner_vert($logo){
    global $default_site,$dir_site,$dir_img,
           $banners_v,$banners_v_link;

    $ki=sys_line_local("Hirdet�s");
    if ($logo==""){
      echo("<center>");
      echo("<br />");
      echo("<hr class='hrcl' />");
    }else{
      echo("<div class='$logo'>");
    }
    echo("<div class='div_u'>$ki</div>");
    echo("<br />");
    $n=sys_random_line($banners_v,0);
    $k="$dir_site/$default_site/$dir_img/$banners_v[$n]";
    echo("<a class='hrefclass' href='$banners_v_link[$n]'><img class='imgclass3' src='$k' alt='$k' /></a>");
    echo("<br /><br /><br />");
    if ($logo<>""){
      echo("</div>");
    }else{
      echo("<br /><br />");
      echo("<hr class='hrcl' />");
      echo("<br /><br />");
      echo("</center>");
    }
  }

  function site_page_banner_open($logo,$n,$link){
    global $default_site,$dir_img,$dir_site,$banners_h,
           $s_program,$sitepos,$default_site;

    $k="$dir_site/$default_site/$dir_img/$n";
    if ($logo<>""){
      echo("<div class='$logo'>");
    }
    if ($link==""){
      sys_env_new($sitepos,$default_site);
      $e=sys_env_pack();
      $link="$s_program?$e";
    }
    echo("<a class='hrefclass' href='$link'><img class='imgclass2' src='$k' alt='$k' /></a>");
    if ($logo<>""){
      echo("</div>");
    }
  }


  function site_page_enter_user($head,$block,$line){
    echo("<div class='$head'>");
    if ($line<>""){
      $ki=sys_line_local("Bejelentkez�s");
      echo("<center><div class='$line'>$ki</div></center>");
    }
    echo("<div class='$block'>");
    site_enter(false);
    echo("</div>");
    echo("</div>");
  }


  function site_page_login_hor($block){
    global $user_in,$s_program,
           $default_site,$sitename,
           $sitepage,$k_uout,
           $sitepos,$usercode;

    echo("<div class='$block'>");
    if (!$user_in){
      site_enter(true);
    }else{
      $n=site_user("");
      $ki=sys_line_local("Bejelentkezve");
      $ki2=sys_line_local("Kijelentkez�s");
      echo("$ki: $n. ");
      $uc=sys_env_find($usercode);
      $sp=sys_env_find($sitepos);
      sys_env_del($sitepos);
      sys_env_del($usercode);
      sys_env_new($sitepage,$k_uout);
      $e=sys_env_pack();
      echo(" (<a class='href' href='$s_program?$e'>$ki2</a>)");
      sys_env_del($sitepage);
      sys_env_new($sitepos,$sp);
      sys_env_new($usercode,$uc);
    }
    echo("</div>");
  }


  function site_page_enter_user_hor($block){
    echo("<div class='$block'>");
    site_enter(true);
    echo("</div>");
  }


  function site_page_search($head,$block,$line){
    echo("<div class='$head'>");
    if ($line<>""){
      $ki=sys_line_local("Keres�s");
      echo("<center><div class='$line'>$ki</div></center>");
    }
    echo("<div class='$block'>");
    site_find_local(false);
    echo("</div>");
    echo("</div>");
  }


  function site_page_box_open($head,$block,$line,$wline){
    echo("<div class='$head'>");
    if (($line<>"")and($wline)){
      echo("<center><div class='$line'>$wline</div></center>");
    }
    echo("<div class='$block'>");
  }


  function site_page_box_end(){
    echo("</div>");
    echo("</div>");
  }


  function site_page_search_hor($block){
    echo("<div class='$block'>");
    site_find_local(true);
    echo("</div>");
  }


  function site_page_lang($head,$block,$line){
    global $language,$lang_desc,$lang_label,$s_program,
           $sitepos,$sitepage,$menupos,$dirpos,$messpage;

    $y=count($lang_desc);
    if ($y>0){
      echo("<div class='$head'>");
      if ($line<>""){
        $ki=sys_line_local("Nyelv v�lszt�s");
        echo("<center><div class='$line'>$ki</div></center>");
      }
      echo("<div class='$block'>");
      $m=sys_env_find($sitepage);
      $m4=sys_env_find($sitepos);
      $m1=sys_env_find($menupos);
      $m2=sys_env_find($dirpos);
      $m3=sys_env_find($messpage);
      $l=sys_env_find($language);
      sys_env_del($sitepage);
      sys_env_del($sitepos);
      sys_env_del($menupos);
      sys_env_del($dirpos);
      sys_env_del($messpage);
      $x=0;
      echo("<ul class='ul_menu'>");
      while($x<$y){
        sys_env_new($language,$lang_label[$x]);
        $e=sys_env_pack();
        echo("<li class='li_me1'>");
        echo("<a class='href' href='$s_program?$e'>$lang_desc[$x]</a>");
        echo("</li>");
        $x+=1;
      }
      echo("</ul>");
      sys_env_new($sitepage,$m);
      sys_env_new($sitepos,$m4);
      sys_env_new($menupos,$m1);
      sys_env_new($dirpos,$m2);
      sys_env_new($messpage,$m3);
      sys_env_new($language,$l);
      echo("</div>");
      echo("</div>");
    }
  }



  function site_page_logo($block){
    global $default_site,$dir_site,$dir_img,$site_logo,
           $developer,$dev_logo;

    $k="$dir_site/$default_site/$dir_img/$site_logo";
    echo("<div class='$block'>");
    echo("<center><br />");
    echo("<img class='imgclass' src='$k' alt='$k' />");
    echo("<br />");
    if ($dev_logo<>""){
      $k="$dir_site/$default_site/$dir_img/$dev_logo";
      echo("<img class='imgclass' src='$k' alt='$k' />");
    }else{
      echo("<br />$developer");
    }
    echo("<br /></center>");
    echo("</div>");
  }


  function site_page_last_article_list($head,$block,$line,$cat,$time,$timeonly){
    $c="";
    $out=site_new_data_list($c,$cat,$time,$timeonly);
    if ($head<>""){
      echo("<div class='$head'>");
    }
    if ($c==""){
      $ki=sys_line_local("�r�sok k�z�tt");
    }else{
      //$ki=$c." (".sys_line_local("friss").")";
      $ki=$c;
    }
    if ($line<>""){
      echo("<center><div class='$line'>$ki</div></center>");
    }else{
      //echo("<b>$ki</b><br /><br />");
      echo("<div class='div_address'>$ki</div><br />");
    }
    if ($block<>""){
      echo("<div class='$block'>");
    }
    echo($out);
    if ($head<>""){
      echo("</div>");
    }
    if ($block<>""){
      echo("</div>");
    }
  }


?>
