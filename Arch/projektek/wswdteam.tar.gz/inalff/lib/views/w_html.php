<?php

  // w_robot --- PHP portalrobot
  // (verzioadatok a konfiguracios fajlban)
  //
  // fejleszto: InalR Fejlesztoi Iroda



  // a site inditasa

  function site_html_open(){
    global $default_site,$sitename,
           $template_path,$file_template_css,
           $file_template_css_page,$dir_conf,$file_system_css,
           $doctype,$xmltype,$htmlpar,$keyword,$description,
           $s_dev_program;


    echo($xmltype);
    echo($doctype);
    echo("<html $htmlpar>");
    echo("<head>");
    sys_meta($keyword,$description);
    $siten=sys_env_find($sitename);
    if ($siten==""){
      if ($default_site==""){
        $siten=$s_dev_program;
      }else{
        $siten=$default_site;
      }
    }
    $file="$dir_conf/$file_system_css";
    sys_style($file);
    $file="$template_path/$file_template_css_page";
    sys_style($file);
    $file="$template_path/$file_template_css";
    sys_style($file);
    echo("<title>$siten</title>");
    echo("</head>");
  }


  // a site zarasa

  function site_html_end(){

    //echo("</div>");
    echo("</body></html>");
  }


  function site_page_open(){
    echo("<body class='body'>");
  }


  function site_page_open_print(){
    echo("<body class='printbody'>");
  }


  function site_refresh(){
    global $s_program,
           $doctype,$xmltype,$htmlpar;

    $e=sys_env_pack();
    echo($xmltype);
    echo($doctype);
    echo("<meta http-equiv='refresh' content='1;URL=$s_program?$e'>");
    echo("<html $htmlpar>");
    echo("<head></head>");
    echo("<body></body>");
    echo("<html></html>");
  }


?>
