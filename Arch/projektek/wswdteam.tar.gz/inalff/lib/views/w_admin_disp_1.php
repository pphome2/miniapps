<?php

  // w_robot --- PHP portalrobot
  // (verzioadatok a konfiguracios fajlban)
  //
  // fejleszto: InalR Fejlesztoi Iroda


  function site_admin_dataplace(){
    global $deldata,$k_admin,$sitepage,$administrator,
           $s_program,$sitepos,$dir_img,$dir_file,
           $dir_site,$default_site,$dir_data,$delkod,
           $dirdata,$file_user_config,
           $specchar2,$site_data_css_container,
           $separator,$sql_table_list;

    $dirname="$dir_site/$default_site/$dir_data";
    $ki2=sys_line_local("Adatt�r");
    echo("<div class='div_address'>$ki2</div>");
    echo("<br />");
    $admin=true;
    $dload=true;
    sys_env_del($deldata);
    site_directory_list($dirname,$admin,$dload);
    $e=sys_env_pack();
    if ($site_data_css_container!=""){
      echo("</div><div class='$site_data_css_container'>");
    }else{
      echo("<hr class='hrcl' />");
    }
    $ki2=sys_line_local("Ment�s");
    echo("<br /><br />");
    echo("<div class='div_address'>$ki2</div>");
    echo("<br /><br />");
    echo("<center>");
    echo("<form method='post' enctype='multipart/form-data' action='./$s_program?$e'>");
    $ki=sys_line_local("Mehet");
    echo("<button class='button_1' type='submit' id='b02' name='b02' value='$ki'>$ki</button>");
    echo("</form>");
    echo("</center>");
    $ki2=sys_line_local("F�jl felt�lt�se k�nyvt�rba");
    echo("<br /><br />");
    echo("<div class='div_address'>$ki2</div>");
    echo("<br /><br />");
    echo("<center>");
    echo("<form method='post' enctype='multipart/form-data' action='./$s_program?$e'>");
    $ki=sys_line_local("F�jl");
    echo("<div class='div_r1'>$ki: </div>");
    echo("<input class='input_f1' type='file' id='userfile' name='userfile' size='40' maxlength='100' /><br /><br />");
    $ki=sys_line_local("Mehet");
    echo("<button class='button_1' type='submit' id='b02' name='b02' value='$ki'>$ki</button>");
    echo("</form>");
    echo("</center>");
    $tomb=array();
    sys_dir_list($dirname,$tomb);
    sort($tomb);
    $ki2=sys_line_local("Vissza�ll�t�s ment�sb�l");
    echo("<br /><br />");
    echo("<div class='div_address'>$ki2</div>");
    echo("<br /><br />");
    echo("<center>");
    echo("<form method='post' enctype='multipart/form-data' action='./$s_program?$e'>");
    $ki=sys_line_local("Ment�s");
    echo("<div class='div_r1'>$ki: </div>");
    echo("<select class='select_r1' id='mfile0' name='mfile0'>");
    $x=count($tomb);
    while ($x>0){
      $x--;
      echo("<option value='$tomb[$x]'>$tomb[$x]</option>");
    }
    echo("</select>");
    $ki=sys_line_local("T�bla");
    echo("<div class='div_r1'>$ki: </div>");
    echo("<select class='select_r1' id='mfile1' name='mfile1'>");
    $y=count($sql_table_list);
    while ($x<$y){
      echo("<option value='$sql_table_list[$x]'>$sql_table_list[$x]</option>");
      $x++;
    }
    echo("</select>");
    echo("<input class='input_r1' type='hidden' id='mfile2' name='mfile2' value='$dirname' /><br /><br />");
    $ki=sys_line_local("Mehet");
    echo("<button class='button_1' type='submit' id='b02' name='b02' value='$ki'>$ki</button>");
    echo("</form>");
    echo("</center><br />");
  }


  function site_admin_user(){
    global $deldata,$k_admin_1,$k_admin_7,
           $sitepage,$administrator,
           $s_program,$sitepos,
           $separator,$full_date_format,
           $mess_akt_page,$mess_per_page,$messpage;

    $sp=sys_env_find($sitepage);
    $tx=sql_user_get_result();
    $regdb=sql_result_db($tx);
    $ki=sys_line_local("Adminisztr�ci�");
    echo("<div class='div_address'>$ki</div>");
    echo("<br />");
    $ki=sys_line_local("Felhaszn�l�k");
    echo("<div class='div_p'><b>$ki</b></div>");
    echo("<br />");
    echo("<center><div class='page_table'>");
    $ki=sys_line_local("Feladat");
    echo("<div class='div_a1'><b>$ki</b><br /> </div>");
    $ki=sys_line_local("N�v");
    echo("<div class='div_a2'><b>$ki</b><br /> </div>");
    $ki=sys_line_local("Teljes n�v");
    echo("<div class='div_a3'><b>$ki, ");
    $ki=sys_line_local("lakc�m, ");
    echo("$ki");
    $ki=sys_line_local("e-mail");
    echo("$ki");
    echo("<br />");
    $ki=sys_line_local("Regisztr�ci�");
    echo("$ki, ");
    $ki=sys_line_local("lej�rat");
    echo("$ki");
    echo("</b></difv>");
    echo("</div>");
    $ki0=sys_line_local("T�r�l");
    $ki1=sys_line_local("M�dos�t");
    site_pageing_init($regdb,$tol,$ig,$mess_per_page,$mess_akt_page);
    $db=$tol;
    while ($db<$ig){
      $tomb=sql_get_result_data($tx,$db);
      $db+=1;
      if ($tomb[0]<>""){
        echo("<div class='page_table'>");
        sys_env_new($deldata,$tomb[0]);
        echo("<div class='div_a1'>");
        if ($tomb[3]<>$administrator){
          sys_env_new($sitepage,$k_admin_1);
          $e=sys_env_pack();
          echo("<a class='href' href='./$s_program?$e'>$ki0</a><br />");
          sys_env_new($sitepage,$k_admin_7);
          $e=sys_env_pack();
          echo("<a class='href' href='./$s_program?$e'>$ki1</a><br />");
        }else{
          echo("-");
        }
        echo("</div>");
        echo("<div class='div_a2'>$tomb[3]</div>");
        echo("<div class='div_a3'>");
        echo("$tomb[5], ");
        echo("$tomb[6], ");
        echo("$tomb[7]");
        echo("<br />");
        $s=$tomb[0];
        $ki2=sys_time_code_to_date($full_date_format,$s);
        echo("$ki2, ");
        if ($tomb[2]==$separator){
          $ki2=sys_line_local("nincs lej�rat");
        }else{
          $ki2=sys_line_local("lej�r");
          $t=intval($tomb[1])+intval($tomb[2]);
          $ki2=$ki2.": ".sys_time_code_to_date($full_date_format,$t);
        }
        echo("$ki2");
        echo("</div>");
        echo("</div>");
      }
    }
    sys_env_del($deldata);
        sys_env_new($sitepage,$sp);
    $ki=sys_line_local("�sszesen");
    echo("<br /><br /><div class='div_u'>$ki: $regdb.</div>");
    echo("</div></center>");
    site_pageing($regdb,$mess_per_page,$mess_akt_page,$messpage);
  }



?>
