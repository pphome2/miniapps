<?php

  // w_robot --- PHP portalrobot
  // (verzioadatok a konfiguracios fajlban)
  //
  // fejleszto: InalR Fejlesztoi Iroda




  function site_directory(){
    global $sitepage,$k_dir,$dir_site,$default_site,
           $dir_data;

    $ki=sys_line_local("Az adatt�r tartalma");
    echo("<div class='div_address'>$ki</div>");
    echo("<br />");
    $admin=false;
    $dload=false;
    $dir="$dir_site/$default_site/$dir_data";
    sys_env_new($sitepage,$k_dir);
    site_directory_list($dir,$admin,$dload);
    sys_env_del($sitepage);
  }



  function site_files(){
    global $dir_file,$default_site,$dir_site,
           $sitepage,$k_files;

    $ki=sys_line_local("A k�nyvt�r tartalma");
    echo("<div class='div_address'>$ki</div>");
    echo("<br />");
    $admin=false;
    $dload=true;
    $dir="$dir_site/$default_site/$dir_file";
    sys_env_new($sitepage,$k_files);
    site_directory_list($dir,$admin,$dload);
    sys_env_del($sitepage);
  }


  function site_history(){
    site_history_line();
  }


  function site_enter($hor){
    global $sitepage,$k_regist,$k_enter,$s_program,
           $enable_new_reg,$enable_login,$k_login;

    if ($enable_login){
      sys_env_new($sitepage,$k_enter);
      $e=sys_env_pack();
      echo("<form method='post' action='./$s_program?$e'>");
      $ki=sys_line_local("Mehet");
      if ($hor){
        $i=sys_line_local("Felhaszn�l�i n�v");
        $i2=sys_line_local("Jelsz�");
        echo("$i:");
        echo("<input class='input_b2' type='text' id='b1' name='b1' size='20' /> ");
        echo("$i2:");
        echo("<input class='input_b2' type='password' id='b2' name='b2' size='20' /> ");
        echo("<button class='button_1' type='submit' id='b4' name='b4' value='$ki'>$ki</button>");
      }else{
        echo("<center>");
        $i=sys_line_local("Felhaszn�l�i n�v �s jelsz�");
        echo("$i:<br />");
        echo("<input class='input_b1' type='text' id='b1' name='b1' size='20' /><br />");
        echo("<input class='input_b1' type='password' id='b2' name='b2' size='20' /><br />");
        $i=sys_line_local("Maradjon bejelentkezve");
        echo("<input class='inputr_b1' type='checkbox' id='b3' name='b3' />$i<br />");
        echo("<button class='button_1' type='submit' id='b4' name='b4' value='$ki'>$ki</button>");
        echo("<br />");
        if ($enable_new_reg){
          sys_env_new($sitepage,$k_regist);
          $e=sys_env_pack();
          $i=sys_line_local("�j felhaszn�l� l�trehoz�sa");
          echo("<br />");
          echo("<a class='href' href='./$s_program?$e'>$i</a>");
          //echo("<br />");
        }
        sys_env_new($sitepage,$k_login);
        $e=sys_env_pack();
        $i=sys_line_local("Elfelejtett jelsz�");
        echo("<br />");
        echo("<a class='href' href='./$s_program?$e'>$i</a>");
        echo("</center>");
      }
      echo("</form>");
      sys_env_del($sitepage);
    }
  }


  function site_login(){
    global $sitepage,$k_regist,$k_enter,$s_program,
           $enable_new_reg,$enable_login,
           $site_admin_email,$k_login,
           $developer;

    $mail=true;
    $ok=sys_data_post($db,$tkx,$tex);
    if ($ok){
      if ($site_admin_email<>""){
        $ukod=site_user_name($tex[0]);
        if ($ukod<>""){
          $t=site_user_data_all($ukod);
          $tx=sys_unix_time();
          $t[4]=md5($tx);
          sql_user_update($ukod,$t);
          $ki0=sys_line_local("Elfelejtett jelsz�");
          $ki1=sys_line_local("K�rem bejelentkez�s ut�n azonnal v�ltoztassa meg jelszav�t");
          $ki2=sys_line_local("Felhaszn�l�i n�v");
          $ki3=sys_line_local("Jelsz�");
          $ki4=sys_line_local("Kedves");
          $ki5=sys_line_local("�dv�zlettel");
          $to=$tex[1];
          $re=$site_admin_email;
          $cc="";
          $bcc=$site_admin_email;
          $sub=$ki0;
          $mess="$ki4 $tex[0]! \r\n \r\n";
          $mess=$mess."$ki1! \r\n \r\n";
          $mess=$mess."$ki2: $tex[0] \r\n";
          $mess=$mess."$ki3: $tx \r\n \r\n";
          $mess=$mess."$ki5: $developer \r\n \r\n";
          $mail=site_send_mail($to,$re,$cc,$bcc,$sub,$mess);
        }else{
          $ki=sys_line_local("A megadott felhaszn�l�i n�vvel m�g nem regisztr�ltak");
          echo("$ki.<br />");
        }
      }else{
        $ki=sys_line_local("Az automatikus jelsz�k�ld�s jelenleg nem m�k�dik");
        echo("$ki.<br />");
        $ki=sys_line_local("�rja meg e-mail-ben a felhaszn�l�i nev�t, e-mail c�m�t az adminisztr�tornak");
        echo("$ki:<br />");
        echo("<a class='href' href=mailto:$site_admin_email >$site_admin_email</a><br />");
        echo("<br />");
      }
    }
    if ($enable_login){
      sys_env_new($sitepage,$k_enter);
      $e=sys_env_pack();
      $ki=sys_line_local("Bejelentkez�s");
      echo("<br /><div class='div_address'>$ki:</div>");
      echo("<br /><br /><br />");
      echo("<form method='post' action='./$s_program?$e'>");
      $ki=sys_line_local("Mehet");
      echo("<center>");
      $ki=sys_line_local("Felhaszn�l�i n�v");
      echo("<div class='div_r1'>$ki:</div>");
      echo("<input class='input_r1' type='text' id='b1' name='b1' size='20' /><br />");
      $ki=sys_line_local("Jelsz�");
      echo("<div class='div_r1'>$ki:</div>");
      echo("<input class='input_r1' type='password' id='b1' name='b2' size='20' /><br />");
      $ki=sys_line_local("Maradjon bejelentkezve");
      echo("<div class='div_r1'>$ki:</div>");
      echo("<input class='checkbox_r1' type='checkbox' id='b2' name='b3' /><br />");
      echo("<br />");
      $ki=sys_line_local("Mehet");
      echo("<button class='button_1' type='submit' id='b4' name='b4' value='$ki'>$ki</button>");
      echo("<br />");
      echo("</form>");
      if ($enable_new_reg){
        sys_env_new($sitepage,$k_regist);
        $e=sys_env_pack();
        $i=sys_line_local("�j felhaszn�l� l�trehoz�sa");
        echo("<br />");
        echo("<a class='href' href='./$s_program?$e'>$i</a>");
        //echo("<br />");
      }
      echo("<br />");
      echo("<br />");
      echo("</center>");
      if ($ok){
        echo("<br />");
        $ki=sys_line_local("A bejelentkez�se adatok hamarosan meg�rkeznek a megadott e-mail c�mre");
        echo("$ki.<br />");
        $ki=sys_line_local("A megk�ld�tt bejelentkez�si adatokkal haszn�lhatja majd a rendszert");
        echo("$ki.<br />");
      }else{
        if ($mail){
          sys_env_new($sitepage,$k_login);
          $e=sys_env_pack();
          $ki=sys_line_local("Elfelejtett bejelentkez�si adatok");
          echo("<br /><div class='div_address'>$ki:</div>");
          echo("<br /><br />");
          echo("<center>");
          echo("<form method='post' action='./$s_program?$e'>");
          $ki=sys_line_local("Mehet");
          echo("<center>");
          $ki=sys_line_local("Felhaszn�l�i n�v");
          echo("<div class='div_r1'>$ki:</div>");
          echo("<input class='input_r1' type='text' id='b1' name='b1' size='20' /><br />");
          $ki=sys_line_local("E-mail c�m");
          echo("<div class='div_r1'>$ki:</div>");
          echo("<input class='input_r1' type='text' id='b1' name='b2' size='20' /><br />");
          echo("<br />");
          $ki=sys_line_local("Mehet");
          echo("<button class='button_1' type='submit' id='b4' name='b4' value='$ki'>$ki</button>");
          echo("<br />");
          echo("</form>");
          echo("</center>");
          sys_env_del($sitepage);
        }else{
          echo("<br />");
          echo("<br />");
          $ki=sys_line_local("Elfelejtett bejelentkez�si adatok");
          echo("<br /><div class='div_address'>$ki:</div>");
          echo("<br /><br />");
          $ki=sys_line_local("Felhaszn�l�i nev�t �s e-mail c�m�t k�ldje el a rendszer adminisztr�tor�nak");
          echo("$ki,<br />");
          $ki=sys_line_local("aki a megadott c�mre elk�ldi a bejelentkez�si adatokat");
          echo("$ki.<br />");
          echo("<br />");
          if ($site_admin_email<>""){
            $ki=sys_line_local("Lev�l az adminisztr�tornak");
            $ki0=sys_line_local("Elfelejtett jelsz�");
            $ki1=sys_line_local("K�rem k�ldj�k meg sz�momra a bejelentkez�si adataimat");
            $ki2=sys_line_local("Felhaszn�l�i nevem, e-mail c�mem");
            echo("<a class='href' href='mailto:$site_admin_email?subject=$ki0&body=$ki1. $ki2:'>$ki</a> ");
          }
          if ($enable_new_reg){
            echo("<br />");
            echo("<br />");
            $ki=sys_line_local("Amennyiben m�g nem regisztr�lt, most megteheti");
            echo("$ki.<br />");
            echo("<br />");
            sys_env_new($sitepage,$k_regist);
            $e=sys_env_pack();
            $i=sys_line_local("�j felhaszn�l� l�trehoz�sa");
            echo("<a class='href' href='./$s_program?$e'>$i</a>");
          }
        }
      }
    }else{
      echo("<br />");
      $ki=sys_line_local("Bejelentkez�s letiltva");
      echo("$ki.<br />");
    }
  }



?>
