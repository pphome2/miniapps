<?php

  // w_robot --- PHP portalrobot
  // (verzioadatok a konfiguracios fajlban)
  //
  // fejleszto: InalR Fejlesztoi Iroda




  function site_reg_menu(){
    global $sitepage,$user_admin,$usercode,
           $k_edit,$k_privat,$k_mail,$k_message,
           $s_program,$reg_menu_plus,$sitepos,
           $messpage,$menupos,$dirpos,$deldata,
           $enable_messagewall,$k_delreg,
           $k_uout,$menu;

    $l=sys_env_find($sitepos);
    sys_env_del($sitepos);
    $m=sys_env_find($sitepage);
    sys_env_del($sitepage);
    $u=sys_env_find($usercode);
    $e=sys_env_pack();
    sys_env_new($sitepage,$k_privat);
    $e=sys_env_pack();
    $k=sys_line_local("Saj�t adatok");
    if ($menu==$k_privat){
      $href="menuahref";
    }else{
      $href="menuhref";
    }
    echo("<a class=$href href='./$s_program?$e'>$k</a><br />");
    if ($enable_messagewall){
      sys_env_new($sitepage,$k_message);
      $e=sys_env_pack();
      $k=sys_line_local("�zen�fal");
      if ($menu==$k_message){
        $href="menuahref";
      }else{
        $href="menuhref";
      }
      echo("<a class=$href href='./$s_program?$e'>$k</a><br />");
    }
    if ($user_admin){
      sys_env_new($sitepage,$k_edit);
      $e=sys_env_pack();
      $k=sys_line_local("Szerkeszt�s");
      echo("<br />");
      if ($menu==$k_edit){
        $href="menuahref";
      }else{
        $href="menuhref";
      }
      echo("<a class=$href href='./$s_program?$e'>$k</a><br />");
    }
    $uc=count($reg_menu_plus);
    if ($uc>0){
      echo("<br />");
      sys_env_del($sitepage);
      $uu=0;
      while ($uu<$uc){
        $sl=$reg_menu_plus[$uu];
        if ($sl<>""){
          $sl2=$sl;
          sys_env_new($sitepos,$sl2);
          $e=sys_env_pack();
          if ($menu==$sl2){
            $href="menuahref";
          }else{
            $href="menuhref";
          }
          echo("<a class=$href href='$s_program?$e'>$sl</a><br />");
        }
        $uu+=1;
      }
    }
    echo("<br />");
    if (!$user_admin){
      sys_env_new($sitepage,$k_delreg);
      sys_env_new($deldata,$u);
      sys_env_del($sitepos);
      sys_env_del($usercode);
      $e=sys_env_pack();
      sys_env_del($deldata);
      $k=sys_line_local("Adataim t�rl�se");
      if ($menu==$k_delreg){
        $href="menuahref";
      }else{
        $href="menuhref";
      }
      echo("<a class=$href href='./$s_program?$e'>$k</a><br />");
    }
    sys_env_del($usercode);
    sys_env_del($sitepage);
    sys_env_del($sitepos);
    $m1=sys_env_find($menupos);
    $m2=sys_env_find($dirpos);
    $m3=sys_env_find($messpage);
    sys_env_del($menupos);
    sys_env_del($dirpos);
    sys_env_del($messpage);
    $e=sys_env_pack();
    $k=sys_line_local("Kijelentkez�s");
    //echo("<br />");
    sys_env_new($sitepage,$k_uout);
    $e=sys_env_pack();
    if ($menu==$k_uout){
      $href="menuahref";
    }else{
      $href="menuhref";
    }
    echo("<a class=$href href='./$s_program?$e'>$k</a><br />");
    sys_env_new($usercode,$u);
    sys_env_new($sitepage,$m);
    sys_env_new($sitepos,$l);
    sys_env_new($menupos,$m1);
    sys_env_new($dirpos,$m2);
    sys_env_new($messpage,$m3);
  }


?>
