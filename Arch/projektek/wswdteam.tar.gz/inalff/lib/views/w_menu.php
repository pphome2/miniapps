<?php

  // w_robot --- PHP portalrobot
  // (verzioadatok a konfiguracios fajlban)
  //
  // fejleszto: InalR Fejlesztoi Iroda



  // menu kiirasa

  function site_menu_global(){
    global $default_site;

    site_menu($default_site);
  }


  // menu kiirasa

  function site_menu_global_txt(&$txt){
    global $default_site;

    site_menu_txt($default_site,$txt);
  }


  // menu kiirasa

  function site_menu_local($menu){
    global $sitepos,$s_program;

    $x=count($menu);
    if ($x>0){
      $p=sys_env_find($sitepos);
      $y=0;
      while ($y<$x){
        sys_env_new($sitepos,$menu[$y]);
        $e=sys_env_pack();
        echo("<a class='href' href='./$s_program?$e'>$menu[$y]</a><br />");
        $y++;
      }
      sys_env_new($sitepos,$p);
    }
  }


  function site_menu_link($menu,$link,$hor){
    global $sitepos,$s_program;

    $x=count($menu);
    if ($x>0){
      $p=sys_env_find($sitepos);
      $y=0;
      while ($y<$x){
        if ($link[$y]<>""){
          $e=$link[$y];
        }else{
          sys_env_new($sitepos,$menu[$y]);
          $e=sys_env_pack();
        }
        echo("<a class='href' href='./$s_program?$e'>$menu[$y]</a>");
        $y++;
        if (!$hor){
          echo("<br />");
        }else{
          if ($y<$x){
            echo(" - ");
          }
        }
      }
      sys_env_new($sitepos,$p);
    }
  }


  // menu kiirasa

  function site_menu_txt($menupage,&$txt){
    global $sitepage,$default_page,$sitepos,$k_dir,
           $s_program,$default_site,
           $l_open,$l_end,$s_sys,$s_submenu,
           $s_menu,$menupos,$s_line,$s_nline,
           $s_language,$lang_system;


    $alap=sys_env_find($sitepos);
    $mlap=sys_env_find($menupos);
    $slap=sys_env_find($sitepage);
    sys_env_del($sitepage);
    sys_env_new($sitepos,$menupage);
    sys_env_del($menupos);
    $e=sys_env_pack();
    $mdata=site_menu_in($menupage);
    $mdata=explode($l_open,$mdata);
    $mline=count($mdata);
    if ($menupage<>$default_site){
      sys_env_new($menupos,$mlap);
    }
    $txt=array();
    $menusor=0;
    $ki=sys_line_local("Nyit�lap");
    $txt[$menusor]="<a class='href' href='./$s_program?$e'>$ki</a>";
    $menusor++;
    $n=0;
    $x=1;
    while ($x<$mline){
      $mdata[$x]=$l_open.$mdata[$x];
      $x++;
    }
    $x=0;
    while ($x<$mline) {
      if ($mdata[$x]!==""){
        if (substr($mdata[$x],0,1)==$l_open){
          $x2=1;
          $c=strlen($mdata[$x]);
          while (($x2<$c)and(substr($mdata[$x],$x2,1)<>$l_end)){
            $x2+=1;
          }
          $md=substr($mdata[$x],1,$x2-1);
          if (substr($md,0,strlen($s_sys))<>$s_sys){
            $p=$md;
            sys_env_new($sitepos,$p);
            $t=explode(" ",$p);
            switch ($t[0]){
              case $s_menu:
                $ujs=0;
                $v=substr($p,2,strlen($p)-0);
                $p=$v;
                sys_env_new($sitepos,$p);
                $msor=$menusor-1;
                sys_env_new($menupos,$msor);
                $e=sys_env_pack();
                $txt[$menusor]="<a class='href' href='./$s_program?$e'>$v</a>";
                $menusor+=1;
                break;
              default:
                $p="";
                break;
            }
          }
        }
      }
      $x+=1;
    }
    sys_env_new($sitepos,$alap);
    sys_env_new($menupos,$mlap);
    sys_env_new($sitepage,$slap);
  }


  // menu kiirasa

  function site_menu($menupage){
    global $sitepage,$default_page,$sitepos,$k_dir,
           $s_program,$default_site,
           $l_open,$l_end,$s_sys,$s_submenu,
           $s_menu,$menupos,$s_line,$s_nline,
           $s_language,$lang_system;


    $alap=sys_env_find($sitepos);
    $mlap=sys_env_find($menupos);
    $slap=sys_env_find($sitepage);
    sys_env_del($sitepage);
    $mdata=site_menu_in($menupage);
    $mdata=explode($l_open,$mdata);
    $mline=count($mdata);
    sys_env_new($sitepos,$menupage);
    sys_env_del($menupos);
    $e=sys_env_pack();
    sys_env_new($sitepos,$alap);
    if ($menupage<>$default_site){
      sys_env_new($menupos,$mlap);
    }
    $n=0;
    $mlap2=$mlap;
    if ($mlap==""){
      echo("<a class='menuahref' href='./$s_program?$e'>$menupage</a><br />");
      $mlap="-1";
    }else{
      echo("<a class='menuhref' href='./$s_program?$e'>$menupage</a><br />");
    }
    echo("<ul class='ul_menu'>");
    $x=1;
    while ($x<$mline){
      $mdata[$x]=$l_open.$mdata[$x];
      $x++;
    }
    $x=0;
    $almenu=true;
    $outalmenu=false;
    $sor=0;
    $aldb=0;
    $menusor=0;
    $menuaktsor=0;
    while ($x<$mline) {
      if ($mdata[$x]!==""){
        if (substr($mdata[$x],0,1)==$l_open){
          $x2=1;
          $c=strlen($mdata[$x]);
          while (($x2<$c)and(substr($mdata[$x],$x2,1)<>$l_end)){
            $x2+=1;
          }
          $md=substr($mdata[$x],1,$x2-1);
          if (substr($md,0,strlen($s_sys))<>$s_sys){
            $p=$md;
            sys_env_new($sitepos,$p);
            $t=explode(" ",$p);
            switch ($t[0]){
              case $s_submenu:
                $v=substr($p,2,strlen($p)-0);
                $p=$v;
                $aldb++;
                $msublap=$menuaktsor*100+$aldb;
                if ($mlap>100){
                  if ($mlap-($menuaktsor*100)<100){
                    $kisz=($menuaktsor)*100;
                    $kisz2=($menuaktsor)*100+100;
                  }else{
                    $kisz=0;
                    $kisz2=0;
                  }
                }else{
                  $kisz=($mlap+1)*100;
                  $kisz2=($mlap+1)*100+100;
                }
                //echo("$mlap-$menuaktsor-$msublap-$kisz-$kisz2:");
                if (($almenu)and($msublap>$kisz)and($msublap<$kisz2)){
                  $outalmenu=true;
                  sys_env_new($sitepos,$p);
                  sys_env_new($menupos,$msublap);
                  $e=sys_env_pack();
                  if ($mlap==$msublap){
                    $p="<li class='li_me2'><a class='menuahref' href='./$s_program?$e'>$v</a></li>";
                  }else{
                    $p="<li class='li_me2'><a class='menuhref' href='./$s_program?$e'>$v</a></li>";
                  }
                }else{
                  $p="";
                }
                $menusor+=1;
                break;
              case $s_menu:
                $v=substr($p,2,strlen($p)-0);
                $p=$v;
                sys_env_new($sitepos,$p);
                sys_env_new($menupos,$menuaktsor);
                $e=sys_env_pack();
                if ($mlap==$menuaktsor){
                  $p="<li class='li_me1'><a class='menuahref' href='./$s_program?$e'>$v</a></li> ";
                }else{
                  $p="<li class='li_me1'><a class='menuhref' href='./$s_program?$e'>$v</a></li> ";
                }
                $menusor+=1;
                $menuaktsor+=1;
                $aldb=0;
                if (($almenu)and($outalmenu)){
                  $almenu=false;
                }
                break;
              case $s_nline:
                if ($sor>0){
                  $p="<br />";
                }else{
                  $p="";
                }
                break;
              case $s_line:
                $p="<hr class='hrcl' />";
                break;
              default:
                $p="";
                break;
            }
            $e=sys_env_pack();
            if ($p<>""){
              echo("$p");
              $sor+=1;
            }
          }
        }
      }
      $x+=1;
    }
    if ($menusor==0){
      echo("<li class='li_me2'>-</li>");
    }
    echo("</ul>");
    sys_env_new($menupos,$mlap2);
    sys_env_new($sitepos,$alap);
    sys_env_new($sitepage,$slap);
  }



?>
