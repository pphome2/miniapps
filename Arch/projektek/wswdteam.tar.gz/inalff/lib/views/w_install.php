<?php

  // w_robot --- PHP portalrobot
  // (verzioadatok a konfiguracios fajlban)
  //
  // fejleszto: InalR Fejlesztoi Iroda



  // telepites, alapbeallitas

  function site_install(){
    global $k_privat,$usercode,$s_program,$user_admin,
           $sitepage,$separator,$k_regist,$sitename,
           $default_site,$default_template,
           $sitepage,$k_install,
           $install_config_file,
           $sql_name,$sql_server,
           $sql_port,$sql_user,
           $sql_pass,$sql_db,
           $smtp_host,$smtp_port,
           $smtp_user,$smtp_password;

    $tomb=array("","","","","","","","","","","","","","","","","","","","");
    $readonly="";
    $ki=sys_line_local("A telep�t�s befejez�se");
    echo("<div class='div_address'>$ki</div>");
    echo("<br /><br />");
    $db=0;
    $ok=sys_data_post($db,$tkx,$tex);
    if ($ok){
      $readonly="readonly";
      $tomb[0]=$tex[0];
      $tomb[1]=$tex[1];
      $tomb[2]=$tex[2];
      $tomb[3]=$tex[3];
      $tomb[4]=$tex[4];
      $tomb[5]=$tex[5];
      $tomb[6]=$tex[6];
      $tomb[7]=$tex[7];
      $tomb[8]=$tex[8];
      $tomb[9]=$tex[9];
      $tomb[10]=$tex[10];
      $tomb[11]=$tex[11];
    }else{
      if (file_exists($install_config_file)){
        sys_file_in($install_config_file,$t);
        $c=count($t);
        $x=20;
        while ($c<=$x){
          $t[$c]="";
          $c++;
        }
        $tomb[0]=site_get_data_quota($t[2]);
        $tomb[1]=site_get_data_quota($t[3]);
        $tomb[2]=site_get_data_quota($t[4]);
        $tomb[3]=site_get_data_quota($t[5]);
        $tomb[4]=site_get_data_quota($t[6]);
        $tomb[5]=site_get_data_quota($t[7]);
        $tomb[6]=site_get_data_quota($t[8]);
        $tomb[7]=site_get_data_quota($t[10]);
        $tomb[8]=site_get_data_quota($t[11]);
        $tomb[9]=site_get_data_quota($t[12]);
        $tomb[10]=site_get_data_quota($t[13]);
        $tomb[11]=site_get_data_quota($t[15]);
      }
    }
    $e="";
    echo("<center>");
    if (!$ok){
      if ($default_site<>""){
        sys_env_new($sitepage,$k_install);
        $e=sys_env_pack();
        echo("<form method='post' action='./$s_program?$e'>");
        sys_env_del($sitepage,$k_install);
      }else{
        echo("<form method='post' action='./$s_program'>");
      }
    }
    $ki=sys_line_local("Alap�rtelmezett weblap (site) neve");
    echo("<div class='div_r1'>$ki:</div>");
    echo("<input class='input_r1' type='text' id='m1' name='m1' value='$tomb[0]' size='120' maxlength='100' $readonly /><br />");
    $ki=sys_line_local("Alap�rtelmezett felsz�n neve");
    echo("<div class='div_r1'>$ki:</div>");
    echo("<input class='input_r1' type='text' id='m2' name='m2' value='$tomb[1]' size='120' maxlength='100' $readonly /><br />");
    echo("<br /><br />");
    $ki=sys_line_local("SQL adatb�zis neve");
    echo("<div class='div_r1'>$ki:</div>");
    echo("<input class='input_r1' type='text' id='m3' name='m3' value='$tomb[2]' size='120' maxlength='100' $readonly /><br />");
    $ki=sys_line_local("SQL szerver c�me (neve)");
    echo("<div class='div_r1'>$ki:</div>");
    echo("<input class='input_r1' type='text' id='m4' name='m4' value='$tomb[3]' size='120' maxlength='100' $readonly /><br />");
    $ki=sys_line_local("SQL szerver port");
    echo("<div class='div_r1'>$ki:</div>");
    echo("<input class='input_r1' type='text' id='m5' name='m5' value='$tomb[4]' size='120' maxlength='100' $readonly /><br />");
    $ki=sys_line_local("SQL hozz�f�r�s felhaszn�l�i neve");
    echo("<div class='div_r1'>$ki:</div>");
    echo("<input class='input_r1' type='text' id='m6' name='m6' value='$tomb[5]' size='120' maxlength='100' $readonly /><br />");
    $ki=sys_line_local("SQL hozz�f�r�s jelszava");
    echo("<div class='div_r1'>$ki:</div>");
    echo("<input class='input_r1' type='text' id='m7' name='m7' value='$tomb[6]' size='120' maxlength='100' $readonly /><br />");
    echo("<br />");
    $ki=sys_line_local("SMTP szerver (e-mail k�ld�shez)");
    echo("<div class='div_r1'>$ki:</div>");
    echo("<input class='input_r1' type='text' id='m8' name='m8' value='$tomb[7]' size='120' maxlength='100' $readonly /><br />");
    $ki=sys_line_local("SMTP szerver port");
    echo("<div class='div_r1'>$ki:</div>");
    echo("<input class='input_r1' type='text' id='m9' name='m9' value='$tomb[8]' size='120' maxlength='100' $readonly /><br />");
    $ki=sys_line_local("SMTP szerver felhaszn�l�i neve");
    echo("<div class='div_r1'>$ki:</div>");
    echo("<input class='input_r1' type='text' id='m10' name='m10' value='$tomb[9]' size='120' maxlength='100' $readonly /><br />");
    $ki=sys_line_local("SMTP szerver jelszava");
    echo("<div class='div_r1'>$ki:</div>");
    echo("<input class='input_r1' type='text' id='m11' name='m11' value='$tomb[10]' size='120' maxlength='100' $readonly /><br />");
    echo("<br />");
    $ki=sys_line_local("Adminisztr�tori e-mail c�m");
    echo("<div class='div_r1'>$ki:</div>");
    echo("<input class='input_r1' type='text' id='m12' name='m12' value='$tomb[11]' size='120' maxlength='100' $readonly /><br />");
    echo("<br />");
    if (!$ok){
      $ki=sys_line_local("Mehet");
      echo("<button class='button_1' type='submit' id='b7' name='b7' value='$ki'>$ki</button>");
      echo("</form>");
    }
    echo("</center>");
    if ($ok){
      echo("<br />");
      $ki=sys_line_local("A telep�t�s v�gleges�t�se");
      echo("<div class='div_address'>$ki.</div>");
      $ki=sys_line_local("SQL adatb�zis �s t�bl�k l�trehoz�sa");
      echo("<div class='div_address'>$ki.</div>");
      sql_open();
      if ($tomb[11]<>""){
        $ki=sys_line_local("Teszt e-mail k�ld�se");
        echo("<div class='div_address'>$ki.</div>");
        $kix=sys_line_local("Teszt e-mail");
        site_send_mail($tomb[11],"","","","Teszt",$ki);
      }
      echo("<br />");
      $ki=sys_line_local("A be�ll�t�sok ki�r�sa");
      echo("<div class='div_address'>$ki.</div>");
      echo("<br />");
      site_config_write($tomb);
      echo("<br />");
      $ki=sys_line_local("A telep�t�s befejezve");
      echo("<div class='div_address'>$ki.</div>");
      echo("<br />");
      $ki=sys_line_local("Amennyiben hib�t �szlel, itt jav�thatja az adatokat");
      echo("<div class='div_address'>");
      sys_env_new($sitepage,$k_install);
      $e=sys_env_pack();
      echo("<a href='./$s_program?$e' class='href'>$ki</a>");
      sys_env_del($sitepage);
      echo("</div>");
      echo("<br />");
      $ki=sys_line_local("Folytat�s: a rendszer ind�t�sa");
      echo("<div class='div_address'>");
      echo("<a href='./$s_program?$sitename=$tomb[0]' class='href'>$ki</a>");
      echo("</div>");
      echo("<br />");
    }
  }


  function site_config_write($tomb){
    global $install_config_file,
           $default_site_source,
           $default_template_source,
           $dir_site,$dir_template;

    $t[0]="<?php";
    $t[1]="";
    $t[2]="\$default_site=\"$tomb[0]\";";
    $t[3]="\$default_template=\"$tomb[1]\";";
    $t[4]="\$sql_name=\"$tomb[2]\";";
    $t[5]="\$sql_server=\"$tomb[3]\";";
    $t[6]="\$sql_port=\"$tomb[4]\";";
    $t[7]="\$sql_user=\"$tomb[5]\";";
    $t[8]="\$sql_pass=\"$tomb[6]\";";
    $t[9]="";
    $t[10]="\$smtp_system_host=\"$tomb[7]\";";
    $t[11]="\$smtp_system_port=\"$tomb[8]\";";
    $t[12]="\$smtp_system_user=\"$tomb[9]\";";
    $t[13]="\$smtp_system_password=\"$tomb[10]\";";
    $t[14]="";
    $t[15]="\$system_administrator_email=\"$tomb[11]\";";
    $t[16]="";
    $t[17]="?>";
    $t[18]="";
    sys_file_out($install_config_file,$t);
    $f1="$dir_site/$default_site_source";
    $f2="$dir_site/$tomb[0]";
    sys_dir_copy($f1,$f2);
    $f1="$dir_template/$default_template_source";
    $f2="$dir_template/$tomb[0]";
    sys_dir_copy($f1,$f2);
    $c=count($t);
    $x=1;
    while ($x<$c-2){
      echo("$t[$x]<br>");
      $x++;
    }
  }



  function site_get_data_quota($t){
    $v="";
    $t2=explode("\"",$t);
    if (count($t2)>1){
      $v=$t2[1];
    }
    //$v=substr($t2[1],0,strlen($t2[1])-2);
    return($v);
  }


?>
