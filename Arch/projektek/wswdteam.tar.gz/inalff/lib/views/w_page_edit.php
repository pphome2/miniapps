<?php

  // w_robot --- PHP portalrobot
  // (verzioadatok a konfiguracios fajlban)
  //
  // fejleszto: InalR Fejlesztoi Iroda



  // egy lap kiirasa


  function site_page_edit(){
    global $article_text,$article_brief,
           $k_edit,$sitepage,$default_site,
           $dir_site,$s_program,$cat_view,
           $site_data_css_container,$sitepos,
           $article_category,$default_site;

    sys_env_new($sitepage,$k_edit);
    $e=sys_env_pack();
    echo("<br /><br />");
    if ($site_data_css_container<>""){
      echo("</div><div class='$site_data_css_container'>");
    }else{
      echo("<hr class='hrcl' />");
    }
    $n=site_page_name();
    if (substr($n,0,2)==".."){
      sys_env_new($sitepos,$default_site);
      site_in($default_site);
      $n=$default_site;
    }
    $ki=sys_line_local("Szerkeszt�s");
    echo("<div class='div_address'>$ki ($n):</div>");
    echo("<br /><br />");
    echo("<center>");
    echo("<form method='post' action='./$s_program?$e'>");
    $ki=sys_line_local("R�vid bevezet�s");
    echo("<div class='div_address'>$ki:</div>");
    echo("<br /><br />");
    echo("<textarea class='textarea_e1' id='br1' name='br1' cols='70' rows='5'>");
    site_page_out_2($article_brief);
    echo("</textarea>");
    echo("<br /><br />");
    $ki=sys_line_local("Tartalom");
    echo("<div class='div_address'>$ki:</div>");
    echo("<br /><br />");
    echo("<textarea class='textarea_e1' id='br2' name='br2' cols='70' rows='25'>");
    site_page_out_2($article_text);
    echo("</textarea>");
    echo("<br /><br />");
    $ki=sys_line_local("Kateg�ria");
    echo("<div class='div_address'>$ki:</div>");
    echo("<br /><br />");
    $tx=sql_category_get_result();
    $regdb=sql_result_db($tx);
    echo("<select class='select_r1' id='br3' name='br3'>");
    $db=0;
    while ($db<$regdb){
      $tomb=sql_get_result_data($tx,$db);
      $db+=1;
      $sc=strlen($article_category);
      if ($article_category==$tomb[1]){
        echo("<option selected='selected' value='$tomb[1]'>$tomb[1] </option>");
      }else{
        echo("<option value='$tomb[1]'>$tomb[1] </option>");
      }
    }
    $ki=sys_line_local($cat_view);
    if ($article_category==$ki){
      echo("<option selected='selected' value='$ki'>$ki </option>");
    }else{
      echo("<option value='$ki'>$ki </option>");
    }
    echo("</select>");
    echo("<br /><br />");
    $ki=sys_line_local("Mehet");
    echo("<button class='button_1' type='submit' id='b6' name='b6' value='$ki'>$ki</button>");
    echo("</form>");
    echo("</center>");
    echo("<br />");
    if ($site_data_css_container!=""){
      echo("</div><div class='$site_data_css_container'>");
    }
    site_edit_help();
  }


?>
