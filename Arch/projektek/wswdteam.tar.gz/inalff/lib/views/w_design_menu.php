<?php

  // w_robot --- PHP portalrobot
  // (verzioadatok a konfiguracios fajlban)
  //
  // fejleszto: InalR Fejlesztoi Iroda



  function site_page_menu_wiki($container){
    global $template_path,$dir_temp_img,
           $wiki_style;

    if ($wiki_style){
      if ($container<>""){
        echo("<div class='$container'>");
        site_page_menu();
        echo("</div>");
      }else{
        site_page_menu();
        echo("<br />");
      }
    }
  }


  function site_page_menu_admin($head,$block,$line){
    echo("<div class='$head'>");
    if ($line<>""){
      $ki=sys_line_local("Adminisztr�ci�");
      echo("<center><div class='$line'>$ki</div></center>");
    }
    echo("<div class='$block'>");
    site_admin_menu();
    echo("</div>");
    echo("</div>");
  }


  function site_page_menu_plugin($head,$block,$line){
    global $plugin_menu;

    if (count($plugin_menu)>0){
      echo("<div class='$head'>");
      if ($line<>""){
        $ki=sys_line_local("Alkalmaz�s");
        echo("<center><div class='$line'>$ki</div></center>");
      }
      echo("<div class='$block'>");
      plugin_menu_out();
      echo("</div>");
      echo("</div>");
    }
  }


  function site_page_menu_reg_admin($head,$block,$line){
    global $reg_menu_plus,$admin_menu_plus,
           $user_in,$user_admin;

    $x=count($reg_menu_plus);
    // kikapcs
    $x=0; 
    if (($x>0)and($user_in<>"")){
      echo("<div class='$head'>");
      echo("<div class='$block'>");
      site_menu_local($reg_menu_plus);
      echo("</div>");
      echo("</div>");
    }
    if ($user_admin){
      echo("<div class='$head'>");
      if ($line<>""){
        $ki=sys_line_local("Adminisztr�ci�");
        echo("<center><div class='$line'>$ki</div></center>");
      }
      echo("<div class='$block'>");
      site_admin_menu();
      echo("</div>");
      echo("</div>");
    }
  }


  function site_page_menu_global($head,$block){
    echo("<div class='$head'>");
    echo("<div class='$block'>");
    site_menu_global();
    echo("</div>");
    echo("</div>");
  }


  function site_page_menu_reg($head,$block,$line,$login){
    global $user_in;

    if ($user_in<>""){
      echo("<div class='$head'>");
      if ($line<>""){
        $ki=sys_line_local("Bejelentkezve");
        echo("<center><div class='$line'>$ki</div></center>");
      }
      echo("<div class='$block'>");
      site_reg_menu();
      echo("</div>");
      echo("</div>");
    }else{
      if ($login){
        site_page_enter_user($head,$block,$line);
      }
    }
  }


  function site_page_menu_link($head,$block,$line,$cim,$t1,$t2,$h){
    if ($head<>""){
      echo("<div class='$head'>");
    }
    if ($line<>""){
      echo("<center><div class='$line'>$cim</div></center>");
    }
    if ($block<>""){
      echo("<div class='$block'>");
    }
    site_menu_link($t1,$t2,$h);
    if ($head<>""){
      echo("</div>");
    }
    if ($block<>""){
      echo("</div>");
    }
  }


  function site_page_menu_plus($head,$block,$line){
    global $local_menu_plus;

    $x=count($local_menu_plus);
    if ($x>0){
      echo("<div class='$head'>");
      if ($line<>""){
        $ki=sys_line_local("Rendszer");
        echo("<center><div class='$line'>$ki</div></center>");
      }
      echo("<div class='$block'>");
      site_menu_local($local_menu_plus);
      echo("</div>");
      echo("</div>");
    }
  }

?>
