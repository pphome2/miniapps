<?php

  // w_robot --- PHP portalrobot
  // (verzioadatok a konfiguracios fajlban)
  //
  // fejleszto: InalR Fejlesztoi Iroda




  function site_privat_edit($kod){
    global $k_privat,$usercode,$s_program,$user_admin,
           $sitepage,$separator,$k_regist;

    $ki=sys_line_local("Felhaszn�l�i adatok");
    echo("<div class='div_address'>$ki</div>");
    echo("<br /><br />");
    $sp=sys_env_find($sitepage);
    $db=0;
    if ($kod==""){
      //$kod=sys_env_find($usercode);
      sys_env_new($sitepage,$k_regist);
      $ki=sys_line_local("Felhaszn�l�k�nt hozz�f�rhet olyan tartalmakhoz, melyet a");
      echo("$ki ");
      $ki=sys_line_local("weboldal �zemeltet�je azonos�t�shoz k�t�tt.");
      echo("$ki ");
      $ki=sys_line_local("A regisztr�ci�val �n elfogadja az �zemeltet� �ltal meghat�rozott");
      echo("$ki ");
      $ki=sys_line_local("ir�nyelveket, felt�teleket.");
      echo("$ki ");
      $ki=sys_line_local("Ezekr�l a felt�telekr�l a Felhaszn�l�si felt�telek");
      echo("$ki ");
      $ki=sys_line_local("men�pont alatt tal�l t�j�koztat�st.");
      echo("$ki<br /><br />");
      $ki=sys_line_local("Adatait az Adatv�delmi ir�nyelvek szerint kezelj�k.");
      echo("$ki ");
      $ki=sys_line_local("Ezekr�l az Adatv�delmi ir�nyelvek");
      echo("$ki ");
      $ki=sys_line_local("men�pont alatt tal�l t�j�koztat�st.");
      echo("$ki<br />");
      echo("<br /><br />");
      $i=0;
      while ($i<20){
        $tomb[$i]="";
        $i++;
      }
      $tomb[0]=sys_time_code();
      $tomb[1]=time();
      $tomb[2]=$separator;
    }else{
      $tomb=sql_user_getdata_all($kod);
    }
    $sp=sys_env_find($sitepage);
    if ($sp==""){
      sys_env_new($sitepage,$k_privat);
    }
    $e=sys_env_pack();
    if ($tomb[0]<>""){
      echo("<center>");
      echo("<form method='post' action='./$s_program?$e'>");
      echo("<input class='input_r1' type='hidden' id='m1' name='m1' value='$tomb[0]' />");
      echo("<input class='input_r1' type='hidden' id='m2' name='m2' value='$tomb[1]' />");
      if ($user_admin){
        $ki=sys_line_local("Bejelentkez�si korl�t");
        $kd=sys_line_local("nap");
        $kw=sys_line_local("h�t");
        $km=sys_line_local("h�nap");
        $ky=sys_line_local("�v");
        $ku=sys_line_local("Korl�tlan bel�p�s");
        $kt=sys_line_local("Bejelentkez�s letiltva");
        echo("<div class='div_r1'>$ki:</div>");
        echo("<select class='select_r1' id='m3' name='m3'>");
        if ($tomb[2]==$separator){
          echo("<option selected='selected' value='$separator'>$ku</option>");
        }else{
          echo("<option selected='selected' value='$separator'>$ku</option>");
        }
        if ($tomb[2]=="86400"){
          echo("<option selected='selected' value='86400'>1 $kd</option>");
        }else{
          echo("<option value='86400'>1 $kd</option>");
        }
        if ($tomb[2]=="604800"){
          echo("<option selected='selected' value='604800'>1 $kw</option>");
        }else{
          echo("<option value='604800'>1 $kw</option>");
        }
        if ($tomb[2]=="2678400"){
          echo("<option selected='selected' value='2678400'>1 $km</option>");
        }else{
          echo("<option value='2678400'>1 $km</option>");
        }
        if ($tomb[2]=="8035200"){
          echo("<option selected='selected' value='8035200'>3 $km</option>");
        }else{
          echo("<option value='8035200'>3 $km</option>");
        }
        if ($tomb[2]=="16070400"){
         echo("<option selected='selected' value='16070400'>6 $km</option>");
        }else{
         echo("<option value='16070400'>6 $km</option>");
        }
        if ($tomb[2]=="31536000"){
          echo("<option selected='selected' value='31536000'>1 $ky</option>");
        }else{
          echo("<option value='31536000'>1 $ky</option>");
        }
        if ($tomb[2]=="0"){
          echo("<option selected='selected' value='0'>$kt</option>");
        }else{
          echo("<option value='0'>$kt</option>");
        }
        echo("</select>");
      }else{
        echo("<input class='input_r1' type='hidden' id='m3' name='m3' value='$tomb[2]' />");
      }
      $ki=sys_line_local("N�v");
      echo("<div class='div_r1'>$ki:</div>");
      echo("<input class='input_r1' type='text' id='m4' name='m4' value='$tomb[3]' size='120' maxlength='100' /><br />");
      $ki=sys_line_local("Jelsz�");
      echo("<div class='div_r1'>$ki:</div>");
      echo("<input class='input_r1' type='password' id='m5' name='m5' value='$tomb[4]' size='120' maxlength='100' /><br />");
      $ki=sys_line_local("Teljes n�v");
      echo("<div class='div_r1'>$ki:</div>");
      echo("<input class='input_r1' type='text' id='m6' name='m6' value='$tomb[5]' size='120' maxlength='100' /><br />");
      $ki=sys_line_local("Lakc�m");
      echo("<div class='div_r1'>$ki:</div>");
      echo("<input class='input_r1' type='text' id='m7' name='m7' value='$tomb[6]' size='120' maxlength='100' /><br />");
      $ki=sys_line_local("E-mail");
      echo("<div class='div_r1'>$ki:</div>");
      echo("<input class='input_r1' type='text' id='m8' name='m8' value='$tomb[7]' size='120' maxlength='100' /><br />");
      if ($tomb[8]<>$separator){
        $checked="checked";
      }else{
        $checked="";
      }
      $ki=sys_line_local("H�rlev�l k�r�se");
      echo("<div class='div_r1'>$ki:</div>");
      echo("<input class='input_r1' type='checkbox' id='m9' name='m9' $checked /><br />");
      echo("<br />");
      $ki=sys_line_local("Mehet");
      echo("<button class='button_1' type='submit' id='b7' name='b7' value='$ki'>$ki</button>");
      echo("</form>");
      echo("</center>");
    }else{
      $ki=sys_line_local("Adatok nem el�rhet�k");
      echo("$ki.");
    }
    sys_env_del($sitepage);
  }



?>
