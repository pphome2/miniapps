<?php

  // w_robot --- PHP portalrobot
  // (verzioadatok a konfiguracios fajlban)
  //
  // fejleszto: InalR Fejlesztoi Iroda



  function site_global_admin($admin_pont){
    global $deldata,$k_admin,$sitepage,$administrator,
           $s_program,$sitepos,$dir_img,$dir_file,
           $dir_site,$default_site,$dir_data,$delkod,
           $k_admin_1,$k_admin_2,$k_admin_3,$k_admin_4,
           $k_admin_5,$k_admin_6,$k_admin_7,$k_admin_8,
           $k_admin_9,$dirdata,$file_user_config,
           $specchar2,$site_data_css_container,
           $separator,$sql_table_list,$dirpos,
           $user_admin,
           $mess_per_page,$mess_akt_page,$messpage;

    if ($user_admin){
      sys_env_new($sitepage,$admin_pont);
      switch ($admin_pont){
        case $k_admin_1:
        case $k_admin_7:
          site_admin_user();
          break;
        case $k_admin_2;
          $ki2=sys_line_local("Adatt�r");
          echo("<div class='div_address'>$ki2</div>");
          echo("<br />");
          $dirname="$dir_site/$default_site/$dir_data";
          $admin=true;
          $dload=true;
          sys_env_del($deldata);
          site_directory_list($dirname,$admin,$dload);
          break;
        case $k_admin_3:
          $ki2=sys_line_local("K�pt�r");
          echo("<div class='div_address'>$ki2</div>");
          echo("<br />");
          $dirname="$dir_site/$default_site/$dir_img";
          $admin=true;
          $dload=true;
          if ($dirdata<>""){
            $dirn="../$dirdata";
          }else{
            $dirn=$dirname;
          }
          sys_env_del($deldata);
          site_directory_list($dirname,$admin,$dload);
          $e=sys_env_pack();
          if ($site_data_css_container!=""){
            echo("</div><div class='$site_data_css_container'>");
          }else{
            echo("<hr class='hrcl' />");
          }
          $ki2=sys_line_local("K�p felt�lt�se k�pt�rba");
          echo("<br /><br /><div class='div_address'>$ki2</div>");
          echo("<br /><br />");
          echo("<center>");
          echo("<form method='post' enctype='multipart/form-data' action='./$s_program?$e'>");
          $ki=sys_line_local("K�pf�jl");
          echo("<div class='div_r1'>$ki: </div>");
          //echo("<input class='input_r1' type='file' id='userfile' name='userfile' size='120' maxlength='100' /><br /><br />");
          echo("<input class='input_f1' type='file' id='userfile' name='userfile' size='40' maxlength='100' /><br /><br />");
          $ki=sys_line_local("�j k�nyvt�r");
          echo("<div class='div_r1'>$ki: </div>");
          echo("<input class='input_r1' type='text' id='userdir' name='userdir' size='120' maxlength='100' /><br /><br />");
          echo("<input type='hidden' id='aktdir' size='120' maxlength='100' value='$dirname' />");
          $ki=sys_line_local("Mehet");
          echo("<button class='button_1' type='submit' id='b01' name='b01' value='$ki'>$ki</button>");
          echo("</form>");
          echo("</center><br />");
          break;
        case $k_admin_4:
          $ki2=sys_line_local("K�nyvt�r");
          echo("<div class='div_address'>$ki2</div>");
          echo("<br />");
          $dirname="$dir_site/$default_site/$dir_file";
          if ($dirdata<>""){
            $dirn=$dirname.$dirdata;
          }else{
            $dirn=$dirname;
          }
          sys_env_del($deldata);
          $admin=true;
          $dload=true;
          site_directory_list($dirname,$admin,$dload);
          sys_env_new($dirpos,$dirdata);
          $e=sys_env_pack();
          sys_env_del($dirdata);
          if ($site_data_css_container!=""){
            echo("</div><div class='$site_data_css_container'>");
          }else{
            echo("<hr class='hrcl' />");
          }
          $ki2=sys_line_local("F�jl felt�lt�se k�nyvt�rba");
          echo("<br /><br />");
          echo("<div class='div_address'>$ki2:</div>");
          echo("<br /><br />");
          echo("<center>");
          echo("<form method='post' enctype='multipart/form-data' action='./$s_program?$e'>");
          $ki=sys_line_local("F�jl");
          echo("<div class='div_r1'>$ki: </div>");
          //echo("<input class='input_r1' type='file' id='userfile' name='userfile' size='120' maxlength='100' /><br /><br />");
          echo("<input class='input_f1' type='file' id='userfile' name='userfile' size='40' maxlength='100' /><br /><br />");
          $ki=sys_line_local("�j k�nyvt�r");
          echo("<div class='div_r1'>$ki: </div>");
          echo("<input class='input_r1' type='text' id='userdir' name='userdir' size='120' maxlength='100' /><br /><br />");
          echo("<input type='hidden' id='aktdir' size='120' maxlength='100' value='$dirn' />");
          $ki=sys_line_local("Mehet");
          echo("<button class='button_1' type='submit' id='b02' name='b02' value='$ki'>$ki</button>");
          echo("</form>");
          echo("</center><br />");
          break;
        case $k_admin_5:
          site_admin_newsletter();
          break;
        case $k_admin_6:
          $ki2=sys_line_local("Be�ll�t�sok");
          echo("<div class='div_address'>$ki2</div><br />");
          $ki2=sys_line_local("A m�dos�t�s a rendszer �szzeoml�s�t is okozhatja");
          echo("<div class='div_address'>$ki2.</div>");
          $e=sys_env_pack();
          echo("<br />");
          $conffile="$dir_site/$default_site/$file_user_config";
          site_file_in($conffile,$sdata,$sline);
          //echo("<center>");
          //echo("<form method='post' action='./$s_program?$e'>");
          //echo("<textarea class='textarea_e1' id='tartalom' name='tartalom' cols='70' rows='25'>");
          //$x=0;
          //while ($x<$sline){
            //echo($sdata[$x]);
            //if ($x<$sline-1){
              //echo($specchar2);
            //}
            //$x+=1;
          //}
          //echo("</textarea><br /><br />");
          //$ki=sys_line_local("Mehet");
          //echo("<button class='button_1' type='submit' id='b03' name='b03' value='$ki'>$ki</button>");
          //echo("</form>");
          //echo("</center>");
          site_form_generator($sdata);
          break;
        case $k_admin_8:
          $tx=sql_category_get_result();
          $regdb=sql_result_db($tx);
          $ki=sys_line_local("Adminisztr�ci�");
          echo("<div class='div_address'>$ki</div>");
          echo("<br />");
          $ki=sys_line_local("Kateg�ri�k");
          echo("<div class='div_address'>$ki</div>");
          echo("<br />");
          echo("<center><div class='page_table'>");
          $ki=sys_line_local("Feladat");
          echo("<div class='div_a1'>-</div>");
          echo("<div class='div_a2'><b>$ki</b></div>");
          $ki=sys_line_local("Kateg�ria neve");
          echo("<div class='div_a3'><b>$ki</b></div>");
          echo("</div>");
          $ki0=sys_line_local("T�r�l");
          $e=sys_env_pack();
          site_pageing_init($regdb,$tol,$ig,$mess_per_page,$mess_akt_page);
          $db=$tol;
          while ($db<$ig){
            $tomb=sql_get_result_data($tx,$db);
            $db+=1;
            if ($tomb[0]<>""){
              echo("<div class='page_table'>");
              sys_env_new($deldata,$tomb[0]);
              $e=sys_env_pack();
              echo("<div class='div_a1'>$db.</div>");
              echo("<div class='div_a2'>");
              echo("<a class='href' href='./$s_program?$e'>$ki0</a>");
              echo("</div>");
              echo("<div class='div_a3'>$tomb[1]</div>");
              echo("</div>");
              sys_env_del($deldata);
            }
          }
          $ki=sys_line_local("�sszesen");
          //echo("<br /><br /><div class='div_u'>$ki: $regdb.</div>");
          echo("<br />");
          echo("<br />");
          site_pageing($regdb,$mess_per_page,$mess_akt_page,$messpage);
          echo("<div class='page_table'>");
          sys_env_del($deldata);
          $e=sys_env_pack();
          $ki=sys_line_local("�j kateg�ria");
          echo("<br />");
          echo("<br />");
          echo("<div class='div_address'><b>$ki</b></div>");
          echo("<br />");
          echo("<br />");
          echo("<form method='post' enctype='multipart/form-data' action='./$s_program?$e'>");
          $ki=sys_line_local("Kateg�ria neve");
          $ti=sys_time_code();
          echo("<input class='input_r1' type='hidden' id='ucat1' name='ucat1' value='$ti' />");
          echo("<div class='div_r1'>$ki: </div>");
          echo("<input class='input_r1' type='text' id='ucat2' name='ucat2' size='120' maxlength='100' /><br /><br />");
          $ki=sys_line_local("Mehet");
          echo("<button class='button_1' type='submit' id='b01' name='b01' value='$ki'>$ki</button>");
          echo("</form>");
          echo("<br /></div></center><br />");
          break;
        case $k_admin_9:
          site_admin_dataplace();
          break;
      }
      sys_env_del($sitepage);
    }else{
      $ki=sys_line_local("Adminisztr�tori jogosults�g sz�ks�ges");
      echo("$ki.");
    }
  }


?>
