<?php

  // w_robot --- PHP portalrobot
  // (verzioadatok a konfiguracios fajlban)
  //
  // fejleszto: InalR Fejlesztoi Iroda



  // adatlista

  function site_data_list(){
    global $messpage,$mess_akt_page,
           $mess_per_page,
           $delkod,$deldata,$user_admin,
           $site_data_css_container,$sitepage,
           $sitepos,$k_alist,
           $article_list_db,$s_program,
           $k_edit;

    if ($delkod<>""){
      sql_article_del($delkod);
      $ki=sys_line_local("T�rl�s megt�rt�nt");
      echo("<br />$ki.<br/><br />");
    }
    $cat="";
    $ok=sys_data_post($dbx,$tkx,$tex);
    if ($ok){
      $cat=$tex[0];
      $mess_akt_page=1;
    }
    sys_env_new($sitepage,$k_alist);
    $e=sys_env_pack();
    echo("<br />");
    echo("<center>");
    echo("<form method='post' action='./$s_program?$e'>");
    $ki=sys_line_local("R�vid bevezet�s");
    $tx=sql_category_get_result();
    $regdb=sql_result_db($tx);
    $ki=sys_line_local("Sz�r�s");
    echo("<select class='select_r1' id='br3' name='br3'>");
    $ki=sys_line_local("Minden �r�s");
    if ($cat==$ki){
      echo("<option selected='selected' value='$ki'>$ki </option>");
      $all=true;
    }else{
      echo("<option value='$ki'>$ki </option>");
      $all=false;
    }
    $db=0;
    while ($db<$regdb){
      $tomb=sql_get_result_data($tx,$db);
      $db+=1;
      if ($cat==$tomb[1]){
        echo("<option selected='selected' value='$tomb[1]'>$tomb[1] </option>");
      }else{
        echo("<option value='$tomb[1]'>$tomb[1] </option>");
      }
    }
    echo("</select>");
    $ki=sys_line_local("Mehet");
    echo("<button class='button_1' type='submit' id='b6' name='b6' value='$ki'>$ki</button>");
    echo("</form>");
    echo("</center>");
    $ul=sys_env_find($sitepos);
    $db=0;
    if ($all){
      $tx=sql_article_all_result_l();
    }else{
      $tx=sql_article_cat_get_result($cat);
    }
    $db=sql_result_db($tx);
    site_pageing_init($db,$tol,$ig,$article_list_db,$mess_akt_page);
    echo("<center><br />");
    $ki=sys_line_local("T�r�l");
    $x=0;
    $out=0;
    while (($x<=($article_list_db-1))and($x<$db)){
      echo("<div class='page_table'>");
      $kdb=$tol+$x;
      $txx=array();
      $txx=sql_get_result_data($tx,$kdb);
      if (count($txx)>0){
        $z=$tol+$x+1;
        $out++;
        echo("<div class='div_a1'>");
        echo("$z");
        echo("</div>");
        echo("<div class='div_a2'>");
        if ($user_admin){
          sys_env_new($deldata,$txx[0]);
          sys_env_new($messpage,$mess_akt_page);
          $e=sys_env_pack();
          sys_env_del($messpage);
          sys_env_del($deldata);
          echo("<a class='href' href=$s_program?$e>$ki</a>");
        }else{
          echo("$txx[2]");
        }
        echo("</div>");
        echo("<div class='div_a3'>");
        sys_env_new($sitepos,$txx[1]);
        $e=sys_env_pack();
        echo("<a class='href' href=$s_program?$e>$txx[1]</a>");
        echo("</div>");
        echo("<br />");
      }
      echo("</div>");
      $x++;
    }
    echo("");
    echo("</center>");
    //echo("<div class='div_hidden'><br /></div>");
    if ($db>$article_list_db){
      if ($site_data_css_container<>""){
        echo("<div class='div_p'></div>");
        echo("</div><div class='$site_data_css_container'>");
      }else{
        echo("<hr class='hrcl' />");
      }
    }else{
      echo("<br />");
    }
    site_pageing($db,$article_list_db,$mess_akt_page,$messpage);
    sys_env_del($sitepage);
  }


  function site_new_data_list(&$cim,$cat,$timeout,$timeonly){
    global $sitepos,$article_list_db,$s_program,
           $last_article_list_db,$time_format,$date_format;

    $l=sys_env_find($sitepos);
    $db=0;
    $sor="";
    if ($cat>10000){
      $tx=sql_article_all_result_l();
    }else{
      $tx0=sql_category_get_result();
      $db=sql_result_db($tx0);
      if ($cat>=$db){
        $tx=sql_article_all_result_l();
      }else{
        $txx0=sql_get_result_data($tx0,$cat);
        $catn=$txx0[1];
        $cim=$catn;
        $tx=sql_article_cat_get_result($catn);
      }
    }
    $db=sql_result_db($tx);
    if ($db>$last_article_list_db){
      $db=$last_article_list_db;
    }
    $x=0;
    while ($x<$db){
      $txx=sql_get_result_data($tx,$x);
      if (count($txx)>0){
        sys_env_new($sitepos,$txx[1]);
        $e=sys_env_pack();
        $ti="";
        if ($timeout){
          if ($timeonly){
            $ti=sys_time_code_to_date($time_format,$txx[0])." - ";
          }else{
            $ti=sys_time_code_to_date($date_format,$txx[0])." - ";
          }
        }
        $sor=$sor.$ti."<a class='href' href=$s_program?$e>$txx[1]</a><br />";
      }
      $x++;
    }
    sys_env_new($sitepos,$l);
    return($sor);
  }


  function site_page_cat_out($lap){
    global $sitepos,$s_program,$k_feed,
           $default_site,
           $l_open,$l_end,$s_ita,$s_eita,$s_nline,
           $k_edit,$l_open,$l_end,$s_program,$open_page,
           $s_program,$sitepage,$plugin_start,
           $comment_all,$comment_1_page,$cat_view,
           $write_out,$editor,$show_writer,
           $messpage,$mess_per_page,$mess_akt_page,
           $site_data_css_container;

    $sp=sys_env_find($sitepage);
    $ki=sys_line_local("RSS/Atom h�rcsatorna");
    sys_env_new($sitepage,$k_feed);
    $e=sys_env_pack();
    sys_env_del($sitepage);
    echo("<br />");
    echo("<div class='div_paddress'>$lap</div>");
    echo("<div class='div_rightst'>[ <a class='href' href='./$s_program?$e'>$ki</a> ]</div>");
    echo("<br /> ");
    $tx=sql_article_cat_get_result($lap);
    $db=sql_result_db($tx);
    $tol=($mess_akt_page-1)*$mess_per_page;
    if ($tol<0){
      $tol=0;
    }
    if ($tol>=$db){
      $mess_akt_page-=1;
      $tol=($mess_akt_page-1)*$mess_per_page;
      if ($tol<0){
        $tol=0;
      }
    }
    if (($tol+$mess_per_page)>$db){
      $ig=$db;
    }else{
      $ig=$tol+$mess_per_page;
    }
    $a=$tol;
    while ($a<$ig){
      if (($a>=$tol)and($a<$tol+$mess_per_page)){
        $txx=sql_get_result_data($tx,$a);
        if ($site_data_css_container<>""){
          echo("<div class='div_p'></div>");
          echo("</div><div class='$site_data_css_container'>");
        }else{
          echo("<hr class='hrcl' />");
        }
        echo("<br />");
        echo("<div class='div_address'>$txx[1]</div>");
        if ($show_writer){
          $ki=sys_line_local("K�sz�tette");
          $ki2=sys_line_local("Kateg�ria");
          //echo("<i>$ki: $txx[3], $txx[4] ($txx[4)</i>");
          echo("<div class='div_u'>( $ki: $txx[3], $txx[2], $ki2: $txx[4] )</div>");
        }else{
          echo("<div class='div_u'>( $txx[2] )</div>");
        }
        echo("<br />");
        $s=$txx[5];
        $sx="";
        $v0=0;
        $vve=strlen($s);
        while ($v0<$vve){
          if (substr($s,$v0,1)==$l_open){
            $v1=$v0+1;
            while (($v1<strlen($s))and(substr($s,$v1,1)<>$l_end)){
              $v1+=1;
            }
            if (substr($s,$v1,1)==$l_end){
              $s2=substr($s,$v0+1,$v1-$v0-1);
              $la=site_lang($s2);
              if (!$plugin_start){
                $s=substr($s,0,$v0).$la.substr($s,$v1+1,strlen($s));
                $vve=strlen($s);
              }else{
                $s=="";
                $v0=$vve;
              }
            }
          }
          $v0+=1;
        }
        if (($s<>"")and(!$plugin_start)and($write_out)){
          echo("$s ");
        }
        echo("<br /><br />");
        sys_env_new($sitepos,$txx[1]);
        $e=sys_env_pack();
        $k=sys_line_local("B�vebben");
        echo("<a class='href' href='./$s_program?$e'>$k</a>");
        echo("<br /><br />");
      }
      $a++;
    }
    sys_env_new($sitepos,$lap);
    sys_env_new($sitepage,$sp);
    site_pageing($db,$mess_per_page,$mess_akt_page,$messpage);
  }



?>
