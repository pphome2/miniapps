<?php

  // w_robot --- PHP portalrobot
  // (verzioadatok a konfiguracios fajlban)
  //
  // fejleszto: InalR Fejlesztoi Iroda



  // site adminisztracio

  function site_admin($m){
    global $sitepos,$deldata,$delkod,$sitepage,
           $usercode,$user_admin,$separator,$dirdata,
           $dir_site,$default_site,
           $dir_data,$dir_img,$dir_file,
           $k_admin_1,$k_admin_2,$k_admin_3,$k_admin_4,
           $k_admin_5,$k_admin_6,$k_admin_7,$k_admin_8,
           $k_admin_9,$separator,
           $file_user_config,$date_time_nodot;

    if ($user_admin){
      switch ($m){
        case $k_admin_1:
          site_user_del($delkod);
          break;
        case $k_admin_2:
          if ($delkod<>""){
            $filename="$dir_site/$default_site/$dir_data/$delkod";
            sys_file_del($filename);
            $delkod="";
          }
          break;
        case $k_admin_3:
          if ($delkod<>""){
            $filename="$dir_site/$default_site/$dir_img/$delkod";
            sys_file_del($filename);
            $delkod="";
          }else{
            $uploaddir="$dir_site/$default_site/$dir_img";
            if (sys_file_upload($uploaddir)){
              $ki=sys_line_local("A felt�lt�s megt�rt�nt");
              echo("<br />$ki.<br />");
            }else{
              $ok=sys_data_post($db,$tk,$te);
              if ($ok){
                sys_mkdir("$uploaddir/$te[0]");
              }else{
                $ki=sys_line_local("Hiba a felt�lt�s k�zben");
                //echo("<br />$ki.<br />");
              }
            }
          }
          break;
        case $k_admin_4:
          if ($delkod<>""){
            $filename="$dir_site/$default_site/$dir_file".$dirdata."/$delkod";
            sys_file_del($filename);
            $delkod="";
          }else{
            $uploaddir="$dir_site/$default_site/$dir_file".$dirdata;
            if (sys_file_upload($uploaddir)){
              $ki=sys_line_local("A felt�lt�s megt�rt�nt");
              echo("<br />$ki.<br />");
            }else{
              $ok=sys_data_post($db,$tk,$te);
              if ($ok){
                sys_mkdir("$uploaddir/$te[0]");
              }else{
                $ki=sys_line_local("Hiba a felt�lt�s k�zben");
                //echo("<br />$ki.<br />");
              }
            }
          }
          break;
        case $k_admin_5:
          if ($delkod<>""){
            $tx=sql_user_getdata_all($delkod);
            $tx[8]=$separator;
            sql_user_update($delkod,$tx);
          }
          break;
        case $k_admin_6:
          $ok=sys_data_post($db,$tkx,$tex);
          if ($ok){
            $conffile="$dir_site/$default_site/$file_user_config";
            $d=date($date_time_nodot);
            $conffilesave=$conffile."-".$d;
            $ki=sys_line_local("Ment�s");
            $ki2=sys_line_local("nem siker�lt");
            $ki3=sys_line_local("siker�lt, friss�tse az oldalt");
            $ok=sys_file_copy($conffile,$conffilesave);
            if ($ok){
              $s=site_form_work_php($tkx,$tex);
              sys_file_out($conffile,$s);
              echo("<br />$ki $ki3.<br /><br />");
            }else{
              echo("<br />$ki $ki2.<br /><br />");
            }
          }
          break;
        case $k_admin_7:
          if ($delkod<>""){
            sys_env_new($sitepage,$k_admin_7);
            sys_env_new($deldata,$delkod);
            site_privat($delkod);
            sys_env_del($deldata);
            sys_env_del($sitepage);
          }
          break;
        case $k_admin_8:
          if ($delkod<>""){
            sql_category_del($delkod);
          }else{
            $ok=sys_data_post($db,$tkx,$tex);
            if ($ok){
              $t[0]=$tex[0];
              $t[1]=$tex[1];
              sql_category_add($t);
            }
          }
          break;
        case $k_admin_9:
          $dirname="$dir_site/$default_site/$dir_data";
          if ($delkod<>""){
            $dirname="$dir_site/$default_site/$dir_data";
            if ($delkod<>""){
              $f=$dirname."/".sys_unstandard_name($delkod);
              sys_file_del($f);
            }
          }else{
            if ($dirdata<>""){
              $uploaddir="../".$dirdata;
            }else{
              $uploaddir="$dir_site/$default_site/$dir_data";
            }
            if (sys_file_upload($uploaddir)){
              $delkod=$separator;
              $ki=sys_line_local("A felt�lt�s megt�rt�nt");
              echo("<br />$ki.<br /><br />");
            }else{
              //$ki=sys_line_local("Hiba a felt�lt�s k�zben");
              //echo("<br />$ki.<br /><br />");
              $ok=sys_data_post($db,$tk,$te);
              if ($ok){
                $delkod=$separator;
                $c=count($te);
                switch ($c){
                  case 1:
                    sql_backup($dirname);
                    $ki=sys_line_local("Ment�s megt�rt�nt");
                    echo("<br />$ki.<br /><br />");
                    break;
                  case 2:
                    break;
                  case 3:
                    break;
                  case 4:
                    $dirname=$dirname."/".$te[0];
                    $table=$te[1];
                    sql_restore($dirname,$table);
                    $ki=sys_line_local("Vissza�ll�t�s megt�rt�nt");
                    echo("<br />$ki.<br /><br />");
                    break;
                }
              }
            }
          }
          break;
      }
    }
    // tovabbi admin feladatok
    site_global_admin($m);
  }



?>
