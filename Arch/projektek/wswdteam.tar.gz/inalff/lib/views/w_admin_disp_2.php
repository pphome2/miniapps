<?php

  // w_robot --- PHP portalrobot
  // (verzioadatok a konfiguracios fajlban)
  //
  // fejleszto: InalR Fejlesztoi Iroda



  function site_admin_newsletter(){
    global $deldata,$k_admin,$sitepage,$administrator,
           $s_program,$sitepos,$separator,$full_date_format,
           $site_data_css_container,$full_date_format,
           $site_admin_email,
           $default_site,$site_admin_email,
           $mess_per_page,$mess_akt_page,$messpage;

    $sp=sys_env_find($sitepage);
    $ok=sys_data_post($db,$tkx,$tex);
    if ($ok){
      if ($site_admin_email<>""){
        $ki=sys_line_local("H�rlev�l");
        $ki2="$default_site - $ki";
        $to=$site_admin_email;
        $re=$site_admin_email;
        $cc="";
        $bcc=$tex[0];
        $sub=$ki2;
        $mess=$tex[1];
        $mailsent=site_send_mail($to,$re,$cc,$bcc,$sub,$mess);
        $kix=sys_line_local("elk�ldve");
        if ($mailsent){
          echo("$ki $kix.<br />");
          echo("<br />");
          echo("<br />");
        }else{
          $kix=sys_line_local("H�rlev�l nem k�ldhet�");
          echo("$kix.<br />");
          echo("<br />");
          echo("<br />");
        }
      }
    }
    $ki2=sys_line_local("H�rlevelet k�r�k");
    echo("<div class='div_address'>$ki2</div>");
    echo("<br />");
    $regdb=0;
    $tx=sql_user_get_result();
    $regdb=sql_result_db($tx);
    echo("<center><div class='page_table'>");
    echo("<div class='page_table'>");
    $ki=sys_line_local("Feladat");
    echo("<div class='div_a1'><b>$ki</b></div>");
    $ki=sys_line_local("N�v");
    echo("<div class='div_a2'><b>$ki</b></div>");
    $ki=sys_line_local("Teljes n�v");
    echo("<div class='div_a3'><b>$ki, ");
    $ki=sys_line_local("lakc�m, ");
    echo("$ki");
    $ki=sys_line_local("e-mail");
    echo("$ki");
    echo("<br />");
    $ki=sys_line_local("Regisztr�ci�");
    echo("$ki, ");
    $ki=sys_line_local("lej�rat");
    echo("$ki");
    echo("</b></div>");
    echo("</div>");
    $ker=0;
    $db=0;
    while ($db<$regdb){
      $tomb=sql_get_result_data($tx,$db);
      if ($tomb[8]<>$separator){
        $ker++;
      }
      $db++;
    }
    $ki=sys_line_local("Nem k�r");
    $kerlist="";
    site_pageing_init($ker,$tol,$ig,$mess_per_page,$mess_akt_page);
    $db=0;
    $kerx=$tol;
    while ($kerx<$ig){
      $tomb=sql_get_result_data($tx,$db);
      $db+=1;
      if ($tomb[8]<>$separator){
        $kerx++;
        echo("<div class='page_table'>");
        if ($kerlist<>""){
          $kerlist=$kerlist.",".$tomb[7];
        }else{
          $kerlist=$tomb[7];
        }
        sys_env_new($deldata,$tomb[0]);
        $e=sys_env_pack();
        echo("<div class='div_a1'>");
        if ($tomb[3]<>$administrator){
          echo("<a class='href' href='./$s_program?$e'>$ki</a>");
        }else{
          echo("-");
        }
        echo("</div>");
        echo("<div class='div_a2'>$tomb[3]</div>");
        echo("<div class='div_a3'>");
        echo("$tomb[5], ");
        echo("$tomb[6], ");
        echo("$tomb[7]");
        echo("<br />");
        $s=$tomb[0];
        $ki2=sys_time_code_to_date($full_date_format,"$s");
        echo("$ki2, ");
        if ($tomb[2]=="0"){
          $ki2=sys_line_local("nincs lej�rat");
        }else{
          $ki2=sys_line_local("lej�r");
          $t=intval($tomb[1])+intval($tomb[2]);
          $ki2=$ki2.": ".sys_time_code_to_date($full_date_format,$t);
        }
        echo("$ki2");
        echo("</div>");
        sys_env_del($deldata);
      }
    }
    $ki=sys_line_local("�sszesen");
    echo("<br /><br /><div class='div_u'>$ki: $ker.</div>");
    echo("</div></center>");
    site_pageing($ker,$mess_per_page,$mess_akt_page,$messpage);
    if (($ker>0)and($site_admin_email<>"")){
      $e=sys_env_pack();
      $ki=sys_line_local("H�rlev�l k�ld�se");
      echo("<br />");
      echo("<br />");
      echo("<div class='div_address'>$ki</div>");
      echo("<br /><br />");
      echo("<center>");
      echo("<form method='post' action='./$s_program?$e'>");
      echo("<input class='input_r1' type='hidden' id='b0' name='b0' value='$kerlist' />");
      $ki=sys_line_local("H�rlev�l tartalma");
      echo("<div class='div_r1'>$ki:</div>");
      echo("<textarea class='textarea_e1' id='b1' name='b1' cols='70' rows='5'>");
      echo("</textarea>");
      echo("<br />");
      echo("<br />");
      $ki=sys_line_local("Mehet");
      echo("<button class='button_1' type='submit' id='b4' name='b4' value='$ki'>$ki</button>");
      echo("<br />");
      echo("</form>");
    }
  }


?>
