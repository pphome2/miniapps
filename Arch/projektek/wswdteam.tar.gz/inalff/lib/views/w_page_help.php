<?php

  // w_robot --- PHP portalrobot
  // (verzioadatok a konfiguracios fajlban)
  //
  // fejleszto: InalR Fejlesztoi Iroda




  function site_edit_help(){
    global $s_link,$s_img,$s_sys,$s_pos,$s_posp,$l_open,$l_end,
           $s_cent,$s_ecent,$s_nline,$s_line,$s_kgal,
           $s_h,$s_eh,$s_bold,$s_ebold,$s_ita,$s_eita,
           $s_und,$s_eund,$s_par,$s_epar,$s_plugin,
           $plugin_start,$s_menu,$s_submenu,$s_nocomment,
           $s_col,$s_ecol1,$s_ecol,$s_table,$s_etable,
           $s_row,$s_erow,$s_data,$s_edata,$s_language,
           $s_comment,$s_commentrate,$s_mail,
           $s_embed,$s_modul,$s_div,$s_ediv,
           $s_go,$s_ego,
           $dir_site,$default_site,$dir_img,$dir_siteinc;

    echo("<center>");
    echo("<div class='help_h0'>");
    //echo("<br />");
    $ki=sys_line_local("Haszn�lhat� elemek");
    $ki2=sys_line_local("Feladat");
    echo("<div class='div_h1'><b><i>$ki</i></b></div>");
    echo("<div class='div_h2'><b><i>$ki2</i></b></div>");
    echo("<br />");
    $ki=sys_line_local("lap neve");
    $ki2=sys_line_local("saj�t lapra link");
    echo("<div class='div_h1'><b>$l_open$ki$l_end</b></div>");
    echo("<div class='div_h2'>$ki2</div>");
    echo("<br />");
    $ki=sys_line_local("lap neve");
    $ki2=sys_line_local("saj�t lapra link");
    $ki3=sys_line_local("le kell z�rni, k�z�te lehet k�p is");
    echo("<div class='div_h1'><b>$l_open$s_go $ki$l_end</b></div>");
    echo("<div class='div_h2'>$ki2 ($ki3)</div>");
    echo("<br />");
    $ki=sys_line_local("link saj�t lapra lez�r�sa");
    echo("<div class='div_h1'><b>$l_open$s_ego$l_end</b></div>");
    echo("<div class='div_h2'>$ki</div>");
    echo("<br />");
    $ki=sys_line_local("link m�s oldalra");
    $ki2=sys_line_local("lapn�v");
    echo("<div class='div_h1'><b>$l_open$s_link www.xyz.hu $ki2$l_end</b></div>");
    echo("<div class='div_h2'>$ki</div>");
    echo("<br />");
    $ki=sys_line_local("elektronikus lev�l k�ld�se");
    $ki2=sys_line_local("lev�lc�m");
    echo("<div class='div_h1'><b>$l_open$s_mail $ki2$l_end</b></div>");
    echo("<div class='div_h2'>$ki</div>");
    echo("<br />");
    $ki=sys_line_local("k�p besz�r�sa alk�nyvt�rb�l");
    $ki2=sys_line_local("k�p_neve nagy_k�p_neve");
    echo("<div class='div_h1'><b>$l_open$s_img $ki2$l_end</b></div>");
    echo("<div class='div_h2'>$ki ($dir_site/$default_site/$dir_img)</div>");
    echo("<br />");
    $ki=sys_line_local("k�p gal�ria megjelen�t�se alk�nyvt�rb�l");
    $ki2=sys_line_local("alk�nyvt�r_neve");
    echo("<div class='div_h1'><b>$l_open$s_kgal $ki2$l_end</b></div>");
    echo("<div class='div_h2'>$ki ($dir_site/$default_site/$dir_img)</div>");
    echo("<br />");
    $ki=sys_line_local("k�z�pre rendez�s");
    echo("<div class='div_h1'><b>$l_open$s_cent$l_end</b></div>");
    echo("<div class='div_h2'>$ki</div>");
    echo("<br />");
    $ki=sys_line_local("k�z�pre rendez�s v�ge");
    echo("<div class='div_h1'><b>$l_open$s_ecent$l_end</b></div>");
    echo("<div class='div_h2'>$ki</div>");
    echo("<br />");
    $ki=sys_line_local("�j sor (kett� eset�n �res sor)");
    echo("<div class='div_h1'><b>$l_open$s_nline$l_end</b></div>");
    echo("<div class='div_h2'>$ki</div>");
    echo("<br />");
    $ki=sys_line_local("vonal h�z�sa a sz�veg al�");
    echo("<div class='div_h1'><b>$l_open$s_line$l_end</b></div>");
    echo("<div class='div_h2'>$ki</div>");
    echo("<br />");
    $ki=sys_line_local("c�msor (a sz�m 1-5 lehet)");
    $ki2=sys_line_local("sz�m");
    echo("<div class='div_h1'><b>$l_open$s_h $ki2$l_end</b></div>");
    echo("<div class='div_h2'>$ki</div>");
    echo("<br />");
    $ki=sys_line_local("c�msor v�ge");
    echo("<div class='div_h1'><b>$l_open$s_eh$l_end</b></div>");
    echo("<div class='div_h2'>$ki</div>");
    echo("<br />");
    $ki=sys_line_local("vastag�tott bet�s ki�r�s");
    echo("<div class='div_h1'><b>$l_open$s_bold$l_end</b></div>");
    echo("<div class='div_h2'>$ki</div>");
    echo("<br />");
    $ki=sys_line_local("vastag�tott bet�s ki�r�s v�ge");
    echo("<div class='div_h1'><b>$l_open$s_ebold$l_end</b></div>");
    echo("<div class='div_h2'>$ki</div>");
    echo("<br />");
    $ki=sys_line_local("d�lt bet�s ki�r�s");
    echo("<div class='div_h1'><b>$l_open$s_ita$l_end</b></div>");
    echo("<div class='div_h2'>$ki</div>");
    echo("<br />");
    $ki=sys_line_local("d�lt bet�s ki�r�s v�ge");
    echo("<div class='div_h1'><b>$l_open$s_eita$l_end</b></div>");
    echo("<div class='div_h2'>$ki</div>");
    echo("<br />");
    $ki=sys_line_local("al�h�zott bet�s ki�r�s");
    echo("<div class='div_h1'><b>$l_open$s_und$l_end</b></div>");
    echo("<div class='div_h2'>$ki</div>");
    echo("<br />");
    $ki=sys_line_local("al�h�zott bet�s ki�r�s v�ge");
    echo("<div class='div_h1'><b>$l_open$s_eund$l_end</b></div>");
    echo("<div class='div_h2'>$ki</div>");
    echo("<br />");
    $ki=sys_line_local("bekezd�s kezd�se");
    echo("<div class='div_h1'><b>$l_open$s_par$l_end</b></div>");
    echo("<div class='div_h2'>$ki</div>");
    echo("<br />");
    $ki=sys_line_local("bekezd�s v�ge");
    echo("<div class='div_h1'><b>$l_open$s_epar$l_end</b></div>");
    echo("<div class='div_h2'>$ki</div>");
    echo("<br />");
    $ki=sys_line_local("t�bb oszlopos �r�s - sz�m: ennyi oszlop lesz");
    $ki2=sys_line_local("sz�m");
    echo("<div class='div_h1'><b>$l_open$s_ecol $ki2$l_end</b></div>");
    echo("<div class='div_h2'>$ki</div>");
    echo("<br />");
    $ki=sys_line_local("egy oszlop v�ge");
    echo("<div class='div_h1'><b>$l_open$s_ecol1$l_end</b></div>");
    echo("<div class='div_h2'>$ki</div>");
    echo("<br />");
    $ki=sys_line_local("t�bb oszlopos �r�s v�ge");
    echo("<div class='div_h1'><b>$l_open$s_ecol$l_end</b></div>");
    echo("<div class='div_h2'>$ki</div>");
    echo("<br />");
    $ki=sys_line_local("t�bl�zat kezdete");
    echo("<div class='div_h1'><b>$l_open$s_table$l_end</b></div>");
    echo("<div class='div_h2'>$ki</div>");
    echo("<br />");
    $ki=sys_line_local("t�bl�zat v�ge");
    echo("<div class='div_h1'><b>$l_open$s_etable</b></div>");
    echo("<div class='div_h2'>$ki</div>");
    echo("<br />");
    $ki=sys_line_local("t�bl�zat sor�nak kezdete");
    echo("<div class='div_h1'><b>$l_open$s_row$l_end</b></div>");
    echo("<div class='div_h2'>$ki</div>");
    echo("<br />");
    $ki=sys_line_local("t�bl�zat sor�nak v�ge");
    echo("<div class='div_h1'><b>$l_open$s_erow$l_end</b></div>");
    echo("<div class='div_h2'>$ki</div>");
    echo("<br />");
    $ki=sys_line_local("t�bl�zat sor�ban egy adat kezdete");
    echo("<div class='div_h1'><b>$l_open$s_data$l_end</b></div>");
    echo("<div class='div_h2'>$ki</div>");
    echo("<br />");
    $ki=sys_line_local("t�bl�zatban sor�ban egy adat v�ge");
    echo("<div class='div_h1'><b>$l_open$s_edata$l_end</b></div>");
    echo("<div class='div_h2'>$ki</div>");
    echo("<br />");
    $ki=sys_line_local("men�");
    $ki2=sys_line_local("men�pont neve");
    echo("<div class='div_h1'><b>$l_open$s_menu $ki2$l_end</b></div>");
    echo("<div class='div_h2'>$ki</div>");
    echo("<br />");
    $ki=sys_line_local("almen�");
    $ki2=sys_line_local("almen� neve");
    echo("<div class='div_h1'><b>$l_open$s_submenu $ki2$l_end</b></div>");
    echo("<div class='div_h2'>$ki</div>");
    echo("<br />");
    $ki=sys_line_local("plugin ind�t�sa");
    $ki2=sys_line_local("pl-k�nyvt�r pl-file pl-fg param�terek");
    $ki3=sys_line_local("pl-k�nyvt�r/pl-file.php f�jlb�l a plugin-fg ind�t�sa");
    echo("<div class='div_h1'><b>$l_open$s_plugin $ki2$l_end</b></div>");
    echo("<div class='div_h2'>$ki ($ki3)</div>");
    echo("<br />");
    $ki=sys_line_local("beillesztett elem (pl.: video)");
    $ki2=sys_line_local("f�jln�v");
    $ki3=sys_line_local("HTML k�df�jl");
    echo("<div class='div_h1'><b>$l_open$s_embed $ki2$l_end</b></div>");
    echo("<div class='div_h2'>$ki - $ki3 ($dir_site/$default_site/$dir_siteinc -b�l)</div>");
    echo("<br />");
    $ki=sys_line_local("beillesztett elem (pl.: flash modul)");
    $ki2=sys_line_local("c�m sz�less�g magass�g");
    $ki3=sys_line_local("modul c�me");
    echo("<div class='div_h1'><b>$l_open$s_modul $ki2$l_end</b></div>");
    echo("<div class='div_h2'>$ki (http://... 200 150)</div>");
    echo("<br />");
    $ki=sys_line_local("saj�t form�z�s (div) ind�t�sa");
    $ki2=sys_line_local("class-n�v");
    echo("<div class='div_h1'><b>$l_open$s_div $ki2$l_end</b></div>");
    echo("<div class='div_h2'>$ki</div>");
    $ki=sys_line_local("saj�t form�z�s lez�r�sa");
    echo("<div class='div_h1'><b>$l_open$s_ediv$l_end</b></div>");
    echo("<div class='div_h2'>$ki</div>");
    $ki=sys_line_local("nyelv v�laszt�s");
    $ki2=sys_line_local("param�ter (pl.: hu)");
    echo("<div class='div_h1'><b>$l_open$s_language $ki2$l_end</b></div>");
    echo("<div class='div_h2'>$ki</div>");
    echo("<br />");
    $ki=sys_line_local("hozz�sz�l�s a laphoz nem enged�lyezett");
    echo("<div class='div_h1'><b>$l_open$s_nocomment$l_end</b></div>");
    echo("<div class='div_h2'>$ki</div>");
    echo("<br />");
    $ki=sys_line_local("hozz�sz�l�s enged�lyezett");
    echo("<div class='div_h1'><b>$l_open$s_comment$l_end</b></div>");
    echo("<div class='div_h2'>$ki</div>");
    echo("<br />");
    $ki=sys_line_local("hozz�sz�l�s a laphoz enged�lyezett, pontoz�ssal");
    echo("<div class='div_h1'><b>$l_open$s_commentrate$l_end</b></div>");
    echo("<div class='div_h2'>$ki</div>");
    echo("</div></center>");
  }


?>
