<?php

  // w_robot --- PHP portalrobot
  // (verzioadatok a konfiguracios fajlban)
  //
  // fejleszto: InalR Fejlesztoi Iroda




  // galeria

  function site_gallery_list(){
    global $sitepos,$default_site,$dir_site,$dir_img,
           $sitepage,$k_gallery,$s_program,$dirpos;

    $p=sys_env_find($sitepos);
    $a=sys_env_find($sitepage);
    $dir=$dir_site."/".$default_site."/".$dir_img;
    sys_dir_list($dir,$t);
    sort($t);
    $c=count($t);
    $dirt=array();
    $dirtdb=array();
    $ddb=0;
    if ($c>0){
      $l=0;
      while ($l<$c){
        $t2=array();
        $d2=$dir."/".$t[$l];
        sys_dir_list($d2,$t2);
        $cc=count($t2);
        if ($cc>0){
          $dirt[$ddb]=$t[$l];
          $dirtdb[$ddb]=$cc;
          $ddb++;
        }
        $l++;
      }
      $c=count($dirt);
      if ($c>0){
        //sort($dirt);
        $ki=sys_line_local("K�pt�r (gal�ri�k)");
        echo("<div class='page_table'>");
        echo("<div class='div_address'>$ki</div>");
        echo("<br />");
        echo("<br />");
        echo("<center><div class='page_table'>");
        $ki=sys_line_local("Tartalom");
        echo("<div class='div_a1'>-</div>");
        echo("<div class='div_a2'><b>$ki</b></div>");
        $ki=sys_line_local("K�pt�r neve");
        echo("<div class='div_a3'><b>$ki</b></div>");
        echo("</div>");
        $ki0=sys_line_local("k�p a k�pt�rban");
        $db=0;
        while ($db<$c){
          sys_env_new($sitepage,$k_gallery);
          sys_env_new($dirpos,$dirt[$db]);
          $e=sys_env_pack();
          $kdb=$db+1;
          echo("<div class='page_table'>");
          echo("<div class='div_a1'>$kdb.</div>");
          echo("<div class='div_a2'>");
          echo("$dirtdb[$db] $ki0");
          echo("</div>");
          echo("<div class='div_a3'>");
          echo("<a class='href' href='./$s_program?$e'>$dirt[$db]</a>");
          echo("</div>");
          echo("</div>");
          $db++;
        }
        $ki=sys_line_local("�sszesen");
        //echo("<br /><br /><div class='div_u'>$ki: $c.</div>");
        echo("</div></center><br />");
      }else{
        $ki=sys_line_local("K�pt�r nincs felt�ltve");
        echo("$ki.");
        echo("<br /><br />");
        echo("<br /><br />");
      }
    }else{
      $ki=sys_line_local("K�pt�r nem el�rhet�");
      echo("$ki.");
      echo("<br /><br />");
      echo("<br /><br />");
    }
    sys_env_del($dirpos);
    sys_env_new($sitepage,$a);
    sys_env_new($sitepos,$p);
  }


  // galeria

  function site_gallery(){
    global $sitepos,$default_site,$dir_site,$dir_img,
           $sitepage,$k_gallery,$list_img_ext,$text_ext,
           $mess_per_page,$mess_akt_page,$messpage,
           $separator4,$dirpos,$dirdata;

    $dirx=$dirdata;
    $dir=$dir_site."/".$default_site."/".$dir_img."/".$dirx;
    sys_dir_list($dir,$t);
    $oktxt=false;
    $c=count($t);
    if ($c>0){
      $l=0;
      while ($l<$c){
        $ext=substr($t[$l],strlen($t[$l])-4,4);
        if ($ext==$text_ext){
          $f=$dir."/".$t[$l];
          if (file_exists($f)){
            sys_file_in($f,$txt);
            $oktxt=true;
          }
        }
        if (!in_array($ext,$list_img_ext)){
          unset($t[$l]);
        }
        $l++;
      }
      sort($t);
      $c=count($t);
      $kk=explode("/",$dir);
      $kepg=$kk[count($kk)-1];
      $ki=sys_line_local("K�p gal�ria");
      echo("<div class='div_address'>$ki ($kepg)</div>");
      echo("<center><br /><br />");
      if ($mess_akt_page==0){
        $mess_akt_page=1;
      }
      $i=$t[$mess_akt_page-1];
      $sor="";
      if ($oktxt){
        $v=0;
        $n=count($txt);
        $sor="";
        while (($v<$n)and($sor=="")){
          $e=substr($txt[$v],0,strlen($i));
          if ($i==$e){
            $sor=substr($txt[$v],strlen($i)+1,strlen($txt[$v]));
          }
          $v++;
        }
      }
      $i=$dir."/".$i;
      echo("<img class='imgclass3' src=$i value='hely' />");
      if ($sor<>""){
        echo("<br /><br />");
        echo("<div class='div_u2'>$sor</div>");
      }
      echo("</center><br /><br />");
    }else{
      $ki=sys_line_local("K�pek nem el�rhet�k");
      echo("$ki.");
      echo("<br /><br />");
      echo("</center><br /><br />");
    }
    $pm=sys_env_find($sitepage);
    sys_env_new($sitepage,$k_gallery);
    sys_env_new($dirpos,$dirx);
    site_pageing($c,1,$mess_akt_page,$messpage);
    sys_env_del($dirpos);
    sys_env_new($sitepage,$pm);
  }

  // segitseg

  function site_help(){
    global $sitepos,$default_site,$lang_system,
           $dir_site,$help_file;

    $file=$dir_site."/".$default_site."/".$help_file.$lang_system;
    if (file_exists($file)){
      $ki=sys_line_local("A rendszer le�r�sa");
      echo("<div class='div_address'>$ki</div>");
      echo("<br /><br />");
      sys_file_in($file,$t);
      $c=count($t);
      $x=0;
      while ($x<$c){
        echo("$t[$x]<br />");
        $x++;
      }
      echo("</center><br /><br />");
    }else{
      $ki=sys_line_local("Le�r�s nem el�rhet�");
      echo("$ki.");
      echo("<br /><br />");
      echo("</center><br /><br />");
    }
  }

  // egy kep kirajzolasa konyvtarbol

  function site_bigpic(){
    global $sitepos,$default_site,
           $dirpos,$dirdata,$sitepage,
           $dir_site,$default_site,$dir_img,
           $dir_file,$s_program,$imgdata,
           $separator5;

    $t=explode($separator5,$dirdata);
    if (count($t)<2){
      $t[0]=$dirdata;
      $t[1]="";
    }
    $lap=$imgdata;
    if (substr($lap,0,2)<>".."){
      $lap="$dir_site/$default_site/$dir_img/$lap";
    }
    $ki=sys_line_local("Nagyitott k�p");
    echo("<div class='div_address'>$ki</div>");
    echo("<br /><br />");
    echo("<br /><center>");
    echo("<img class='imgclass' src=$lap value='hely' />");
    echo("<br /><br />");
    $ki=sys_line_local("Vissza az el�z� feladathoz");
    sys_env_new($dirpos,$t[0]);
    sys_env_new($sitepage,$t[1]);
    $e=sys_env_pack();
    sys_env_del($dirpos);
    sys_env_del($sitepage);
    echo("<a class='href' href='./$s_program?$e'>$ki</a>");
    echo("</center><br /><br />");
  }

  // egy kep kirajzolasa laprol 

  function site_bigimg(){
    global $sitepos,$default_site,$dirdata,
           $dir_site,$default_site,$dir_img,
           $dir_file,$sitepage,$s_program,
           $imgdata;

    sys_env_del($sitepage);
    $lap="$dir_site/$default_site/$dir_img/$imgdata";
    $ki=sys_line_local("Nagyitott k�p");
    echo("<div class='div_address'>$ki</div>");
    echo("<br /><br />");
    echo("<br /><center>");
    echo("<img class='imgclass' src=$lap value='' />");
    echo("<br /><br />");
    $ki=sys_line_local("Vissza a cikkhez");
    $e=sys_env_pack();
    echo("<a class='href' href='./$s_program?$e'>$ki</a>");
    echo("</center><br /><br />");
  }

  // laptortenet kiirasa

  function site_history_line(){
    global $sitepos,$default_site,$article_history,
           $separator,$hist_db;

    $lap=sys_env_find($sitepos);
    if (($lap=="")or(substr($lap,0,2)=="..")){
      $lap=$default_site;
    }
    $ki=sys_line_local("A lap t�rt�nete");
    echo("<div class='div_address'>$ki</div>");
    echo("<br />");
    $ki=sys_line_local("az utols� $hist_db m�dos�t�s adatai");
    echo("(<i>$lap</i>: $ki.)<br /><br />");
    $k1=sys_line_local("Felhaszn�l� neve");
    $k2=sys_line_local("D�tum");
    $k3=sys_line_local("Id�");
    echo("<center>");
    $name="$lap";
    site_in($name);
    $x=0;
    $h=explode($separator,$article_history[0]); 
    $y=count($h);
    $out=0;
    while ($x<$y) {
      if ($h[$x]<>""){
        echo("<div class='page_table'>");
        $h2=explode(" ",$h[$x]);
        echo("<div class='div_a1'>");
        $x2=$x+1;
        echo("$x2");
        echo("</div>");
        echo("<div class='div_a2'>");
        echo("$h2[0] $h2[1]");
        echo("</div>");
        echo("<div class='div_a3'>");
        echo("$h2[2] ");
        echo("</div>");
        echo("<br />");
        echo("</div>");
        $out++;
      }
      $x+=1;
    }
    echo("<div class='page_table'>");
    $ki1=sys_line_local("Megjelen�tve");
    echo("<div class='div_stat'>");
    echo("<br />$ki1: $out.<br />");
    echo("</div>");
    echo("</div>");
    echo("</center>");
    echo("<div class='div_hidden'><br /></div>");
    sys_env_new($sitepos,$lap);
  }


  // site lapok szerkesztese

  function site_edit(){
    global $sitepos,$usercode,$editor,$default_site,
           $article_text,$article_brief,$article_category,
           $enable_edit,$enable_reg_edit,$user_admin;

    $lap=sys_env_find($sitepos);
    $name="$lap";
    if (($enable_edit)or
       (($$enable_reg_edit)and(sys_env_find($usercode)<>""))or
       ($user_admin)){
      site_in($name);
      $ok=sys_data_post($db,$dk,$de);
      if ($ok){
        $article_brief[0]=strip_tags($de[0]);
        $article_text[0]=strip_tags($de[1]);
        $article_category=strip_tags($de[2]);
        site_out($name);
      }
      $editor=true;
      if (substr($lap,0,2)==".."){
        sys_env_new($sitepos,$default_site);
      }
      site_page_out();
      site_page_edit();
    }
  }

?>
