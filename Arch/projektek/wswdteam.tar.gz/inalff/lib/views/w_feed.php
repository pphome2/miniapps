<?php

  // w_robot --- PHP portalrobot
  // (verzioadatok a konfiguracios fajlban)
  //
  // fejleszto: InalR Fejlesztoi Iroda




  // feed (rss-atom) megvalositasa

  function feed_out(){
    global $atom;

    if ($atom){
      atom_out();
    }else{
      rss_out();
    }
  }


  function rss_out(){
    global $sitepos,$default_site,$s_program,$sitepage,
           $printed,$editor,$usercode,
           $s_full_program,$s_full_path,$dir_site,$lang_system,
           $l_open,$l_end,$plugin_start,
           $dir_img,$site_logo,$feed_out_db,$description;

    echo('<?xml version="1.0" encoding="ISO-8859-2" ?>');
    echo('<!DOCTYPE rss PUBLIC "-//Netscape Communications//DTD RSS 0.91//EN" ');
    echo('"http://my.netscape.com/publish/formats/rss-0.91.dtd">');
    echo("\n");
    echo('<rss version="2.0">');
    echo("\n");
    sys_env_del($usercode);
    $lap=sys_env_find($sitepos);
    if ($lap==""){
      $lap=$default_site;
    }
    $tx=sql_article_cat_get_result($lap);
    $db=sql_result_db($tx);
    if ($feed_out_db>$db){
      $ig=$db;
    }else{
      $ig=$feed_out_db;
    }
    echo("<channel>");
    echo("\n");
    echo("  <title>$default_site</title>");
    echo("\n");
    echo("  <link>$s_full_program?site=$default_site</link>");
    echo("\n");
    echo("  <description>$description</description>");
    echo("\n");
    echo("  <language>$lang_system</language>");
    echo("\n");
    $d=date('D, d M Y G:i:s O');
    echo("  <pubDate>$d</pubDate>");
    echo("\n");
    echo("  <image>");
    echo("\n");
    echo("    <title>$default_site</title>");
    echo("\n");
    echo(  "  <link>$s_full_program?site=$default_site</link>");
    echo("\n");
    echo("  </image>");
    echo("\n");
    $a=0;
    while ($a<$ig) {
      $txx=sql_get_result_data($tx,$a);
      $s=$txx[5];
      $sx="";
      $v0=0;
      $vve=strlen($s);
      while ($v0<$vve){
        if (substr($s,$v0,1)==$l_open){
          $v1=$v0+1;
          while (($v1<strlen($s))and(substr($s,$v1,1)<>$l_end)){
            $v1+=1;
          }
          if (substr($s,$v1,1)==$l_end){
            $s2=substr($s,$v0+1,$v1-$v0-1);
            $la=site_lang($s2);
            if (!$plugin_start){
              $s=substr($s,0,$v0).$la.substr($s,$v1+1,strlen($s));
              $vve=strlen($s);
            }else{
              $s=="";
              $v0=$vve;
            }
          }
        }
        $v0+=1;
      }
      echo("  <item>");
      echo("\n");
      echo("    <title>$txx[1]</title>");
      echo("\n");
      $fn=$txx[1];
      sys_env_new($sitepos,$fn);
      $e=sys_env_pack();
      echo("    <link>$s_full_program?$e</link>");
      echo("\n");
      echo("    <description>");
      echo("\n");
      //$s=strip_tags($s);
      echo("    $s");
      echo("    </description>");
      echo("\n");
      echo("    <pubDate>$txx[2]</pubDate>");
      echo("\n");
      //ho("<dc:creator>$txx[3]</dc:creator>");
      echo("  </item>");
      echo("\n");
      $a++;
    }
    echo("</channel>");
    echo("</rss>");
  }


  function atom_out(){
    global $sitepos,$default_site,$s_program,$sitepage,
           $printed,$editor,$usercode,
           $s_full_program,$s_full_path,$dir_site,$lang_system,
           $l_open,$l_end,$plugin_start,
           $dir_img,$site_logo,$feed_out_db,$description;

    sys_env_del($usercode);
    $lap=sys_env_find($sitepos);
    if ($lap==""){
      $lap=$default_site;
    }
    $tx=sql_article_cat_get_result($lap);
    $db=sql_result_db($tx);
    if ($feed_out_db>$db){
      $ig=$db;
    }else{
      $ig=$feed_out_db;
    }
    $d=date('c');
    echo('<?xml version="1.0" encoding="ISO-8859-2"?>');
    echo("\n");
    echo('<feed xmlns="http://www.w3.org/2005/Atom">');
    echo("\n");
    echo("  <title>$default_site</title>");
    echo("\n");
    echo('  <link rel="self" href="');
    echo("$s_full_program");
    echo('"/>');
    echo("\n");
    echo("  <updated>$d</updated>");
    echo("\n");
    echo("  <id>$s_full_program</id>");
    echo("\n");
    echo("  <author><name>Admin</name></author>");
    echo("\n");
    $k="$s_full_path".substr($dir_site,3,strlen($dir_site)-3)."/$default_site/$dir_img/$site_logo";
    echo("  <logo>$k</logo>");
    echo("\n");
    $a=0;
    while ($a<$ig) {
      $txx=sql_get_result_data($tx,$a);
      $s=$txx[5];
      $sx="";
      $v0=0;
      $vve=strlen($s);
      while ($v0<$vve){
        if (substr($s,$v0,1)==$l_open){
          $v1=$v0+1;
          while (($v1<strlen($s))and(substr($s,$v1,1)<>$l_end)){
            $v1+=1;
          }
          if (substr($s,$v1,1)==$l_end){
            $s2=substr($s,$v0+1,$v1-$v0-1);
            $la=site_lang($s2);
            if (!$plugin_start){
              $s=substr($s,0,$v0).$la.substr($s,$v1+1,strlen($s));
              $vve=strlen($s);
            }else{
              $s=="";
              $v0=$vve;
            }
          }
        }
        $v0+=1;
      }
      echo("  <entry>");
      echo("\n");
      echo("    <title>$txx[1]</title>");
      echo("\n");
      $fn=$txx[1];
      sys_env_new($sitepos,$fn);
      $e=sys_env_pack();
      echo('    <link href="');
      echo("$s_full_program?$e");
      echo('" />');
      echo("\n");
      echo("    <id>$s_full_program?$e</id>");
      //echo("    <id>$txx[0]</id>");
      echo("\n");
      $d=sys_time_code_to_date('c',$txx[0]);
      echo("    <updated>$d</updated>");
      echo("\n");
      echo("    <author><name>$txx[3]</name></author>");
      echo("\n");
      echo('    <content type="text/html">');
      //echo("\n");
      echo("$s");
      //echo("\n");
      echo('    </content>');
      echo("\n");
      echo("  </entry>");
      echo("\n");
      $a++;
    }
    echo("</feed>");
  }

?>
