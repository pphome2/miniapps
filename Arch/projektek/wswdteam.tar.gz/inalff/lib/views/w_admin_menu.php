<?php

  // w_robot --- PHP portalrobot
  // (verzioadatok a konfiguracios fajlban)
  //
  // fejleszto: InalR Fejlesztoi Iroda


  function site_admin_menu(){
    global $sitepage,$user_admin,$usercode,
           $s_program,$sitepos,$dir_data,
           $k_admin_1,$k_admin_2,$k_admin_3,
           $k_admin_4,$k_admin_5,$k_admin_6,
           $k_admin_7,$k_admin_8,$k_admin_9,
           $k_install,$menu,
           $dir_site,$default_site,$k_edit,
           $admin_menu_plus,
           $enable_new_reg,$k_regist;

    $m=sys_env_find($sitepage);
    $p=sys_env_find($sitepos);
    $sp=$menu;
    if ($user_admin){
      if ($sp==$k_edit){
        $href="menuahref";
      }else{
        $href="menuhref";
      }
      sys_env_new($sitepage,$k_edit);
      $e=sys_env_pack();
      $ki=sys_line_local("Szerkeszt�s");
      echo("<a class=$href href='./$s_program?$e'>$ki</a><br />");
      if ($sp==$k_admin_9){
        $href="menuahref";
      }else{
        $href="menuhref";
      }
      sys_env_new($sitepage,$k_admin_9);
      $e=sys_env_pack();
      $k=sys_line_local("Ment�s, vissza�ll�t�s");
      echo("<a class=$href href='./$s_program?$e'>$k</a><br />");
      if ($sp==$k_regist){
        $href="menuahref";
      }else{
        $href="menuhref";
      }
      sys_env_new($sitepage,$k_regist);
      $e=sys_env_pack();
      $k=sys_line_local("�j felhaszn�l�");
      echo("<a class=$href href='./$s_program?$e'>$k</a><br />");
      if ($sp==$k_admin_1){
        $href="menuahref";
      }else{
        $href="menuhref";
      }
      sys_env_new($sitepage,$k_admin_1);
      $e=sys_env_pack();
      $k=sys_line_local("Felhaszn�l�k");
      echo("<a class=$href href='./$s_program?$e'>$k</a><br />");
      if ($sp==$k_admin_8){
        $href="menuahref";
      }else{
        $href="menuhref";
      }
      sys_env_new($sitepage,$k_admin_8);
      $e=sys_env_pack();
      $k=sys_line_local("Kateg�ria");
      echo("<a class=$href href='./$s_program?$e'>$k</a><br />");
      if ($sp==$k_admin_2){
        $href="menuahref";
      }else{
        $href="menuhref";
      }
      sys_env_new($sitepage,$k_admin_2);
      $e=sys_env_pack();
      $k=sys_line_local("Adatt�r");
      echo("<a class=$href href='./$s_program?$e'>$k</a><br />");
      if ($sp==$k_admin_3){
        $href="menuahref";
      }else{
        $href="menuhref";
      }
      sys_env_new($sitepage,$k_admin_3);
      $e=sys_env_pack();
      $k=sys_line_local("K�pt�r");
      echo("<a class=$href href='./$s_program?$e'>$k</a><br />");
      if ($sp==$k_admin_4){
        $href="menuahref";
      }else{
        $href="menuhref";
      }
      sys_env_new($sitepage,$k_admin_4);
      $e=sys_env_pack();
      $k=sys_line_local("K�nyvt�r");
      echo("<a class=$href href='./$s_program?$e'>$k</a><br />");
      if ($sp==$k_admin_5){
        $href="menuahref";
      }else{
        $href="menuhref";
      }
      sys_env_new($sitepage,$k_admin_5);
      $e=sys_env_pack();
      $k=sys_line_local("H�rlevelet k�r�k");
      echo("<a class=$href href='./$s_program?$e'>$k</a><br />");
      if ($sp==$k_admin_6){
        $href="menuahref";
      }else{
        $href="menuhref";
      }
      sys_env_new($sitepage,$k_admin_6);
      $e=sys_env_pack();
      $k=sys_line_local("Be�ll�t�sok");
      echo("<a class=$href href='./$s_program?$e'>$k</a><br />");
      if ($sp==$k_install){
        $href="menuahref";
      }else{
        $href="menuhref";
      }
      sys_env_new($sitepage,$k_install);
      $e=sys_env_pack();
      $k=sys_line_local("Telep�t�");
      echo("<a class=$href href='./$s_program?$e'>$k</a><br />");
      $x=0;
      $y=count($admin_menu_plus);
      if ($y>0){
        echo("<br />");
        sys_env_del($sitepage);
        while ($x<$y){
          if ($sp==$admin_menu_plus[$x]){
            $href="menuahref";
          }else{
            $href="menuhref";
          }
          $k=$admin_menu_plus[$x];
          sys_env_new($sitepos,$k);
          $e=sys_env_pack();
          echo("<a class=$href href='./$s_program?$e'>$admin_menu_plus[$x]</a><br />");
          $x+=1;
        }
      }
    }else{
    }
    sys_env_new($sitepage,$m);
    sys_env_new($sitepos,$p);
  }


?>
