<?php

  // w_robot --- PHP portalrobot
  // (verzioadatok a konfiguracios fajlban)
  //
  // fejleszto: InalR Fejlesztoi Iroda



  // Menu kiirasa

  function site_page_menu(){
    global $sitepage,$k_edit,$s_program,$sitepos,$k_login,
           $k_history,$k_print,$k_alist,$k_files,$usercode,
           $enable_view,$enable_edit,$enable_history,
           $enable_print,$enable_alist,$wiki_style,
           $enable_reg_edit,$enable_files,$user_admin,
           $k_search,$enable_search,$plugin_start,
           $enable_login,$enable_help,$k_help,
           $enable_image_gallery,$k_gallery_list,
           $enable_reg_edit,$enable_search,$menu;

    $u=sys_env_find($sitepage);
    sys_env_del($sitepage);
    if ($wiki_style){
      echo("<div class='div_menu1'>");
      $jel=" - ";
    }else{
      $jel="";
    }
    $unev=sys_env_find($usercode);
    if (($enable_reg_edit)and($unev!=="")){
      $enable_edit=true;
    }else{
      $enable_edit=false;
    }
    //
    if ($user_admin){  
      $enable_view=true;
      $enable_edit=true;
      $enable_reg_edit=false;
      $enable_search=true;
      $enable_view=true;
      $enable_history=true;
      $enable_print=true;
      $enable_dir=true;
      $enable_files=true;
      $enable_alist=true;
      $enable_help=true;
      $enable_image_gallery=true;
    }
    $elso=true;
    if (($enable_login)and($unev=="")){
      if (!$elso){
        echo($jel);
      }else{
        $elso=false;
      }
      $ki=sys_line_local("Bejelentkez�s");
      sys_env_new($sitepage,$k_login);
      $e=sys_env_pack();
      if ($menu==$k_login){
        $href="menuahref";
      }else{
        $href="menuhref";
      }
      echo("<a class=$href href='./$s_program?$e'>$ki</a>");
      if (!$wiki_style){
        echo("<br />");
      }
    }
    if (($enable_view)and(!$plugin_start)){
      if (!$elso){
        echo($jel);
      }else{
        $elso=false;
      }
      $ki=sys_line_local("N�z");
      sys_env_del($sitepage);
      $e=sys_env_pack();
      if ($menu==""){
        $href="menuahref";
      }else{
        $href="menuhref";
      }
      echo("<a class=$href href='./$s_program?$e'>$ki</a>");
      if (!$wiki_style){
        echo("<br />");
      }
    }
    if (($enable_edit)and(!$plugin_start)){
      if (!$elso){
        echo($jel);
      }else{
        $elso=false;
      }
      $ki=sys_line_local("Szerkeszt");
      sys_env_new($sitepage,$k_edit);
      $e=sys_env_pack();
      if ($menu==$k_edit){
        $href="menuahref";
      }else{
        $href="menuhref";
      }
      echo("<a class=$href href='./$s_program?$e'>$ki</a>");
      if (!$wiki_style){
        echo("<br />");
      }
    }
    if (($enable_history)and(!$plugin_start)){
      if (!$elso){
        echo($jel);
      }else{
        $elso=false;
      }
      $ki=sys_line_local("T�rt�net");
      sys_env_new($sitepage,$k_history);
      $e=sys_env_pack();
      if ($menu==$k_history){
        $href="menuahref";
      }else{
        $href="menuhref";
      }
      echo("<a class=$href href='./$s_program?$e'>$ki</a>");
      if (!$wiki_style){
        echo("<br />");
      }
    }
    if (($enable_print)and(!$plugin_start)){
      if (!$elso){
        echo($jel);
      }else{
        $elso=false;
      }
      $ki=sys_line_local("Nyomtat�s");
      sys_env_new($sitepage,$k_print);
      $e=sys_env_pack();
      if ($menu==$k_print){
        $href="menuahref";
      }else{
        $href="menuhref";
      }
      echo("<a class=$href href='./$s_program?$e'>$ki</a>");
      if (!$wiki_style){
        echo("<br />");
      }
    }
    if ($enable_alist){
      if (!$elso){
        echo($jel);
      }else{
        $elso=false;
      }
      $ki=sys_line_local("�r�sok");
      sys_env_new($sitepage,$k_alist);
      $e=sys_env_pack();
      if ($menu==$k_alist){
        $href="menuahref";
      }else{
        $href="menuhref";
      }
      echo("<a class=$href href='./$s_program?$e'>$ki</a>");
      if (!$wiki_style){
        echo("<br />");
      }
    }
    if ($enable_image_gallery){
      if (!$elso){
        echo($jel);
      }else{
        $elso=false;
      }
      $ki=sys_line_local("K�pt�r");
      sys_env_new($sitepage,$k_gallery_list);
      $e=sys_env_pack();
      if ($menu==$k_gallery_list){
        $href="menuahref";
      }else{
        $href="menuhref";
      }
      echo("<a class=$href href='./$s_program?$e'>$ki</a>");
      if (!$wiki_style){
        echo("<br />");
      }
    }
    if ($enable_files){
      if (!$elso){
        echo($jel);
      }else{
        $elso=false;
      }
      $ki=sys_line_local("Let�lt�sek");
      sys_env_new($sitepage,$k_files);
      $e=sys_env_pack();
      if ($menu==$k_files){
        $href="menuahref";
      }else{
        $href="menuhref";
      }
      echo("<a class=$href href='./$s_program?$e'>$ki</a>");
      if (!$wiki_style){
        echo("<br />");
      }
    }
    if ($enable_search){
      if (!$elso){
        echo($jel);
      }else{
        $elso=false;
      }
      $ki=sys_line_local("Keres�s");
      sys_env_new($sitepage,$k_search);
      $e=sys_env_pack();
      if ($menu==$k_search){
        $href="menuahref";
      }else{
        $href="menuhref";
      }
      echo("<a class=$href href='./$s_program?$e'>$ki</a>");
      if (!$wiki_style){
        echo("<br />");
      }
    }
    if ($enable_help){
      if (!$elso){
        echo($jel);
      }else{
        $elso=false;
      }
      $ki=sys_line_local("Seg�ts�g");
      sys_env_new($sitepage,$k_help);
      $e=sys_env_pack();
      if ($menu==$k_help){
        $href="menuahref";
      }else{
        $href="menuhref";
      }
      echo("<a class=$href href='./$s_program?$e'>$ki</a>");
      if (!$wiki_style){
        echo("<br />");
      }
    }
    if ($wiki_style){
      echo("</div>");
    }
    if ($u==""){
      sys_env_del($sitepage);
    }else{
      sys_env_new($sitepage,$u);
    }
  }


?>
