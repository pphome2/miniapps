<?php

  // w_robot --- PHP portalrobot
  // (verzioadatok a konfiguracios fajlban)
  //
  // fejleszto: InalR Fejlesztoi Iroda




  // uzenofal megvalositasa

  function site_comment($fn,$mcim){
    global $separator,$guest_user,$user_admin,
           $messpage,$mess_per_page,$mess_akt_page,
           $site_data_css_container,$sitepage,
           $usercode,$administrator,$full_date_format,
           $comment_rate,$deldata,$delkod,$s_program;

    $uc=sys_env_find($usercode);
    site_comment_new("");
    if ($delkod<>""){
      sql_comment_del($delkod);
    }
    $ok=sys_data_post($dbx,$tkx,$tex);
    if ($ok){
      if (strip_tags($tex[0])<>""){
        $ido=date($full_date_format);
        $n=site_user("");
        if ($n=="") {
          $n=$guest_user;
        }
        $ti=sys_time_code();
        if ($dbx<1){
          $pont=0;
        }else{
          $pont=$tex[1];
        }
        sql_comment_add($ti,$fn,$ido,$n,$pont,$tex[0]);
      }
    }
    $db=0;
    $tx=sql_comment_get_result($fn);
    $db=sql_result_db($tx);
    if ($site_data_css_container<>""){
      echo("<div class='div_p'></div>");
      echo("</div><div class='$site_data_css_container'>");
    }else{
      echo("<hr class='hrcl' />");
    }
    if ($mcim<>""){
      echo("<br /><b />$mcim.</b><br />");
    }
    if ($db==0){
      $ki=sys_line_local("M�g nem �rkezett hozz�sz�l�s");
      echo("<br /><b />$ki.</b><br /><br />");
    }else{
      $ki1=sys_line_local("hozz�sz�l�s");
      $ki2=sys_line_local("�tlagosan");
      $ki3=sys_line_local("pont");
      $ki4=sys_line_local("T�r�l");
      if ($comment_rate){
        $x=0;
        $opont=0;
        while ($x<$db){
          $txx=sql_get_result_data($tx,$x);
          $opont=$opont+intval($txx[4]);
          $x++;
        }
        if ($opont>0){
          $apont=$opont/$db;
        }else{
          $apont=0;
        }
        $apont=round($apont,1);
        echo("<br /><div class='div_address'>$db $ki1,  $ki2 $apont $ki3</div>");
        echo("<br />");
      }
      echo("<br />");
      site_pageing_init($db,$tol,$ig,$mess_per_page,$mess_akt_page);
      $x=0;
      $out=0;
      while ($x<=($mess_per_page-1)){
        $kdb=$tol+$x;
        $txx=sql_get_result_data($tx,$kdb);
        if ((count($txx)>0)and($txx[5]<>"")){
          echo("<div class='page_table'>");
          if ($user_admin){
            sys_env_new($deldata,$txx[0]);
            sys_env_new($messpage,$mess_akt_page);
            $e=sys_env_pack();
            sys_env_del($messpage);
            sys_env_del($deldata);
            echo("<div class='div_a1'>");
            echo("<a class='href' href='./$s_program?$e'>$ki4</a>");
            echo("</div>");
          }else{
            echo("<div class='div_a1'>");
            $sor=$tol+$x+1;
            echo("$sor");
            echo("</div>");
          }
          echo("<div class='div_a2'>");
          echo("<b />$txx[3]<br />$txx[2] </b>");
          if ($comment_rate){
            echo("<br />$txx[4] $ki3." );
          }
          echo("</div>");
          echo("<div class='div_a3'>");
          echo("$txx[5] <br /><br />" );
          echo("</div>");
          //echo("<br /><br /><br />");
          echo("</div>");
          $out++;
        }
        $x++;
      }
      if ($db>$mess_per_page){
        echo("<div class='page_table'>");
        $ki1=sys_line_local("Megjelen�tve");
        $ki2=sys_line_local("�sszesen");
        echo("<div class='div_stat'>");
        $out=$tol+$out;
        $tol++;
        echo("<br />$ki1: $tol-$out. ($ki2: $db.)<br />");
        echo("</div>");
        echo("</div>");
        site_pageing($db,$mess_per_page,$mess_akt_page,$messpage);
        if ($site_data_css_container<>""){
          echo("<div class='div_p'></div>");
          echo("</div><div class='$site_data_css_container'>");
        }else{
          echo("<br />");
          echo("<hr class='hrcl' />");
          echo("<br />");
        }
      }
    }
    sys_env_del($sitepage);
  }


  function site_comment_new($mcim){
    global $sitepage,$s_program,$rate_point,$usercode,
           $comment_rate,$k_message,$site_data_css_container;

    $e=sys_env_pack();
    if ($mcim==""){
      $ki=sys_line_local("Hozz�sz�l�s");
    }else{
      $ki=$mcim;
    }
    if ($site_data_css_container<>""){
      echo("</div><div class='$site_data_css_container'>");
    }else{
      echo("<hr class='hrcl' />");
      echo("<br />");
    }
    echo("<div class='div_p'>$ki:</div>");
    echo("<br />");
    $uc=sys_env_find($usercode);
    if ($uc<>""){
      echo("<br /><br />");
      echo("<center>");
      echo("<form method='post' action='./$s_program?$e'>");
      echo("<textarea class='textarea_m1' id='x0' name='x0' cols='50' rows='6'></textarea><br /><br />");
      if ($comment_rate){
        $ki=sys_line_local("�rt�kel�s");
        echo("$ki: ");
        $ki=sys_line_local("pont");
        $x=0;
        while ($x<=$rate_point){
          if ($x==3){
            echo("<input type='radio' id='x1' name='x1' value='$x' checked='checked' />$x $ki ");
          }else{
            echo("<input type='radio' id='x1' name='x1' value='$x' />$x $ki ");
          }
          $x+=1;
        }
      }
      $ki=sys_line_local("Mehet");
      echo("<br /><br />");
      echo("<button class='button_1' type='submit' id='b5' name='b5' value='$ki'>$ki</button>");
      echo("</form>");
      echo("<br />");
      echo("</center>");
    }else{
      $ki=sys_line_local("Hozz�sz�l�s �r�s�hoz be kell jelentkeznie");
      echo("$ki. <br />");
    }
  }


  // uzenofal megvalositasa

  function site_message_wall_menu(){
    global $printed;

    if (!$printed){
      site_message_wall();
    }
  }

  // uzenofal megvalositasa

  function site_message_wall(){
    global $separator,$guest_user,
           $messpage,$mess_per_page,$mess_akt_page,
           $site_data_css_container,$sitepage,
           $usercode,$user_admin,$full_date_format,
           $deldata,$delkod,$s_program,$k_message;

    $uc=sys_env_find($usercode);
    if ($uc<>""){
      site_mess_new();
    }else{
      $ki=sys_line_local("�zenet �r�s�hoz be kell jelentkeznie");
      echo("$ki. <br />");
    }
    sys_env_new($sitepage,$k_message);
    if ($delkod<>""){
      sql_mwall_del($delkod);
    }
    $ok=sys_data_post($dbx,$tkx,$tex);
    if ($ok){
      if (strip_tags($tex[0])<>""){
        $ido=date($full_date_format);
        $n=site_user("");
        if ($n=="") {
          $n=$guest_user;
        }
        $ti=sys_time_code();
        sql_mwall_add($ti,$ido,$n,$tex[0]);
      }
    }
    $db=0;
    $tx=sql_mwall_get_result();
    $db=sql_result_db($tx);
    if ($site_data_css_container<>""){
      echo("<div class='div_p'></div>");
      echo("</div><div class='$site_data_css_container'>");
    }else{
      echo("<hr class='hrcl' />");
    }
    site_pageing_init($db,$tol,$ig,$mess_per_page,$mess_akt_page);
    $ki=sys_line_local("T�r�l");
    $x=0;
    $out=0;
    while ($x<=($mess_per_page-1)){
      $kdb=$tol+$x;
      $txx=sql_get_result_data($tx,$kdb);
      if (count($txx)>0){
        echo("<div class='page_table'>");
        if ($user_admin){
          sys_env_new($deldata,$txx[0]);
          sys_env_new($messpage,$mess_akt_page);
          $e=sys_env_pack();
          sys_env_del($deldata);
          sys_env_del($messpage);
          echo("<div class='div_a1'>");
          echo("<a class='href' href='./$s_program?$e'>$ki</a>");
          echo("</div>");
        }else{
          echo("<div class='div_a1'>");
          $xx=$x+1;
          echo("$xx");
          echo("</div>");
        }
        echo("<div class='div_a2'>");
        echo("<b />$txx[2] - $txx[1] </b>" );
        echo("</div>");
        echo("<div class='div_a3'>");
        echo("$txx[3] <br /><br />" );
        echo("</div>");
        //echo("<br /><br /><br />");
        echo("</div>");
        $out++;
      }
      $x++;
    }
    if ($db>$mess_per_page){
      echo("<div class='page_table'>");
      $ki1=sys_line_local("Megjelen�tve");
      $ki2=sys_line_local("�sszesen");
      echo("<div class='div_stat'>");
      $out=$tol+$out;
      $tol++;
      echo("<br />$ki1: $tol-$out. ($ki2: $db.)<br />");
      echo("</div>");
      echo("</div>");
      if ($site_data_css_container<>""){
        echo("<div class='div_p'></div>");
        echo("</div><div class='$site_data_css_container'>");
      }else{
        echo("<hr class='hrcl' />");
      }
    }
    site_pageing($db,$mess_per_page,$mess_akt_page,$messpage);
    sys_env_del($sitepage);
  }


  function site_mess_new(){
    global $sitepage,$s_program,$k_message;

    sys_env_new($sitepage,$k_message);
    $e=sys_env_pack();
    $ki=sys_line_local("�j �zenet");
    echo("<div class='div_address'>$ki:</div>");
    echo("<br />");
    echo("<br /><br />");
    echo("<center>");
    echo("<form method='post' action='./$s_program?$e'>");
    echo("<textarea class='textarea_m1' id='x1' name='x1' cols='50' rows='6'></textarea><br /><br />");
    $ki=sys_line_local("Mehet");
    echo("<button class='button_1' type='submit' id='b5' name='b5' value='$ki'>$ki</button>");
    echo("</form>");
    echo("<br />");
    echo("</center>");
  }


?>
