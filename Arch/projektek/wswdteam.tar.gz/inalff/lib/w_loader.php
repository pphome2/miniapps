<?php

  // w_robot --- PHP portalrobot
  // (verzioadatok a konfiguracios fajlban)
  //
  // fejleszto: InalR Fejlesztoi Iroda


  // system files in

  $system_config_file="w_config.php";
  $system_error_file="../i_error.html";

  $st=explode(" ",microtime());
  $start_time=$st[1]+$st[0];

  //error_reporting(E_ALL);// error handler function
  error_reporting(E_ERROR | E_WARNING | E_PARSE);
  //error_reporting(E_ALL);

  if (function_exists("date_default_timezone_set")){
    date_default_timezone_set("CET");
  }

  $system_ready=true;
  $system_ready_f2=false;

  if (file_exists("./$system_config_file")){
    include("./$system_config_file");
    $dir_include="../$dir_include";
    $dir_conf="../$dir_conf";
    if (strpos($s_licence,$gpl_string)){
      $gpl_system=true;
      $s_dev_program=$s_gpl_dev_program;
      $s_dev_version=$s_gpl_dev_version;
      $s_dev_copyright=$s_gpl_dev_copyright;
      $s_dev_team=$s_gpl_dev_team;
      $s_dev_mail=$s_gpl_dev_mail;
      $s_dev_web=$s_gpl_dev_web;
    }
  }else{
    $system_ready=false;
  }

  if (($system_ready)and(file_exists("$dir_conf/$sql_config_file"))){
    include("$dir_conf/$sql_config_file");
  }else{
    $system_ready=false;
  }

  if (($system_ready)and(file_exists("$dir_conf/$file_sysvar"))){
    include("$dir_conf/$file_sysvar");
  }else{
    $system_ready=false;
  }

  if ($_SERVER['HTTPS']<>""){
    $site_server_name="https://";
  }else{
    $site_server_name="http://";
  }
  $site_server_name=$site_server_name.$_SERVER['SERVER_NAME'];
  if ($system_ready){
    $mail_system_available=true;
    $i=0;
    $y=count($file_lib);
    while ($i<$y){
      if (file_exists("$dir_include/$file_lib[$i]")){
        include("$dir_include/$file_lib[$i]");
      }else{
        $system_ready=false;
      }
      $i+=1;
    }
  }

  // prepare system
  if ($system_ready){
    set_error_handler("sys_error");
    if (isset($_SERVER['HTTPS'])){
      $s_full_program="https://";
    }else{
      $s_full_program="http://";
    }
    $s_full_program=$s_full_program.$_SERVER['SERVER_NAME'].$_SERVER['PHP_SELF'];
    $s_program=basename($s_full_program);
    $s_full_path=substr($s_full_program,0,strlen($s_full_program)-strlen($s_program)-strlen($dir_bin)-1);
    $system_ready_f2=false;
    sys_env_in();
    $akt_site=sys_env_find($sitename);
    if ($akt_site<>""){
      $default_site=$akt_site;
    }else{
      sys_env_new($sitename,$default_site);
    }
    $dir_site="../$dir_site";
    $dir_system="../$dir_system";
    $dir_guest_code="../$dir_guest_code";
    $dir_log="../$dir_log";
    $dir_template="../$dir_template";
    $dir_plugin="../$dir_plugin";
    $dir_driver="../$dir_driver";
    $error_log_file="$dir_log/$error_log_file";
    $lsystem=sys_env_find($language);
    if ($lsystem==""){
      if (count($lang_label)>0){
        $lang_system=$lang_label[0];
      }
    }
    if ($default_site<>""){
      if (file_exists("$dir_site/$default_site/$file_user_config")){
        include("$dir_site/$default_site/$file_user_config");
        if (!$gpl_system){
          if (file_exists("$dir_plugin/$file_plugins")){
            include("$dir_plugin/$file_plugins");
          }
        }
        $st=sys_env_find($sitepos);
        if (($st=="")and($first_page_template<>"")){
          $default_template=$first_page_template;
        }
        if ($site_date_format<>""){
          $date_format=$site_date_format;
        }
        if ($site_time_format<>""){
          $time_format=$site_time_format;
        }
        if ($site_lang_system<>""){
          $lang_system=$site_lang_system;
        }
        $full_date_format="$date_format $time_format";
      }else{
        $default_site="";
        sys_env_new($sitename,$default_site);
        $default_template=$default_template_install;
      }
    }
    if (file_exists("$dir_driver/$sql_driver.php")){
      include("$dir_driver/$sql_driver.php");
    }
    $template_path="$dir_template/$default_template";
    if (file_exists("$template_path/$file_template_main")){
      include("$template_path/$file_template_main");
      $system_ready_f2=true;
    }
  }else{
    //system_error();
  }
  // start

  if ($system_ready_f2){
    fmain();
  }else{
    system_error();
  }

  // files error

  function system_error(){
    global $system_error_file;

    if (file_exists($system_error_file)){
      include($system_error_file);
    }else{
      echo("Rendszerhiba. / System error.");
    }
  }


?>
