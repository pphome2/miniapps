<?php

header("Content-Type: text/html; charset=iso-8859-2");

$item_name[0][0]="";
$item_line[0][0]="";
$item_db=0;
$item_num=0;
$lastdb=20;
$old_key=array("&lt;","&gt;","[CDATA[","]]");
$new_key=array("<",   ">",   "",       "");
$error=false;
$encoding=false;
$utf=array("utf","UTF");
$rss_key=array("item","description","pubDate","link","url","title","copyrigth");
$url="";


error_reporting(0);

$rssurl="";
foreach ($_GET as $key => $data) {
  if (strlen($data)>7){
    $rssurl=$data;
  }
}

if ($rssurl!=""){
  //echo("$rssurl");
  $content="";
  $content=file_get_contents($rssurl);
  if ($content!=""){
    $i=0;
    $y=strlen($content);
    $line="";
    $item_name[0][0]="";
    $item_line[0][0]="";
    $item_db=0;
    while (($x<=$y)and($item_num<=$lastdb)){
      $nch=$content[$x];
      if ($nch=="<"){
        $nch="";
        $l=$x;
        while (($x<=$y)and($content[$x]!=">")){
          $x+=1;
        }
        if ($content[$x]==">"){
          $keyword=substr($content,$l+1,$x-$l-1);
          $keyw=substr($keyword,0,4);
          //$x+=1;
          if ($keyw==$rss_key[0]){  //item
            $item_db=0;
            $item_num+=1;
            $line="";
          }else{
            $jel=substr($keyword,0,1);
            $keyword=substr($keyword,1,strlen($keyword));
            switch ($jel){
              case "/":
                if (in_array($keyword,$rss_key)){
                  //echo("$keyword - $line<br />");
                  $item_name[$item_num][$item_db]=$keyword;
                  $line=str_replace($old_key,$new_key,$line);
                  $line=strip_tags($line);
                  if ($encoding){
                    $line=iconv("UTF-8","ISO-8859-2",$line);
                  }
                  $item_line[$item_num][$item_db]=$line;
                  $item_db+=1;
                  $line="";
                }
                break;
              case "?":
                $cc=0;
                $cce=strlen($keyword)-3;
                while ($cc<=$cce){
                $utfe=substr($keyword,$cc,3);
                  if (in_array($utfe,$utf)){
                    $encoding=true;
                    $cc=$cce;
                  }
                  $cc+=1;
                }
                break;
              case "!":
                $jel2=substr($keyword,0,7);
                if ($jel2<>"DOCTYPE"){
                  $line=$keyword;
                }
                break;
              default:
                  $line="";
                break;
            }
          }
        }
      }
      $line=$line.$nch;
      $x+=1;
    }
  }
  
  $x=0;
  while ($x<$item_num){
    $y=0;
    while ($item_name[$y]!=""){
      $l=$item_name[$x][$y];
      //echo("$l <br />");
      $y+=1;
    }
    if ($x==0){
      echo("<div class='Border' >");
      $sor1=get_xml_tag("title",$x);
      $sor0=get_xml_tag("link",$x);
      echo("<div class='Head' >");
      if ($sor0!=""){
        echo("<a href='$sor0' >$sor1</a>");
      }else{
        echo("$sor1");
      }
      echo("</div>");
      echo("<div class='Text2' >");
      $sor1=get_xml_tag("url",$x);
      if ($sor1!=""){
        echo("<img src='$sor1' alt='$sor1'><br />");
      }
      $sor1=get_xml_tag("copyright",$x);
      if ($sor1!=""){
        echo("($sor1)<br />");
      }
      echo("</div>");
      echo("</div>");
    }else{
      echo("<div class='Border' >");
      $sor1=get_xml_tag("title",$x);
      $sor0=get_xml_tag("link",$x);
      echo("<div class='Head' >");
      echo("<a href='$sor0' >$sor1</a> ");
      $sor1=get_xml_tag("pubDate",$x);
      if ($sor1!=""){
        $sor1=strtotime($sor1);
        $sor1=date("Y.m.d. G:i",$sor1);
        echo(" $sor1");
      }
      echo("</div>");
      echo("<div class='Text' >");
      echo("<br />");
      $sor1=get_xml_tag("description",$x);
      if ($sor1!=""){
        echo("$sor1<br />");
      }
      echo("<br /><b /><a href='$sor0' >Tov�bb</a></b><br /><br />");
      echo("</div>");
      echo("</div>");
    }
    $x+=1;
  }

}



function get_xml_tag($tag,$num){
  global $item_name,$item_line;

  $s=0;
  while (($item_name[$num][$s]!="")and($item_name[$num][$s]!=$tag)){
    $s+=1;
  }
  $v=0;
  if ($item_name[$num][$s]==$tag){
    $v=$item_line[$num][$s];
  }
  return $v;
}




?>
