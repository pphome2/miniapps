<?php
    
  header("Content-Type: text/html; charset=iso-8859-2");
  
  $filename="./rss.txt";
  $rsstomb=array("");
  $f=0;
  while ((!$h=fopen($filename,'r'))and($f<10)){
    usleep(200);
    $f+=1;
  }
  $db=0;
  while (!feof($h)) {
    $rsstomb[$db]=fgets($h);
    $db+=1;
  }
  fclose($h);

  echo("RSS el�rhet�s�g: ");
  echo("<select class ='st' id='st' name='urss' > ");
  $i=0;
  $l=sizeof($rsstomb);
  while ($i<$l-1){
    $rssdata=explode(';',$rsstomb[$i]);
    echo("<option value='$rssdata[0]'>$rssdata[1]</option>");
    $i+=1;
  }
  echo("</select> ");
  //echo("<button type='submit' class='b01' id='b01' name='b01' value='' />Mehet</button>");

?>
