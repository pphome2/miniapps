<?php

//include("./02i.php");

$app_name="Sz�t�r v0.2";
$app_copyrigth="(c) 2009. WSWDTeam (Demo)";
$program="szotar.php";


$exec_name=array("Magyar-Angol","Angol-Magyar");
$exec_par=array("dict","Shell");
$param_k=array("");
$param_d=array("");
$lastdb=20;
$error=false;
$encoding=false;
$ajax=false;

error_reporting(0);

main();


function main(){
  global $url,$ajax;

  get_param();
  if (!$ajax){
    out_head();
  }else{
    out_ajax_head();
  }
  if (!$ajax){
    get_panel();
  }
  get_exec_head();
  get_exec();
  get_exec_foot();
  if (!$ajax){
    out_foot();
  }
}


function out_ajax_head(){
  header("Content-Type: text/html; charset=iso-8859-2");
}


function out_head(){
  global $app_name;

  echo("<!DOCTYPE html PUBLIC '-//W3C//DTD XHTML 1.0 Transitional//EN' ");
  echo("'http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd'>");
  echo("<html xmlns='http://www.w3.org/1999/xhtml' lang='hu' xml:lang='hu'>");
  echo("<head>");
  echo("<meta http-equiv='Content-Type' content='text/xml; charset=iso-8859-2' />");
  echo("<style type='text/css' media='screen'>");
  echo("  .Program {display:block;padding:5px 5px 5px 5px;");
  echo("            font-size:14px;font-weight:bold;background-color:teal;color:white;}");
  echo("  .Program2 {display:block;padding:5px 5px 5px 5px;font-size:10px;");
  echo("             text-align:center;font-weight:bold;background-color:teal;color:white;}");
  echo("  .Head {display:block;padding:5px 5px 5px 5px;");
  echo("         font-size:12px;font-weight:bold;background-color:orange;color:white}");
  echo("  .Text {display:block;padding:5px 5px 5px 5px;font-size:10px;");
  echo("         background-color:white;color:black;}");
  echo("  .Text2 {display:block;padding:5px 5px 5px 5px;");
  echo("          text-align:center;font-size:10px;background-color:white;color:black;}");
  echo("  .Border {display:block;border:solid 1px;margin:15px 15px 0px 15px;}");
  echo("</style>");
  echo("<title>$app_name</title>");
  echo("</head>");
  echo("<body>");
}


function get_panel($par){
  global $app_name,$program,$exec_name;

  echo("<div class='Border'>");
  echo("<div class='Program'>");
  echo("<b><i>$app_name</i></b>");
  echo("</div>");
  echo("<div class='Text2'>");
  echo("<form method='post' action='./$program'>");
  echo("Keresett sz�: ");
  #echo("<select id='t1' name='urss'> ");
  #foreach ($exec_name as $gu){
  #  echo("<option>$gu</option>");
  #}
  #echo("</select> ");
  echo("<input type='text' id='t1' value='' name='prpar' size='50' maxlength='120' /> ");
  echo("<button type='submit' id='b1' name='b01' value=''>Mehet</button>");
  echo("");
  echo("</form>");
  echo("</div>");
  echo("</div>");
  $formdb+=1;
}


function get_exec_head(){
  echo("<div class='Border'>");
  echo("<div class='Head'>");
  echo("<b><i>Eredm�ny</i></b>");
  echo("</div>");
  echo("<div class='Text'>");
}


function get_exec_foot(){
  echo("<br />");
  echo("</div>");
  echo("</div>");
}


function get_exec(){
  global $param_k,$param_d,$exec_name,$ajax;

  echo("<br />");
  $keres_a=$param_d[0];
  if (!$ajax){
    $keres=iconv("ISO-8859-2","UTF-8",$keres_a);
  }else{
    $keres=$keres_a;
  }
  #echo($keres_a);
  exec("dict $keres",$v2);
  $i=2;
  $y=count($v2);
  if ($y>0){
    while ($i<$y){
      $ki=iconv("UTF-8","ISO-8859-2",$v2[$i]);
      $ki=ltrim($ki," ");
      $ii=0;
      $yy=strlen($ki);
      while (($ii<$yy)and(substr($ki,$ii,1)!="[")){
        $ii++;
      }
      if ($ii<$yy-1){
        echo("<b>Sz�t�r: ".substr($ki,$ii+1,strlen($ki)-$ii-3).".</b><br />");
      }else{
        #echo("-$ki-$keres_a-<br />");
        if (substr($ki,0,strlen($keres_a))==$keres_a){
          echo("<i>$ki</i><br />");
        }else{
          echo("$ki<br />");
        }
      }
      $i++;
    }
  }else{
    echo("Nincs tal�lat.<br />");
  }
}


function get_param(){
  global $ajax,$param_k,$param_d;

  $db=0;
  foreach ($_POST as $key => $data) {
    $param_k[$db]=$key;
    $param_d[$db]=$data;
    $db+=1;
  }
  #echo("--$db--");
  if ($db>2){
    $ajax=true;
  }
}



function out_foot(){
  global $app_name, $app_copyrigth;

  echo("<div class='Border'>");
  echo("<div class='Program2'>");
  echo("$app_name -[ $app_copyrigth ]-");
  echo("</div>");
  echo("<div class='Text2'>");
  echo("<a href='http://jigsaw.w3.org/css-validator/check/referer'>");
  echo("<img style='border:0;width:88px;height:31px' ");
  echo("src='http://jigsaw.w3.org/css-validator/images/vcss' ");
  echo("alt='Valid CSS!' /></a>");
  echo("<a href='http://validator.w3.org/check?uri=referer'>");
  echo("<img style='border:0;' src='http://www.w3.org/Icons/valid-xhtml10' ");
  echo("alt='Valid XHTML 1.0 Transitional' height='31' width='88' /></a>");
  echo("</div>");
  echo("</div>");
  echo("</body></html>");
}

?>
