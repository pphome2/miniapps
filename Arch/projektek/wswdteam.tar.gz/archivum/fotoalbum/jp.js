/*!
 * jP JavaScript Library v0.1
 * http://wswdteam.vacau.com
 *
 * Copyright 2011, WSWDTeam
 * GPL Version 2 licenses or later
 *
 */

  var popupstatus=0;
  var popup=0;
  var galeria=0;
  var slideshow=0;
  var popupimgdb=1;
  var description=0;
  var desconimg=1;
  var imgmaxdb=0;
  var imagelist=0;
  var imgpos=0;
  var wwidth=1024;
  var wheight=768;
  var popupborder=50;
  var minimgsize=100;
  var maximgsize=0;
  var dirparam='m-';
  var time;
  var timex;
  var timey;



  function empty(cycle){
    cdb=0;
    do{
      cdb=cdb+1;
      $('.empty').html(cdb);
    }while(cdb<=cycle);
  }


  function preparepopup(){
    if(popupstatus==0){
      if (slideshow==1){
        $('.popupstep').css({
          'display': 'none'
        });
        $('.popupstep2').css({
          'display': 'block'
        });
      }else{
        if (galeria==1){
          $('.popupstep').css({
            'display': 'block'
          });
          $('.popupstep2').css({
            'display': 'none'
          });
        }else{
          $('.popupstep').css({
            'display': 'none'
          });
          $('.popupstep2').css({
            'display': 'none'
          });
          db='';
        }
      }
      $('.backgroundpopup').css({
        'opacity': '0.7'
      });
      $('.backgroundpopup').fadeIn('slow');
    }
  }


  function descout(dimgpos) {
    if (description==1){
      t=$('.il').eq(dimgpos).attr('alt');
      $('.popupimgdescout').html('');
      $('.desc').html('');
      a=t.substr(2);
      c=a.search('/')+1;
      cs=a.substr(c);
      c2=cs.indexOf('.');
      cs='.w'+cs.substr(0,c2);
      b='';
      b=$(cs).attr('for');
      if (b!=''){
         $('.popupimgdescout').html(b);
        $('.desc').html(b);
      }
    }
  }


  function loadpopup(dimg){
    loadingpopup();
    preparepopup();
    descout(dimg);
    t=$('.il').eq(dimg).attr('alt');
    imgs=new Image();
    //$('.bem2').attr('src',t);
    imgs.src=t;
    imgs.onload=function(){
      $('.loading').hide();
      centerpopup(imgs);
      $('.bem2').attr('src',t);
      if (description==1){
        timex=setTimeout('popupdescout()',2000);
      }
      if (slideshow==1){
        time=setTimeout('popupstep(2)',5000);
      }
    };
    $('.popupimg').fadeIn();
    popupstatus=1;
  }


  function popupdescout(){
    if ((description==1)&&($('.popupimgdescout').html!='')){
      $('.popupimgdesc').fadeIn('slow');
    }
  }

  function loadingpopup(){
    $('.loading').show();
    $('.bem2').css({
      'width':0,
      'height':0
    });
  }


  function closepopup(){
    if(popupstatus!=0){
      $('.popupimgdesc').hide();
      $('.popupimg').fadeOut('slow');
      $('.backgroundpopup').fadeOut('slow');
      if (slideshow==1){
        clearTimeout(time);
      }
      if (description==1){
        clearTimeout(timex);
      }
      popupstatus=0;
      slideshow=0;
    }
  }


  function closepopup2(i){
    if (popupstatus==1){
      $('.loading').show();
      $('.bem2').css({
        'width':0,
        'height':0
      });
      //$('.popupimg').hide('slow');
      $('.popupimgdesc').hide();
      //loadingpopup();
      popupstatus=0;
      popupstep(i);
    }
  }


  function centerpopup(imgx){
    m=0;
    im=0;
    iw=imgx.width;
    ih=imgx.height;
    //iw=$('.bem2').width();
    //ih=$('.bem2').height();
    nu=iw/ih;
    if (nu==0){
      nu=1;
    }
    if (ih==0){
      ih=wheight/2;
      iw=ih*nu;
      m=1;
      im=1;
    }
    if (iw==0){
      iw=wwidth/2;
      ih=iw/nu;
      m=1;
      im=1;
    }
    if (iw>wwidth-(2.5*popupborder)){
      iw=wwidth-(3*popupborder);
      ih=iw/nu;
      m=1;
    }
    if (ih>wheight-(2.5*popupborder)){
      ih=wheight-(3*popupborder);
      iw=ih*nu;
      m=1;
    }
    ih=Math.round(ih);
    iw=Math.round(iw);
    $('.bem2').css({
      'width':iw,
      'height':ih
    });
    if (iw<minimgsize){      //>
       pw=minimgsize+popupborder;
     }else{
      pw=iw+popupborder;
    }
    if (ih<minimgsize){      //>
      ph=minimgsize+popupborder+30;
    }else{
      ph=ih+popupborder+30;
    }
    if (description==1){
      //ph=ph+10;
    }
    pl=wwidth-pw-popupborder;
    pl=pl/2;
    pl=Math.round(pl);
    pt=wheight-ph-popupborder;
    pt=pt/2;
    pt=Math.round(pt);
    ki=iw+'-'+ih+';'+pl+'-'+pt+';'+pw+'-'+ph;
    //$('.pupdb').html(ki);
    $('.popupimg').css({
      'position':'absolute',
      'top':pt,
      'left':pl,
      'width':pw,
      'height':ph
    });
    if (desconimg==1){
      idt=ih-30;
      idl=4;
      idw=iw-1;
      idh=popupborder;
      $('.popupimgdesc').css({
        'position':'absolute',
        'opacity': '0.7',
        'top':idt,
        'left':idl,
        'width':idw,
        'height':idh
      });
    }
  }


  function centerimg(imgx){
    m=0;
    im=0;
    iw=imgx.width;
    ih=imgx.height;
    nu=iw/ih;
    if (nu==0){
      nu=1;
    }
    if (ih==0){
      ih=wheight/2;
      iw=ih*nu;
      m=1;
      im=1;
    }
    if (iw==0){
      iw=wwidth/2;
      ih=iw/nu;
      m=1;
      im=1;
    }
    if (iw>wwidth-(2.5*popupborder)){
      iw=wwidth-(3*popupborder);
      ih=iw/nu;
      m=1;
    }
    if (ih>wheight-(2.5*popupborder)){
      ih=wheight-(3*popupborder);
      iw=ih*nu;
      m=1;
    }
    ih=Math.round(ih);
    iw=Math.round(iw);
    $('.bem1').css({
      'width':iw,
      'height':ih
    });
  }


  function popupstep(i){
    if (popupstatus==1){
      closepopup2(i);
    }else{
    imgmaxdb=$('.il').length;
    if (i!=0){
      if (i==1){
        imgpos=imgpos-1;
        if (imgpos<0){
          imgpos=imgmaxdb-1;
        }
      }else{
        imgpos=imgpos+1;
        if (imgpos>imgmaxdb-1){
          imgpos=0;
        }
      }
    }
    edb=imgpos+1;
    db=edb+' / '+imgmaxdb;
    if (popup==1){
      $('.pupdb').html('');
    }else{
      $('.pupdb').html(db);
    }
    loadpopup(imgpos);
    }
  }


  function be(da){
    if (popup==1){
      imgpos=da;
      popupstep(0);
    }else{
      a=$('.il').eq(da).attr('alt');
      $('.bem1').attr('src',a);
      imgs=new Image();
      imgs.src=a;
      imgs.onload=function(){
        centerimg(imgs);
      };
      imgpos=da;
      descout(da);
      $('.bem').hide();
      $('.bem').slideDown('slow');
    }
  }


  function fblock(bn){
    z1=$('.chkb01').attr('checked');
    z2=$('.chkb02').attr('checked');
    z3=$('.chkb03').attr('checked');
    z4=$('.chkb04').attr('checked');
    slideshow=0;
    galeria=0;
    popup=0;
    description=0;
    if (z1){
      slideshow=0;
      galeria=0;
      popup=1;
    }
    if (z2){
      slideshow=0;
      galeria=1;
      popup=0;
    }
    if (z3){
      slideshow=1;
      galeria=0;
      popup=0;
    }
    if (z4){
      description=1;
      $('.desc').html('');
      $('.popdesc').html('');
      $('.desc').show();
    }else{
      $('.desc').hide();
      $('.popdesc').hide();
      $('.desc').html('');
      $('.popupimgdescout').html('');
    }
    if (popup==1){
      $('.block2').show('slow');
      $('.block3').hide('slow');
      $('.chkbs1').show('slow');
      $('.chkbs3').hide('slow');
      if (imagelist==1){
        $('.b02').show();
      }else{
        $('.b02').hide();
      }
    }else{
      if (galeria==1){
        $('.block2').hide('slow');
        $('.block3').hide('slow');
        $('.chkbs1').hide('slow');
        $('.chkbs3').show('slow');
        $('.b02').hide();
      }else{
        if (slideshow==1){
          $('.block2').hide('slow');
          $('.block3').hide('slow');
          $('.chkbs1').hide('slow');
          $('.chkbs3').show('slow');
          $('.b02').hide();
        }else{
          $('.block2').show('slow');
          $('.block3').show('slow');
          $('.chkbs1').show('slow');
          $('.chkbs3').hide('slow');
          if (imagelist==1){
            $('.b02').show();
          }else{
            $('.b02').hide();
          }
        }
      }
    }
  }


  $.get('album-1.php',{'s':dirparam}, function(list) {     // ajax lap betoltese
    $('.result').html(list);
    $('.albumid').prepend(list);
  });


  $(document).ready(function(){

    wwidth=window.innerWidth;
    wheight=window.innerHeight;
    pt=2*popupborder;
    pl=3*popupborder;
    pw=wwidth-(6*popupborder);
    ph=wheight-(4*popupborder);
    $('.popupimg').css({
      'position': 'absolute',
      'top':pt,
      'left':pl,
      'width':pw,
      'height':ph
    });
    $('.chkb01').attr('checked',false);
    $('.chkb02').attr('checked',false);
    $('.chkb03').attr('checked',false);
    $('.chkb04').attr('checked',false);

    $('.bem').hide();
    $('.b02').hide();
    $('.chkbs3').hide();
    $('.popupstep').hide();
    $('.popupstep2').hide();
    $('.popupimgdesc').hide();
    $('.loading').hide();

    $('.b01').click(function(){
      $('.kep').hide('slow');
      $('.bem').hide('slow');
      $('.kep').html('');
      d=$('.sel').attr('value');
      $.get('album-2.php',{'s1':d, 's2':dirparam}, function(list2) {
        $('.result').html(list2);
        fblock(2);
        imgpos=0;
        $('.kep').html(list2);
        $('.kep').show('slow');
        if (description==1){
          descout(imgpos);
        }
        if ((galeria==0)&&(slideshow==0)){
          $('.b02').show();
        }
        imagelist=1;
        if ((galeria==1) || (slideshow==1)){
          popupstep(0);
        }
      });
    });

    $('.bem').click(function(){
      $('.bem').hide('slow');
    });

    $('.b02').click(function(){
      $('.kep').html('');
      $('.bem').html('');
      $('.b02').hide();
      imagelist=0;
      $('.kep').hide('slow');
    });
  });


