<?php

  header("Content-Type: text/html; charset=iso-8859-2");


  $max_image_db=10;
  $image=array(".jpg",".png",".gif");
  $tdesc=array();
  $kimg=array();
  $descfile=".txt";
  $dir="";
  $db=0;
  $try_open=20;

  foreach ($_GET as $key => $data) {
    if (strlen($data)>1){
      $db++;
      if ($db>1){
        $dirp=$data;
      }else{
        $dir=$data;
      }
    }
  }

  //echo("$dir");
  if ($dir!=""){
    $dl=scandir("./$dir");
    $i=sizeof($dl);
    $k=0;
    $db=0;
    $sdb=0;
    $kdb=0;
    while ($k<$i){
      if (!is_dir($dl[$k])){
        $ki=substr($dl[$k],-4,4); 
        if (in_array($ki,$image)){
          $kimg[$kdb]=$dl[$k];
          $kdb+=1;
          $src="./$dirp$dir/$dl[$k]";
          $dl[$k]="./$dir/$dl[$k]";
          echo("<img class='il' src='$src' id= 'i1' alt='$dl[$k]' onclick='be($db)' >");
          echo(" ");
          $db+=1;
          if ($db>=$max_image_db){
            echo("<br />");
            $db=0;
          }
        }else{
          if ($ki==$descfile){
            $dl[$k]="./$dir/$dl[$k]";
            $f=0;
            while ((!$h=fopen($dl[$k],"r"))and($f<$try_open)){
              usleep(200);
              $f+=1;
            }
            if ($f<$try_open){
              while (!feof($h)){
                $sor=fgets($h); 
                if ($sor!=""){
	          $x=strpos($sor,":");
                  $tdesc[$sdb][0]=substr($sor,0,$x);
                  $tdesc[$sdb][1]=substr($sor,$x+1,strlen($sor));
                  $sdb+=1;
	        }
              }
              fclose($h);
            }
          }
        }
      }
      $k+=1;
    }
    if ($sdb>0){
      $xdb=0;
      while ($xdb<=$sdb){
        $tx=$tdesc[$xdb][0];
        if (in_array($tx,$kimg)and($tx<>"")){
          $t0=substr($tdesc[$xdb][0],0,strlen($tdesc[$xdb][0])-4);
          $t1=$tdesc[$xdb][1];
          echo("<label class='w$t0' for='$t1' ></label>");
          $t2=$tdesc[$xdb][0];
          $cc=0;
          $cc2=sizeof($kimg);
          $t3=$kimg[0];
          while (($cc<$cc2)and($t2<>$kimg[$cc])){
            $cc+=1;
          }
          if ($cc<$cc2){
            $kimg[$cc]="";
          }
          echo("");
        }
        $xdb++;
      }
    }
    $c=0;
    while ($c<=$kdb){
      if ($kimg[$c]<>""){
        $t0=substr($kimg[$c],0,strlen($kimg[$c])-4);
        echo("<label class='w$t0' for='' ></label>");
      }
      $c+=1;
    }
  }

?>
