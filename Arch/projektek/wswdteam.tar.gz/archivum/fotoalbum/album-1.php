<?php

  header("Content-Type: text/html; charset=iso-8859-2");

  $dirp='';
  foreach ($_GET as $key => $data) {
    if (strlen($data)>0){
      $dirp=$data;
    }
  }

  $sdp=sizeof($dirp)+1;
  $dl=scandir('.');
  $i=sizeof($dl);
  $k=0;
  echo("<select class='sel' width='300px' >");
  while ($k<$i){
    if ((is_dir($dl[$k]))and($dl[$k][0]<>'.')){
      if (substr($dl[$k],0,$sdp)<>$dirp){
        echo("<option value='$dl[$k]' >$dl[$k]</option>");
      }
    }
    $k+=1;
  }
  echo("</select>");

?>
