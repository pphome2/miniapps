# ----------------------------------------------------------
#  database: mysql, "source installdb.sql"
#  adatb�zisn�v: a c�gnev...
# ----------------------------------------------------------


create database szuvszolnok;

use szuvszolnok;

create table eszk_tipus (
    #t_id smallint auto_increment,
    t_tipusnev varchar (20) not null,
    t_leiras varchar (100),
    t_tartalom varchar (250),
    #primary key(t_id),
    unique (t_tipusnev),
    index t_inev (t_tipusnev)
);

create table eszk_szoftver (
    #s_id smallint auto_increment,
    s_csomagnev varchar (20) not null,
    s_leiras varchar (100),
    s_tartalom varchar (250),
    #primary key(s_id),
    unique (s_csomagnev),
    index s_inev (s_csomagnev)
);

create table eszk_gep (
    #g_id smallint auto_increment,
    g_gepnev varchar (20) not null,
    g_leiras varchar (100),
    g_tartalom varchar (250),
    #primary key(g_id),
    unique (g_gepnev),
    index g_inev (g_gepnev)
);

create table eszk_adatok (
    #a_id smallint auto_increment,
    a_azonosito varchar (20) not null,
    a_eszktipus varchar (20),
    a_nev varchar (100),
    a_gepnev varchar (20),
    a_gyariszam varchar (50),
    a_szoftver varchar (20),
    a_helyiseg varchar (20),
    a_megjegyzes varchar (250),
    a_megjegyzes2 varchar (250),
    a_kategoria varchar (20),
    a_cpu varchar (20),
    a_ram varchar (20),
    a_hdd varchar (20),
    a_opt varchar (20),
    #primary key(a_id),
    unique (a_azonosito),
    index a_iazonosito (a_azonosito)
);

create table hd_nev (
    #n_id smallint auto_increment,
    n_nev varchar (40) not null,
    n_tudas varchar (100),
    n_megj varchar (250),
    #primary key(n_id),
    unique (n_nev),
    index n_inev (n_nev)
);

create table hd_tipus (
    #t_id smallint auto_increment,
    t_nev varchar (40) not null,
    t_leiras varchar (100),
    t_megj varchar (250),
    #primary key(t_id),
    unique (t_nev),
    index t_inev (t_nev)
);

create table hd_prior (
    #p_id smallint auto_increment,
    p_nev varchar (20) not null,
    p_leiras varchar (100),
    p_megj varchar (250),
    #primary key(p_id),
    unique (p_nev),
    index p_inev (p_nev)
);

create table hd_bejel (
    #b_id smallint auto_increment,
    b_datum varchar (23) not null,
    b_bnev varchar (250),
    b_eszk varchar (100),
    b_tipus varchar (40),
    b_prior varchar (20),
    b_leir varchar (250),
    b_zarva varchar (23),
    b_sznev varchar (40),
    b_megold varchar (250),
    b_j_dat varchar (11),
    b_j_kezd varchar (5),
    b_j_vege varchar (5),
    b_j_kisz varchar (3),
    b_j_ido varchar (3),
    b_all varchar (250),
    #primary key(b_id),
    unique (b_datum),
    index b_idatum (b_datum)
);


insert into eszk_tipus values("-","dat","Nincs adat");
insert into eszk_szoftver values("-","Nincs adat","Nincs adat");
insert into eszk_gep values("-","Nincs adat","Nincs adat");


insert into hd_nev values("P�teri P�ter","Szerv�z vezet�","-");
insert into hd_nev values("Balogh G�bor","Szerv�z m�rn�k","-");
insert into hd_nev values("Vitai Roland","Szerv�z technikus","-");
insert into hd_nev values("Mannheim Jen�","Szerv�z technikus","-");
insert into hd_nev values("Tolvaj Csaba","Keresked�","-");
insert into hd_nev values("Deme J�zsefn�","Keresked�","-");
insert into hd_nev values("P�l Szilvia","Helpdesk","-");
insert into hd_nev values("M�csai L�szl�","Vezet�","-");
insert into hd_nev values("Dr. Bug�n Mih�ly","Vezet�","-");


insert into hd_tipus values("Hardver","Hardvert �rint� hiba","-");
insert into hd_tipus values("Hardver-garancia","Hardvert �rint� hiba garanci�lis","-");
insert into hd_tipus values("Szoftver","Szoftvert �rint� hiba","-");
icnsert into hd_tipus values("Albacomp","Szerz�d�s szerinti hibajav�t�s","Albacomp forgalmaz�s�ban");
icnsert into hd_tipus values("Okm�nyiroda","Szerz�d�s szerinti hibajav�t�s","BM");


insert into hd_prior values("Norm�l","Norm�l elh�r�t�si idej� hiba","-");
insert into hd_prior values("S�rg�s","S�rg�s elh�r�t�si idej� hiba","-");

