<?php

  // s_robot --- PHP portalrobot
  // (verzioadatok a konfiguracios fajlban)
  //
  // fejleszto: Zebulon.hu Team

  
  // uzenofal megvalositasa

  function uzenofal(){
    global $ut,$tk,$te;
    
    echo("<div class=tartalom2>");
    include("$ut/txt/u_new.txt");
    echo("</div>");
    $filename="$ut/txt/u_data.txt";
    if (file_exists($filename)) {
      $h1=fopen($filename,"r");
      $s=0;
      while (!feof($h1)) {
        $sor[$s]=fgets($h1);
	$s+=1;
      }
      fclose($h1);
      if ($te[1]==='uj'){
        $dbx=0;    
        foreach ($_POST as $kulcs => $ertek) {
          $tkx[$dbx]=$kulcs;
          $tex[$dbx]=$ertek;
          $dbx+=1;    
        }
        $h1=fopen($filename,"w");
	$ido=date("Y.m.d. H:i");
	$ki=kiir("�rkezett");
        fwrite($h1, "<br><h3>$ki: $ido</h3>\n");
        fwrite($h1, "<br>\n");
        fwrite($h1, strip_tags($tex[0]));
        fwrite($h1, "\n<br><br>\n");
        fwrite($h1, "-\n\n");
  	$x=0;
	$db=1;
        while ($x<$s) {
	  if ($db<20){
  	    if ($sor[$x]==="-\n"){
              $db+=1;
	    }
            fwrite($h1, $sor[$x]);
	  }
          $x+=1;
        }	  
        fclose($h1);
        $h1=fopen($filename,"r");
        $s=0;
        while (!feof($h1)) {
          $sor[$s]=fgets($h1);
	  $s+=1;
        }
	fclose($h1);
      }
      echo("<div class=tartalom2>");
      $x=0;
      while ($x<$s) {
	if ($sor[$x]<>"-\n"){
          echo("$sor[$x]");
	}
        $x+=1;
      }
      echo("<br>");
      echo("</div>");
    }
    return(0);
  }
  
  
  // hirek kiirasa
  
  function hirek(){
    global $ut, $tk, $te;
    
    $db2=0;
    if ($db=1){
      $te[1]=100;
    }
    if (file_exists("$ut/txt/a_$te[0]_1.txt")) {
      echo("<div class=tartalom2>");
      include "$ut/txt/a_$te[0]_1.txt";
      echo("</div>");
    }
    while ($db2 < $te[1]) {
      $db2+=1;
      if (file_exists("$ut/txt/t_$te[0]_$db2.txt")) {
        echo("<div class=tartalom2>");
        include "$ut/txt/t_$te[0]_$db2.txt";
        echo("</div>");
      }
    }
  }  
  
  
?>

