<?php

  // s_robot --- PHP portalrobot
  // (verzioadatok a konfiguracios fajlban)
  //
  // fejleszto: Zebulon.hu Team


  // fej, menuoldal, jobboldal, kozepresz nyitas
  // itt lehet megv�ltoztatni a portal felepiteset
  
  function fejmenu(){
    global $ut;
    
    include("$ut/inc/i_lap_fej.inc");
    include("$ut/inc/i_bal_fej.inc");
    include("$ut/inc/i_bal_menu.inc");
    include("$ut/inc/i_bal_kapcs.inc");
    include("$ut/inc/i_bal_link.inc");
    include("$ut/inc/i_bal_zar.inc");
    include("$ut/inc/i_jobb_fej.inc");
    include("$ut/inc/i_jobb_hiba.inc");
    include("$ut/inc/i_jobb_akcio.inc");
    include("$ut/inc/i_jobb_szerviz.inc");
    include("$ut/inc/i_jobb_zar.inc");
    include("$ut/inc/i_kozep_fej.inc");
  }  
  
  
  // kozep zar, lab
  
  function lab(){
    global $ut,$program,$verzio,$fejleszto,$fejlesztomail,$liszensz;
        
    include("$ut/inc/i_kozep_zar.inc");
    include("$ut/inc/i_lap_lab.inc");
  }

  
?>
  