<?php

  // s_robot --- PHP portalrobot
  // (verzioadatok a konfiguracios fajlban)
  //
  // fejleszto: Zebulon.hu Team

  
  // design: jobb oldal, bal menu, valtozok
  
  include("s_config.php");
  include("s_system.php");
  include("s_design.php");
  include("s_local.php");

  // alapbeallitasok
  dirut();
  $langfile=$ut$langfile;
  
  // foprogram - vezerles
  fejmenu();
  langbe();
  
  $db=0;
  foreach ($_GET as $kulcs => $ertek) {
    $tk[$db]=$kulcs;
    $te[$db]=$ertek;
    $db+=1;    
  }
  switch ($te[0]){
    case 'u':
      uzenofal();
      break;
    default:
      hirek();
      break;
  }
  
  lab();  
?>

