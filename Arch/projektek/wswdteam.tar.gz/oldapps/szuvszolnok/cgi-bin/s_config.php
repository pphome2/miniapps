<?php

  // s_robot --- PHP portalrobot
  // (verzioadatok a konfiguracios fajlban)
  //
  // fejleszto: Zebulon.hu Team

  $program="s_robot";
  $verzio="0.1.4";
  $fejleszto="webmaster@szuvszolnok.hu";
  $fejlesztomail="webmaster@szuvszolnok.hu";
  $liszensz="[-] 2006. SzuvSzolnok.hu Team";
  
  $sitenev="www.szuvszolnok.hu";
  
  $langfile="/inc/i_lang.inc";
  
  
?>
  