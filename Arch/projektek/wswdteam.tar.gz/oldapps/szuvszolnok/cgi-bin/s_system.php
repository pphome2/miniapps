<?php

  // s_robot --- PHP portalrobot
  // (verzioadatok a konfiguracios fajlban)
  //
  // fejleszto: Zebulon.hu Team


  // utvonalak
  
  function dirut(){
    global $ut,$sitenev;
    
    $nev=getenv("SERVER_NAME");
    if ($nev===$sitenev){
      $ut="../html";
    }else{
      $ut="..";
    }
  }
  
  
  // nyelvi kiiras, vagy mentes
  
  function kiir($sor){
    global $lang,$langdb,$langfile;
  
    $x=0;
    while ($langdb>=$x and $lang[$x][0]!=$sor){
      $x+=1;
    }
    if ($lang[$x][0]===$sor){
      return($lang[$x][1]);
    }else{    
      if (file_exists($langfile)) {
        $h1=fopen($langfile,"a");
	$ki="$sor=$sor\n";
        fwrite($h1, $ki);
        fclose($h1);
      }
      return($sor);
    }    
  }
  
  
  // nyelvi adatok beolvasasa
  
  function langbe(){
    global $lang,$langdb,$langfile;
  
    if (file_exists($langfile)) {
      $h1=fopen($langfile,"r");
      $langdb=0;
      while (!feof($h1)) {
        $sor=fgets($h1);
	if ($sor!=""){
	  $x=strpos($sor,"=");
          $lang[$langdb][0]=substr($sor,0,$x);
          $lang[$langdb][1]=substr($sor,$x+1,strlen($sor));
          $langdb+=1;
	}
      }
      fclose($h1);
    }    
  }
  

?>

