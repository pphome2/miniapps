<?php  

function i_bal_zar(){
  global $site_template_path,$default_template,$dir_temp_img;
  
  $k="$site_template_path/$default_template/$dir_temp_img/i_szuv_nev.gif";
  echo("  <div class=ceglogo>");
  echo("    <br><br>");
  echo("    <img src=$k>");
  echo("    <br><br><br>");
  echo("  </div>");
  echo("</div>");
}

?>
