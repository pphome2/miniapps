<?php

function i_jobb_szerviz(){
  global $site_template_path,$default_template,$dir_temp_img;
  
  $k="$site_template_path/$default_template/$dir_temp_img/logo.png";
  echo("  <div class=jobbablak>");
  echo("  <center><b>Szerviz-pertnereink:</b>");
  echo("  <br><br><br>");
  $k="$site_template_path/$default_template/$dir_temp_img/sz_ac.gif";
  echo("  <img src=$k");
  echo("  <br><br>");
  $k="$site_template_path/$default_template/$dir_temp_img/sz_fsc.gif";
  echo("  <img src=$k>");
  echo("  <br><br>");
  $k="$site_template_path/$default_template/$dir_temp_img/sz_hp.gif";
  echo("  <img src=$k>");
  echo("  <br><br>");
  $k="$site_template_path/$default_template/$dir_temp_img/sz_ibm.gif";
  echo("  <img src=$k>");
  echo("  <br><br>");
  echo("  </center>");
  echo("  </div>");
}

?>
