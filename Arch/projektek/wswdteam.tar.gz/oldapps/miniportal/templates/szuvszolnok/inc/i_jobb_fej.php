<?php

function i_jobb_fej(){
  echo("<div class=jobbsav>");
  echo("  <div class=jobbmenu>");
  echo("  <br><b>SZ�V-Szolnok Kft.</b><br><br>");
  echo("  5000, Szolnok<br>");
  echo("  Baross �t 10-12.<br>");
  echo("  Telefon: 56/512-810<br><br>");
  echo("  </div>");
}

?>
