<?php

function i_jobb_zar(){
  echo("</div>");
}

?>