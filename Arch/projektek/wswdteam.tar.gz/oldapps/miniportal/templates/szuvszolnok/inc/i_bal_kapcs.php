<?php  

function i_bal_kapcs(){
  echo("  <div class=menutest>");
  echo("  <center><b>El�rhet�s�geink:</b></center>");
  echo("  <div class=menublock>");
  echo("      <a href=mailto:helpdesk@szuvszolnok.hu>Hibabejelent�s</a><br>");
  echo("      <a href=mailto:kereskedelem@szuvszolnok.hu>�raj�nlat k�r�se</a><br>");
  echo("      <a href=mailto:szerviz@szuvszolnok.hu>Szerv�z</a><br><br>");
  echo("      <a href=mailto:jegyiroda@szuvszolnok.hu>Jegyiroda</a><br>");
  echo("  </div>");
  echo("  </div>");
}

?>
