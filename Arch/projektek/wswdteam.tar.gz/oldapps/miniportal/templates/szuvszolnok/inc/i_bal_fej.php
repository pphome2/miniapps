<?php

function i_bal_fej(){
  global $site_template_path,$default_template,$dir_temp_img;
  
  $k="$site_template_path/$default_template/$dir_temp_img/i_szuv.gif";
  $k2="$site_template_path/$default_template/$dir_temp_img/i_szuv_nev.gif";
  echo("<div class=balsav>");
  echo("  <div class=ceglogo>");
  echo("    <br><br>");
  echo("    <img src=$k>");
  echo("    <img src=$k2>");
  echo("    <br><br>");
  echo("  </div>");
}

?>