<?php

function i_jobb_keres(){
  echo("  <div class=menutest>");
  echo("  <center>");
  site_keres();		    
  echo("  </center>");
  echo("  </div>");
}

?>
