<?php

function i_jobb_bejel(){
  echo("  <div class=menutest>");
  site_bejel();
  echo("  </div>");
}

?>
