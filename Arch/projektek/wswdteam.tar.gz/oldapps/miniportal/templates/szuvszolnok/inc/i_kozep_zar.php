<?php

function i_kozep_zar(){
  global $fejleszto,$fejlesztomail,$liszensz;
  
  echo("</div>");
  echo("  <div class=tartalom2>");
  echo("$liszensz<br>");
  echo("<a href=mailto:$fejlesztomail>$fejleszto</a>");
  echo("  </div>");
  echo("</div>");
  echo("</div>");
}

?>

