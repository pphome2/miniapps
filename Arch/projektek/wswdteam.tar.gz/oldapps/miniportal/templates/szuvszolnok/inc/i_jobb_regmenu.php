<?php  

function i_jobb_regmenu(){
  echo("<div class=menutest>");
  site_regmenu();
  echo("</div>");
}

?>