<?php

function i_jobb_hiba(){
  echo("  <div class=menutest>");
  echo("  <center><br><b>Hibabejelent�s</b>");
  echo("  <br><br></center>");
  echo("  Helpdesk: 56/512-820<br>");
  echo("  E-mail: <a href=mailto:helpdesk@szuvszolnok.hu>helpdesk@szuvszolnok.hu</a><br><br>");
  echo("  </div>");
}

?>
