<?php

  // s_robot --- PHP portalrobot
  // (verzioadatok a konfiguracios fajlban)
  //
  // fejleszto: Zebulon.hu Team


  // fej, menuoldal, jobboldal, kozepresz nyitas
  // itt lehet megv�ltoztatni a portal felepiteset
  
  function design(){
    global $template_path,$dir_temp_inc,$usercode;
    
    $iut="$template_path/$dir_temp_inc";
    include("$iut/i_bal_fej.php");
    include("$iut/i_bal_menu.php");
    include("$iut/i_bal_kapcs.php");
    include("$iut/i_bal_link.php");
    include("$iut/i_bal_zar.php");
    include("$iut/i_jobb_fej.php");
    include("$iut/i_jobb_hiba.php");
    include("$iut/i_jobb_keres.php");
    include("$iut/i_jobb_regmenu.php");
    include("$iut/i_jobb_bejel.php");
    include("$iut/i_jobb_szerviz.php");
    include("$iut/i_jobb_zar.php");
    include("$iut/i_kozep_fej.php");
    
    i_bal_fej();
    i_bal_menu();
    i_bal_kapcs();
    i_bal_link();
    i_bal_zar();
    i_jobb_fej();
    i_jobb_hiba();
    i_jobb_keres();
    $e=sys_env_keres($usercode);
    if ($e<>""){
      i_jobb_regmenu();
    }else{
      i_jobb_bejel();
    }
    i_jobb_szerviz();
    i_jobb_zar();
    i_kozep_fej();
  }  
  
  
  // kozep zar, lab
  
  function design_end(){
    global $template_path,$dir_temp_inc;
        
    $iut="$template_path/$dir_temp_inc";
    
    include("$iut/i_kozep_zar.php");
    
    i_kozep_zar();
  }

  
?>
  