<?php  

function i_bal_zar(){
  global $site_template_path,$default_template,$dir_temp_img;
  
  $k="$site_template_path/$default_template/$dir_temp_img/debian_2.gif";  
  echo("  <div class=ceglogo>");
  echo("    <br><br>");
  echo("    <img src=$k alt=$k>");
  echo("    <br><br><br>");
  echo("  </div>");
  echo("</div>");
}

?>
