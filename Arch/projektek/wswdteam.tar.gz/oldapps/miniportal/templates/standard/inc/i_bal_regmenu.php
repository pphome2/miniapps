<?php  

function i_bal_regmenu(){
  echo("<div class=menutest>");
  site_regmenu();
  echo("</div>");
}

?>