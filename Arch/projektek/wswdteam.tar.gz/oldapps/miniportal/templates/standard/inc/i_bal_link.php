<?php  

function i_bal_link(){
  echo("  <div class=menutest>");
  echo("  <center><b>Aj�nlott oldalak:</b></center>");
  echo("  <div class=menublock>");
  echo("      <a href=http://www.szuvszolnok.hu>Sz�v-Szolnok Kft.</a><br>");
  echo("      <a href=http://www.szuv.hu>Sz�v Zrt.</a><br>");
  echo("      <a href=http://www.albacomp.hu>Albacomp Zrt.</a><br>");
  echo("  </div>");
  echo("  </div>");
}  

?>
