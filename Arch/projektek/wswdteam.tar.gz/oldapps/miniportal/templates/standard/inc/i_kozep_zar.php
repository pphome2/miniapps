<?php

function i_kozep_zar(){
  global $developer,$developer_email,$licence;
  
  echo("</div>");
  echo("  <div class=tartalom2>");
  echo("$licence<br>");
  echo("<a href=mailto:$developer_email>$developer</a>");
  echo("  </div>");
  echo("</div>");
  echo("</div>");
}

?>

