<?php

function i_kozep_fej(){
  global $site_template_path,$default_template,$dir_temp_img;
  
  $k="$site_template_path/$default_template/$dir_temp_img/debian.png";
  echo("<div class=kozepresz>");
  echo("  <div class=fejlec>");
  echo("    <img src=$k alt=$k>");
  echo("  </div>");
  echo("<div class=tartalom2>");
}

?>