<?php  

function i_bal_kapcs(){
  echo("  <div class=menutest>");
  echo("  <center><b>El�rhet�s�geink:</b></center>");
  echo("  <div class=menublock>");
  echo("      <a href=mailto:ppeteri@szuvszolnok.hu>Hibabejelent�s</a><br>");
  echo("  </div>");
  echo("  </div>");
}

?>
