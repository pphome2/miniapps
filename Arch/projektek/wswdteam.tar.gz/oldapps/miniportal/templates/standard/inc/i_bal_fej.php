<?php

function i_bal_fej(){
  global $site_template_path,$default_template,$dir_temp_img;
  
  $k="$site_template_path/$default_template/$dir_temp_img/logo.png";
  echo("<div class=balsav>");
  echo("  <div class=ceglogo>");
  echo("    <br><br>");
  echo("    <img src=$k alt=$k>");
  echo("    <br><br>");
  echo("  </div>");
}

?>