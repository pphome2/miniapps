<?php

function i_bal_bejel(){
  echo("  <div class=menutest>");
  site_bejel();
  echo("  </div>");
}

?>
