<?php  

function i_bal_menu(){
  echo("  <div class=menutest>");
  echo("  <div class=menublock>");
  site_menu();
  echo("  </div>");
  echo("  </div>");
}


?>