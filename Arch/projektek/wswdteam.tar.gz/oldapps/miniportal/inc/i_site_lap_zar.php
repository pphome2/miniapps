<?php

function site_lap_zar(){
  global $s_program,$s_version,$s_copyright;

  echo("<center>");
  echo("-[ $s_copyright -- $s_program $s_version ]-");
  echo("</center>");
  echo("</body></html>");
}

?>

