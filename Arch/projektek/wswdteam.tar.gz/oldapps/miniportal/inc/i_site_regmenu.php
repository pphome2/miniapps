<?php

function site_regmenu(){
  global $sitepage,$administrator;
  global $k_admin,$k_szerk,$k_sajat,$k_level,$k_uzenet;
  
  $m=sys_env_keres($sitepage);
  echo("<center><b>Bejelentkezve</b></center><br>");
  $e=sys_env_fuz();
  sys_env_uj($sitepage,$k_sajat);
  $e=sys_env_fuz();
  $k=sys_kiir("Saj�t adatok");
  echo("<li><a href=./s_robot.php?$e>$k</a><br>");
  sys_env_uj($sitepage,$k_level);
  $e=sys_env_fuz();
  $k=sys_kiir("H�rlev�l");
  echo("<li><a href=./s_robot.php?$e>$k</a><br>");
  sys_env_uj($sitepage,$k_uzenet);
  $e=sys_env_fuz();
  $k=sys_kiir("�zen�fal");
  echo("<li><a href=./s_robot.php?$e>$k</a><br>");
  if (site_user()==$administrator){
    sys_env_uj($sitepage,$k_admin);
    $e=sys_env_fuz();
    $k=sys_kiir("Adminisztr�ci�");
    echo("<br><li><a href=./s_robot.php?$e>$k</a><br>");
    sys_env_uj($sitepage,$k_szerk);
    $e=sys_env_fuz();
    $k=sys_kiir("Szerkeszt�s");
    echo("<li><a href=./s_robot.php?$e>$k</a><br>");
  }
  $k=sys_kiir("Kijelentkez�s");
  echo("<br><li><a href=./s_robot.php>$k</a><br><br>");
  sys_env_uj($sitepage,$m);
}

?>