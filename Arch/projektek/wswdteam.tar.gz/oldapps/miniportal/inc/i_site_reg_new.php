<?php

function site_reg_new(){
  global $sitepage,$newdata;
  
  sys_env_uj($newdata,$newdata);
  $e=sys_env_fuz();
  $ki=sys_kiir("Regisztr�ci�");
  echo("<h2>$ki</h2>");
  echo("<br><br>");
  $ki=sys_kiir("K�sz�nj�k bizalm�t.");
  echo($ki);
  echo("<br><br>");
  $ki=sys_kiir("A regisztr�ci� ut�n k�nnyebben tarthatja a kapcsolatot");
  echo("$ki");
  $ki=sys_kiir("vel�nk, illetve k�rheti h�rlevel�nket is. Nyerem�nyj�t�kainkban");
  echo("$ki");
  $ki=sys_kiir("�s rendezv�nyeinken csak a regisztr�lt �gyfeleink vehetnek r�szt.");
  echo("$ki");
  echo("<br><br>");
  $ki=sys_kiir("Adatait a hat�lyos jogszab�lyok betart�s�val kezelj�k,");
  echo("$ki");
  $ki=sys_kiir("azokat harmadik f�lnek nem adjuk ki, k�r�s�re azonnal t�r�lj�k.");
  echo("$ki");
  echo("<br><br>");
  $ki=sys_kiir("Minden k�rt adatot t�lts�n ki a sikeres regisztr�ci�hoz.");
  echo("$ki");
  echo("<br><br>");
  echo("<center>");
  echo("<form method=post action=./s_robot.php?$e>");
  $ki=sys_kiir("Bejelentkez�si n�v");
  echo("<label class=label_r1>$ki:</label>");
  echo("<input class=input_r1 type=text name=b1 length=120 maxlength=100><br>");
  $ki=sys_kiir("Jelsz�");
  echo("<label class=label_r1>$ki:</label>");
  echo("<input class=input_r1 type=password name=b2 length=120 maxlength=100><br>");
  $ki=sys_kiir("N�v");
  echo("<label class=label_r1>$ki:</label>");
  echo("<input class=input_r1 type=text name=b3 length=1200 maxlength=100><br>");
  $ki=sys_kiir("C�m");
  echo("<label class=label_r1>$ki:</label>");
  echo("<input class=input_r1 type=text name=b4 length=1200 maxlength=100><br>");
  $ki=sys_kiir("E-mail");
  echo("<label class=label_r1>$ki:</label>");
  echo("<input class=input_r1 type=text name=b5 length=120 maxlength=100><br>");
  echo("<br>");
  $ki=sys_kiir("Mehet");
  echo("<input class=button_1 type=submit value=$ki>");
  echo("<center>");
  echo("</form>");
  sys_env_torol($newdata);
}
?>
