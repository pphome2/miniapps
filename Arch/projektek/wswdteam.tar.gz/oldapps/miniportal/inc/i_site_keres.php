<?php

function site_keres(){
  global $site_title,$country_domain;

  $e=sys_env_fuz();
  $ki=sys_kiir("Keres�s");
  echo("    <b>$ki:</b><br><br>");
  echo("  <form method='get' action='http://www.google.com/search'>");
  echo("    <input class=input_k1 type=hidden name='ie' value='iso-8859-2'>");
  echo("    <input class=input_k1 type=hidden name='oe' value='iso-8859-2'>");
  echo("    <input class=input_k1 type=text name='q' size=20 maxlength=255>");
  echo("    <select class=select_k1 name='sitesearch' id='sitesearch'>");
  $ki=sys_kiir("Ezeken a lapokon");
  echo("    <option value='$site_title'>$ki</option>");
  $ki=sys_kiir("Magyar oldalakon");
  echo("    <option value='$country_domain'>$ki</option>");
  $ki=sys_kiir("Weben");
  echo("    <option value=''>$ki</option>");
  echo("    </select><br>");
  echo("    <input type=hidden name='domains' value='$site_title'>");
  $ki=sys_kiir("Mehet");
  echo("    <input class=button_1 type=submit name='btnG' value=$ki>");
  echo("  </form>");
}

?>
