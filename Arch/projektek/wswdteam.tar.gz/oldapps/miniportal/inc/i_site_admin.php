<?php

function site_global_admin(){
  global $deldata,$regdata,$regdb,$k_admin,$sitepage;
    
  echo("<style type=text/css media=screen>");
  echo("<!--");
  echo(".label20 {display:block;width:15%;float:left;margin-bottom:0px;");
  echo("text-align:center;padding-right:10px}");
  echo("-->");
  echo("</style>");
  sys_env_uj($sitepage,$k_admin);
  echo("<br><br>");
  $ki=sys_kiir("Adminisztr�ci�");
  echo("<h2>$ki</h2>");
  echo("<br><br>");
  $ki=sys_kiir("Felhaszn�l�k");
  echo("<h2>$ki</h2>");
  echo("<br><br>");
  echo("<center><b>");
  $ki=sys_kiir("N�v");
  echo("<label class=label20>$ki</label>");
  $ki=sys_kiir("Jelsz�");
  echo("<label class=label20>$ki</label>");
  $ki=sys_kiir("Teljes n�v");
  echo("<label class=label20>$ki</label>");
  $ki=sys_kiir("Lakc�m");
  echo("<label class=label20>$ki</label>");
  $ki=sys_kiir("E-mail");
  echo("<label class=label20>$ki</label>");
  echo("</b><br><br>");
  $ki=sys_kiir("T�r�l");
  $db=0;
  while ($db<=$regdb){
    $tomb=split("-",$regdata[$db]);
    $db+=1;
    if ($tomb[0]<>""){
      sys_env_uj($deldata,$tomb[5]);
      $e=sys_env_fuz();
      echo("<label class=label20>$tomb[0]</label>");
      echo("<label class=label20>***</label>");
      echo("<label class=label20>$tomb[2]</label>");
      echo("<label class=label20>$tomb[3]</label>");
      echo("<label class=label20>$tomb[4]</label>");
      echo("<label class=label20><a href=./s_robot.php?$e>$ki</a>");
      echo("</label>");
      echo("<br><br>");
    }
  }
  echo("<hr width=80%><br>");
  echo("</center>");
  sys_env_torol($deldata);
}
?>
