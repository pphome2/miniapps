<?php

function site_lap_edit(){
  global $newdata,$newmenu,$sitedata,$siteline,$deldata;
  global $k_szerk,$sitepage;
    
  sys_env_uj($newdata,$newdata);
  sys_env_uj($sitepage,$k_szerk);
  $e=sys_env_fuz();
  echo("<br><br>");
  echo("<hr align=center width=70%>");
  echo("<br><br>");
  echo("<br><br>");
  $nev=site_lap_nev();
  $ki=sys_kiir("Szerkeszt�s");
  echo("<h2>$ki ($nev)</h2>");
  echo("<br><br>");
  echo("<br><br>");
  echo("<form method=post action=./s_robot.php?$e>");
  $ki=sys_kiir("Tartalom");
  echo("<b>$ki:</b><br><br>");
  echo("<center>");
  echo("<textarea class=textarea_e1 name=tartalom cols=70 rows=25>");
  site_lap_ki_2();
  echo("</textarea>");
  echo("<br><br>");
  $ki=sys_kiir("Mehet");
  echo("<input class=button_1 type=submit value=$ki>");
  echo("</form>");
  echo("<br><br></center>");
  $ki=sys_kiir("saj�t lapra link: [men�pont sorsz�m mint lent] sz�, amire kattintva �tl�p");
  echo("- $ki.<br>");  
  $ki=sys_kiir("P�ld�ul: [010000] h�rek");
  echo("- $ki.");  
  echo("<br><br><center>");
  echo("<br><br>");
  echo("<hr align=center width=70%>");
  echo("<br><br>");
  echo("</center>");
  $ki=sys_kiir("�j men�elem beilleszt�se");
  echo("<b>$ki</b>");
  echo("<center>");
  echo("<br><br>");
  echo("<form method=post action=./s_robot.php?$e>");
  $ki=sys_kiir("�j men�pont");
  echo("<label class=label_e1>$ki:</label>");
  echo("<input class=input_e1 type=text name=menu1 length=120 maxlength=100><br>");
  $ki=sys_kiir("Men�elem sorsz�ma (000000-999999)");
  echo("<label class=label_e1>$ki:</label>");
  echo("<input class=input_e1 type=text name=menu2 length=120 maxlength=6><br><br>");
  $ki=sys_kiir("Mehet");
  echo("<input class=button_1 type=submit value=$ki>");
  echo("</form>");
  echo("</center>");
  echo("<br><br>");
  $ki=sys_kiir("�j men�elem t�rol�sa ut�n friss�tine kell a lapot, hogy megjelenjen");
  echo("- $ki.</p>");
  echo("<br><br>");
  echo("<hr align=center width=70%>");
  echo("<br><br>");
  $ki=sys_kiir("Men�elem t�rl�se");
  echo("<b>$ki</b>");
  echo("<center>");
  echo("<br><br>");
  $ki=sys_kiir("Sorsz�m");
  echo("<label class=label_e2><b>$ki</b></label>");
  $ki=sys_kiir("N�v");
  echo("<label class=label_e2><b>$ki</b></label>");
  echo("<label class=label_e2><b>-</b></label><br><br>");
  $ki=sys_kiir("T�r�l");
  $db=0;
  while ($db<=$siteline){
    if (substr($sitedata[$db],0,1)=="-"){
      $sz=substr($sitedata[$db],1,6);
      sys_env_uj($deldata,$sz);
      $e=sys_env_fuz();
      $sz=substr($sitedata[$db],8,strlen($sitedata[$db])-9);
      //$sz2=substr($sitedata[$db],1,2);
      $sz2=substr($sitedata[$db],1,6);
      if ($sz<>""){
        echo("<label class=label_e2>$sz2</label>");
        echo("<label class=label_e2>$sz</label>");
        echo("<label class=label_e2><a href=./s_robot.php?$e>$ki</a>");
        echo("</label>");
        echo("<br>");
      }
    }
    $db+=1;
  }  
  echo("</center>"); 
  echo("<br><br>");
  sys_env_torol($deldata);
  sys_env_torol($newdata);
}
?>
