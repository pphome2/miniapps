<?php

function site_lap_nyit(){
  global $site_title;
  
  echo("<!DOCTYPE HTML PUBLIC -//W3C//DTD HTML 4.0//EN>");
  echo("<html>");
  echo("<head>");
  echo("<title>$site_title</title>");
  echo("</head>");
  echo("<body class=body>");
  echo("<center>");
}

?>