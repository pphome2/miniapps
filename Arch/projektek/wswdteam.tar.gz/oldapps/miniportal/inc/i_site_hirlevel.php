<?php

function site_hir_lap(){
  global $deldata,$usercode;
  
  $s=sys_env_keres("$usercode");
  sys_env_uj($deldata,$s);
  $e=sys_env_fuz();
  echo("<br><br>");
  echo("<br><br>");
  $ki=sys_kiir("Regisztr�ci� a h�rlev�lre megt�rt�nt");
  echo("<br>$ki.<br>");
  echo("<br><br>");
  $ki=sys_kiir("H�rlev�l lemomd�s�hoz kattintson");
  echo("<br>$ki <a href=./s_robot.php?$e>");
  $ki=sys_kiir("ide");
  echo(" $ki.</a>");
  echo("<br><br>");
  echo("<br><br>");
  sys_env_torol($deldata);
}

?>

