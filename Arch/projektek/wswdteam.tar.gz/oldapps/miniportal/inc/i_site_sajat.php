<?php

function site_sajat_edit(){
  global $newdata,$regdata,$regdb,$k_sajat,$usercode;
    
  sys_env_uj($newdata,$newdata);
  $e=sys_env_fuz();
  echo("<br><br>");
  echo("<br><br>");
  $ki=sys_kiir("Felhaszn�l�i adatok");
  echo("<h2>$ki</h2>");
  echo("<br><br>");
  echo("<br><br>");
  $db=0;
  $kod=sys_env_keres($usercode);
  $tomb[0]="";
  $tomb[5]="";
  while (($db<=$regdb)and($kod<>$tomb[5])){
    $tomb=split("-",$regdata[$db]);
    $db+=1;
  }
  if ($tomb[0]<>""){
    echo("<center>");
    echo("<form method=post action=./s_robot.php?$e>");
    $ki=sys_kiir("N�v");
    echo("<label class=label_s1>$ki:</label>");
    echo("<input class=input_s1 type=text name=m1 value='$tomb[0]' length=120 maxlength=100><br>");
    $ki=sys_kiir("Jelsz�");
    echo("<label class=label_s1>$ki:</label>");
    echo("<input class=input_s1 type=password name=m2 value='$tomb[1]' length=120 maxlength=100><br>");
    $ki=sys_kiir("Teljes n�v");
    echo("<label class=label_s1>$ki:</label>");
    echo("<input class=input_s1 type=text name=m3 value='$tomb[2]' length=120 maxlength=100><br>");
    $ki=sys_kiir("Lakc�m");
    echo("<label class=label_s1>$ki:</label>");
    echo("<input class=input_s1 type=text name=m4 value='$tomb[3]' length=120 maxlength=100><br>");
    $ki=sys_kiir("E-mail");
    echo("<label class=label_s1>$ki:</label>");
    echo("<input class=input_s1 type=text name=m5 value='$tomb[4]' length=120 maxlength=100><br>");
    echo("</label>");
    echo("<br><br>");
    $ki=sys_kiir("Mehet");
    echo("<input class=button_1 type=submit value=$ki>");
    echo("</form>");
    echo("</center>");
  }else{
    $ki=sys_kiir("Adatok nem el�rhet�k");
    echo("$ki.");    
  }
  echo("<br><br>");
  sys_env_torol($newdata);
}
?>
