<?php

function site_mess_new(){
  global $sitepage,$newdata;

  $m=sys_env_keres($sitepage);  
  sys_env_uj($newdata,$newdata);
  $e=sys_env_fuz();
  echo("<h2>�j �zenet</h2>");
  echo("<br><br>");
  echo("<center>");
  echo("<form method=post action=./s_robot.php?$e>");
  echo("<textarea class=textarea_m1 name=1 cols=50 rows=10></textarea><br><br>");
  echo("<input class=button_1 type=submit value=Mehet>");
  echo("</form>");
  echo("<br><br>");
  echo("</center>");
  sys_env_torol($newdata); 
  sys_env_uj($sitepage,$m);
}

?>
