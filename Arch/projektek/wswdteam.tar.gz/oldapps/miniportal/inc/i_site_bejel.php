<?php

function site_bejel(){
  global $sitepage,$k_regiszt,$k_bejel;
  
  $m=sys_env_keres($sitepage);
  sys_env_uj($sitepage,$k_bejel);
  $e=sys_env_fuz();
  $i=sys_kiir("Bejelentkez�s");
  echo("  <center><b>$i:</b>");
  echo("  <br><br>");
  echo("  <form method=post action=./s_robot.php?$e>");
  $i=sys_kiir("Felhaszn�l�i n�v �s jelsz�");
  echo("  $i:<br>");
  echo("  <input class=input_b1 type=text name=b1 length=20><br>");
  echo("  <input class=input_b1 type=password name=b2 length=20><br>");
  $i=sys_kiir("Mehet");
  echo("  <input class=button_1 type=submit value=$i>");
  echo("  </form>");
  echo("  <br>");
  sys_env_uj($sitepage,$k_regiszt);
  $e=sys_env_fuz();
  $i=sys_kiir("�j felhaszn�l� l�trehoz�sa");
  echo("  <a href=./s_robot.php?$e>$i</a>");
  echo("  <br>");
  echo("  </center>");
  sys_env_uj($sitepage,$m);
}

?>
