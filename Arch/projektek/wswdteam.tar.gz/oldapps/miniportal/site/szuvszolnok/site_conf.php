<?php

  // user config file

  $developer="webmaster@szuvszolnok.hu";
  $developer_email="webmaster@szuvszolnok.hu";
  $licence="[-] 2006. WSTeam";
    
  $site_title="WSTeam";
  
  $country_domain=".hu";
  // for search
  
  $default_template="szuvszolnok";
  // directory name
  
  $file_template_css="design.css";
  $file_template_main="design.php";
  // include design() and design_end() function !!!!!
  
  $site_path="";
  // from s_robot.php
  // if empty, system generate it
  $site_template_path="";
  // from site root
  // if empty, system generate it
  
  $file_lang="/lang/lang_hu.inf";
  
  $administrator="peter";
  // username
  
?>
  