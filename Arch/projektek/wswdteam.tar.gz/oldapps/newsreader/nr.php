<?php

//include("./02i.php");

$app_name="NewsReader v0.3";
$app_copyrigth="(c) 2011. WSWDTeam (Demo)";
$program="nr.php";

$item_name[0][0]="";
$item_line[0][0]="";
$item_db=0;
$item_num=0;
$formdb=0;
$lastdb=20;
$old_key=array("&lt;","&gt;","[CDATA[","]]");
$new_key=array("<",   ">",   "",       "");
$error=false;
$encoding=false;
$ajax=false;
$utf=array("utf","UTF");
$rss_key=array("item","description","pubDate","link","url","title","copyrigth");

$rss_url=array("",
               "http://tortenelemportal.hu/feed/",
               "http://www.hirtv.hu/rss",
               "http://www.origo.hu/contentpartner/rss/itthon/origo.xml",
               "http://f1vilag.hu/rss.xml",
               "http://feeds.feedburner.com/HUP",
               "http://www.hirado.hu/Newsreel/rss/LatestNews.aspx",
               "http://index.hu/24ora/rss/",
               "http://www.metnet.hu/rss/",
               "http://www.hwsw.hu/xml/latest_news_rss.xml");
$rss_name=array("",
               "T�rt�nelemPort�l",
               "H�rTV - friss h�rek",
               "Origo - itthon rovat h�rei",
               "F1Vil�g - Forma-1 h�rek",
               "HUP - Hungarian Unix Portal",
               "H�rad�.hu",
               "Index - 24 �ra h�rei",
               "MetNet - id�j�r�s",
               "HWSW - informatikai h�rmagazin");

$url=$rss_url[0];

error_reporting(0);

main();


function main(){
  global $url,$error,$item_num,$ajax;

  get_param($url);
  if (!$ajax){
    out_head();
  }else{
    out_ajax_head();
  }
  if (!$ajax){
    get_panel($url,true);
  }
  get_rss_xml($url);
  out_rss_xml();
  if (!$ajax){
    get_panel($url,false);
    out_foot();
  }
}


function out_ajax_head(){
  header("Content-Type: text/html; charset=iso-8859-2");
}


function out_head(){
  global $app_name;

  echo("<!DOCTYPE html PUBLIC '-//W3C//DTD XHTML 1.0 Transitional//EN' ");
  echo("'http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd'>");
  echo("<html xmlns='http://www.w3.org/1999/xhtml' lang='hu' xml:lang='hu'>");
  echo("<head>");
  echo("<meta http-equiv='Content-Type' content='text/xml; charset=iso-8859-2' />");
  echo("<style type='text/css' media='screen'>");
  echo("  .Program {display:block;padding:5px 5px 5px 5px;");
  echo("            font-size:14px;font-weight:bold;background-color:teal;color:white;}");
  echo("  .Program2 {display:block;padding:5px 5px 5px 5px;font-size:10px;");
  echo("             text-align:center;font-weight:bold;background-color:teal;color:white;}");
  echo("  .Head {display:block;padding:5px 5px 5px 5px;");
  echo("         font-size:12px;font-weight:bold;background-color:orange;color:white}");
  echo("  .Text {display:block;padding:5px 5px 5px 5px;font-size:10px;");
  echo("         background-color:white;color:black;}");
  echo("  .Text2 {display:block;padding:5px 5px 5px 5px;");
  echo("          text-align:center;font-size:10px;background-color:white;color:black;}");
  echo("  .Border {display:block;border:solid 1px;margin:15px 15px 0px 15px;}");
  echo("</style>");
  echo("<title>$app_name</title>");
  echo("</head>");
  echo("<body>");
}


function get_panel($rssurl,$top){
  global $app_name,$program,$formdb,$rss_name,$rss_url;

  echo("<div class='Border'>");
  echo("<div class='Program'>");
  echo("<b><i>$app_name</i></b>");
  echo("</div>");
  echo("<div class='Text2'>");
  echo("<form method='get' action='./$program'>");
  echo("RSS el�rhet�s�g: ");
  if ($top){
    echo("<select id='t$formdb' name='urss'> ");
    $i=0;
    $l=sizeof($rss_name);
    while ($i<$l){
      echo("<option value='$rss_url[$i]'>$rss_name[$i]</option>");
      $i+=1;
    }
    echo("</select> ");
  }else{
    echo("<input type='text' id='t$formdb' value='$rssurl' name='urss' size='50' maxlength='120' /> ");
  }
  echo("<button type='submit' id='b$formdb' name='b01' value=''>Mehet</button>");
  echo("");
  echo("</form>");
  echo("</div>");
  echo("</div>");
  $formdb+=1;
}


function get_param(&$url){
  global $ajax,$rss_name,$rss_url;

  $elso=false;
  $db=0;
  $url="";
  foreach ($_GET as $key => $data) {
    if ((strlen($data)>7)and(!$elso)){
      $url=$data;
      $elso=true;
    }
    $db+=1;
  }
  if ($db>2){
    $ajax=true;
  }
  return($url);
}


function get_rss_xml($rssurl){
  global $item_num,$item_name,$item_line,$item_db,$rss_key,
         $lastdb,$encoding,$utf;

  //echo("$rssurl");
  $content="";
  if ($rssurl<>""){
    $content=file_get_contents($rssurl);
  }
  if ($content!=""){
    $i=0;
    $y=strlen($content);
    $line="";
    $item_name[0][0]="";
    $item_line[0][0]="";
    $item_db=0;
    while (($x<=$y)and($item_num<=$lastdb)){
      $nch=$content[$x];
      if ($nch=="<"){
        $nch="";
        $l=$x;
        while (($x<=$y)and($content[$x]!=">")){
          $x+=1;
        }
        if ($content[$x]==">"){
          $keyword=substr($content,$l+1,$x-$l-1);
          $keyw=substr($keyword,0,4);
          //$x+=1;
          if ($keyw==$rss_key[0]){  //item
            $item_db=0;
            $item_num+=1;
            $line="";
          }else{
            $jel=substr($keyword,0,1);
            $keyword=substr($keyword,1,strlen($keyword));
            switch ($jel){
              case "/":
                if (in_array($keyword,$rss_key)){
                  //echo("$keyword - $line<br />");
                  $item_name[$item_num][$item_db]=$keyword;
                  $item_line[$item_num][$item_db]=check_line($line);
                  $item_db+=1;
                  $line="";
                }
                break;
              case "?":
                $cc=0;
                $cce=strlen($keyword)-3;
                while ($cc<=$cce){
                $utfe=substr($keyword,$cc,3);
                  if (in_array($utfe,$utf)){
                    $encoding=true;
                    $cc=$cce;
                  }
                  $cc+=1;
                }
                break;
              case "!":
                $jel2=substr($keyword,0,7);
                if ($jel2<>"DOCTYPE"){
                  $line=$keyword;
                }
                break;
              default:
                  $line="";
                break;
            }
          }
        }
      }
      $line=$line.$nch;
      $x+=1;
    }
  }else{
    if ($rssurl<>""){
      notfound();
    }
  }
}


function check_line($chkline){
  global $old_key,$new_key,$encoding,$ajax;

  $chkline=str_replace($old_key,$new_key,$chkline);
  $chkline=strip_tags($chkline);
  if ($encoding){
    $chkline=iconv("UTF-8","ISO-8859-2",$chkline);
  }
  return($chkline);
}


function get_xml_tag($tag,$num){
  global $item_name,$item_line;

  $s=0;
  while (($item_name[$num][$s]!="")and($item_name[$num][$s]!=$tag)){
    $s+=1;
  }
  $v=0;
  if ($item_name[$num][$s]==$tag){
    $v=$item_line[$num][$s];
  }
  return $v;
}


function out_rss_xml(){
  global $item_num,$item_name,$item_line,$item_db;

  $x=0;
  while ($x<$item_num){
    $y=0;
    while ($item_name[$y]!=""){
      $l=$item_name[$x][$y];
      //echo("$l <br />");
      $y+=1;
    }
    if ($x==0){
      echo("<div class='Border'>");
      $sor1=get_xml_tag("title",$x);
      $sor0=get_xml_tag("link",$x);
      echo("<div class='Head'>");
      if ($sor0!=""){
        echo("<a href='$sor0'>$sor1</a>");
      }else{
        echo("$sor1");
      }
      echo("</div>");
      echo("<div class='Text2'>");
      $sor1=get_xml_tag("url",$x);
      if ($sor1!=""){
        echo("<img src='$sor1' alt='$sor1'/><br />");
      }
      $sor1=get_xml_tag("copyright",$x);
      if ($sor1!=""){
        echo("($sor1)<br />");
      }
      echo("</div>");
      echo("</div>");
    }else{
      echo("<div class='Border'>");
      $sor1=get_xml_tag("title",$x);
      $sor0=get_xml_tag("link",$x);
      echo("<div class='Head'>");
      echo("<a href='$sor0'>$sor1</a> ");
      $sor1=get_xml_tag("pubDate",$x);
      if ($sor1!=""){
        $sor1=strtotime($sor1);
        $sor1=date("Y.m.d. G:i",$sor1);
        echo(" $sor1");
      }
      echo("</div>");
      echo("<div class='Text'>");
      echo("<br />");
      $sor1=get_xml_tag("description",$x);
      if ($sor1!=""){
        echo("$sor1<br />");
      }
      echo("<br /><b><a href='$sor0'>Tov�bb</a></b><br /><br />");
      echo("</div>");
      echo("</div>");
    }
    $x+=1;
  }
}


function notfound(){
  global $error;

  $error=true;
  echo("<div class='Border'>");
  echo("<div class='Head'>");
  echo("Hiba t�rt�nt");
  echo("</div>");
  echo("<div class='Text2'>");
  echo("A megadott RSS-el�r�sr�l nem �rhet� el inform�ci�.");
  echo("</div>");
  echo("</div>");
  echo("</body></html>");
}


function out_foot(){
  global $app_name, $app_copyrigth;

  echo("<div class='Border'>");
  echo("<div class='Program2'>");
  echo("$app_name -[ $app_copyrigth ]-");
  echo("</div>");
  echo("<div class='Text2'>");
  echo("<a href='http://jigsaw.w3.org/css-validator/check/referer'>");
  echo("<img style='border:0;width:88px;height:31px' ");
  echo("src='http://jigsaw.w3.org/css-validator/images/vcss' ");
  echo("alt='Valid CSS!' /></a>");
  echo("<a href='http://validator.w3.org/check?uri=referer'>");
  echo("<img style='border:0;' src='http://www.w3.org/Icons/valid-xhtml10' ");
  echo("alt='Valid XHTML 1.0 Transitional' height='31' width='88' /></a>");
  echo("</div>");
  echo("</div>");
  echo("</body></html>");
}

?>
