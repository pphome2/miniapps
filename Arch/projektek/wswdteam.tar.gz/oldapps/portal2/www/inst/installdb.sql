# ----------------------------------------------------------
#  database: mysql, "source installdb.sql"
# ----------------------------------------------------------


create database portal;

use portal;

create table cikk (
    c_id varchar (20),
    c_cim varchar (100),
    c_kuldo varchar (20),
    c_datum varchar (13),
    primary key(c_id)
);

create table tema (
    t_id varchar (20),
    t_cim varchar (100),
    t_kuldo varchar (20),
    t_datum varchar (13),
    primary key(t_id)
);

create table forum (
    f_id varchar (20),
    f_temaid varchar (20),
    f_kuldo varchar (20),
    f_datum varchar (13),
    primary key(f_id)
);

create table hirek (
    h_id varchar (20),
    h_cim varchar (100),
    h_kuldo varchar (20),
    h_datum varchar (13),
    primary key(h_id)
);

create table letoltes (
    l_id varchar (20),
    l_leiras varchar (200),
    l_kuldo varchar (20),
    l_datum varchar (13),
    l_file varchar (80),
    primary key(l_id)
);

create table tagok (
    t_id varchar (20),
    t_nev varchar (20),
    t_emil varchar (100),
    t_jelszo varchar (20),
    t_hirado varchar (1),
    primary key(t_id)
);

#---
