<?php

  // E-Shop --- eshop plugin
  // (verzioadatok a konfiguracios fajlban)
  //
  // fejleszto: Zebulon.hu Team


  // init

  function eshop_init(){
    global $es_del,$es_kosar,$es_tdel,$es_tkosar,
           $dir_plugins,$es_name,$es_css_file,
           $dir_ldata,$default_site,$dir_site,
	   $es_lang_file,$lang_file;


    sys_load_run("$dir_plugins/EShop/eshop_conf.php","");
    $es_lang_file=$es_lang_file.$lang_file;
    //$fs="$dir_plugins/$es_name/$es_css_file";
    //sys_style($fs);
    $es_tdel=sys_env_plugin_find($es_del);
    $es_tkosar=sys_env_plugin_find($es_kosar);
    sys_env_plugin_del($es_del);
    sys_env_plugin_del($es_kosar);
  }

  // vezerles

  function eshop($l,$l2,$l3,$l4,$l5){
    global $dir_plugins,$es_css_file,$es_name,
           $es_list,$es_view,$es_pack,$es_order,
           $es_lang,$es_langdb,$es_lang_file,
           $es_admin;

    eshop_init();
    $f="$dir_plugins/$es_name/$es_lang_file";
    sys_lang_in($f,$es_lang,$es_langdb);
    switch ($l){
      case $es_list:
        eshop_list();
        break;
      case $es_view:
        eshop_view($l2,$l3);
        break;
      case $es_pack:
        eshop_pack(false);
        break;
      case $es_order:
        eshop_order();
        break;
      case $es_admin:
        eshop_admin();
        break;
      default:
        break;
    }
  }

  // eshop menu

  function eshop_amenu(){
    global $dir_plugins,$es_name,$es_data_dir,
           $s_program,$es_lang_file,$es_lang,$es_lang_db,
           $sitepos,$sitepage,$es_rendeles_lap,
           $dir_site,$default_site;

    $fl="$dir_plugins/$es_name/$es_lang_file";
    $fd="$dir_site/$default_site/$es_data_dir";
    if (!is_dir($fd)){
      sys_mkdir($fd);
    }
    $lap=sys_env_find($sitepos);
    $sp=sys_env_find($sitepage);
    sys_env_del($sitepage);
    $n=sys_standard_name($es_rendeles_lap);
    sys_env_new($sitepos,$n);
    $admin=true;
    $ki=sys_line("Megrendel�sek",$fl,$es_lang,$es_lang_db);
    $e=sys_env_plugin_pack();
    echo("<a class='href' href='$s_program?$e'>$ki</a><br />");
    sys_env_new($sitepos,$lap);
    sys_env_new($sitepage,$sp);
  }

  // eshop menu

  function eshop_menu(){
    global $dir_plugins,$es_name,$es_data_dir,
           $s_program,$es_lang_file,$es_lang,$es_lang_db,
           $sitepos,$es_m_hasz,$es_m_szall,
	   $es_m_ved,$es_m_vas,$sitepage,
           $dir_site,$default_site;


    $fl="$dir_plugins/$es_name/$es_lang_file";
    $fd="$dir_site/$default_site/$es_data_dir";
    $lap=sys_env_find($sitepos);
    $sp=sys_env_find($sitepage);
    sys_env_del($sitepage);
    $m=sys_standard_name($es_m_hasz);
    sys_env_new($sitepos,$m);
    $ki=sys_line("A haszn�lat szab�lyai",$fl,$es_lang,$es_lang_db);
    $e=sys_env_pack();
    echo("<a class='href' href='$s_program?$e'>$ki</a><br />");
    $m=sys_standard_name($es_m_szall);
    sys_env_new($sitepos,$m);
    $ki=sys_line("Sz�ll�t�s �s garancia",$fl,$es_lang,$es_lang_db);
    $e=sys_env_pack();
    echo("<a class='href' href='$s_program?$e'>$ki</a><br />");
    $m=sys_standard_name($es_m_vas);
    sys_env_new($sitepos,$m);
    $ki=sys_line("V�s�rl�i szerz�d�s",$fl,$es_lang,$es_lang_db);
    $e=sys_env_pack();
    echo("<a class='href' href='$s_program?$e'>$ki</a><br />");
    $m=sys_standard_name($es_m_ved);
    sys_env_new($sitepos,$m);
    $ki=sys_line("Adatv�delem",$fl,$es_lang,$es_lang_db);
    $e=sys_env_pack();
    echo("<a class='href' href='$s_program?$e'>$ki</a><br />");
    sys_env_new($sitepos,$lap);
    sys_env_new($sitepage,$sp);
  }

  // eshop admin

  function eshop_admin(){
    global $dir_plugins,$es_name,$es_data_dir,
           $s_program,$es_lang_file,$es_lang,$es_lang_db,
           $sitepos,$es_rendeles_lap,$delkod,
           $dir_site,$default_site;

    $fl="$dir_plugins/$es_name/$es_lang_file";
    $fd="$dir_site/$default_site/$es_data_dir";
    $ki=sys_line("Megrendel�sek",$fl,$es_lang,$es_lang_db);
    echo("<br /><b>$ki</b><br /><br />");
    if ($delkod<>""){
      sys_file_del($delkod);
      $delkod="";
    }
    $admin=true;
    $dload=false;
    site_directory_list($fd,$admin,$dload);
  }

  // megrendeles

  function eshop_order(){
    global $dir_plugins,$es_name,$es_data_dir,
           $usercode,$es_kosar_file,$es_kosar_rend,
           $es_lang,$es_lang_db,$specchar2,
           $es_lang_file,$separator,
	   $s_program,$s_bold,$s_ebold,$es_money,
           $dir_site,$default_site,
	   $site_data_css_container;

    $fl="$dir_plugins/$es_name/$es_lang_file";
    $fd="$dir_site/$default_site/$es_data_dir";
    $kdb=eshop_pack(true);
    $user=sys_env_find($usercode);
    if (($kdb>0)and($user<>"")){
      if ($site_data_css_container<>""){
        echo("<label class='label_p'></label>");
        echo("</div><div class='$site_data_css_container'>");
      }else{
        echo("<hr width='85%' />");
      }
      $ki=sys_line("Megrendel� adatai",$fl,$es_lang,$es_lang_db);
      echo("<br /><b>$ki</b><br /><br /><br />");
      $ok=sys_data_post($db,$tkey,$tdata);
      $ud=site_user_data();
      $tomb=split($separator,$ud);
      if ($tomb[0]<>""){
        echo("<center>");
	$ro="";
	if (!$ok){
          $ki=sys_line("A kisz�ll�t�shoz k�rem ellen�rizze,",$fl,$es_lang,$es_lang_db);
          $ki2=sys_line("�s adja meg a k�rt adatokat",$fl,$es_lang,$es_lang_db);
          echo("<label class='es_label_s2'>$ki $ki2.</label>");
          echo("<br /><br />");
	  $d1="";
	  $d2="";
	  $d3="";
	}else{
	  $ro="readonly='readonly'";
	  $d1=$tdata[0];
	  $d2=$tdata[1];
	  $d3=$tdata[2];
	}
        $e=sys_env_pack();
        $ki=sys_line("N�v",$fl,$es_lang,$es_lang_db);
        echo("<label class='es_label_s1'>$ki:</label>");
        echo("<input class='es_input_s1' type='text' id='m1' name='m1' value='$tomb[5]' size='120' maxlength='100' readonly='readonly' /><br />");
        $ki=sys_line("Lakc�m",$fl,$es_lang,$es_lang_db);
        echo("<label class='es_label_s1'>$ki:</label>");
        echo("<input class='es_input_s1' type='text' id='m2' name='m2' value='$tomb[6]' size='120' maxlength='100' readonly='readonly' /><br />");
        $ki=sys_line("E-mail",$fl,$es_lang,$es_lang_db);
        echo("<label class='es_label_s1'>$ki:</label>");
        echo("<input class='es_input_s1' type='text' id='m3' name='m3' value='$tomb[7]' size='120' maxlength='100' readonly='readonly' /><br />");
        echo("<form method='post' action='./$s_program?$e'>");
        $ki=sys_line("Telefonsz�m",$fl,$es_lang,$es_lang_db);
        echo("<label class='es_label_s1'>$ki:</label>");
        echo("<input class='es_input_s1' type='text' id='m4' name='m4' value='$d1' size='120' maxlength='40' $ro /><br />");
        $ki=sys_line("Sz�ml�z�si c�m",$fl,$es_lang,$es_lang_db);
        echo("<label class='es_label_s1'>$ki:</label>");
        echo("<input class='es_input_s1' type='text' id='m5' name='m5' value='$d2' size='120' maxlength='200' $ro /><br />");
        $ki=sys_line("Kisz�ll�t�si c�m",$fl,$es_lang,$es_lang_db);
        echo("<label class='es_label_s1'>$ki:</label>");
        echo("<input class='es_input_s1' type='text' id='m6' name='m6' value='$d3' size='120' maxlength='200' $ro /><br />");
        echo("<br /><br />");
	if (!$ok){
          $ki=sys_line("Megrendelem a megismert felt�telek alapj�n a megadott adatokkal",$fl,$es_lang,$es_lang_db);
          $ki2=sys_line("a lapon szerepl� term�keket",$fl,$es_lang,$es_lang_db);
          echo("<label class='es_label_s2'>$ki $ki2.</label>");
          echo("<br />");
          $ki=sys_line("Minden mez� kit�lt�se k�telez�",$fl,$es_lang,$es_lang_db);
          echo("<label class='es_label_s2'><b>$ki.</b></label>");
          echo("<br /><br />");
          $ki=sys_line("Megrendel�s",$fl,$es_lang,$es_lang_db);
          //echo("<input class=es_button_s1 type=submit value=$ki />");
          echo("<button class='es_button_s1' id='esb' name='esb' type='submit' value='$ki'>$ki</button>");
          echo("</form>");
	}else{
          $ki=sys_line("A megrendel�st a megadott param�terekkel r�gz�tett�k",$fl,$es_lang,$es_lang_db);
          echo("<label class='es_label_s2'>$ki.</label>");
          $ki=sys_line("Az adatok ellen�rz�se ut�n a megrendl�st teljes�tj�k",$fl,$es_lang,$es_lang_db);
          echo("<label class='es_label_s2'>$ki.</label>");
          $ki=sys_line("K�sz�nj�k a v�s�rl�st",$fl,$es_lang,$es_lang_db);
          echo("<label class='es_label_s2'>$ki.</label>");
          echo("<br /><br />");
	  $uc=sys_env_find($usercode);
	  $datum=date("Ymd");
	  $ido=date("His");
	  $n=sys_standard_name($es_kosar_file);
          $fd2="$fd/$es_kosar_rend.$datum-$ido.$uc";
          $fd="$fd/$n.$uc";
          if (file_exists($fd)) {
            sys_file_in($fd,$sor);
	    $sdb=count($sor);
	    $osszar=0;
	    $x=0;
	    $ski[0]="";
	    $kidb=0;
            while ($x<$sdb) {
              if (strlen($sor[$x])<>0){
	        $td=explode("=",$sor[$x]);
		if (strlen($td[1])==0){
		  $td[1]="-";
		}
	        $ski[$kidb]="$td[0] --- [$s_bold] $td[1] $es_money [$s_ebold]";
		$kidb+=1;
	        $osszar=$osszar+$td[1];
	      }
	      $x+=1;
            }
	    sys_file_del($fd);
            $ki=sys_line("�sszesen",$fl,$es_lang,$es_lang_db);
	    $kidb+=1;
	    $ski[$kidb]=" $specchar2";
	    $kidb+=1;
	    $ski[$kidb]="[$s_bold] $ki: $osszar $es_money [$s_ebold]";
            $ki=sys_line("N�v",$fl,$es_lang,$es_lang_db);
	    $kidb+=1;
	    $ski[$kidb]="[$s_bold] $ki [$s_ebold]: $tomb[5]";
            $ki=sys_line("Lakc�m",$fl,$es_lang,$es_lang_db);
	    $kidb+=1;
	    $ski[$kidb]="[$s_bold] $ki [$s_ebold]: $tomb[6]";
            $ki=sys_line("E-mail",$fl,$es_lang,$es_lang_db);
	    $kidb+=1;
	    $ski[$kidb]="[$s_bold] $ki [$s_ebold]: $tomb[7]";
            $ki=sys_line("Telefonsz�m",$fl,$es_lang,$es_lang_db);
	    $kidb+=1;
	    $ski[$kidb]="[$s_bold] $ki [$s_ebold]: $d1";
            $ki=sys_line("Sz�ml�z�si c�m",$fl,$es_lang,$es_lang_db);
	    $kidb+=1;
	    $ski[$kidb]="[$s_bold] $ki [$s_ebold]: $d2";
            $ki=sys_line("Kisz�ll�t�si c�m",$fl,$es_lang,$es_lang_db);
	    $kidb+=1;
	    $ski[$kidb]="[$s_bold] $ki [$s_ebold]: $d3";
	    $kidb+=1;
	    $ski[$kidb]="-";
            sys_file_out($fd2,$ski);
          }
	}
        echo("</center>");
      }
    }
  }

  // kosar

  function eshop_pack($order){
    global $es_kosar,$es_vjel,$dir_plugins,$es_name,$es_data_dir,
           $usercode,$es_kosar_file,$es_lang,$es_lang_db,
           $es_lang_file,$es_money,$es_del,$s_program,
           $specchar2,$es_tdel,$es_tkosar,$sitepos,$s_program,
           $dir_site,$default_site,$usercode;

    $fl="$dir_plugins/$es_name/$es_lang_file";
    $fd="$dir_site/$default_site/$es_data_dir";
    $write=false;
    if ($es_tdel==""){
      $es_tdel=-1;
    }
    sys_env_plugin_del($es_kosar);
    $uc=sys_env_find($usercode);
    $es_kosar_file=sys_standard_name($es_kosar_file);
    $fd="$fd/$es_kosar_file.$uc";
    $osszar=0;
    $db=0;
    $kidb=0;
    if (file_exists($fd)) {
      sys_file_in($fd,$tc);
      $x=0;
      $y=count($tc);
      $kidb=0;
      while ($x<$y) {
        if (strlen($tc[$x])<>0){
	  $db+=1;
	  if ($x<>$es_tdel){
	    $td=explode("=",$tc[$x]);
	    $tomb[$kidb][0]=$td[0];
	    $tomb[$kidb][1]=$td[1];
	    $kidb+=1;
	  }else{
	    $write=true;
	  }
	}
	$x+=1;
      }
    }
    if ($es_tkosar<>""){
      $t=explode($es_vjel,$es_tkosar);
      $t[0]=sys_unstandard_name($t[0]);
      $tomb[$kidb][0]=$t[0];
      $tomb[$kidb][1]=$t[1];
      $kidb+=1;
      $write=true;
    }
    $user=sys_env_find($usercode);
    if (($kidb>0)and($user<>"")){
      $ki=sys_line("Kos�r tartalma",$fl,$es_lang,$es_lang_db);
      echo("<br /><b>$ki</b><br /><br /><center>");
      echo("<table class='table_1' border='1'>");
      $ki=sys_line("T�r�l",$fl,$es_lang,$es_lang_db);
      $x=0;
      while($x<$kidb){
        $c=$tomb[$x][0];
        if (strlen($c)<>0){
          echo("<tr>");
	  $c=$tomb[$x][0];
	  echo("<td width='45%' align='left'>$c</td>");
	  $c=$tomb[$x][1];
	  echo("<td width='25%' align='right'>$c ,- $es_money</td>");
	  if (!$order){
            sys_env_plugin_new($es_del,"$x");
	    $e=sys_env_plugin_pack();
	    echo("<td align='center'><a class='href' href=$s_program?$e>$ki</a></td>");
	  }
	  echo("</tr>");
	  $osszar=$osszar+$tomb[$x][1];
	}
        $x+=1;
      }
      $ki=sys_line("�r �sszesen",$fl,$es_lang,$es_lang_db);
      echo("<tr><td align='center'><b>$ki</b></td>");
      echo("<td align='right'><b>$osszar ,- $es_money</b></td>");
      sys_env_plugin_del($es_del);
      if (!$order){
        $ki=sys_line("Megrendelem",$fl,$es_lang,$es_lang_db);
        $ki2=sys_line("Megrendel�s",$fl,$es_lang,$es_lang_db);
        $l=sys_standard_name($ki2);
        $m=sys_env_find($sitepos);
        sys_env_new($sitepos,$l);
        $e=sys_env_plugin_pack();
        echo("<td align='center'><b><a class='href' href=$s_program?$e>$ki</a></b></td>");
        sys_env_new($sitepos,$m);
      }
      echo("</tr></table>");
      echo("</center><br /><br />");
    }else{
      $ki=sys_line("A kos�r m�g �res",$fl,$es_lang,$es_lang_db);
      echo("<br />$ki.<br /><br />");
    }
    if ($write){
      $x=0;
      $kis=0;
      $kisor[0]="";
      while ($x<$kidb) {
        $c=$tomb[$x][0];
        if (strlen($c)<>0){
	  $c1=$tomb[$x][1];
          $kisor[$kis]="$c=$c1$specchar2";
	  $kis+=1;
	}
	$x+=1;
      }
      sys_file_out($fd,$kisor);
    }
    return($kidb);  }

  // egy termek adatai, kosar link

  function eshop_view($n,$a){
    global $sitepos,$sitedata,$siteline,$default_site,
           $k_szerk,$l_open,$l_end,$s_program,$s_plugin,
           $s_program,$sitepage,$k_print,$editor,
           $dir_plugins,$es_css_file,$es_name,$es_lang_file,
           $es_lang,$es_langdb,$es_mess,$es_vjel,
           $dir_site,$default_site,$dir_data,
           $es_kosar,$es_kosar_file,$usercode,
	   $site_data_css_container;

    $fl="$dir_plugins/$es_name/$es_lang_file";
    $lap=sys_env_find($sitepos);
    $user=false;
    if (sys_env_find($usercode)<>""){
      $user=true;
    }
    if ($lap==""){
      $lap=$default_site;
    }
    $l=sys_unstandard_name($lap);
    $bord=0;
    $f="$lap";
    site_in($f);
    $x=0;
    $l="";
    echo("<center><table class='table_1' border='$bord'><tr>");
    while ($x<$siteline) {
      $s=$sitedata[$x];
      $v0=0;
      while ($v0<strlen($s)){
        if (substr($s,$v0,1)==$l_open){
  	  $v1=$v0+1;
	  while (($v1<strlen($s))and(substr($s,$v1,1)<>$l_end)){
	    $v1+=1;
  	  }
	  if (substr($s,$v1,1)==$l_end){
	    $s2=substr($s,$v0+1,$v1-$v0-1);
	    $t=explode(' ',$s2);
	    if (($t[0]<>$s_plugin)and($t[0]<>$s_program)){
  	      $l=site_lang($s2);
	    }else{
	      $s="";
	      $l="";
	    }
	    $s=substr($s,0,$v0).$l.substr($s,$v1+1,strlen($s));
	  }
	  $v0=0;
  	}
        $v0+=1;
      }
      if ($s<>""){
	if (substr($s,9,4)=="<img"){
	  echo("</td></tr><tr><td align='left' valign='bottom'>");
	  echo($link);
	  echo("</td></table><br />");
	  echo("<br /><center><table class='table_1' border='$bord'>");
	  $s="<td width='30%' align='center' valign='top' rowspan='2'>$s</td>";
	  $s="$s<td align='left' valign='top'>";
	}
	echo("$s");
      }
        $x+=1;
    }
    $link=sys_standard_name(strip_tags($s));
    $es_kosar_file=sys_standard_name($es_kosar_file);
    sys_env_new($sitepos,$es_kosar_file);
    $n2=sys_standard_name($n);
    sys_env_plugin_new($es_kosar,"$n2$es_vjel$a");
    $e=sys_env_plugin_pack();
    if ($user){
      $ki=sys_line("Kos�rba teszem",$fl,$es_lang,$es_lang_db);
      $link="<a class='href' href='$s_program?$e'>$ki</a>";
    }
    sys_env_plugin_del($es_kosar);
    echo("</td></tr><tr><td align='left' valign='bottom'>");
    echo($link);
    echo("</td></table></center><br />");
    if ($site_data_css_container<>""){
      echo("<label class='label_p'></label>");
      echo("</div><div class='$site_data_css_container'>");
    }else{
      echo("<hr width='85%' />");
    }
    sys_env_new($sitepos,$lap);
    if ($editor<>true){
      $ki=sys_line("V�lem�nyek a term�kr�l",$fl,$es_lang,$es_lang_db);
      echo("<br /><b>$ki</b><br /><br />");
      $fu="$dir_data/$f$es_mess";
      $ki=sys_line("V�lem�ny a term�kr�l",$fl,$es_lang,$es_lang_db);
      site_message_wall($fu,$ki);
    }
  }

  // termeklista

  function eshop_list(){
    global $sitepos,$sitedata,$siteline,$default_site,
           $k_szerk,$l_open,$l_end,$s_program,$s_plugin,
           $s_program,$sitepage,$k_print,$printed,$editor,
           $dir_plugins,$es_css_file,$es_name,$es_lang_file,
           $es_lapdb,$es_lang,$es_lang_db,$es_lapsz,$s_img,
	   $site_data_css_container;

    $fl="$dir_plugins/$es_name/$es_lang_file";
    $lap=sys_env_find($sitepos);
    if ($lap==""){
      $lap=$default_site;
    }
    $l=sys_unstandard_name($lap);
    $bord=0;
    if ($printed){
      $bord=1;
    }
    $f="$lap";
    $alap=sys_env_plugin_find($es_lapsz);
    sys_env_plugin_del($es_lapsz);
    if ($alap==""){
      $alap=1;
    }
    $tol=($alap-1)*$es_lapdb;
    site_in($f);
    $x=0;
    $link="";
    $kidb=0;
    $uj=true;
    $linkname=false;
    $odb=0;
    while ($x<$siteline) {
      $s=$sitedata[$x];
      $v0=0;
      while ($v0<strlen($s)){
        if (substr($s,$v0,1)==$l_open){
          $v1=$v0+1;
          while (($v1<strlen($s))and(substr($s,$v1,1)<>$l_end)){
            $v1+=1;
          }
          if (substr($s,$v1,1)==$l_end){
            $s2=substr($s,$v0+1,$v1-$v0-1);
            $t=explode(' ',$s2);
            $l="";
            if (($t[0]<>$s_plugin)and($t[0]<>$s_program)){
              $l=site_lang($s2);
            }else{
              $s="";
            }
            $s=substr($s,0,$v0).$l.substr($s,$v1+1,strlen($s));
          }
          $v0=0;
        }
        $v0+=1;
      }
      if (substr($s,1,3)=="<hr"){
        $odb+=1;
        $uj=true;
        $s="";
      }
      if (($odb>=$tol)and($odb<($tol+$es_lapdb))){
        if ($uj){
          if ($kidb>0){
            if (($printed<>true)and($editor<>true)){
              $link=sys_standard_name(strip_tags($link));
              sys_env_new($sitepos,$link);
              $e=sys_env_plugin_pack();
              $ki=sys_line("R�szletek",$fl,$es_lang,$es_lang_db);
              $link="</td></tr><tr><td align='left' valign='bottom'>";
              $link="$link<a class='href' href='$s_program?$e'>$ki</a>";
            }
            echo("$link");
            $link="";
            echo("</td></tr></table></center><br />");
            if (($printed<>true)and($editor<>true)){
              if ($site_data_css_container<>""){
	        echo("<label class='label_p'></label>");
                echo("</div><div class='$site_data_css_container'>");
              }else{
                echo("<hr width='85%' />");
	      }
            }
          }
          $uj=false;
          $kidb+=1;
        }
        if (substr($s,9,4)=="<img"){
          echo("<br /><center><table class='table_1' border='$bord'>");
          $s="<tr><td width='30%' align='center' valign='top' rowspan='2'>$s";
          echo("$s");
          echo("</td><td align='left' valign='top'>");
          $linkname=true;
        }else{
          echo("$s");
          if ($linkname){
            $linkname=false;
            $link=$s;
          }
        }
      }
      $x+=1;
    }
    if ($kidb>0){
      $link=trim($link," ");
      $link=sys_standard_name(strip_tags($link));
      sys_env_new($sitepos,$link);
      $e=sys_env_plugin_pack();
      $ki=sys_line("R�szletek",$fl,$es_lang,$es_lang_db);
      $link="</td></tr><tr><td align='left' valign='bottom'>";
      $link="$link<a class='href' href='$s_program?$e'>$ki</a>";
      echo("$link");
      echo("</td></tr></table></center><br />");
    }
    sys_env_new($sitepos,$lap);
    if ($site_data_css_container<>""){
      echo("<label class='label_p'></label>");
      echo("</div><div class='$site_data_css_container'>");
    }else{
      echo("<hr width='85%' />");
    }
    site_pageing($odb,$es_lapdb,$alap,$es_lapsz);
  }


?>
