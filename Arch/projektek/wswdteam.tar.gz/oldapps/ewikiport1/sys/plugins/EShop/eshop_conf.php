<?php

  // E-Shop --- eshop plugin
  // (verzioadatok a konfiguracios fajlban)
  //
  // fejleszto: Zebulon.hu Team

  global $es_name,$es_css_file,$es_lang_file,$es_data_dir,
         $es_class_open,$es_list,$es_view,$es_pack,$es_order,
	 $es_admin,$es_m_hasz,$es_m_szall,$es_m_vas,$es_m_ved,
	 $es_lapdb,$es_lapsz,$es_kosar,$es_del,$es_kosar_file,
	 $es_kosar_rend,$es_rendeles_lap,$es_lang,$es_langdb,
	 $es_mess,$es_vjel,$es_money,$es_tdel,$es_tkosar;

  $es_name="EShop";
  $es_css_file="eshop.css";
    
  $es_lang_file="lang/";
  $es_data_dir="es_data";

  $es_class_open="container";
  
  $es_list="l";
  $es_view="v";
  $es_pack="p";
  $es_order="o";
  $es_admin="a";
  
  $es_m_hasz="Ahaszn�lat szab�lyai";
  $es_m_szall="Sz�ll�tasi felt�telek";
  $es_m_vas="V�s�rl�i szerz�d�s";
  $es_m_ved="Adatv�delem";
  
  $es_lapdb=2;
  $es_lapsz="tlap";
  $es_kosar="kosar";
  $es_del="kdel";
  $es_kosar_file="Kos�r";
  $es_kosar_rend="Megrendelve";
  $es_rendeles_lap="Megrendel�sek";
  $es_lang[0][0]="";
  $es_langdb=0;
  $es_mess="-velemeny";
  $es_vjel="__";
  $es_money="Ft";
  $es_tdel="";
  $es_tkosar="";
  
?>
