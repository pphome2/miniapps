<?php

  global $dchanger_name,$dc_reg_user_default_template,
         $dc_css_file,$dc_data_file,$dc_choose_data_file,
	 $dc_choose_template,$dc_init_ok,
	 $dc_choose_template_desc,
	 $dc_lang_file,$dc_lang,$dc_lang_db;
	 
  $dchanger_name="Dchanger";
  
  $dc_reg_user_default_template="WSWDTeam";
  
  $dc_css_file="dchanger.css";
  $dc_data_file="data/dchanger.txt";
  $dc_choose_data_file="data/dchoose.php";
  
  $dc_lang_file="lang/";
  $dc_lang[0][0]="";
  $dc_langdb=0;
  
  $dc_init_ok=false;
  
  $dc_choose_template=array();
  $dc_choose_template_desc=array();
  
?>
