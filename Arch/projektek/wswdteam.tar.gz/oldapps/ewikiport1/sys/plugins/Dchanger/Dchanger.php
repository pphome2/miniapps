<?php

  sys_load_run("$dir_plugins/Dchanger/dchanger_conf.php","");

  function dchanger_init(){
    global $dc_reg_user_default_template,
           $default_template,$usercode,
	   $dir_plugins,$dchanger_name,
	   $dc_css_file,$dir_site,$default_site,
	   $dc_data_file,$separator,$dchanger_name,
	   $dc_choose_data_file,$dc_init_ok,
	   $dc_choose_template,$dc_choose_template_desc,
	   $dc_lang_file,$lang_file,$lang_system;

    $dc_init_ok=true;
    //$fs="$dir_plugins/$dchanger_name/$dc_css_file";
    //sys_style($fs);
    $uc=sys_env_find($usercode);
    $fn="$dir_site/$default_site/$dc_choose_data_file";
    sys_load_run($fn,"");
    if ($uc<>""){
      $fn="$dir_site/$default_site/$dc_data_file";
      sys_file_in($fn,$ut);
      $xx=count($ut);
      if ($xx>0){
        $poz="";
        $y=0;
	while ($y<$xx){
	  $dct=explode($separator,$ut[$y]);
	  if ($dct[0]==$uc){
	    $poz=$dct[1];
	    $y=$xx;
	  }
	  $y+=1;
	}
	if ($poz<>""){
	  $default_template=sys_standard_name($poz);
	}
      }else{
        if ($dc_reg_user_default_template<>""){
          $default_template=$dc_reg_user_default_template;
        }
      }
    }
  }

  function dchanger_change(){
    global $usercode,$s_program,$default_template,
           $dc_choose_template,$dc_choose_template_desc,
	   $dc_data_file,$dc_init_ok,$lang_file,
	   $dir_site,$default_site,$usercode,$separator,
	   $s_program,$dc_lang_file,$dchanger_name,$dir_plugins,
	   $dc_lang,$dc_lang_db,$dc_lang_file,$lang_file,
	   $lang_system;

    if (!$dc_init_ok){
      dchanger_init();
    }
    dc_lang_init($lang_system);
    $flang="$dir_plugins/$dchanger_name/$dc_lang_file$lang_file";
    $x=count($dc_choose_template);
    if ($x>0){
      $ok=sys_data_post($db,$dk,$de);
      if ($ok){
        $fn="$dir_site/$default_site/$dc_data_file";
        $ut[0]="";
        sys_file_in($fn,$ut);
	$uc=sys_env_find($usercode);
	$xx=count($ut);
	$poz=$xx;
	if ($xx>0){
	  $y=0;
	  while ($y<$xx){
	    $dct=explode($separator,$ut[$y]);
	    if ($dct[0]==$uc){
	      $poz=$y;
	      $y=$xx;
	    }
	    $y+=1;
	  }
	}
	//$de[$db]=sys_standard_name($de[$db]);
	$ut[$poz]=$uc.$separator.$de[0];
	site_user_check($ut,$separator);
	sys_file_out($fn,$ut);
	$e=sys_env_pack();
        $dc_save_message=sys_line("A be�ll�t�s mentve, itt friss�theti az oldalt.",$flang,$dc_lang,$dc_lang_db);
	echo("<br /><br /><a class='href' href='$s_program?$e'>$dc_save_message</a><br /><br />");
      }
      $e=sys_env_pack();
      //echo("-$s_program,$e-");
      echo("<form method='post' action='./$s_program?$e'>");
      echo("<br /><label class='dc_label_1'> ");
      echo("<select id='s1' name='s1'>");
      $y=0;
      while ($y<$x){
        $dcc=sys_unstandard_name($dc_choose_template[$y]);
        if ($dc_choose_template[$y]==$default_template){
          echo("<option selected='selected'>$dcc");
	}else{
          echo("<option>$dcc");
	}
        $y+=1;
      }
      echo("</select></label>");
      echo("<label class='dc_label_2'>");
      $dc_ok_button=sys_line("Mehet",$flang,$dc_lang,$dc_lang_db);
      //echo("<input class=dc_button_1 type=submit value=$dc_ok_button> /");
      echo("<button class='button_1' id='cbb' name='cbb' type='submit' value='$dc_ok_button'>$dc_ok_button</button>");
      echo("</label>");
      echo("</form>");
      echo("<br /><br /><br /><br />");
      $x=count($dc_choose_template_desc);
      $y=0;
      while ($y<$x){
        echo("<label class='dc_label_3'>$dc_choose_template_desc[$y]</label><br />");
        $y+=1;
      }
      echo("<br /><br /><br />");
    }
  }

?>
