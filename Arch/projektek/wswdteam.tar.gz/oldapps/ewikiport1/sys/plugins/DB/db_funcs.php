<?php

  // ellenorzo fuggvenyek, visszateres hibauzenet
  function db_noempty($data){
    $ret="";
    if ($data==""){
      $ret="Mez� nem lehet �res.";
    }
    return($ret);
  }

?>
