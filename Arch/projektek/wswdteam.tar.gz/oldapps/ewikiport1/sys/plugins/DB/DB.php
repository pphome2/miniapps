<?php

  sys_load_run("$dir_plugins/DB/db_conf.php","");
  sys_load_run("$dir_plugins/DB/db_funcs.php","");

  // alapbe�ll�t�sok

  function db_init(){
    global $dir_plugins,$db_plugin_name,$db_css_file,
           $db_idx_label,$db_idx,$db_func_label,$db_func,
	   $dir_site,$default_site,$db_dir_data,
	   $db_lang_file,$lang_file;

    $db_lang_file=$db_lang_file.$lang_file;
    //$fs="$dir_plugins/$db_plugin_name/$db_css_file";
    //sys_style($fs);
    $db_idx=sys_env_plugin_find($db_idx_label);
    sys_env_plugin_del($db_idx_label);
    $db_func=sys_env_plugin_find($db_func_label);
    sys_env_plugin_del($db_func_label);
    $fd="$dir_site/$default_site/$db_dir_data";
    if (!is_dir($fd)){
      sys_mkdir($fd);
    }
  }

  //vez�rl�s

  function db($p,$p1,$p2,$p3){
    global $dir_plugins,$db_plugin_name,$db_lang_file,
           $db_lang,$db_lang_db,$db_idx,$db_table,
           $db_m_add,$db_m_list,$db_m_del,
           $db_dir_data,$db_file_data,$db_idx,
           $default_site,$dir_site,$db_idx_label,
           $db_table_name,$db_table_len,$db_table_idx,
           $db_table,$db_table_space,$db_table_funcs,
           $db_func;

    db_init();
    if ($p<>""){
      $db_file_data=$p;
    }
    $flang="$dir_plugins/$db_plugin_name/$db_lang_file";
    $fd="$dir_site/$default_site/$db_dir_data/$db_file_data".".php";
    if (is_file($fd)){
      sys_load_run("$fd","");
      if ($p1<>""){
        $db_func=$p1;
      }
      echo("<center><b><i>$db_table</i></b></center><br /><br /><br />");
      $un=site_user("");
      if ($un<>""){
        switch ($db_func){
          case $db_m_add:
	    if ($db_idx<>""){
	      db_record();
	    }
	    db_data();
            break;
          case $db_m_list:
	    if ($db_idx<>""){
	      db_del();
	    }
	    db_list();
            break;
          case $db_m_del:
	    db_del();
            break;
          default:
	    if ($db_idx<>""){
	      db_record();
	    }
	    db_data();
            break;
        }
      }else{
        switch ($p){
          default:
            $ki=sys_line("Nincs bejelentkezve",$flang,$db_lang,$db_lang_db);
            echo("<br />$ki.<br /><br />");
            break;
        }
      }
    }else{
      $ki=sys_line("Modul konfigur�l�sa nem megfelel�.",$flang,$db_lang,$db_lang_db);
      echo("<br />$ki.<br /><br />");
    }
  }

  // rekord torlese

  function db_del(){
    global $dir_site,$default_site,
           $db_dir_data,$db_table,
           $db_table_funcs,$db_file_index,
           $db_table_idx,$db_table_name,
           $db_sep_char,$db_idx;

    if ($db_idx<>""){
      $fx=sys_standard_name($db_idx);
      $tnev=sys_standard_name($db_table);
      $fa="$dir_site/$default_site/$db_dir_data/$tnev/$fx";
      $ft="$dir_site/$default_site/$db_dir_data/$tnev/$db_file_index";
      sys_file_del($fa);

      sys_file_in_lock($ft,$ti);
      $x=0;
      $y=count($ti);
      $t=explode($db_sep_char,$ti[$x]);
      $dbn=sys_unstandard_name($db_idx);
      while (($x<$y)and($t[0]<>$dbn)){
        $x+=1;
        $t=explode($db_sep_char,$ti[$x]);
      }
      $ti[$x]="";
      sort($ti);
      sys_file_out_lock($ft,$ti);
    }
  }

  // adatlista

  function db_list(){
    global $dir_plugins,$db_plugin_name,$db_lang_file,
           $db_lang,$db_lang_db,$db_idx,$db_table,
           $dir_site,$default_site,$db_dir_data,
           $db_table_name,$db_table_len,$db_table_idx,
           $db_table_space,$db_file_index,
           $db_rec_label,$db_idx_label,$s_program,
           $db_sep_char,$s_program,$db_idx_label,
           $sitepos,$db_file_data,$db_file_data,
	   $db_m_add,$db_func_label,$db_m_del,
           $printed,$db_idx_data,$user_admin;

    $flang="$dir_plugins/$db_plugin_name/$db_lang_file";
    $tnev=sys_standard_name($db_table);
    $ld="$flang/$db_table";
    //if (!is_dir($ld)){
      //sys_mkdir($ld);
    //}
    $fi="$dir_site/$default_site/$db_dir_data/$tnev/$db_file_index";
    sys_file_in($fi,$ti,true);
    $x=0;
    $y=count($ti);
    $ap=sys_env_find($sitepos);
    if ($y>0){
      $ki=sys_line("T�rl�s",$flang,$db_lang,$db_lang_db);
      echo("<center>");
      if ($printed){
        echo("<table class='table_1' border='1'>");
      }else{
        echo("<div class='page_table'>");
      }
      $fdb=0;
      while ($x<$y){
        $t=explode($db_sep_char,$ti[$x]);
	if ($t[0]<>""){
	  $fdb+=1;
	  $tl=$db_table." - ".$db_file_data;
	  $tl=sys_standard_name($tl);
	  sys_env_new($sitepos,$tl);
	  $ts=sys_standard_name($t[0]);
	  sys_env_plugin_new($db_idx_label,$ts);
	  sys_env_plugin_new($db_func_label,$db_m_add);
	  $e=sys_env_plugin_pack();
	  if ($t[1]==""){
	    $t[1]="-";
	  }
	  if ($t[2]==""){
	    $t[2]="-";
	  }
	  if ($t[3]==""){
	    $t[3]="-";
	  }
	  if ($t[4]==""){
	    $t[4]="-";
	  }
          if ($printed){
	    echo("<tr>");
	    if ($t[0]==""){
	      $t[0]="<br />";
	    }
	    echo("<td width='20%' align='center'>$t[0]");
	    echo("</td>");
	    if ($t[1]==""){
	      $t[1]="<br />";
	    }
	    echo("<td width='15%' align='center'>$t[1]");
	    echo("</td>");
	    if ($t[2]==""){
	      $t[2]="<br />";
	    }
	    echo("<td width='15%' align='center'>$t[2]");
	    echo("</td>");
	    if ($t[3]==""){
	      $t[3]="<br />";
	    }
	    echo("<td width='15%' align='center'>$t[3]");
	    echo("</td>");
	    if ($t[4]==""){
	      $t[4]="<br />";
	    }
	    echo("<td width='15%' align='center'>$t[4]");
	    echo("</td>");
	    echo("</tr>");
          }else{
            echo("<label class='l-4_table-1'>
	         <a class='href' href='$s_program?$e'>$t[0]</a>
	         </label>");
            echo("<label class='l-4_table-2'>$t[1]</label>");
            echo("<label class='l-4_table-3'>$t[2]</label>");
	    sys_env_new($sitepos,$ap);
	    sys_env_plugin_new($db_func_label,$db_m_del);
	    $e=sys_env_plugin_pack();
            echo("<label class='l-4_table-4'>
	         <a class='href' href='$s_program?$e'>$ki</a>
	         </label>");
	    sys_env_plugin_del($db_idx_data);
            echo("<label class='l-4_table-empty'></label>");
            echo("<label class='l-4_table-2'>$t[3]</label>");
            echo("<label class='l-4_table-3'>$t[4]</label>");
            echo("<label class='l-4_table-empty'>-</label>");
	  }
	}
        $x+=1;
      }
      if ($printed){
        echo("</table>");
      }else{
        echo("<label class='l-1_table-empty'></label><br />");
        $ki1=sys_line("�sszesen",$flang,$db_lang,$db_lang_db);
        $ki2=sys_line("db",$flang,$db_lang,$db_lang_db);
        echo("$ki1: $fdb $ki2.");
        echo("</div>");
      }
      echo("</center><br />");
    }else{
      $ki=sys_line("Nincs el�rhet� adat",$flang,$db_lang,$db_lang_db);
      echo("$ki.");
      echo("<br /><br />");
    }
    sys_env_new($sitepos,$ap);
  }

  // rekord tarolasa

  function db_record(){
    global $dir_site,$default_site,
           $db_dir_data,$db_table,
           $db_table_funcs,$db_file_index,
           $db_table_idx,$db_table_name,
           $db_sep_char;

    $ok=sys_data_post($db,$tk,$te);
    if ($ok){
      $ellenor=true;
      $x=0;
      $y=count($db_table_funcs);
      while ($x<$y){
        if ($db_table_funcs[$x]<>""){
          $er=call_user_func($db_table_funcs[$x],$te[$x]);
	  if ($er<>""){
	    $ellenor=false;
	    echo("$db_table_name[$x]: $er<br />");
	  }
        }
        $x+=1;
      }
      if ($ellenor){
        $fx=sys_standard_name($te[0]);
        $tnev=sys_standard_name($db_table);
        $fa="$dir_site/$default_site/$db_dir_data/$tnev";
        $ft="$dir_site/$default_site/$db_dir_data/$tnev/$db_file_index";
        if (!is_dir($fa)){
          sys_mkdir($fa);
        }
        $fa=$fa."/".$fx;
        sys_file_out($fa,$te,true);
        sys_file_in($ft,$ti,false);
        $x=0;
        $y=count($ti);
        $t=explode($db_sep_char,$ti[$x]);
        while (($x<$y)and($t[0]<>$te[0])){
          $x+=1;
	  $t=explode($db_sep_char,$ti[$x]);
        }
        $ti[$x]="";
        $z=0;
        $y=count($db_table_idx);
        while ($z<$y){
          if ($ti[$x]<>""){
	    $ti[$x]=$ti[$x].$db_sep_char;
	  }
	  $ix=$db_table_idx[$z];
          $ti[$x]=$ti[$x].$te[$ix];
          $z+=1;
        }
        sort($ti);
        sys_file_out($ft,$ti,false);
      }else{
        echo("<br /><br /><br /><br />");
      }
    }
  }

  // uj rekord

  function db_data(){
    global $dir_plugins,$db_plugin_name,$db_lang_file,
           $db_lang,$db_lang_db,$db_idx,$db_table,
           $dir_site,$default_site,$db_dir_data,
           $db_table_name,$db_table_len,$db_table_idx,
           $db_table_space,
           $db_rec_label,$db_idx_label,$s_program;

    $flang="$dir_plugins/$db_plugin_name/$db_lang_file";
    $fielddb=count($db_table_name);
    $x=0;
    while ($x<$fielddb){
      $be[$x]="";
      $x+=1;
    }
    if ($db_idx<>""){
      $tnev=sys_standard_name($db_table);
      $fd="$dir_site/$default_site/$db_dir_data/$tnev/$db_idx";
      sys_file_in($fd,$be);
    }else{
      while ($x<$fielddb){
        $be[$x]="";
        $x+=1;
      }
    }
    if (false){
    }else{
      sys_env_plugin_new($db_idx_label,$db_rec_label);
      $e=sys_env_plugin_pack();
      sys_env_plugin_del($db_idx_label);
      echo("<form method='post' action='./$s_program?$e'>");
      $x=0;
      $space=false;
      $readonly="";
      while ($x<$fielddb){
        if (in_array($x,$db_table_space)){
	  if (!$space){
	    echo("<br />");
	    $space=true;
	  }else{
	    $space=false;
	  }
	}
	if (!$space){
          echo("<label class='db_label_s1'>$db_table_name[$x]</label>");
	  $name="m".$x;
	  if ($db_table_len[$x]==0){
	    $readonly=" readonly='readonly'";
	  }
          echo("<input class='db_input_s1' type='text' id='$name' name='$name' value='$be[$x]'
	        size='100' maxlength='$db_table_len[$x]' $readonly /><br />");
	  if ($readonly<>""){
	    $readonly="";
	  }
	  $x+=1;
	}
      }

      echo("<br /><center>");
      $ki=sys_line("Mehet",$flang,$db_lang,$db_lang_db);
      //echo("<input class=db_button_s1 type=submit value=$ki />");
      echo("<button class='button_s1' id='dbb' name='dbb' type='submit' value='$ki'>$ki</button>");
      echo("</center></form>");
      echo("<br /><br />");
    }
  }

?>
