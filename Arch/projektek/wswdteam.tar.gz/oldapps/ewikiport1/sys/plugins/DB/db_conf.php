<?php

  global $db_plugin_name,$db_css_file,$db_lang_file,
         $db_dir_data,$db_file_data,$db_file_index,
	 $db_idx_label,$db_rec_label,$db_func_label,
	 $db_data_name,$db_m_add,$db_m_list,$db_m_del,
	 $db_lang,$db_langdb,$db_sep_char,$db_idx,
	 $db_func;

  $db_plugin_name="DB";
  $db_css_file="db.css";

  $db_lang_file="lang/";
  $db_dir_data="db_data";
  $db_file_data="dbfile.php";
  $db_file_index="index.txt";
  
  $db_idx_label="dbdata";
  $db_rec_label="rec";
  $db_func_label="func";
  
  $db_data_name="Adat";
  
  $db_m_add="a";
  $db_m_list="l";
  $db_m_del="d";
  
  $db_lang[0][0]="";
  $db_langdb=0;
  $db_sep_char="=";
  $db_idx="";
  $db_func="";
?>
