<?php

  function sql_func_exists(){
    // its need for check this file load
    return true;
  }

  function sql_mysql($server,$user,$pass,$db,$c1,$c2,$c3,$c4){
    global $sql_link,$sql_result,$sql_show_error,$sql_error,
           $sql_show_messages;

    $sql_link=mysql_connect($server,$user,$pass);
    if ($sql_link){
      mysql_select_db($db,$sql_link);
      $sql_error=mysql_error($sql_link);
      if (($sql_error<>"")and($sql_show_error)){
        if ($sql_show_messages){
          echo("<br />SQL: $sql_error.<br />");
        }
      }
      if ($c1<>""){
        $sql_result=mysql_query($c1,$sql_link);
        $sql_error=mysql_error($sql_link);
        if (($sql_error<>"")and($sql_show_error)){
          if ($sql_show_messages){
            echo("<br />SQL: $sql_error.<br />");
          }
        }
      }
      if ($c2<>""){
        $sql_result=mysql_query($c2,$sql_link);
        $sql_error=mysql_error($sql_link);
        if (($sql_error<>"")and($sql_show_error)){
          if ($sql_show_messages){
            echo("<br />SQL: $sql_error.<br />");
          }
        }
      }
      if ($c3<>""){
        $sql_result=mysql_query($c3,$sql_link);
        $sql_error=mysql_error($sql_link);
        if (($sql_error<>"")and($sql_show_error)){
          if ($sql_show_messages){
            echo("<br />SQL: $sql_error.<br />");
          }
        }
      }
      if ($c4<>""){
        $sql_result=mysql_query($c4,$sql_link);
        $sql_error=mysql_error($sql_link);
        if (($sql_error<>"")and($sql_show_error)){
          if ($sql_show_messages){
            echo("<br />SQL: $sql_error.<br />");
          }
        }
      }
      mysql_close($sql_link);
    }
  }


  function sql_mysql_create_only_db($server,$user,$pass,$db){
    global $sql_link,$sql_table,$sql_name_first,$sql_name_last,
           $sql_show_error,$sql_error,$sql_show_messages,
           $dir_site,$dir_plugins,$default_site,$dir_ldata,
           $dir_plugins,$sql_plugin_name,$sql_lang_file,$sql_lang,$sql_lang_db;

    $sql_link=mysql_connect($server,$user,$pass);
    if ($sql_link){
      if ($sql_show_messages){
        $ki=sys_line("Adatb�zis l�trehoz�sa",$sql_lang_file,$sql_lang,$sql_lang_db);
        echo("$ki.<br />");
      }
      mysql_query("create database $db;",$sql_link);
      $sql_error=mysql_error($sql_link);
      if (($sql_error<>"")and($sql_show_error)){
        if ($sql_show_messages){
          echo("<br />SQL: $sql_error.<br />");
        }
      }
      mysql_select_db($db,$sql_link);
      $sql_error=mysql_error($sql_link);
      if (($sql_error<>"")and($sql_show_error)){
        if ($sql_show_messages){
          echo("<br />SQL: $sql_error.<br />");
        }
      }
      mysql_close($sql_link);
    }else{
      if ($sql_show_messages){
        $ki=sys_line("SQL: adatb�zis kapcsolat nem �l",$sql_lang_file,$sql_lang,$sql_lang_db);
        echo("<br />$ki.<br />");
      }
    }
  }
  
  function sql_mysql_create($server,$user,$pass,$db){
    global $sql_link,$sql_table,$sql_name_first,$sql_name_last,
           $sql_show_error,$sql_error,$sql_show_messages,
           $dir_site,$dir_plugins,$default_site,$dir_ldata,
           $sql_table_f,$sql_table_t,
           $dir_plugins,$sql_plugin_name,$sql_lang_file,$sql_lang,$sql_lang_db;

    $sql_link=mysql_connect($server,$user,$pass);
    if ($sql_link){
      if ($sql_show_messages){
        $ki=sys_line("Adatb�zis l�trehoz�sa",$sql_lang_file,$sql_lang,$sql_lang_db);
        echo("$ki.<br />");
      }
      mysql_query("create database $db;",$sql_link);
      $sql_error=mysql_error($sql_link);
      if (($sql_error<>"")and($sql_show_error)){
        if ($sql_show_messages){
          echo("<br />SQL: $sql_error.<br />");
        }
      }
      mysql_select_db($db,$sql_link);
      $sql_error=mysql_error($sql_link);
      if (($sql_error<>"")and($sql_show_error)){
        if ($sql_show_messages){
          echo("<br />SQL: $sql_error.<br />");
        }
      }
      if ($sql_show_messages){
        $ki=sys_line("T�bl�k l�trehoz�sa",$sql_lang_file,$sql_lang,$sql_lang_db);
        echo("<br />$ki:<br />");
      }
      $y=count($sql_table);
      $x=0;
      while ($x<$y){
        $sql_command="create table $sql_table[$x] (";
        if ($sql_show_messages){
          echo("- $sql_table[$x] ... (");
        }
        $cname=$sql_name_first.$sql_table[$x].$sql_name_last;
        sys_load_run("$dir_site/$default_site/$dir_ldata/$cname","");
        $yy=count($sql_table_f);
        $xx=0;
        while($xx<$yy){
          if ($sql_show_messages){
            if ($xx<>0){
              echo(",");
            }
            echo("$sql_table_f[$xx]");
          }
          $sql_command=$sql_command."$sql_table_f[$xx] $sql_table_t[$xx],";
          $xx+=1;
        }
        if ($sql_show_messages){
          echo(").<br />");
        }
        $sql_command=$sql_command." key ($sql_table_f[0])";
        $sql_command=$sql_command.")";
        if ($sql_show_messages){
          echo("<br />$sql_command<br />");
        }
        mysql_query("$sql_command",$sql_link);
        $sql_error=mysql_error($sql_link);
        if (($sql_error<>"")and($sql_show_error)){
          if ($sql_show_messages){
            echo("<br />SQL: $sql_error.<br />");
          }
        }
        $x+=1;
      }
      if ($sql_show_messages){
        $ki=sys_line("K�sz",$sql_lang_file,$sql_lang,$sql_lang_db);
        echo("<br />$ki.<br />");
      }
      mysql_close($sql_link);
    }else{
      if ($sql_show_messages){
        $ki=sys_line("SQL: adatb�zis kapcsolat nem �l",$sql_lang_file,$sql_lang,$sql_lang_db);
        echo("<br />$ki.<br />");
      }
    }
  }
  
  function sql_mysql_table_create($server,$user,$pass,$db,$tname){
    global $sql_link,$sql_table,$sql_name_first,$sql_name_last,
           $sql_show_error,$sql_error,$sql_show_messages,
           $dir_site,$dir_plugins,$default_site,$dir_ldata,
           $sql_table_f,$sql_table_t,
           $dir_plugins,$sql_plugin_name,$sql_lang_file,$sql_lang,$sql_lang_db;

    $sql_link=mysql_connect($server,$user,$pass);
    if ($sql_link){
      mysql_select_db($db,$sql_link);
      $sql_error=mysql_error($sql_link);
      if (($sql_error<>"")and($sql_show_error)){
        if ($sql_show_messages){
          echo("<br />SQL: $sql_error.<br />");
        }
      }
      if ($sql_show_messages){
        $ki=sys_line("T�bla l�trehoz�sa",$sql_lang_file,$sql_lang,$sql_lang_db);
        echo("<br />$ki: $tname.<br />");
      }
      $sql_command="create table $tname (";
      $cname=$sql_name_first.$tname.$sql_name_last;
      sys_load_run("$dir_site/$default_site/$dir_ldata/$cname","");
      $yy=count($sql_table_f);
      $xx=0;
      while($xx<$yy){
        if ($sql_show_messages){
          if ($xx<>0){
            echo(",");
          }else{
            echo("(");
          }
          echo("$sql_table_f[$xx]");
        }
        $sql_command=$sql_command."$sql_table_f[$xx] $sql_table_t[$xx],";
        $xx+=1;
      }
      if ($sql_show_messages){
        echo(").<br />");
      }
      $sql_command=$sql_command." key ($sql_table_f[0])";
      $sql_command=$sql_command.");";
      if ($sql_show_messages){
        echo("<br />$sql_command<br />");
      }
      mysql_query("$sql_command",$sql_link);
      $sql_error=mysql_error($sql_link);
      if (($sql_error<>"")and($sql_show_error)){
        if ($sql_show_messages){
          echo("<br />SQL: $sql_error.<br />");
        }
      }
      if ($sql_show_messages){
        $ki=sys_line("K�sz",$sql_lang_file,$sql_lang,$sql_lang_db);
        echo("<br />$ki.<br />");
      }
      mysql_close($sql_link);
    }else{
      if ($sql_show_messages){
        $ki=sys_line("SQL: adatb�zis kapcsolat nem �l",$sql_lang_file,$sql_lang,$sql_lang_db);
        echo("<br />$ki.<br />");
      }
    }
  }
  
  function sql_mysql_delete($server,$user,$pass,$db){
    global $sql_link,$sql_table,$sql_name_first,$sql_name_last,
           $sql_show_error,$sql_error,$sql_show_messages,
           $dir_site,$dir_plugins,$default_site,$dir_ldata,
           $sql_table_f,$sql_table_t,
           $dir_plugins,$sql_plugin_name,$sql_lang_file,$sql_lang,$sql_lang_db;

    $sql_link=mysql_connect($server,$user,$pass);
    if ($sql_link){
      if ($sql_show_messages){
        $ki=sys_line("Adatb�zis t�rl�se",$sql_lang_file,$sql_lang,$sql_lang_db);
        echo("$ki: $db.<br />");
      }
      mysql_query("drop database $db;",$sql_link);
      $sql_error=mysql_error($sql_link);
      if (($sql_error<>"")and($sql_show_error)){
        if ($sql_show_messages){
          echo("<br />SQL: $sql_error.<br />");
        }
      }
      if ($sql_show_messages){
        $ki=sys_line("K�sz",$sql_lang_file,$sql_lang,$sql_lang_db);
        echo("<br />$ki.<br />");
      }
      mysql_close($sql_link);
    }else{
      if ($sql_show_messages){
        $ki=sys_line("SQL: adatb�zis kapcsolat nem �l",$sql_lang_file,$sql_lang,$sql_lang_db);
        echo("<br />$ki.<br />");
      }
    }
  }
  
  function sql_mysql_table_delete($server,$user,$pass,$db,$tname){
    global $sql_link,$sql_table,$sql_name_first,$sql_name_last,
           $sql_show_error,$sql_error,$sql_show_messages,
           $dir_site,$dir_plugins,$default_site,$dir_ldata,
           $sql_table_f,$sql_table_t,
           $dir_plugins,$sql_plugin_name,$sql_lang_file,$sql_lang,$sql_lang_db;

    $sql_link=mysql_connect($server,$user,$pass);
    if ($sql_link){
      mysql_select_db($db,$sql_link);
      $sql_error=mysql_error($sql_link);
      if (($sql_error<>"")and($sql_show_error)){
        echo("<br />SQL: $sql_error.<br />");
      }
      if ($sql_show_messages){
        $ki=sys_line("T�bla t�rl�se: $tname",$sql_lang_file,$sql_lang,$sql_lang_db);
        echo("$ki.<br />");
      }
      mysql_query("drop table $tname;",$sql_link);
      $sql_error=mysql_error($sql_link);
      if (($sql_error<>"")and($sql_show_error)){
        echo("<br />SQL: $sql_error.<br />");
      }
      if ($sql_show_messages){
        $ki=sys_line("K�sz",$sql_lang_file,$sql_lang,$sql_lang_db);
        echo("<br />$ki.<br />");
      }
      mysql_close($sql_link);
    }else{
      if ($sql_show_messages){
        $ki=sys_line("SQL: adatb�zis kapcsolat nem �l",$sql_lang_file,$sql_lang,$sql_lang_db);
        echo("<br />$ki.<br />");
      }
    }
  }
  
  function sql_mysql_command($server,$user,$pass,$db,$comm,&$data){
    global $sql_link,$sql_show_error,$sql_error,$sql_show_messages,
           $sql_lang,$sql_lang_db,$sql_result,
           $dir_plugins,$sql_plugin_name,$sql_lang_file;
  
    $sql_link=mysql_connect($server,$user,$pass);
    if ($sql_link){
      mysql_select_db($db,$sql_link);
      $sql_error=mysql_error($sql_link);
      if (($sql_error<>"")and($sql_show_error)){
        if ($sql_show_messages){
          echo("<br />SQL: $sql_error.<br />");
        }
      }
      $sql_result=mysql_query($comm,$sql_link);
      $data=$sql_result;
      $sql_error=mysql_error($sql_link);
      if (($sql_error<>"")and($sql_show_error)){
        if ($sql_show_messages){
          echo("<br />SQL: $sql_error.<br />");
        }
      }
    }else{
      if ($sql_show_messages){
        $ki=sys_line("SQL: adatb�zis kapcsolat nem �l",$sql_lang_file,$sql_lang,$sql_lang_db);
        echo("<br />$ki.<br />");
      }
    }
  }
  
  function sql_mysql_connect($server,$user,$pass,$db){
    global $sql_link,$sql_show_error,$sql_error,$sql_show_messages,
           $sql_lang,$sql_lang_db,
           $dir_plugins,$sql_plugin_name,$sql_lang_file;
  
    $sql_link=mysql_connect($server,$user,$pass);
    if ($sql_link){
      mysql_select_db($db,$sql_link);
      $sql_error=mysql_error($sql_link);
      if (($sql_error<>"")and($sql_show_error)){
        if ($sql_show_messages){
          echo("<br />SQL: $sql_error.<br />");
        }
      }
    }else{
      if ($sql_show_messages){
        $ki=sys_line("SQL: adatb�zis kapcsolat nem �l",$sql_lang_file,$sql_lang,$sql_lang_db);
        echo("<br />$ki.<br />");
      }
    }
  }
  
  function sql_mysql_close(){
    global $sql_link;
    
    if ($sql_link){
      mysql_close($sql_link);
    }
  }
  
    
?>
