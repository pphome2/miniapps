<?php


  // alapbe�ll�t�sok
  
  function sql_init(){
    global $dir_site,$dir_plugins,$default_site,$dir_ldata,$sql_driver,
           $sql_lang_file,$lang_file,$sql_plugin_name;

    sys_load_run("$dir_plugins/SQL/sql_global_conf.php","");
    $sql_lang_file="$dir_plugins/$sql_plugin_name/$sql_lang_file$lang_file";
    sys_load_run("$dir_site/$default_site/$dir_ldata/sql_conf.php","");
    if (!function_exists("sql_func_exists")){
      sys_load_run("$dir_plugins/SQL/SQL_$sql_driver.php","");
    }
  }
  
  
  function sql($p,$p1,$p2,$p3){
    global $sql_driver,$sql_server,$sql_name,$sql_db,$sql_user,$sql_pass,
           $dir_plugins,$sql_plugin_name,$sql_lang_file,$sql_lang,$sql_lang_db,
           $sql_show_messages;

    sql_init();
    if ($sql_show_messages){
      $ki=sys_line("SQL kapcsol�",$sql_lang_file,$sql_lang,$sql_lang_db);
      echo("$ki: $sql_driver.<br />");
      $ki=sys_line("SQL szerver",$sql_lang_file,$sql_lang,$sql_lang_db);
      echo("$ki: $sql_server.<br />");
      $ki=sys_line("SQL n�v",$sql_lang_file,$sql_lang,$sql_lang_db);
      echo("$ki: $sql_name.<br />");
      $ki=sys_line("SQL adatb�zis",$sql_lang_file,$sql_lang,$sql_lang_db);
      echo("$ki: $sql_db.<br />");
      $ki=sys_line("SQL felhaszn�l�",$sql_lang_file,$sql_lang,$sql_lang_db);
      echo("$ki: $sql_user.<br />");
      $ki=sys_line("SQL jelsz�",$sql_lang_file,$sql_lang,$sql_lang_db);
      echo("$ki: $sql_pass.<br />");
      $ki=sys_line("SQL utas�t�s",$sql_lang_file,$sql_lang,$sql_lang_db);
      echo("$ki 1: $p.<br />");
      echo("$ki 2: $p1.<br />");
      echo("$ki 3: $p2.<br />");
      echo("$ki 4: $p3.<br />");
      echo("<br />");    
    }
    $p=str_replace("_"," ",$p);
    $p1=str_replace("_"," ",$p1);
    $p2=str_replace("_"," ",$p2);
    $p3=str_replace("_"," ",$p3);
    switch ($sql_driver){
      case "mysql":
        sql_mysql($sql_server,$sql_user,$sql_pass,$sql_db,$p,$p1,$p2,$p3);
        break;
      default:
        sql_mysql($sql_server,$sql_user,$sql_pass,$sql_db,$p,$p1,$p2,$p3);
        break;
    }
  }

  //vez�rl�s
  
  function sql_connect(){
    global $sql_driver,$sql_server,$sql_name,$sql_db,$sql_user,$sql_pass;
    
    sql_init();
    switch ($sql_driver){
      case "mysql":
        sql_mysql_connect($sql_server,$sql_user,$sql_pass,$sql_db);
        break;
      default:
        sql_mysql_connect($sql_server,$sql_user,$sql_pass,$sql_db);
        break;
    }
  }
  
  function sql_create(){
    global $sql_driver,$sql_server,$sql_name,$sql_db,$sql_user,$sql_pass;
    
    sql_init();
    switch ($sql_driver){
      case "mysql":
        sql_mysql_create($sql_server,$sql_user,$sql_pass,$sql_db);
        break;
      default:
        sql_mysql_create($sql_server,$sql_user,$sql_pass,$sql_db);
        break;
    }
  }
  
  function sql_create_only_db(){
    global $sql_driver,$sql_server,$sql_name,$sql_db,$sql_user,$sql_pass;
    
    sql_init();
    switch ($sql_driver){
      case "mysql":
        sql_mysql_create_only_db($sql_server,$sql_user,$sql_pass,$sql_db);
        break;
      default:
        sql_mysql_create_only_db($sql_server,$sql_user,$sql_pass,$sql_db);
        break;
    }
  }
  
  function sql_delete(){
    global $sql_driver,$sql_server,$sql_name,$sql_db,$sql_user,$sql_pass;
    
    sql_init();
    switch ($sql_driver){
      case "mysql":
        sql_mysql_delete($sql_server,$sql_user,$sql_pass,$sql_db);
        break;
      default:
        sql_mysql_delete($sql_server,$sql_user,$sql_pass,$sql_db);
        break;
    }
  }
  
  function sql_table_create($tname){
    global $sql_driver,$sql_server,$sql_name,$sql_db,$sql_user,$sql_pass;
    
    sql_init();
    switch ($sql_driver){
      case "mysql":
        sql_mysql_table_create($sql_server,$sql_user,$sql_pass,$sql_db,$tname);
        break;
      default:
        sql_mysql_table_create($sql_server,$sql_user,$sql_pass,$sql_db,$tname);
        break;
    }
  }
  
  function sql_table_delete($tname){
    global $sql_driver,$sql_server,$sql_name,$sql_db,$sql_user,$sql_pass;
    
    sql_init();
    switch ($sql_driver){
      case "mysql":
        sql_mysql_table_delete($sql_server,$sql_user,$sql_pass,$sql_db,$tname);
        break;
      default:
        sql_mysql_table_delete($sql_server,$sql_user,$sql_pass,$sql_db,$tname);
        break;
    }
  }
  
  function sql_command($command,&$data){
    global $sql_driver,$sql_server,$sql_name,$sql_db,$sql_user,$sql_pass;
    
    sql_init();
    switch ($sql_driver){
      case "mysql":
        sql_mysql_command($sql_server,$sql_user,$sql_pass,$sql_db,$command,$data);
        break;
      default:
        sql_mysql_command($sql_server,$sql_user,$sql_pass,$sql_db,$command,$data);
        break;
    }
  }
  
  function sql_result_data($res,$db){
    global $sql_driver;
    
    sql_init();
    $ret="";
    switch ($sql_driver){
      case "mysql":
        $rows=mysql_num_rows($res);
        if ($rows>=$db){
          $ret=mysql_result($res,$db);
        }
        break;
      default:
        $rows=mysql_num_rows($res);
        if ($rows>=$db){
          $ret=mysql_result($res,$db);
        }
        break;
    }
    return $ret;
  }
  
  function sql_fetch_array($res){
    global $sql_driver;
    
    sql_init();
    $ret="";
    switch ($sql_driver){
      case "mysql":
        $ret=mysql_fetch_array($res);
        break;
      default:
        $ret=mysql_fetch_array($res);
        break;
    }
    return $ret;
  }
  
  function sql_free_result($res){
    global $sql_driver;
    
    sql_init();
    $ret="";
    switch ($sql_driver){
      case "mysql":
        $ret=mysql_free_result($res);
        break;
      default:
        $ret=mysql_free_result($res);
        break;
    }
    return $ret;
  }
  
  function sql_close(){
    global $sql_driver;
    
    sql_init();
    switch ($sql_driver){
      case "mysql":
        sql_mysql_connect();
        break;
      default:
        sql_mysql_connect();
        break;
    }
  }
  
?>
