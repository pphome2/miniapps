<?php

  global $sql_support_driver,$sql_name_first,$sql_name_last,
         $sql_plugin_name,$sql_lang_file,$sql_lang,$sql_lang_db;

  $sql_plugin_name="SQL";
  
  $sql_support_driver=array("mysql");
  
  $sql_command_connect["mysql"]="mysql_connect";
  $sql_command_close["mysql"]="mysql_close";
  $sql_command_select_db["mysql"]="mysql_select_db";
  $sql_command_error["mysql"]="mysql_error";
  $sql_command_query["mysql"]="mysql_query";
  $sql_command_fetch_result["mysql"]="mysql_fetch_array";
  $sql_command_free_result["mysql"]="mysql_freeh_result";
  
  $sql_name_first="sql_conf_";
  $sql_name_last=".php";
  
  $sql_lang_file="lang/";
  $sql_lang[0][0]="";
  $sql_lang_db=0;
  
  $sql_link="";
  $sql_result="";
  $sql_error="";
  
?>
