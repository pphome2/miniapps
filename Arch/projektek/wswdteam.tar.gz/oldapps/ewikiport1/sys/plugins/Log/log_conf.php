<?php

  global $log_name,$log_dir,$log_ext;
  
  $log_name="Log";
  $log_dir="log";
  $log_ext="log";
  
  
?>
