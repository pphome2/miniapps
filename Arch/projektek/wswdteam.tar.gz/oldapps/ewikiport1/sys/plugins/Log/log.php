<?php

  sys_load_run("$dir_plugins/Log/log_conf.php","");

  // alapbe�ll�t�sok
  
  function log_init(){
    global $log_name,$log_dir,$dir_site,$default_site,
           $log_ext;
    
    $ido=date("Ymd");
    $ld="$dir_site/$default_site/$log_dir";
    if (!is_dir($ld)){
      sys_mkdir($ld);
    }
    $ld=$ld."/$ido.$log_ext";
    $line=date("Y.m.d. H:i");
    $line=$line." -=- ".$_SERVER['REMOTE_ADDR'];
    $line=$line." -=- ".$_SERVER['REQUEST_URI'];
    if (isset($HTTP_USER_AGENT)){
      $line=$line." -=- ".$_SERVER['HTTP_USER_AGENT'];
    }else{
      $line=$line." -=- http_user_agent?";
    }
    $line=$line." -=- ".$_SERVER['HTTP_ACCEPT_LANGUAGE'];
    $line=$line."\n";
    sys_file_line_out($ld,$line);
  }
  
  function logview(){
    global $log_name,$log_dir,$dir_site,$default_site;
    
    $ld="$dir_site/$default_site/$log_dir";
    $ki=sys_line_local("A log-ok tartalma");
    echo("<b>$ki:</b><br /><br />");
    $admin=true;
    $dload=false;
    site_directory_list($ld,$admin,$dload);
  }

  function log_add($line){
    global $log_name,$log_dir,$dir_site,$default_site,
           $log_ext;
    
    $ld="$dir_site/$default_site/$log_dir";
    $ido=date("Ymd");
    $ld="$dir_site/$default_site/$log_dir/$ido.$log_ext";
    $line=$line.date("Y.m.d. H:i");
    sys_file_line_out($ld,$line);
  }

?>
