<?php

// plugin.php --- PHP portalrobot
// (verzioadatok a konfiguracios fajlban)
//
// fejleszto: Zebulon.hu Team

// global used plugins


  $env_plugin_style_file[0]="News/news.css";
  $env_plugin_style_file[1]="DB/db.css";
  $env_plugin_style_file[2]="Dchanger/dhanger.css";
  $env_plugin_style_file[3]="EShop/eshop.css";
  $env_plugin_style_file[4]="Helpdesk/helpdesk.css";
  $env_plugin_style_file[5]="IME/ime.css";

  $env_plugin_name[0]="data";        // Helpdesk
  $env_plugin_name[1]="hddir";
  $env_plugin_name[2]="dbdata";      // DB
  $env_plugin_name[3]="rec";
  $env_plugin_name[4]="func";
  $env_plugin_name[5]="tlap";        // EShop
  $env_plugin_name[6]="kosar";
  $env_plugin_name[7]="kdel";
  $env_plugin_name[8]="nlap";        // News
  $env_plugin_name[9]="imelap";      // IME

  sys_load_run("$dir_plugins/Time/time.php","");
  sys_load_run("$dir_plugins/News/News.php","");

  //sys_load_run("$dir_plugins/Dchanger/Dchanger.php","");
  //sys_load_run("$dir_plugins/Log/log.php","");
  //sys_load_run("$dir_plugins/Log/log_conf.php","");

  // plugins initialization

  function plugins_init(){
    global $env_plugin_db,$env_plugin_name,$env_plugin_data,
           $env_plugin_style_file,$dir_plugins;

    sys_env_plugin_in();

    news_init();

    time_init();
    //dchanger_init();
    //log_init();
  }

  // plugins close

  function plugins_end(){
    time_end();
  }

?>
