<?php

  // php.ini ---- output_buffering=On !!!!!!!!!!!

  sys_load_run("$dir_plugins/Cookie/cookie_conf.php","");
  
  function cookie_init(){ 
    ini_set("output_buffering","1");
  }

  function cookie_send($cname,$val,$ti){
    ob_start();
    setcookie($cname,$val,time()+$ti);
    ob_flush();
  }

  function cookie_read($cname){
    global $cookie_value;
    
    if (isset($_COOKIE[$cname])) {
      $cookie_value=$_COOKIE["$cname"];
    }
    return($cookie_value);
  }

  function cookie_change($cname,$val,$ti){
    if (isset($_COOKIE["$cname"])) {
      cookie_send($cname,$val,$ti);
    }
  }

  function cookie_read_2($cname){
    global $no_cookie;
    
    $nc=cookie_read($cname);
    if ($nc<>""){
      echo($nc);
    }else{
      echo("?");
    }
  }

  function cookie_del($cname){
    cookie_send($cname,"",-1);
  }

?>
