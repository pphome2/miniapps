<?php

  global $cookie_name,$cookie_value;
	 
  $cookie_name="Cookie";
  
  $cookie_value="";
  
?>
