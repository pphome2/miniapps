<?php

  global $time_name,$time_str_1,$time_str_2,$start_time;
  
  $time_name="Time";
  
  $time_str_1="=>";
  $time_str_2="s";
  
  $start_time=0;
  
  function time_init_lang(){
    global $lang_system,
           $time_str_1,$time_str_2;
    
    switch ($lang_system){
      case "en":
        $time_str_1="Runing time";
        $time_str_2=" sec";
        break;
      case "hu":
        $time_str_1="Fut�si id�";
        $time_str_2=" m�sodperc";
        break;
      default:
        $time_str_1="Fut�si id�";
        $time_str_2=" m�sodperc";
        break;
    }
  }
  
?>
