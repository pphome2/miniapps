<?php

  sys_load_run("$dir_plugins/Time/time_conf.php","");

  // alapbe�ll�t�sok

  function time_init(){
    global $time_name,$start_time,$printed;

    if (!$printed){
      $st=explode(" ",microtime());
      $start_time=$st[1]+$st[0];
      time_init_lang();
    }
  }

  function time_end(){
    global $time_name,$start_time,
           $time_str_1,$time_str_2,
           $printed,$no_out_html;

    if ((!$printed)and(!$no_out_html)){
      $st=explode(" ",microtime());
      $end_time=$st[1]+$st[0];
      $run_time=substr($end_time-$start_time,0,5);
      echo("<center>$time_str_1: $run_time $time_str_2.</center>");
    }
  }

?>
