<?php
  global $ime_plugin_name,$ime_lang_file,$ime_lang,$ime_lang_db,
         $ime_menu_input,$ime_separator,$ime_admin,$ime_menu_flist,
         $ime_menu_check,$ime_page,$ime_data_page,$ime_file_css,
         $ime_menu_sname,$ime_filename;

  $ime_plugin_name="IME";

  $ime_admin="vonaferi";
  
  $ime_lang_file="lang/";
  $ime_lang[0][0]="";
  $ime_lang_db=0;
  
  $ime_separator=",";
  
  $ime_menu_input="input";
  $ime_menu_search="search";
  $ime_menu_sname="name";
  $ime_menu_flist="flist";
  $ime_menu_check="check";
  
  $ime_page="imelap";
  $ime_data_page=50;
  $ime_akt_page=1;
  $ime_file_css="ime.css";
  $ime_filename="Veelemeenyek_a_jaateekosrool_-_";
  
?>
