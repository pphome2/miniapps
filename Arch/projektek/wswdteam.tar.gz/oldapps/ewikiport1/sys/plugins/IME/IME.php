<?php

    sys_load_run("$dir_plugins/SQL/SQL.php","");

  // alapbe�ll�t�sok

  function ime_init(){
    global $dir_site,$dir_plugins,$default_site,$dir_ldata,
	   $ime_lang_file,$lang_file,$ime_admin,
	   $admin_menu_plus,$reg_menu_plus,
	   $s_program,$sitepos,$ime_page,$ime_akt_page,
	   $ime_plugin_name,$ime_file_css;

    sys_load_run("$dir_plugins/IME/ime_conf.php","");
    //$fs="$dir_plugins/$ime_plugin_name/$ime_file_css";
    //sys_style($fs);
    $ime_lang_file=$ime_lang_file.$lang_file;
    $un=site_user("");
    if ($un==$ime_admin){
      $k=count($admin_menu_plus)-1;
      $m=sys_env_find($sitepos);
      $np=sys_standard_name($admin_menu_plus[$k]);
      sys_env_new($sitepos,$np);
      $e=sys_env_pack();
      echo("<a href='$s_program?$e'>$admin_menu_plus[$k]</a><br /><br /><br />");
      sys_env_new($sitepos,$m);
    }
    $ime_akt_page=sys_env_plugin_find($ime_page);
    if ($ime_akt_page==""){
      $ime_akt_page=1;
    }
    sys_env_plugin_del($ime_page);
  }


  function ime($p,$p1,$p2,$p3){
    global $dir_plugins,$ime_plugin_name,$ime_lang_file,$ime_lang,$ime_lang_db,
           $ime_menu_input,$ime_menu_search,$ime_menu_flist,$ime_menu_check,
           $ime_menu_sname;

    ime_init();
    $flang="$dir_plugins/$ime_plugin_name/$ime_lang_file";
    $ki=sys_line("IME - Ismerd meg ellenfeled",$flang,$ime_lang,$ime_lang_db);

    echo("$ki!<br /><br />");

    switch ($p){
      case "$ime_menu_input":
        ime_konvert();
        break;
      case "$ime_menu_search":
        ime_search();
        break;
      case "$ime_menu_flist":
        ime_filelist();
        break;
      case "$ime_menu_sname":
        ime_name();
        break;
      case "$ime_menu_check":
        ime_datacheck();
        break;
      default:
        ime_oow();
        break;
    }
  }

  function ime_oow(){
    global $dir_plugins,$ime_plugin_name,$ime_lang_file,$ime_lang,$ime_lang_db;

    //ime_init();
    $flang="$dir_plugins/$ime_plugin_name/$ime_lang_file";
    echo("<br /><br />");
    $ki=sys_line("�zemen k�v�l",$flang,$ime_lang,$ime_lang_db);
    echo("<b>$ki.</b>");
    echo("<br /><br />");
  }

  function ime_datacheck(){
    global $dir_plugins,$ime_plugin_name,$ime_lang_file,$ime_lang,$ime_lang_db,
           $dir_site,$dir_ldata,$default_site,$s_program,$ime_separator,
           $sql_error,$sql_result,$ime_akt_page,$ime_page,$ime_data_page;

    //ime_init();
    $flang="$dir_plugins/$ime_plugin_name/$ime_lang_file";
    echo("<br /><br />");
    $ki=sys_line("Adatok ellen�rz�se",$flang,$ime_lang,$ime_lang_db);
    echo("<b>$ki</b><br /><br />");
    $sqlc="select * from ime1 order by nev;";
    $to="";
    sql_command($sqlc,$to);
    if ($sql_error<>""){
      //echo("$sqlc");
    }
    $tdb=0;
    $err=0;
    $arr2=array("","","","","","");
    $errsql=array();
    $errsql=array();
    while ($arr=sql_fetch_array($to)){
      if (($arr2[1]==$arr[1])and
         ($arr2[2]==$arr[2])and
         ($arr2[3]==$arr[3])and
         ($arr2[4]==$arr[4])and
         ($arr2[5]==$arr[5])and
         ($arr2[6]==$arr[6])and
         ($tdb>0)){
        $a1=str_replace("'","\'",$arr[1]);
        $a2=str_replace("'","\'",$arr[2]);
        $a3=str_replace("'","\'",$arr[3]);
        $a4=str_replace("'","\'",$arr[4]);
        $a5=str_replace("'","\'",$arr[5]);
        $a6=str_replace("'","\'",$arr[6]);
        $errsql[$err]="delete from ime1 where";
        $errsql[$err]=$errsql[$err]." hely='$a1' and nev='$a2' and";
        $errsql[$err]=$errsql[$err]." nyeremeny='$a3' and buyin='$a4' and";
        $errsql[$err]=$errsql[$err]." prizepole='$a5' and tournament='$a6';";
        //echo($errsql[$err]);
        $err+=1;
      }else{
        $arr2[1]=$arr[1];
        $arr2[2]=$arr[2];
        $arr2[3]=$arr[3];
        $arr2[4]=$arr[4];
        $arr2[5]=$arr[5];
        $arr2[6]=$arr[6];
      }
      $tdb+=1;
    }
    $ki=sys_line("�sszesen",$flang,$ime_lang,$ime_lang_db);
    $ki2=sys_line("db ellen�rizve",$flang,$ime_lang,$ime_lang_db);
    echo("$ki $tdb $ki2.<br />");
    if ($err>0){
      $x=0;
      while ($x<$err){
        sql_command($errsql[$x],$to);
        if ($sql_error<>""){
        }
        $x+=1;
      }
    }
    $ki=sys_line("�sszesen",$flang,$ime_lang,$ime_lang_db);
    $ki2=sys_line("db hiba jav�tva",$flang,$ime_lang,$ime_lang_db);
    echo("$ki $err $ki2.<br /><br />");
  }

  function ime_name(){
    global $dir_plugins,$ime_plugin_name,$ime_lang_file,$ime_lang,$ime_lang_db,
           $dir_site,$dir_ldata,$default_site,$s_program,$ime_separator,
           $sql_error,$sql_result,$ime_data_page,$ime_page,$ime_akt_page,
           $dir_site,$default_site,$dir_data,$ime_filename,$sitepos;

    //ime_init();
    $flang="$dir_plugins/$ime_plugin_name/$ime_lang_file";
    $ki=sys_line("Keresett n�v",$flang,$ime_lang,$ime_lang_db);
    echo("<br /><br /><center>");
    $e=sys_env_pack();
    echo("<form method='post' action='./$s_program?$e'>");
    echo("<label class='label_s1'>$ki: </label>");
    echo("<input class='input_s1' type='text' id='userfile' name='userfile' size='120' maxlength='100' /><br /><br />");
    $ki=sys_line("Mehet",$flang,$ime_lang,$ime_lang_db);
    //echo("<input class=button_1 type=submit value=$ki />");
    echo("<button class='button_1' id='imb' name='imb' type='submit' value='$ki'>$ki</button>");
    echo("</form>");
    echo("</center><br />");
    echo("<hr width='50%' /><br /><br />");
    $ok=sys_data_post($db,$dk,$de);
    if ($ok){
      $ki=sys_line("Keres�s eredm�nye",$flang,$ime_lang,$ime_lang_db);
      echo("$ki ($de[0]):<br /><br />");
      $sqlc="select * from ime1 where nev='".$de[0]."';";
      $to="";
      sql_command($sqlc,$to);
      if ($sql_error<>""){
        //echo("$sqlc");
      }
      $tdb=0;
      $tol=($ime_akt_page*$ime_data_page)-$ime_data_page;
      $ig=$tol+$ime_data_page-1;
      $aktrow=1;
      while ($arr=sql_fetch_array($to)){
        if ($tdb==0){
          echo("<center><table class='table_d1'>");
          echo("<tr class='row_d1'>");
          echo("<td align='center' valign='top' width='20%'><b>");
          $ki=sys_line("N�v",$flang,$ime_lang,$ime_lang_db);
          echo("$ki");
          echo("</b></td>");
          echo("<td align='center' valign='top' width='40%'><b>");
          $ki=sys_line("Adatok",$flang,$ime_lang,$ime_lang_db);
          echo("$ki 1.");
          echo("</b></td>");
          echo("<td align='center' valign='top'><b>");
          echo("$ki 2.</b></td></tr>");
        }
        $ss=1;
        while ($ss<16){
          if ($arr[$ss]==""){
            $arr[$ss]="-";
          }
          $ss+=1;
        }
        if (($tdb>=$tol)and($tdb<=$ig)){
          if ($aktrow=1){
            echo("<tr class='row_d1'>");
            $aktrow=2;
          }else{
            echo("<tr class='row_d2'>");
            $aktrow=1;
          }
          echo("<td align='left' valign='top'>");
          echo("$arr[2] ($arr[1])");
          echo("</td>");

          echo("<td align='left' valign='top'>");
          $ki=sys_line("Nyerem�ny",$flang,$ime_lang,$ime_lang_db);
          echo("<b>$ki:</b> $arr[3]<br />");
          $ki=sys_line("Buyin",$flang,$ime_lang,$ime_lang_db);
          echo("<b>$ki:</b> $arr[4]<br />");
          $ki=sys_line("Prizepole",$flang,$ime_lang,$ime_lang_db);
          echo("<b>$ki:</b> $arr[5]<br />");
          $ki=sys_line("Tournament",$flang,$ime_lang,$ime_lang_db);
          echo("<b>$ki:</b> $arr[6]<br />");
          $ki=sys_line("Indul�",$flang,$ime_lang,$ime_lang_db);
          echo("<b>$ki:</b> $arr[7]<br />");
          $ki=sys_line("Rebuy",$flang,$ime_lang,$ime_lang_db);
          echo("<b>$ki:</b> $arr[8]<br />");
          $ki=sys_line("Addon",$flang,$ime_lang,$ime_lang_db);
          echo("<b>$ki:</b> $arr[9]<br />");
          $ki=sys_line("D�jazott",$flang,$ime_lang,$ime_lang_db);
          echo("<b>$ki:</b> $arr[10]<br />");
          $ki=sys_line("T�pus",$flang,$ime_lang,$ime_lang_db);
          echo("<b>$ki:</b> $arr[11]<br />");
          $ki=sys_line("Kezd�s",$flang,$ime_lang,$ime_lang_db);
          echo("<b>$ki:</b> $arr[12]<br />");
          $ki=sys_line("V�ge",$flang,$ime_lang,$ime_lang_db);
          echo("<b>$ki:</b> $arr[13]<br />");
          echo("</td>");
          echo("<td align='left' valign='top'>");
          $ki=sys_line("J�t�ker�",$flang,$ime_lang,$ime_lang_db);
          echo("<b>$ki:</b> $arr[14]<br />");
          $ki=sys_line("ITM",$flang,$ime_lang,$ime_lang_db);
          echo("<b>$ki:</b> $arr[15]<br />");
          $ki=sys_line("Buyin-�rt�k",$flang,$ime_lang,$ime_lang_db);
          echo("<b>$ki:</b> $arr[16]<br />");
          $ki=sys_line("Versenyid�",$flang,$ime_lang,$ime_lang_db);
          echo("<b>$ki:</b> $arr[17]<br />");
          $ki=sys_line("Buyin-r�ta",$flang,$ime_lang,$ime_lang_db);
          echo("<b>$ki:</b> $arr[28]<br />");
          $ki=sys_line("Roisz",$flang,$ime_lang,$ime_lang_db);
          echo("<b>$ki:</b> $arr[29]<br />");
          $ki=sys_line("Helysz�n",$flang,$ime_lang,$ime_lang_db);
          echo("<b>$ki:</b> $arr[30]<br />");
          $ki=sys_line("Helybesorol�s",$flang,$ime_lang,$ime_lang_db);
          echo("<b>$ki:</b> $arr[31]<br />");
          $ki=sys_line("F�/asztal",$flang,$ime_lang,$ime_lang_db);
          echo("<b>$ki:</b> $arr[32]<br />");
          $ki=sys_line("Ft",$flang,$ime_lang,$ime_lang_db);
          echo("<b>$ki:</b> $arr[33]<br />");
          $ki=sys_line("ITM/Ft",$flang,$ime_lang,$ime_lang_db);
          echo("<b>$ki:</b> $arr[34]<br />");
          echo("</td>");
          echo("</tr>");
        }
        $tdb+=1;
      }
      if ($tdb>0){
        echo("</table></center>");
      }
      $ki=sys_line("�sszesen",$flang,$ime_lang,$ime_lang_db);
      $ki2=sys_line("db tal�lat",$flang,$ime_lang,$ime_lang_db);
      echo("<br /><br />$ki $tdb $ki2.<br /><br />");
      $fn="$ime_filename$de[0]";
      //echo("$fn<br />");
      $ki=sys_line("V�lem�nyek a j�t�kosr�l",$flang,$ime_lang,$ime_lang_db);
      $lap=sys_env_find($sitepos);
      sys_env_new($sitepos,$fn);
      $e=sys_env_pack();
      echo("<a href='$s_program?$e'>$ki</a>");
      echo("<br /><br />");
      sys_env_new($sitepos,$lap);
      site_pageing($tdb,$ime_data_page,$ime_akt_page,$ime_page);
    }
  }

  function ime_search(){
    global $dir_plugins,$ime_plugin_name,$ime_lang_file,$ime_lang,$ime_lang_db,
           $dir_site,$dir_ldata,$default_site,$s_program,$ime_separator,
           $sql_error,$sql_result;

    //ime_init();
    $flang="$dir_plugins/$ime_plugin_name/$ime_lang_file";
    $ki=sys_line("Keresett n�v",$flang,$ime_lang,$ime_lang_db);
    echo("<br /><br /><center>");
    $e=sys_env_pack();
    echo("<form method='post' action='./$s_program?$e'>");
    echo("<label class='label_s1'>$ki: </label>");
    echo("<input class='input_s1' type='text' id='userfile' name='userfile' size='120' maxlength='100' /><br /><br />");
    $ki=sys_line("Mehet",$flang,$ime_lang,$ime_lang_db);
    //echo("<input class=button_1 type=submit value=$ki />");
    echo("<button class='button_1' id='but' name='but' type='submit' value='$ki'>$ki</button>");
    echo("</form>");
    echo("</center><br />");
    echo("<hr width='50%' /><br /><br />");
    $ok=sys_data_post($db,$dk,$de);
    $aktrow=1;
    if ($ok){
      $ki=sys_line("Keres�s eredm�nye",$flang,$ime_lang,$ime_lang_db);
      echo("$ki ($de[0]):<br /><br />");
      $sqlc="select * from ime1 where nev='".$de[0]."' order by indulo;";
      $to="";
      sql_command($sqlc,$to);
      if ($sql_error<>""){
        //echo("$sqlc");
      }
      $tdb=0;
      $idb=0;
      $akt="";
      $place=array(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);
      //echo("<center><div class=page_table>");
      //echo("<table border=0 width='90%'><tr><td>");
      while ($arr=sql_fetch_array($to)){
        if ($akt==""){
          $akt=$arr[7];
        }
        if ($akt==$arr[7]){
          $idb+=1;
          $pl=$arr[1];
          switch ($pl){
            case (($pl>=1)and($pl<=10)):
              $place[$pl]+=1;
              break;
            case (($pl>=11)and($pl<=20)):
              $place[11]+=1;
              break;
            case (($pl>=21)and($pl<=100)):
              $place[12]+=1;
              break;
            case (($pl>=101)and($pl<=200)):
              $place[13]+=1;
              break;
            case (($pl>=201)and($pl<=500)):
              $place[14]+=1;
              break;
            case (($pl>=501)and($pl<=1000)):
              $place[15]+=1;
              break;
            case (($pl>=1001)and($pl<=10000)):
              $place[16]+=1;
              break;
            default:
              $place[17]+=1;
              break;
          }
        }else{
          if ($idb>0){
            $aktrow=1;
            echo("<center><table class='table_d1'>");
            if ($aktrow=1){
              echo("<tr class='row_d1'>");
              $aktrow=2;
            }else{
              echo("<tr class='row_d2'>");
              $aktrow=1;
            }
            echo("<td colspan='2' align='center' valign='top' width='50%'>");
            $ki=sys_line("Statisztika",$flang,$ime_lang,$ime_lang_db);
            echo("<b>$ki</b>");
            echo("</td></tr>");
            if ($aktrow=1){
              echo("<tr class='row_d1'>");
              $aktrow=2;
            }else{
              echo("<tr class='row_d2'>");
              $aktrow=1;
            }
            echo("<td align='left' valign='top' width='50%'>");
            $ki=sys_line("Indul�",$flang,$ime_lang,$ime_lang_db);
            echo("<b>$ki</b>");
            echo("</td>");
            echo("<td align='left' valign='top' width='50%'>");
            echo("$akt");
            echo("</td>");
            echo("</tr>");

            if ($aktrow=1){
              echo("<tr class='row_d1'>");
              $aktrow=2;
            }else{
              echo("<tr class='row_d2'>");
              $aktrow=1;
            }
            echo("<td align='left' valign='top' width='50%'>");
            $ki=sys_line("Vizsg�lt verseny",$flang,$ime_lang,$ime_lang_db);
            echo("<b>$ki</b>");
            echo("</td>");
            echo("<td align='left' valign='top' width='50%'>");
            echo("$idb db.");
            echo("</td>");
            echo("</tr>");

            if ($aktrow=1){
              echo("<tr class='row_d1'>");
              $aktrow=2;
            }else{
              echo("<tr class='row_d2'>");
              $aktrow=1;
            }
            echo("<td colspan='2' align='center' valign='top' width='50%'>");
            $ki=sys_line("Helyez�s",$flang,$ime_lang,$ime_lang_db);
            echo("<b>$ki</b>");
            echo("</td></tr>");

            if ($aktrow=1){
              echo("<tr class='row_d1'>");
              $aktrow=2;
            }else{
              echo("<tr class='row_d2'>");
              $aktrow=1;
            }
            echo("<td align='center' valign='top' width='50%'>");
            echo("<b>1.</b>");
            echo("</td>");
            echo("<td align='left' valign='top' width='50%'>");
            $y=0;
            while ($y<$place[1]){
              echo("*");
              $y+=1;
            }
            echo("</td>");
            echo("</tr>");

            if ($aktrow=1){
              echo("<tr class='row_d1'>");
              $aktrow=2;
            }else{
              echo("<tr class='row_d2'>");
              $aktrow=1;
            }
            echo("<td align='center' valign='top' width='50%'>");
            echo("<b>2.</b>");
            echo("</td>");
            echo("<td align='left' valign='top' width='50%'>");
            $y=0;
            while ($y<$place[1]){
              echo("*");
              $y+=1;
            }
            echo("</td>");
            echo("</tr>");


            if ($aktrow=1){
              echo("<tr class='row_d1'>");
              $aktrow=2;
            }else{
              echo("<tr class='row_d2'>");
              $aktrow=1;
            }
            echo("<td align='center' valign='top' width='50%'>");
            echo("<b>3.</b>");
            echo("</td>");
            echo("<td align='left' valign='top' width='50%'>");
            $y=0;
            while ($y<$place[2]){
              echo("*");
              $y+=1;
            }
            echo("</td>");
            echo("</tr>");

            if ($aktrow=1){
              echo("<tr class='row_d1'>");
              $aktrow=2;
            }else{
              echo("<tr class='row_d2'>");
              $aktrow=1;
            }
            echo("<td align='center' valign='top' width='50%'>");
            echo("<b>3.</b>");
            echo("</td>");
            echo("<td align='left' valign='top' width='50%'>");
            $y=0;
            while ($y<$place[3]){
              echo("*");
              $y+=1;
            }
            echo("</td>");
            echo("</tr>");

            if ($aktrow=1){
              echo("<tr class='row_d1'>");
              $aktrow=2;
            }else{
              echo("<tr class='row_d2'>");
              $aktrow=1;
            }
            echo("<td align='center' valign='top' width='50%'>");
            echo("<b>4.</b>");
            echo("</td>");
            echo("<td align='left' valign='top' width='50%'>");
            $y=0;
            while ($y<$place[4]){
              echo("*");
              $y+=1;
            }
            echo("</td>");
            echo("</tr>");

            if ($aktrow=1){
              echo("<tr class='row_d1'>");
              $aktrow=2;
            }else{
              echo("<tr class='row_d2'>");
              $aktrow=1;
            }
            echo("<td align='center' valign='top' width='50%'>");
            echo("<b>5.</b>");
            echo("</td>");
            echo("<td align='left' valign='top' width='50%'>");
            $y=0;
            while ($y<$place[5]){
              echo("*");
              $y+=1;
            }
            echo("</td>");
            echo("</tr>");

            if ($aktrow=1){
              echo("<tr class='row_d1'>");
              $aktrow=2;
            }else{
              echo("<tr class='row_d2'>");
              $aktrow=1;
            }
            echo("<td align='center' valign='top' width='50%'>");
            echo("<b>6.</b>");
            echo("</td>");
            echo("<td align='left' valign='top' width='50%'>");
            $y=0;
            while ($y<$place[6]){
              echo("*");
              $y+=1;
            }
            echo("</td>");
            echo("</tr>");

            if ($aktrow=1){
              echo("<tr class='row_d1'>");
              $aktrow=2;
            }else{
              echo("<tr class='row_d2'>");
              $aktrow=1;
            }
            echo("<td align='center' valign='top' width='50%'>");
            echo("<b>7.</b>");
            echo("</td>");
            echo("<td align='left' valign='top' width='50%'>");
            $y=0;
            while ($y<$place[7]){
              echo("*");
              $y+=1;
            }
            echo("</td>");
            echo("</tr>");

            if ($aktrow=1){
              echo("<tr class='row_d1'>");
              $aktrow=2;
            }else{
              echo("<tr class='row_d2'>");
              $aktrow=1;
            }
            echo("<td align='center' valign='top' width='50%'>");
            echo("<b>8.</b>");
            echo("</td>");
            echo("<td align='left' valign='top' width='50%'>");
            $y=0;
            while ($y<$place[8]){
              echo("*");
              $y+=1;
            }
            echo("</td>");
            echo("</tr>");

            if ($aktrow=1){
              echo("<tr class='row_d1'>");
              $aktrow=2;
            }else{
              echo("<tr class='row_d2'>");
              $aktrow=1;
            }
            echo("<td align='center' valign='top' width='50%'>");
            echo("<b>9.</b>");
            echo("</td>");
            echo("<td align='left' valign='top' width='50%'>");
            $y=0;
            while ($y<$place[9]){
              echo("*");
              $y+=1;
            }
            echo("</td>");
            echo("</tr>");

            if ($aktrow=1){
              echo("<tr class='row_d1'>");
              $aktrow=2;
            }else{
              echo("<tr class='row_d2'>");
              $aktrow=1;
            }
            echo("<td align='center' valign='top' width='50%'>");
            echo("<b>10.</b>");
            echo("</td>");
            echo("<td align='left' valign='top' width='50%'>");
            $y=0;
            while ($y<$place[10]){
              echo("*");
              $y+=1;
            }
            echo("</td>");
            echo("</tr>");

            if ($aktrow=1){
              echo("<tr class='row_d1'>");
              $aktrow=2;
            }else{
              echo("<tr class='row_d2'>");
              $aktrow=1;
            }
            echo("<td align='center' valign='top' width='50%'>");
            echo("<b>11-20.</b>");
            echo("</td>");
            echo("<td align='left' valign='top' width='50%'>");
            $y=0;
            while ($y<$place[11]){
              echo("*");
              $y+=1;
            }
            echo("</td>");
            echo("</tr>");

            if ($aktrow=1){
              echo("<tr class='row_d1'>");
              $aktrow=2;
            }else{
              echo("<tr class='row_d2'>");
              $aktrow=1;
            }
            echo("<td align='center' valign='top' width='50%'>");
            echo("<b>21-100.</b>");
            echo("</td>");
            echo("<td align='left' valign='top' width='50%'>");
            $y=0;
            while ($y<$place[12]){
              echo("*");
              $y+=1;
            }
            echo("</td>");
            echo("</tr>");

            if ($aktrow=1){
              echo("<tr class='row_d1'>");
              $aktrow=2;
            }else{
              echo("<tr class='row_d2'>");
              $aktrow=1;
            }
            echo("<td align='center' valign='top' width='50%'>");
            echo("<b>101-200.</b>");
            echo("</td>");
            echo("<td align='left' valign='top' width='50%'>");
            $y=0;
            while ($y<$place[13]){
              echo("*");
              $y+=1;
            }
            echo("</td>");
            echo("</tr>");

            if ($aktrow=1){
              echo("<tr class='row_d1'>");
              $aktrow=2;
            }else{
              echo("<tr class='row_d2'>");
              $aktrow=1;
            }
            echo("<td align='center' valign='top' width='50%'>");
            echo("<b>201-500.</b>");
            echo("</td>");
            echo("<td align='left' valign='top' width='50%'>");
            $y=0;
            while ($y<$place[14]){
              echo("*");
              $y+=1;
            }
            echo("</td>");
            echo("</tr>");

            if ($aktrow=1){
              echo("<tr class='row_d1'>");
              $aktrow=2;
            }else{
              echo("<tr class='row_d2'>");
              $aktrow=1;
            }
            echo("<td align='center' valign='top' width='50%'>");
            echo("<b>501-1000.</b>");
            echo("</td>");
            echo("<td align='left' valign='top' width='50%'>");
            $y=0;
            while ($y<$place[15]){
              echo("*");
              $y+=1;
            }
            echo("</td>");
            echo("</tr>");

            if ($aktrow=1){
              echo("<tr class='row_d1'>");
              $aktrow=2;
            }else{
              echo("<tr class='row_d2'>");
              $aktrow=1;
            }
            echo("<td align='center' valign='top' width='50%'>");
            echo("<b>?.</b>");
            echo("</td>");
            echo("<td align='left' valign='top' width='50%'>");
            $y=0;
            while ($y<$place[16]){
              echo("*");
              $y+=1;
            }
            echo("</td>");
            echo("</tr>");
            echo("</table></center>");

            $akt=$arr[7];
            $idb=0;
            $place=array(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);
          }
          $tdb+=1;
        }
      }
      if ($tdb<>0){
        $ki=sys_line("Vizsg�lt j�t�k",$flang,$ime_lang,$ime_lang_db);
        echo("<br />$ki $tdb.<br /><br />");
      }else{
        $ki=sys_line("Nincs tal�lat",$flang,$ime_lang,$ime_lang_db);
        echo("<br />$ki.<br /><br />");
      }
    }
  }


  function ime_search_old(){
    global $dir_plugins,$ime_plugin_name,$ime_lang_file,$ime_lang,$ime_lang_db,
           $dir_site,$dir_ldata,$default_site,$s_program,$ime_separator,
           $sql_error,$sql_result;

    //ime_init();
    $flang="$dir_plugins/$ime_plugin_name/$ime_lang_file";
    $ki=sys_line("Keresett n�v",$flang,$ime_lang,$ime_lang_db);
    echo("<br /><br /><center>");
    $e=sys_env_pack();
    echo("<form method='post' action='./$s_program?$e'>");
    echo("<label class='label_s1'>$ki: </label>");
    echo("<input class='input_s1' type='text' id='userfile' name='userfile' size='120' maxlength='100' /><br /><br />");
    $ki=sys_line("Mehet",$flang,$ime_lang,$ime_lang_db);
    //echo("<input class=button_1 type=submit value=$ki />");
    echo("<button class='button_1' id='bsu' name='bsu' type='submit' value='$ki'>$ki</button>");
    echo("</form>");
    echo("</center><br />");
    echo("<hr width='50%' /><br /><br />");
    $ok=sys_data_post($db,$dk,$de);
    $aktrow=1;
    if ($ok){
      $ki=sys_line("Keres�s eredm�nye",$flang,$ime_lang,$ime_lang_db);
      echo("$ki ($de[0]):<br /><br />");
      $sqlc="select * from ime1 where nev='".$de[0]."';";
      $to="";
      sql_command($sqlc,$to);
      if ($sql_error<>""){
        //echo("$sqlc");
      }
      $tdb=0;
      $stat=array(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);
      while ($arr=sql_fetch_array($to)){
        $stat[0]=$stat[0]+$arr[3];
        $stat[1]=$stat[1]+$arr[14];
        $stat[2]=$stat[2]+$arr[31];
        $tdb+=1;
      }
      if ($tdb>0){
        echo("<center><table class='table_d1'>");
        if ($aktrow=1){
          echo("<tr class='row_d1'>");
          $aktrow=2;
        }else{
          echo("<tr class='row_d2'>");
          $aktrow=1;
        }
        echo("<td colspan='2' align='center' valign='top' width='50%'>");
        $ki=sys_line("Statisztika",$flang,$ime_lang,$ime_lang_db);
        echo("<b>$ki</b>");
        echo("</td></tr>");
        $stat[0]=round($stat[0]/$tdb,2);
        $stat[1]=round($stat[1]/$tdb,2);
        $stat[2]=round($stat[2]/$tdb,2);
        if ($aktrow=1){
          echo("<tr class='row_d1'>");
          $aktrow=2;
        }else{
          echo("<tr class='row_d2'>");
          $aktrow=1;
        }
        echo("<td align='left' valign='top' width='50%'>");
        $ki=sys_line("Tal�lt adat",$flang,$ime_lang,$ime_lang_db);
        echo("<b>$ki</b></td>");
        echo("<td align='center' valign='top'>");
        echo("$tdb");
        echo("</td>");
        echo("</tr>");
        if ($aktrow=1){
          echo("<tr class='row_d1'>");
          $aktrow=2;
        }else{
          echo("<tr class='row_d2'>");
          $aktrow=1;
        }
        echo("<td><b>Nyerem�ny</b></td>");
        echo("<td align='center' valign='top'>");
        echo("$stat[0]");
        echo("</td>");
        echo("</tr>");
        if ($aktrow=1){
          echo("<tr class='row_d1'>");
          $aktrow=2;
        }else{
          echo("<tr class='row_d2'>");
          $aktrow=1;
        }
        echo("<td><b>J�t�ker�</b></td>");
        echo("<td align='center' valign='top'>");
        echo("$stat[1]");
        echo("</td>");
        echo("</tr>");
        if ($aktrow=1){
          echo("<tr class='row_d1'>");
          $aktrow=2;
        }else{
          echo("<tr class='row_d2'>");
          $aktrow=1;
        }
        echo("<td><b>Helybesorol�s</b></td>");
        echo("<td align='center' valign='top'>");
        echo("$stat[2]");
        echo("</td>");
        echo("</tr>");
        echo("</table></center><br /><br />");
      }else{
      $ki=sys_line("Nincs tal�lat",$flang,$ime_lang,$ime_lang_db);
      echo("<br />$ki.<br /><br />");
      }
    }
  }

  function ime_filelist(){
    global $dir_plugins,$ime_plugin_name,$ime_lang_file,$ime_lang,$ime_lang_db,
           $dir_site,$dir_ldata,$default_site,$s_program,$ime_separator,
           $sql_error,$sql_result,$ime_akt_page,$ime_page,$ime_data_page;

    //ime_init();
    $flang="$dir_plugins/$ime_plugin_name/$ime_lang_file";
    echo("<br /><br />");
    $ki=sys_line("Feldolgozott f�jlok",$flang,$ime_lang,$ime_lang_db);
    echo("<b>$ki</b><br /><br />");
    echo("<center>");
    $sqlc="select * from ime2 order by datum desc;";
    $to="";
    sql_command($sqlc,$to);
    if ($sql_error<>""){
      //echo("$sqlc");
    }
    $aktrow=1;
    $tdb=0;
    $tol=($ime_akt_page*$ime_data_page)-$ime_data_page;
    $ig=$tol+$ime_data_page-1;
    while ($arr=sql_fetch_array($to)){
      if ($tdb==0){
        echo("<table class='table_d1'>");
        if ($aktrow==1){
          echo("<tr class='row_d1'>");
          $aktrow=2;
        }else{
          echo("<tr class='row_d2'>");
          $aktrow=1;
        }
        echo("<td width='50%' align='left' valign='top'><b>");
        echo("F�jl neve");
        echo("</b></td>");
        echo("<td align='left' valign='top'><b>");
        echo("Felt�ltve");
        echo("</b>");
        echo("</td></tr>");
      }
      if (($tdb>=$tol)and($tdb<=$ig)){
        if ($aktrow==1){
          echo("<tr class='row_d1'>");
          $aktrow=2;
        }else{
          echo("<tr class='row_d2'>");
          $aktrow=1;
        }
        echo("<td align='center' valign='top'>");
        echo("$arr[0]");
        echo("</td>");
        echo("<td align='center' valign='top'>");
        $d=date("Y.m.d. h:s",$arr[1]);
        echo("$arr[1]");
        echo("</td>");
        echo("</tr>");
      }
      $tdb+=1;
    }
    echo("</table></center>");
    $ki=sys_line("�sszesen",$flang,$ime_lang,$ime_lang_db);
    $ki2=sys_line("db tal�lat",$flang,$ime_lang,$ime_lang_db);
    echo("<br /><br />$ki $tdb $ki2.<br /><br />");
    site_pageing($tdb,$ime_data_page,$ime_akt_page,$ime_page);
  }

  function ime_konvert(){
    global $dir_plugins,$ime_plugin_name,$ime_lang_file,$ime_lang,$ime_lang_db,
           $dir_site,$dir_ldata,$default_site,$s_program,$ime_separator,
           $sql_error,$sql_result;

    //ime_init();
    $flang="$dir_plugins/$ime_plugin_name/$ime_lang_file";
    $ki=sys_line("Adatf�jl",$flang,$ime_lang,$ime_lang_db);
    echo("<center>");
    $e=sys_env_pack();
    echo("<form method='post' enctype='multipart/form-data' action='./$s_program?$e'>");
    echo("<label class='label_s1'>$ki: </label>");
    echo("<input class='input_s1' type='file' id='userfile' name='userfile' size='120' maxlength='100' />");
    echo("<br /><br />");
    $ki=sys_line("Mehet",$flang,$ime_lang,$ime_lang_db);
    echo("<button class='button_1' id='fbu' name='fbu' type='submit' value='$ki'>$ki</button>");
    echo("</form>");
    echo("</center><br />");
    if (isset($_FILES['userfile']['name'])){
      if (basename($_FILES['userfile']['name'])<>""){
        $uploaddir="$dir_site/$default_site/$dir_ldata";
        $uploadfile=$uploaddir."/".basename($_FILES['userfile']['name']);
        $ufile=basename($_FILES['userfile']['name']);
        if (strlen($ufile)>20){
          $ufile2=substr($ufile,0,20);
        }else{
          $ufile2=$ufile;
        }
        //echo("IME-$ufile-$ufile2.<br />");
        $sqlc="select * from ime2 where nev='".$ufile2."';";
        sql_command($sqlc,$sql_result);
        if ($sql_error<>""){
          //echo("$sql_error");
        }
        $c=sql_result_data($sql_result,0);
        $c2=count($sql_result);
        if ($c==""){
          if (move_uploaded_file($_FILES['userfile']['tmp_name'], $uploadfile)) {
            $ki=sys_line("A felt�lt�s megt�rt�nt",$flang,$ime_lang,$ime_lang_db);
            echo("<br />$ki.<br />");
            sys_file_in($uploadfile,$tomb);
            $x=count($tomb);
            $y=1;
            $db=0;
            $err=0;
            while ($y<$x){
              if (substr($tomb[$y],0,1)==$ime_separator){
                $t=explode("$ime_separator",$tomb[$y]);
                $x2=count($t);
                //echo("$x2-$t[1]");
                if (($x2>34)and($t[1]<>"")){
                  $sqlc="insert into ime1 values (";
                  $y2=0;
                  while ($y2<$x2){
                    if ($y2>0){
                      $sqlc=$sqlc.",";
                    }
                    $out=str_replace("'","-",$t[$y2]);
                    $out=str_replace(",",".",$out);
                    $sqlc=$sqlc."'".$out."'";
                    $y2+=1;
                  }
                  while ($y2<40){
                    $sqlc=$sqlc.",''";
                    $y2+=1;
                  }
                  $sqlc=$sqlc.")";
                  sql_command($sqlc,$tomb2);
                  if ($sql_error<>""){
                    //echo("IME-$sqlc<br />");
                    $err+=1;
                  }else{
                    //echo("IME-$sqlc<br />");
                    $db+=1;
                  }
                }
              }
              $y+=1;
            }
            $ki=sys_line("�rv�nyes adat",$flang,$ime_lang,$ime_lang_db);
            echo("<br />$db $ki.<br />");
            $ki=sys_line("hib�s adat",$flang,$ime_lang,$ime_lang_db);
            echo("$err $ki.<br /><br />");
            if (($db>0)and($err==0)){
              $datum=date("Y.m.d. H:i");
              $sqlc="insert into ime2 values('".$ufile."','".$datum."');";
              sql_command($sqlc,$tomb2);
              if ($sql_error<>""){
                //echo("$sqlc");
              }
            }
            sys_file_del($uploadfile);
            $ki=sys_line("A feldolgoz�s megt�rt�nt",$flang,$ime_lang,$ime_lang_db);
            echo("$ki. ($ufile)<br /><br />");
          }else{
            $ki=sys_line("Hiba a felt�lt�s k�zben",$flang,$ime_lang,$ime_lang_db);
            echo("<br />$ki.<br /><br />");
          }
        }else{
          $ki=sys_line("M�r feldolgozott adat�jl",$flang,$ime_lang,$ime_lang_db);
          echo("<br />$ki. ($ufile)<br /><br />");
        }
      }
    }
  }


?>
