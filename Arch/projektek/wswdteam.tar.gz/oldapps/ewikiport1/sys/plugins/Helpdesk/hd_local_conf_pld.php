<?php

  global $hd_b_name,$hd_b_address,
	 $hd_b_contact,$hd_b_phone,$hd_service_name,
	 $hd_service_address,$hd_service_phone,$hd_service_email,
	 $hd_service_web,$hd_open,$hd_type,$hd_etype,
	 $hd_pri,$hd_otype,$hd_otype_k,$hd_order,$hd_slist,
	 $hd_month,$hd_std_close,$hd_admin_user;

  $hd_admin_user=array("peter");
  
  $hd_b_name="P�teri P�ter Labs.";
  $hd_b_address="Cegl�d, B�ke";
  $hd_b_contact="P�teri P�ter	";
  $hd_b_phone="20/359-1224";
  
  $hd_service_name="SZ�V-Szolnok Kft.";
  $hd_service_address="Szolnok, Baross �t 10-12.";
  $hd_service_phone="56/512-820";
  $hd_service_email="helpdesk@szuvszolnok.hu";
  $hd_service_web="www.szuvszolnok.hu";
  
  $hd_open=array("Nyitott","Bevizsg�l�s","Tesztel�s","Szakszerv�z");
  $hd_type=array("sz�m�t�g�p","notebook","nyomtat�","perif�ria","h�l�zati elem","mobil eszk�z","egy�b");
  $hd_etype=array("hardver","hardver (garanci�lis)","szoftver","egy�b");
  $hd_pri=array("norm�l","s�rg�s");
  $hd_otype=array("Fizet�","Garanci�lis","Szerz�d�ses");
  $hd_otype_k=array("Fizet�: �raj�nlatot k�r-e.","Garanci�lis: garanciajegy sz�ma, elad�s d�tuma.",
                    "Szerz�d�ses: szerz�d�s sz�ma.");
  $hd_order=array("Jav�t�s","Bevizsg�l�s","Egy�b");
  $hd_slist=array("Nincs kiadva","Balogh G�bor","Mannheim Jen�","P�teri P�ter","Tolvaj Csaba",
                  "Vitai Roland","Szakszerv�z");
  $hd_month=array("","janu�r","febru�r","m�rcius","�prilis","m�jus","j�nius","j�lius","augusztus",
                  "szeptember","okt�ber","november","december");
  $hd_std_close="�zemk�pesen �tadva.";

?>
