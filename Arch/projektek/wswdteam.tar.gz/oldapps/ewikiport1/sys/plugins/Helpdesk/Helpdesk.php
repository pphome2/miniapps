<?php


  // alapbe�ll�t�sok

  function hd_init(){
    global $dir_plugins,$hd_name,$hd_css_file,
           $hd_data,$hd_idx,
           $hd_dir,$hd_ddir,$hd_indata,
	   $dir_site,$default_site,$hd_dir_data,
           $dir_ldata,$dir_plugins,$hd_local_conf_file,
	   $hd_lang_file,$lang_file;

    sys_load_run("$dir_plugins/Helpdesk/helpdesk_conf.php","");
    if (file_exists("$dir_site/$default_site/$dir_ldata/$hd_local_conf_file")){
      sys_load_run("$dir_site/$default_site/$dir_ldata/$hd_local_conf_file","");
    }else{
      sys_load_run("$dir_plugins/Helpdesk/$hd_local_conf_file","");
    }
    $hd_lang_file=$hd_lang_file.$lang_file;
    //$fs="$dir_plugins/$hd_name/$hd_css_file";
    //sys_style($fs);
    $hd_idx=sys_env_plugin_find($hd_data);
    sys_env_plugin_del($hd_data);
    $hd_ddir=sys_env_plugin_find($hd_dir);
    sys_env_plugin_del($hd_dir);
    $hd_indata=false;
    $ld="$dir_site/$default_site/$hd_dir_data";
    if (!is_dir($ld)){
      sys_mkdir($ld);
    }
  }

  //vez�rl�s

  function hd($p,$p1,$p2,$p3){
    global $hd_p_add,$hd_p_list,$hd_p_akto,
           $hd_p_view,$hd_p_index,$hd_index,
           $hd_p_akt,$hd_indata,$hd_idx,
           $hd_p_work,$hd_p_order,$hd_p_del,
           $dir_plugins,$hd_name,$hd_lang_file,
           $hd_ddir;

    hd_init();
    $un=site_user("");
    $flang="$dir_plugins/$hd_name/$hd_lang_file";
    if ($un<>""){
      switch ($p){
        case $hd_p_add:
          hd_new_data();
	  if (!$hd_indata){
            hd_form();
	  }
          break;
        case $hd_p_list:
          hd_dirlist("");
          break;
        case $hd_p_akt:
          if ($hd_ddir==""){
            $d=hd_dir2();
          }else{
            $d="";
          }
          hd_dirlist("$d");
          break;
        case $hd_p_akto:
          $hd=hd_dir();
  	  $hi=sys_standard_name($hd_index);
  	  $hd_idx=$hd."/".$hi;
          hd_index();
          break;
        case $hd_p_view:
          hd_new_data();
  	  if (!$hd_indata){
            hd_form();
  	  }
          break;
        case $hd_p_index:
          hd_index();
          break;
        case $hd_p_order:
          hd_order();
          break;
        case $hd_p_work:
          hd_work();
          break;
        case $hd_p_del:
          hd_delete();
          break;
        default:
          break;
      }
    }else{
      switch ($p){
        default:
          $ki=sys_line("Nincs bejelentkezve",$flang,$hd_lang,$hd_lang_db);
          echo("<br />$ki.<br /><br />");
          break;
      }
    }
  }

  // indexfajl megtekintese

  function hd_index(){
    global $dir_site,$default_site,$hd_dir_data,
           $dir_plugins,$hd_css_file,$hd_name,
           $hd_lang,$hd_langdb,$hd_lang_file,
           $hd_dir,$hd_ddir,$hd_data,$hd_viewdata,
           $hd_month,$hd_index,$hd_idx,$hd_char,
           $hd_orderpage,$hd_work,$hd_del,
           $s_program,$sitepos,$hd_admin_user,
           $user_admin,$printed;

    $flang="$dir_plugins/$hd_name/$hd_lang_file";
    sys_file_in($hd_idx,$bl);
    $bldb=count($bl);
    $kidb=0;
    $x=strlen($hd_idx)-1;
    while (($x>=0)and(substr($hd_idx,$x,1)<>"/")){
      $x-=1;
    }
    $hd_idx=substr($hd_idx,0,$x);
    $ki1=sys_line("Bejelent�lap",$flang,$hd_lang,$hd_lang_db);
    $ki2=sys_line("Munkalap",$flang,$hd_lang,$hd_lang_db);
    $ki3=sys_line("T�rl�s",$flang,$hd_lang,$hd_lang_db);
    $hdv=sys_standard_name($hd_viewdata);
    $hdo=sys_standard_name($hd_orderpage);
    $hdw=sys_standard_name($hd_work);
    $hdd=sys_standard_name($hd_del);
    $poz=sys_env_find($sitepos);
    echo("<center>");
    if ($printed){
      echo("<table with=90%' border='1'>");
    }else{
      echo("<div class='page_table'>");
    }
    $x=0;
    while($x<$bldb){
      $blt=explode($hd_char,$bl[$x]);
      $y=0;
      $yy=count($blt);
      while($y<$yy){
        if($blt[$y]==""){
	  $blt[$y]="-";
	}
        $y+=1;
      }
      if ($blt[0]<>"-"){
	$ni=$hd_idx."/".sys_standard_name($blt[0]);
	sys_env_new($sitepos,$hdv);
	sys_env_plugin_new($hd_data,$ni);
        $e=sys_env_plugin_pack();
        $kidb+=1;
        if ($printed){
          echo("<tr><td><a class='href' href='./$s_program?$e'>$blt[0]</a></td>");
          echo("<td>$blt[1]</td>");
          echo("<td>$blt[4]</td>");
        }else{
          echo("<label class='l-4_table-1'><a class='href' href='./$s_program?$e'>$blt[0]</a></label>");
          echo("<label class='l-4_table-2'>$blt[1]</label>");
          echo("<label class='l-4_table-3'>$blt[4]</label>");
        }
	sys_env_new($sitepos,$hdo);
        $e=sys_env_plugin_pack();
        if ($printed){
          echo("<td><a class='href' href='./$s_program?$e'>$ki1</a></td></tr>");
          echo("<tr><td>-</td>");
          echo("<td>$blt[2]</td>");
          echo("<td>$blt[3]</td>");
        }else{
          echo("<label class='l-4_table-4'><a class='href' href='./$s_program?$e'>$ki1</a></label>");
          echo("<label class='l-4_table-empty'></label>");
          echo("<label class='l-4_table-2'>$blt[2]</label>");
          echo("<label class='l-4_table-3'>$blt[3]</label>");
        }
	sys_env_new($sitepos,$hdw);
        $e=sys_env_plugin_pack();
        if ($printed){
          echo("<td><a class='href' href='./$s_program?$e'>$ki2</a></td></tr>");
        }else{
          echo("<label class='l-4_table-4'><a class='href' href='./$s_program?$e'>$ki2</a></label>");
        }
        $uc=site_user("");
        if (in_array($uc,$hd_admin_user)){
	  sys_env_new($sitepos,$hdd);
          $e=sys_env_plugin_pack();
          if ($printed){
            echo("<tr><td>-</td>");
            echo("<td>-</td>");
            echo("<td>-</td>");
            echo("<td><a class='href' href='./$s_program?$e'>$ki3</a></td></tr>");
          }else{
            echo("<label class='l-4_table-empty'></label>");
            echo("<label class='l-4_table-empty'></label>");
            echo("<label class='l-4_table-empty'></label>");
            echo("<label class='l-4_table-4'><a class='href' href='./$s_program?$e'>$ki3</a></label>");
          }
        }else{
          //echo("<label class=label_table3>---</label><br />");
        }
      }
      $x+=1;
    }
    if ($printed){
      echo("</table>");
    }else{
      $ki1=sys_line("�sszesen",$flang,$hd_lang,$hd_lang_db);
      $ki2=sys_line("db bejelent�s",$flang,$hd_lang,$hd_lang_db);
      echo("$ki1: $kidb $ki2.");
      echo("</div>");
    }
    echo("</center><br />");
    sys_env_new($sitepos,$poz);
  }

  // bejelentesek listaja

  function hd_dirlist($ad){
    global $dir_site,$default_site,$hd_dir_data,
           $dir_plugins,$hd_css_file,$hd_name,
           $hd_lang,$hd_langdb,$hd_lang_file,
           $hd_dir,$hd_ddir,$hd_data,$hd_viewdata,
           $hd_month,$hd_index,$user_admin,
           $s_program,$sitepos,$printed;

    $flang="$dir_plugins/$hd_name/$hd_lang_file";
    $adir="$dir_site/$default_site/$hd_dir_data";
    if (($ad<>"")and($hd_ddir=="")){
      $hd_ddir=$ad;
    }else{
      //$hd_ddir=sys_env_plugin_find($hd_dir);
    }
    if ($hd_ddir<>""){
      $adir=$adir."/".$hd_ddir;
      $dt=explode("/",$hd_ddir);
      $x=0;
      $y=count($dt);
      $dp="/";
      $e=sys_env_plugin_pack();
      echo("<a class='href' href='./$s_program?$e'> $dp </a>");
      $dp="";
      $per="";
      while($x<$y){
        if ($dp==""){
          $dp=$dt[$x];
	}else{
	  $per="/";
          $dp=$dp.$per.$dt[$x];
	}
        sys_env_plugin_new($hd_dir,$dp);
	$e=sys_env_plugin_pack();
	echo(" $per ");
	if ($dt[$x]<2000){
	  if (substr($dt[$x],0,1)=="0"){
	    $dt[$x]=substr($dt[$x],1,1);
	  }
	  $k=$hd_month[$dt[$x]];
	}else{
	  $k=$dt[$x];
	}
        echo("<a class='href' href='./$s_program?$e'> $k </a>");
	$x+=1;
      }
    }else{
      $dp="/";
      $e=sys_env_plugin_pack();
      echo("<a class='href' href='./$s_program?$e'> $dp </a>");
    }
    $ki=sys_line("k�nyvt�r tartalma",$flang,$hd_lang,$hd_lang_db);
    echo("$ki:<br /><br />");
    sys_dir_list($adir,$fl);
    sys_env_plugin_del($hd_dir);
    $fdb=count($fl);
    $poz=sys_env_find($sitepos);
    $hd_viewdata=sys_standard_name($hd_viewdata);
    sort($fl);
    if ($fdb>0){
      echo("<center>");
      if (!$printed){
        echo("<div class='page_table'>");
      }
      $x=0;
      while ($x<$fdb){
        if ($hd_ddir<>""){
	  $nd=$hd_ddir."/".$fl[$x];
	}else{
	  $nd=$fl[$x];
	}
	if (strlen($fl[$x])>5){
	  $ni=sys_standard_name($hd_index);
	  if ($fl[$x]==$ni){
	    sys_env_new($sitepos,$ni);
	  }else{
	    sys_env_new($sitepos,$hd_viewdata);
	  }
	  $nd=$adir."/".$fl[$x];
	  sys_env_plugin_new($hd_data,$nd);
          $e=sys_env_plugin_pack();
          sys_env_new($sitepos,$poz);
	  sys_env_plugin_del($hd_data);
	}else{
          sys_env_plugin_new($hd_dir,$nd);
          $e=sys_env_plugin_pack();
	}
	if (($fl[$x]<2000)and(strlen($fl[$x])<=2)){
	  if (substr($fl[$x],0,1)=="0"){
	    $fl[$x]=substr($fl[$x],1,1);
	  }
  	  $fn=$hd_month[$fl[$x]];
	}else{
  	  $fn=sys_unstandard_name($fl[$x]);
	}
	if ($printed){
          echo("<a class='href' href='./$s_program?$e'>$fn</a><br />");
	}else{
          echo("<label class='l-1_table-1'><a class='href' href='./$s_program?$e'>$fn</a></label>");
        }
	$x+=1;
      }
      sys_env_plugin_del($hd_dir);
      $ki1=sys_line("�sszesen",$flang,$hd_lang,$hd_lang_db);
      $ki2=sys_line("db",$flang,$hd_lang,$hd_lang_db);
      echo("$ki1: $fdb $ki2.");
      if (!$printed){
        echo("</div>");
      }
      echo("</center><br />");
    }else{
      $ki=sys_line("A k�nyvt�r �res",$flang,$hd_lang,$hd_lang_db);
      echo("$ki.<br /><br />");
    }
    sys_env_new($sitepos,$poz);
  }

  // bejelentes torlese

  function hd_delete(){
    global $dir_plugins,$hd_name,
           $hd_lang,$hd_langdb,$hd_lang_file,
           $hd_index,$hd_idx,$hd_char;

    $fl="$dir_plugins/$hd_name/$hd_lang_file";
    if ($hd_idx<>""){
      $sdir=hd_dir();
      $fid=sys_standard_name($hd_index);
      $idx[0]="";
      sys_file_in_lock("$sdir/$fid",$idx);
      $h=explode("/",$hd_idx);
      $akt=count($h);
      $hdidx=sys_unstandard_name($h[$akt-1]);
      $x=0;
      $y=count($idx);
      $t="";
      while($x<$y){
        $t=explode($hd_char,$idx[$x]);
	if ($t[0]==$hdidx){
	  $idx[$x]="";
	  $x=$y+1;
	}
        $x+=1;
      }
      sys_file_out_lock("$sdir/$fid",$idx);
      sys_file_del("$hd_idx");
      $ki=sys_line("Adatok t�rl�se megt�rt�nt",$fl,$hd_lang,$hd_lang_db);
      echo("$ki.<br /><br />");
    }else{
      $ki=sys_line("Azonos�t� nemtal�lhat�",$fl,$hd_lang,$hd_lang_db);
      echo("$ki.<br /><br />");
    }
  }

  // adatok kezel�se

  function hd_new_data(){
    global $dir_plugins,$hd_css_file,$hd_name,
           $hd_lang,$hd_langdb,$hd_lang_file,
           $hd_index,$hd_idx,$hd_char,
           $hd_indata,$hd_std_close;

    $fl="$dir_plugins/$hd_name/$hd_lang_file";
    $ok=sys_data_post($db,$tk,$te);
    if ($ok){
      $hd_indata=true;
      $sdir=hd_dir();
      $fid=sys_standard_name($hd_index);
      sys_file_in_lock("$sdir/$fid",$idx);
      //$te[0]="";
      $sfile=$sdir."/".sys_standard_name($te[0]);
      if ((substr($te[12],0,2)=="20")and($te[15]=="")){
        $tt=explode(" ",$te[12]);
        $ki=sys_line($hd_std_close,$fl,$hd_lang,$hd_lang_db);
	if ($te[14]==""){
          $te[14]=$ki;
	}
        $te[15]=$tt[0];
	$x=substr($tt[1],0,2)-1;
        $te[16]=$x.":".substr($tt[1],3,2);
        $te[17]=$tt[1];
        $te[18]="1";
        $te[19]="0";
      }else{
      }
      $out[0]="";
      $x=0;
      while ($x<=$db){
        $out[$x+1]=$te[$x];
        $x+=1;
      }
      sys_file_out("$sfile",$out);
      $x=0;
      $db=count($idx);
      $t=explode($hd_char,$idx[$x]);
      while(($x<=$db)and($t[0]<>$te[0])){
        $x+=1;
        $t=explode($hd_char,$idx[$x]);
      }
      if ($t[0]==$te[0]){;
        $idx[$x]=$te[0].$hd_char.$te[1].$hd_char.$te[5].$hd_char.$te[6].$hd_char.$te[12];
      }else{
        $idx[$db]=$te[0].$hd_char.$te[1].$hd_char.$te[5].$hd_char.$te[6].$hd_char.$te[12];
      }
      rsort($idx);
      sys_empty($idx);
      sys_file_out_lock("$sdir/$fid",$idx);
      $ki=sys_line("Adatok t�rol�sa megt�rt�nt",$fl,$hd_lang,$hd_lang_db);
      echo("$ki.<br /><br />");
    }
  }

  // dir megallapitasa

  function hd_dir(){
    global $default_site,$dir_site,
           $hd_index,$hd_dir_data;

    $dirname="$dir_site/$default_site/$hd_dir_data";
    $dy=date("Y");
    $dh=date("m");
    $dirname=$dirname."/".$dy;
    sys_mkdir($dirname);
    $dirname=$dirname."/".$dh;
    sys_mkdir($dirname);
    return($dirname);
  }

  // dir megallapitasa

  function hd_dir2(){
    global $default_site,$dir_site,
           $hd_index,$hd_dir_data;

    $dirname="";
    $dy=date("Y");
    $dh=date("m");
    $dirname=$dirname."/".$dy;
    //sys_mkdir($dirname);
    $dirname=$dirname."/".$dh;
    return($dirname);
  }

  // uj adatsor

  function hd_form(){
    global $dir_plugins,$hd_css_file,$hd_name,
           $hd_lang,$hd_langdb,$hd_lang_file,
           $hd_open,$hd_type,$hd_etype,$hd_pri,$hd_slist,
           $hd_data,$hd_idx,$hd_otype,$hd_order,
           $hd_b_name,$hd_b_address,$hd_b_phone,$hd_b_contact,
           $s_program,$hd_otype_k,$hd_admin_user;

    $fl="$dir_plugins/$hd_name/$hd_lang_file";
    $x=0;
    while ($x<=40){
      $m[$x]="";
      $x+=1;
    }
    if ($hd_idx<>""){
      $ki=sys_line("Bejelent�s m�dos�t�sa",$fl,$hd_lang,$hd_lang_db);
      echo("$ki:<br /><br />");
      $sdir=hd_dir();
      //$sfile=$sdir."/".sys_standard_name($hd_idx);
      sys_file_in("$hd_idx",$m);
      $readonly="";
    }else{
      $m[1]=hd_date();
      $readonly="";
      if ($hd_b_name<>""){
        $m[2]=$hd_b_name;
        $m[3]=$hd_b_address;
        $m[4]=$hd_b_contact;
        $m[5]=$hd_b_phone;
      }
    }
    if (false){
    }else{
      $d=sys_standard_name($m[1]);
      sys_env_plugin_new($hd_data,$d);
      $e=sys_env_plugin_pack();
      sys_env_plugin_del($hd_data);
      echo("<form method='post' action='./$s_program?$e'>");
      $ki=sys_line("Azonos�t�",$fl,$hd_lang,$hd_lang_db);
      echo("<label class='hd_label_s1'>$ki:</label>");
      echo("<input class='hd_input_s1' type='text' id='m1' name='m1' value='$m[1]' size='120' maxlength='100' readonly='readonly' /><br />");
      $ki=sys_line("Bejelent� neve",$fl,$hd_lang,$hd_lang_db);
      echo("<label class='hd_label_s1'>$ki:</label>");
      echo("<input class='hd_input_s1' type='text' id='m2' name='m2' value='$m[2]' size='120' maxlength='100' $readonly /><br />");
      $ki=sys_line("C�me",$fl,$hd_lang,$hd_lang_db);
      echo("<label class='hd_label_s1'>$ki:</label>");
      echo("<input class='hd_input_s1' type='text' id='m3' name='m3' value='$m[3]' size='120' maxlength='100' $readonly /><br />");
      $ki=sys_line("Kapcsolattart�",$fl,$hd_lang,$hd_lang_db);
      echo("<label class='hd_label_s1'>$ki:</label>");
      echo("<input class='hd_input_s1' type='text' id='m4' name='m4' value='$m[4]' size='120' maxlength='100' $readonly /><br />");
      $ki=sys_line("Telefonsz�m/E-mail",$fl,$hd_lang,$hd_lang_db);
      echo("<label class='hd_label_s1'>$ki:</label>");
      echo("<input class='hd_input_s1' type='text' id='m5' name='m5' value='$m[5]' size='120' maxlength='100' $readonly /><br />");
      echo("<br />");

      $ki=sys_line("Eszk�z gy�rt�ja",$fl,$hd_lang,$hd_lang_db);
      echo("<label class='hd_label_s1'>$ki:</label>");
      echo("<input class='hd_input_s1' type='text' id='m6' name='m6' value='$m[6]' size='120' maxlength='100' $readonly /><br />");
      $ki=sys_line("Tipusa",$fl,$hd_lang,$hd_lang_db);
      echo("<label class='hd_label_s1'>$ki:</label>");
      echo("<input class='hd_input_s1' type='text' id='m7' name='m7' value='$m[7]' size='120' maxlength='100' $readonly /><br />");
      $ki=sys_line("Fajt�ja",$fl,$hd_lang,$hd_lang_db);
      echo("<label class='hd_label_s1'>$ki:</label>");
      echo("<select id='m8' name='m8'>");
      $x=0;
      $y=count($hd_type);
      while ($x<$y){
        if ($hd_type[$x]==$m[8]){
          echo("<option selected='selected'>$hd_type[$x]");
	}else{
          echo("<option>$hd_type[$x]");
	}
	$x++;
      }
      echo("</select><br />");
      $ki=sys_line("Gy�ri sz�ma",$fl,$hd_lang,$hd_lang_db);
      echo("<label class='hd_label_s1'>$ki:</label>");
      echo("<input class='hd_input_s1' type='text' id='m9' name='m9' value='$m[9]' size='120' maxlength='100' $readonly /><br />");
      echo("<br />");

      $ki=sys_line("Hiba tipusa",$fl,$hd_lang,$hd_lang_db);
      echo("<label class='hd_label_s1'>$ki:</label>");
      echo("<select id='m10' name='m10'>");
      $x=0;
      $y=count($hd_etype);
      while ($x<$y){
        if ($hd_etype[$x]==$m[10]){
          echo("<option selected='selected'>$hd_etype[$x]");
	}else{
          echo("<option>$hd_etype[$x]");
	}
	$x++;
      }
      echo("</select><br />");
      $ki=sys_line("S�rg�ss�g",$fl,$hd_lang,$hd_lang_db);
      echo("<label class='hd_label_s1'>$ki:</label>");
      echo("<select id='m11' name='m11'>");
      $x=0;
      $y=count($hd_pri);
      while ($x<$y){
        if ($hd_pri[$x]==$m[11]){
          echo("<option selected='selected'>$hd_pri[$x]");
	}else{
          echo("<option>$hd_pri[$x]");
	}
	$x++;
      }
      echo("</select><br />");
      $ki=sys_line("Hiba le�r�sa",$fl,$hd_lang,$hd_lang_db);
      echo("<label class='hd_label_s1'>$ki:</label>");
      echo("<input class='hd_input_s1' type='text' id='m12' name='m12' value='$m[12]' size='120' maxlength='300' $readonly /><br />");
      echo("<br />");

      $ki=sys_line("St�tusz",$fl,$hd_lang,$hd_lang_db);
      echo("<label class='hd_label_s1'>$ki:</label>");
      echo("<select id='m13' name='m13'>");
      $x=0;
      $y=count($hd_open);
      $van=false;
      while ($x<$y){
        if ($hd_open[$x]==$m[13]){
          echo("<option selected='selected'>$hd_open[$x]");
	  $van=true;
	}else{
          echo("<option>$hd_open[$x]");
	}
	$x++;
      }
      if($m[13]<>""){
        if ($van){
          $hd_open[$x]=hd_date();
          echo("<option>$hd_open[$x]");
        }else{
          $hd_open[$x]=$m[13];
          echo("<option selected='selected'>$hd_open[$x]");
	}
      }
      echo("</select><br />");
      echo("<br />");

      $ki=sys_line("Szervizes",$fl,$hd_lang,$hd_lang_db);
      echo("<label class='hd_label_s1'>$ki:</label>");
      echo("<select id='m14' name='m14'>");
      $x=0;
      $y=count($hd_slist);
      while ($x<$y){
        if ($hd_slist[$x]==$m[14]){
          echo("<option selected='selected'>$hd_slist[$x]");
	}else{
          echo("<option>$hd_slist[$x]");
	}
	$x++;
      }
      echo("</select><br />");
      echo("<br />");

      $ki=sys_line("Megold�s, anyagfelhaszn�l�s",$fl,$hd_lang,$hd_lang_db);
      echo("<label class='hd_label_s1>$ki:</label>");
      echo("<input class='hd_input_s1' type='text' id='m15' name='m15' value='$m[15]' size='120' maxlength='300' $readonly /><br />");
      $ki=sys_line("Jav�t�s d�tuma",$fl,$hd_lang,$hd_lang_db);
      echo("<label class='hd_label_s1'>$ki:</label>");
      echo("<input class='hd_input_s1' type='text' id='m16' name='m16' value='$m[16]' size='120' maxlength='15' $readonly /><br />");
      $ki=sys_line("Jav�t�s kezdete (��:pp)",$fl,$hd_lang,$hd_lang_db);
      echo("<label class='hd_label_s1'>$ki:</label>");
      echo("<input class='hd_input_s1' type='text' id='m17' name='m17' value='$m[17]' size='120' maxlength='7' $readonly /><br />");
      $ki=sys_line("Jav�t�s v�ge (��:pp)",$fl,$hd_lang,$hd_lang_db);
      echo("<label class='hd_label_s1'>$ki:</label>");
      echo("<input class='hd_input_s1' type='text' id='m18' name='m18' value='$m[18]' size='120' maxlength='7' $readonly /><br />");
      $ki=sys_line("Jav�t�s ideje (�ra)",$fl,$hd_lang,$hd_lang_db);
      echo("<label class='hd_label_s1'>$ki:</label>");
      echo("<input class='hd_input_s1' type='text' id='m19' name='m19' value='$m[19]' size='120' maxlength='4' $readonly /><br />");
      $ki=sys_line("Kisz�ll�s (km)",$fl,$hd_lang,$hd_lang_db);
      echo("<label class='hd_label_s1'>$ki:</label>");
      echo("<input class='hd_input_s1' type='tex't id='m20' name='m20' value='$m[20]' size='120' maxlength='3' $readonly /><br />");
      echo("<br />");

      $ki=sys_line("Megb�z�s t�pusa",$fl,$hd_lang,$hd_lang_db);
      echo("<label class='hd_label_s1'>$ki:</label>");
      echo("<select id='m21 name='m21''>");
      $x=0;
      $y=count($hd_otype);
      $van=false;
      while ($x<$y){
        if ($hd_otype[$x]==$m[21]){
          echo("<option selected='selected'>$hd_otype[$x]");
	  $van=true;
	}else{
          echo("<option>$hd_otype[$x]");
	}
	$x++;
      }
      echo("</select><br />");
      $ki=sys_line("Kieg�sz�t�s",$fl,$hd_lang,$hd_lang_db);
      echo("<label class='hd_label_s1'>$ki:</label>");
      echo("<input class='hd_input_s1' type='text' id='m22' name='m22' value='$m[22]' size='120' maxlength='300' $readonly /><br />");
      $x=0;
      $y=count($hd_otype_k);
      $van=false;
      while ($x<$y){
        echo("<label class='hd_label_s3'>$hd_otype_k[$x]</label><br />");
	$x++;
      }
      echo("<br />");

      $ki=sys_line("Megb�z�s",$fl,$hd_lang,$hd_lang_db);
      echo("<label class='hd_label_s1'>$ki:</label>");
      echo("<select id='m23' name='m23'>");
      $x=0;
      $y=count($hd_order);
      $van=false;
      while ($x<$y){
        if ($hd_order[$x]==$m[23]){
          echo("<option selected='selected'>$hd_order[$x]");
	  $van=true;
	}else{
          echo("<option>$hd_order[$x]");
	}
	$x++;
      }
      echo("</select><br />");
      echo("<br />");

      $ki=sys_line("Tartoz�kok, �llapot �tv�telkor",$fl,$hd_lang,$hd_lang_db);
      echo("<label class='hd_label_s1'>$ki:</label>");
      echo("<input class='hd_input_s1' type='text' id='m24' name='m24' value='$m[24]' size='120' maxlength='300' $readonly /><br />");
      echo("<br />");

      $ki=sys_line("Jelenlegi �llapot",$fl,$hd_lang,$hd_lang_db);
      echo("<label class='hd_label_s1'>$ki:</label>");
      echo("<input class='hd_input_s1' type='text' id='m25' name='m25' value='$m[25]' size='120' maxlength='300' $readonly /><br />");

      $un=site_user("");
      if (in_array($un,$hd_admin_user)){
        echo("<br /><center>");
        $ki=sys_line("Mehet",$fl,$hd_lang,$hd_lang_db);
        //echo("<input class=hd_button_s1 type=submit value=$ki />");
        echo("<button class='button_1' id='hbu' name='hbu' type='submit' value='$ki'>$ki</button>");
        echo("</center>");
      }
      echo("</form>");
      echo("<br /><br />");
    }
  }

  // d�tum, id� ell��ll�t�sa

  function hd_date(){
    $dt=date("Y.m.d. H:i:s");
    return($dt);
  }

  function hd_date_2(){
    $dt=date("Y.m.d. H:i");
    return($dt);
  }

  function hd_date_3(){
    $dt=date("Y.m.d.");
    return($dt);
  }

  function hd_ymonth(){
    global $hd_month;

    $dt=date("Y");
    $id=date("m");
    $dt=$dt."/".$hd_month[$id];
    return($dt);
  }

  function hd_code(){
    $dt=date("U"); // unix time...
    return($dt);
  }

  // bejelentolap

  function hd_order(){
    global $hd_idx,$hd_lang,$hd_lang_db,$hd_file_felt,
           $dir_plugins,$hd_name,$hd_lang_file,
           $dir_site,$default_site,$hd_dir_data,
           $hd_b_name,$hd_b_address,$hd_b_phone,$hd_b_contact,
           $hd_otype,$hd_order,
           $hd_service_name,$hd_service_address,$hd_service_phone,
           $hd_service_email,$hd_service_web,$printed,
           $sitepage,$k_print,$hd_data,$hd_idx,$s_program,
           $hd_admin_user;

    $empty="<br />";
    $flang="$dir_plugins/$hd_name/$hd_lang_file";
    if ($hd_idx==""){
      $x=0;
      while($x<35){
        $bl[$x]=$empty;
        $x+=1;
      }
      //$bl[0]=hd_date();
      $bl[20]=$hd_otype[0];
      $bl[22]=$hd_order[0];
      if ($hd_b_name<>""){
        $bl[2]=$hd_b_name;
        $bl[3]=$hd_b_address;
        $bl[4]=$hd_b_contact;
        $bl[5]=$hd_b_phone;
      }
    }else{
      $d=$hd_idx;
      sys_file_in($d,$bl);
      $x=0;
      while($x<35){
        if (!isset($bl[$x])){
          $bl[$x]=$empty;
	}
        $x+=1;
      }
    }
    $uc=site_user("");
    if ((!$printed)and(in_array($uc,$hd_admin_user))){
      $ki=sys_line("Nyomtat�s",$flang,$hd_lang,$hd_lang_db);
      $p=sys_env_find($sitepage);
      sys_env_new($sitepage,$k_print);
      sys_env_plugin_new($hd_data,$hd_idx);
      $e=sys_env_plugin_pack();
      echo("<a class='href' href='./$s_program?$e'>$ki</a><br /><br />");
      sys_env_new($sitepage,$p);
      sys_env_plugin_del($hd_data);
    }
    $ki=sys_line("Megrendel�s",$flang,$hd_lang,$hd_lang_db);
    echo("<table border='1' class='hd_table_1' align='center'>");
    echo("<tr>");
    echo("<td width='30%' align='center'>");
    echo("$hd_service_address<br />$hd_service_phone<br />");
    echo("$hd_service_email");
    echo("</td>");
    echo("<td width='30%' align='center'>");
    echo("<b>$ki</b><br />");
    echo("<b>$hd_service_name</b><br />");
    echo("$hd_service_web");
    echo("</td>");
    echo("<td width='30%' align='left'>");
    $ki=sys_line("Sorsz�m",$flang,$hd_lang,$hd_lang_db);
    echo("$ki: <br /><b>$bl[1]</b><br />");
    $da=hd_date();
    $ki=sys_line("D�tum",$flang,$hd_lang,$hd_lang_db);
    echo("$ki: $da");
    echo("</td>");
    echo("</tr>");
    echo("</table>");
    echo("<br />");

    //$ki=sys_line("A megrendel� adatai",$flang,$hd_lang,$hd_lang_db);
    //echo("<center><label class=hd_label_4><b>$ki</b></label></center>");
    echo("<table border='1' class='hd_table_1' align='center'>");
    echo("<tr>");
    echo("<td width='25%' align='center' valign='top'>");
    $ki=sys_line("N�v",$flang,$hd_lang,$hd_lang_db);
    echo("$ki:");
    echo("</td>");
    echo("<td width='75%' align='left' valign='top'>");
    echo("$bl[2]");
    echo("</td>");
    echo("</tr><tr>");
    echo("<td width='25%' align='center' valign='top'>");
    $ki=sys_line("C�m",$flang,$hd_lang,$hd_lang_db);
    echo("$ki:");
    echo("</td>");
    echo("<td width='75%' align='left' valign='top'>");
    echo("$bl[3]");
    echo("</td>");
    echo("</tr><tr>");
    echo("<td width='25%' align='center' valign='top'>");
    $ki=sys_line("Kapcsolattart�",$flang,$hd_lang,$hd_lang_db);
    echo("$ki:");
    echo("</td>");
    echo("<td width='75%' align='left' valign='top'>");
    echo("$bl[4]");
    echo("</td>");
    echo("</tr><tr>");
    echo("<td width='25%' align='center' valign='top'>");
    $ki=sys_line("Telefonsz�m/E-mail",$flang,$hd_lang,$hd_lang_db);
    echo("$ki:");
    echo("</td>");
    echo("<td width='75%' align='left' valign='top'>");
    echo("$bl[5]");
    echo("</td>");
    echo("</tr>");
    echo("</table>");
    echo("<br />");

    //$ki=sys_line("Az eszk�z adatai",$flang,$hd_lang,$hd_lang_db);
    //echo("<center><label class=hd_label_4><b>$ki</b></label><center>");
    echo("<table border='1' class='hd_table_1' align='center'>");
    echo("<tr>");
    echo("<td width='25%' align='center'>");
    $ki=sys_line("Gy�rt�, t�pus",$flang,$hd_lang,$hd_lang_db);
    echo("$ki:");
    echo("</td>");
    echo("<td width='75%' align='left' valign='top'>");
    if ($hd_idx<>""){
      echo("$bl[6] - $bl[7]");
    }else{
      echo("$empty");
    }
    echo("</td>");
    echo("</tr><tr>");
    echo("<td width='25%' align='center' valign='top'>");
    $ki=sys_line("Gy�risz�m",$flang,$hd_lang,$hd_lang_db);
    echo("$ki:");
    echo("</td>");
    echo("<td width='75%' align='left' valign='top'>");
    echo("$bl[9]");
    echo("</td>");
    echo("</tr><tr>");
    echo("<td width='25%' align='center' valign='top'>");
    $ki=sys_line("Kateg�ria",$flang,$hd_lang,$hd_lang_db);
    echo("$ki:");
    echo("</td>");
    echo("<td width='75%' align='left' valign='top'>");
    echo("$bl[8]");
    echo("</td>");
    echo("</tr><tr>");
    echo("<td width='25%' align='center' valign='top'>");
    $ki=sys_line("Hibajelens�g",$flang,$hd_lang,$hd_lang_db);
    echo("$ki:");
    echo("</td>");
    echo("<td width='75%' align='left' valign='top'>");
    echo("$bl[12]");
    echo("</td>");
    echo("</tr><tr>");
    echo("<td width='25%' align='center' valign='top'>");
    $ki=sys_line("Tartoz�kok",$flang,$hd_lang,$hd_lang_db);
    echo("$ki,<br />");
    $ki=sys_line("�llapot �tv�telkor",$flang,$hd_lang,$hd_lang_db);
    echo("$ki:<br />");
    echo("</td>");
    echo("<td width='75%' align='left' valign='top'>");
    echo("$bl[24]");
    if ($hd_idx==""){
     echo("<br /><br />");
    }
    echo("</td>");
    echo("</tr>");
    echo("</table>");
    echo("<br />");

    //$ki=sys_line("A munka jellege",$flang,$hd_lang,$hd_lang_db);
    //echo("<center><label class=hd_label_4><b>$ki</b></label></center>");
    echo("<table border='1' class='hd_table_1' align='center'>");
    echo("<tr>");
    echo("<td width='25%' align='center' valign='top'>");
    $ki=sys_line("Megb�z�s t�pusa",$flang,$hd_lang,$hd_lang_db);
    echo("<b>$ki</b>");
    echo("</td>");
    echo("<td width='75%' align='center' valign='top'>");
    if ($hd_idx<>""){
      echo("<b>$bl[21]</b>");
      echo("</td>");
    }else{
      $x=0;
      $y=count($hd_otype);
      while($x<$y){
        echo("$hd_otype[$x] ");
	if ($x<$y-1){
	  echo(" / ");
	}
        $x+=1;
      }
    }
    echo("</td>");
    echo("</tr>");
    echo("<tr>");
    echo("<td width='25%' align='center' valign='top'>");
    $ki=sys_line("Feladat",$flang,$hd_lang,$hd_lang_db);
    echo("<b>$ki</b>");
    echo("</td>");
      echo("<td width='75%' align='center' valign='top'>");
    if ($hd_idx<>""){
      echo("<b>$bl[23]</b>");
    }else{
      $x=0;
      $y=count($hd_order);
      while($x<$y){
        echo("$hd_order[$x] ");
	if ($x<$y-1){
	  echo(" / ");
	}
        $x+=1;
      }
    }
    echo("</td>");
    echo("</tr>");
    echo("</table>");
    echo("<br />");

    echo("<table border='1' class='hd_table_1' align='center'>");
    echo("<tr>");
    echo("<td width='20%' align='center' valign='top'>");
    $ki=sys_line("Megjegyz�s",$flang,$hd_lang,$hd_lang_db);
    echo("$ki:");
    echo("</td>");
    echo("<td width='80%' align='left' valign='top'>");
    echo("<br /><br />");
    echo("</td>");
    echo("</tr>");
    echo("</table>");
    echo("<br />");

    $ki=sys_line("Felek �ltal elfogadott szerz�d�ses felt�telek",$flang,$hd_lang,$hd_lang_db);
    echo("<table border='1' class='hd_table_1' align='center'>");
    echo("<tr>");
    echo("<td width='30%' align='left' valign='top'>");
    echo("<font size='-4'>");
    echo("<b>$ki</b><br />");
    $d="$dir_plugins/$hd_name/$hd_file_felt";
    sys_file_in($d,$bt);
    $x=count($bt);
    $y=0;
    while($y<$x){
      echo("$bt[$y]<br />");
      $y+=1;
    }
    echo("</font>");
    echo("</td>");
    echo("</tr>");
    echo("</table>");

    $ki=hd_date_3();
    echo("<center><label class='hd_label_4'><b>$ki</b></label></center>");
    echo("<table border=1 class='hd_table_1' align='center'>");
    echo("<tr>");
    echo("<td width='50%' align='left' valign='top'>");
    echo("<br /><br />");
    echo("</td>");
    echo("<td width='50%' align='left' valign='top'>");
    echo("<br /><br />");
    echo("</td>");
    echo("</tr>");
    echo("<tr>");
    echo("<td width='50%' align='center' valign='top'>");
    $ki=sys_line("k�pvisel�je",$flang,$hd_lang,$hd_lang_db);
    echo("$hd_service_name $ki");
    echo("</td>");
    echo("<td width='50%' align='center' valign='top'>");
    $ki=sys_line("Megrendel�",$flang,$hd_lang,$hd_lang_db);
    echo("$ki");
    echo("</td>");
    echo("</tr>");
    echo("</table>");
    if (!$printed){
      echo("<br />");
    }
  }

  // munkalap

  function hd_work(){
    global $hd_idx,$hd_lang,$hd_lang_db,$hd_file_felt,
           $dir_plugins,$hd_name,$hd_lang_file,
           $dir_site,$default_site,$hd_dir_data,
           $hd_b_name,$hd_b_address,$hd_b_phone,$hd_b_contact,
           $hd_service_name,$hd_service_address,$hd_service_phone,
           $hd_service_email,$hd_service_web,$printed,
           $sitepage,$k_print,$hd_data,$hd_idx,$s_program,
           $hd_admin_user;

    $empty="<br />";
    $flang="$dir_plugins/$hd_name/$hd_lang_file";
    if ($hd_idx==""){
      $x=0;
      while($x<35){
        $bl[$x]=$empty;
        $x+=1;
      }
      //$bl[0]=hd_date();
      if ($hd_b_name<>""){
        $bl[2]=$hd_b_name;
        $bl[3]=$hd_b_address;
        $bl[4]=$hd_b_contact;
        $bl[5]=$hd_b_phone;
      }
    }else{
      $d=$hd_idx;
      sys_file_in($d,$bl);
      $x=0;
      while($x<35){
        if (!isset($bl[$x])){
         $bl[$x]=$empty;
        }
        $x+=1;
      }
    }
    $uc=site_user("");
    if ((!$printed)and(in_array($uc,$hd_admin_user))){
      $ki=sys_line("Nyomtat�s",$flang,$hd_lang,$hd_lang_db);
      $p=sys_env_find($sitepage);
      sys_env_new($sitepage,$k_print);
      sys_env_plugin_new($hd_data,$hd_idx);
      $e=sys_env_plugin_pack();
      echo("<a class='href' href='./$s_program?$e'>$ki</a><br /><br />");
      sys_env_new($sitepage,$p);
      sys_env_plugin_del($hd_data);
    }
    $ki=sys_line("Szerv�z munkalap",$flang,$hd_lang,$hd_lang_db);
    echo("<center><label class='hd_label_5'><b>$ki</b></label></center><br />");

    echo("<table border='1' class='hd_table_1' align='center'>");
    echo("<tr>");
    echo("<td width='50%' align='center' valign='top'>");
    echo("<b>$hd_service_name</b><br />$hd_service_address<br />");
    echo("$hd_service_phone, $hd_service_email<br />");
    echo("$hd_service_web");
    echo("</td>");
    echo("<td width='50%' align='center' valign='top'>");
    if ($hd_idx<>""){
      echo("<b>$bl[1]</b><br />");
      echo("<b>$bl[2]</b><br />$bl[3]<br />");
      echo("$bl[4] $bl[5]");
    }else{
      $ki=sys_line("Megrendel�",$flang,$hd_lang,$hd_lang_db);
      echo("$ki:");
      echo("<br /><b>$bl[2]</b><br />$bl[3]<br />");
      echo("$bl[4] $bl[5]");
    }
    echo("</td>");
    echo("</tr>");
    echo("</table>");
    echo("<br />");

    echo("<table border='1' class='hd_table_1' align='center'>");
    echo("<tr>");
    echo("<td width='25%' align='center' valign='top'>");
    $ki=sys_line("Bejelent�s ideje",$flang,$hd_lang,$hd_lang_db);
    echo("$ki");
    echo("</td>");
    echo("<td width='75%' align='center' valign='top'>");
    echo("$bl[1]");
    echo("</td>");
    echo("</tr>");
    echo("<tr>");
    echo("<td width='25%' align='center' valign='top'>");
    $ki=sys_line("Eszk�z",$flang,$hd_lang,$hd_lang_db);
    echo("$ki");
    echo("</td>");
    echo("<td width='75%' align='center' valign='top'>");
    if ($hd_idx<>""){
      echo("$bl[6] - $bl[7]");
    }else{
      echo("<br />");
    }
    echo("</td>");
    echo("</tr>");
    echo("<tr>");
    echo("<td width='25%' align='center' valign='top'>");
    $ki=sys_line("gy�ri sz�ma",$flang,$hd_lang,$hd_lang_db);
    echo("- $ki");
    echo("</td>");
    echo("<td width='75%' align='center' valign='top'>");
    echo("$bl[9]");
    echo("</td>");
    echo("</tr>");
    echo("<tr>");
    echo("<td width='25%' align='center' valign='top'>");
    $ki=sys_line("Tipus, s�rg�ss�g",$flang,$hd_lang,$hd_lang_db);
    echo("$ki");
    echo("</td>");
    echo("<td width='75%' align='center' valign='top'>");
    if ($hd_idx<>""){
      echo("$bl[10] - $bl[11]");
    }else{
      echo("<br />");
    }
    echo("</td>");
    echo("</tr>");
    echo("</table>");
    echo("<br />");

    echo("<table border='1' class='hd_table_1' align='center'>");
    echo("<td width='25%' align='center' valign='top'>");
    $ki=sys_line("Jav�t�s d�tuma",$flang,$hd_lang,$hd_lang_db);
    echo("$ki");
    echo("</td>");
    echo("<td width='75%' align='center' valign='top'>");
    echo("$bl[16]");
    echo("</td>");
    echo("</tr>");
    echo("<tr>");
    echo("<td width='25%' align='center' valign='top'>");
    $ki=sys_line("kezdete",$flang,$hd_lang,$hd_lang_db);
    echo("- $ki");
    echo("</td>");
    echo("<td width='75%' align='center' valign='top'>");
    echo("$bl[17]");
    echo("</td>");
    echo("</tr>");
    echo("<tr>");
    echo("<td width='25%' align='center' valign='top'>");
    $ki=sys_line("v�ge",$flang,$hd_lang,$hd_lang_db);
    echo("- $ki");
    echo("</td>");
    echo("<td width='75%' align='center' valign='top'>");
    echo("$bl[18]");
    echo("</td>");
    echo("</tr>");
    echo("<tr>");
    echo("<td width='25%' align='center' valign='top'>");
    $ki=sys_line("tartama (�ra)",$flang,$hd_lang,$hd_lang_db);
    echo("- $ki");
    echo("</td>");
    echo("<td width='75%' align='center' valign='top'>");
    if ($bl[19]<>$empty){
      echo("$bl[19]");
    }
    $ki=sys_line("�ra",$flang,$hd_lang,$hd_lang_db);
    echo("$ki");
    echo("</td>");
    echo("</tr>");
    echo("<tr>");
    echo("<td width='25%' align='center' valign='top'>");
    $ki=sys_line("Kisz�ll�s (km)",$flang,$hd_lang,$hd_lang_db);
    echo("$ki");
    echo("</td>");
    echo("<td width='75%' align='center' valign='top'>");
    if ($bl[20]<>$empty){
      echo("$bl[20]");
    }
    $ki=sys_line("km",$flang,$hd_lang,$hd_lang_db);
    echo("$ki");
    echo("</td>");
    echo("</tr>");
    echo("<tr>");
    echo("<td width='25%' align='center' valign='top'>");
    $ki=sys_line("Jav�t�st v�gezte",$flang,$hd_lang,$hd_lang_db);
    echo("$ki");
    echo("</td>");
    echo("<td width='75%' align='center' valign='top'>");
    echo("$bl[14]");
    echo("</td>");
    echo("</tr>");
    echo("</table>");
    echo("<br />");

    echo("<table border='1' class='hd_table_1' align='center'>");
    echo("<tr>");
    echo("<td width='20%' align='center' valign='top'>");
    $ki=sys_line("Hiba",$flang,$hd_lang,$hd_lang_db);
    echo("$ki");
    echo("</td>");
    echo("<td width='80%' align='left' valign='top'>");
    echo("$bl[12]<br /><br />");
    if ($hd_idx==""){
      echo("<br /><br />");
    }
    echo("</td>");
    echo("</tr>");
    echo("</table>");
    echo("<br />");

    echo("<table border='1' class='hd_table_1' align='center'>");
    echo("<tr>");
    echo("<td width='20%' align='center' valign='top'>");
    $ki=sys_line("Megold�s",$flang,$hd_lang,$hd_lang_db);
    echo("$ki,<br />");
    $ki=sys_line("anyagfelhaszn�l�s",$flang,$hd_lang,$hd_lang_db);
    echo("$ki");
    echo("</td>");
    echo("<td width='80%' align='left' valign='top'>");
    echo("$bl[15]<br /><br />");
    echo("<br /><br />");
    if ($bl[15]==$empty){
      echo("<br /><br />");
      echo("<br /><br />");
      echo("<br /><br />");
    }
    echo("</td>");
    echo("</tr>");
    echo("</table>");
    echo("<br />");

    $ki=hd_date_3();
    echo("<center><label class='hd_label_4'><b>$ki</b></label></center>");
    echo("<table border='1' class='hd_table_1' align='center'>");
    echo("<tr>");
    echo("<td width='50%' align='left'>");
    echo("<br /><br />");
    echo("</td>");
    echo("<td width='50%' align='left' valign='top'>");
    echo("<br /><br />");
    echo("</td>");
    echo("</tr>");
    echo("<tr>");
    echo("<td width='50%' align='center' valign='top'>");
    $ki=sys_line("k�pvisel�je",$flang,$hd_lang,$hd_lang_db);
    echo("$hd_service_name $ki");
    echo("</td>");
    echo("<td width='50%' align='center' valign='top'>");
    $ki=sys_line("Megrendel�",$flang,$hd_lang,$hd_lang_db);
    echo("$ki");
    echo("</td>");
    echo("</tr>");
    echo("</table>");
    if (!$printed){
      echo("<br />");
    }
  }


?>
