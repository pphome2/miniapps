<?php

  global $hd_name,$hd_css_file,$hd_lang_file,
         $hd_index,$hd_viewdata,$hd_orderpage,$hd_work,$hd_del,
	 $hd_dir_data,$hd_file_felt,$hd_data,$hd_dir,$hd_p_add,
	 $hd_p_list,$hd_p_view,$hd_p_index,$hd_p_order,
	 $hd_p_work,$hd_p_akt,$hd_p_akto,$hd_p_del,$hd_char,
	 $hd_lang,$hd_langdb,$hd_idx,$hd_ddir,$hd_indata,
	 $hd_local_conf_file;

  $hd_name="Helpdesk";
  $hd_css_file="helpdesk.css";
  
  $hd_local_conf_file="hd_local_conf.php";

  $hd_lang_file="lang/";
  $hd_index="Bejelent�sek list�ja";
  $hd_viewdata="Adatok";
  $hd_orderpage="Bejelent�lap";
  $hd_work="Munkalap";
  $hd_del="Bejelent�s t�rl�se";
  $hd_dir_data="hd_data";
  $hd_file_felt="txt/felt.txt";
  
  $hd_data="data";
  $hd_dir="hddir";
  
  $hd_p_add="a";
  $hd_p_list="l";
  $hd_p_view="v";
  $hd_p_index="i";
  $hd_p_order="o";
  $hd_p_work="w";
  $hd_p_akt="m";
  $hd_p_akto="b";
  $hd_p_del="d";
  
  $hd_char="=";
  $hd_lang[0][0]="";
  $hd_langdb=0;
  $hd_idx="";
  $hd_ddir="";
  $hd_indata="";
?>
