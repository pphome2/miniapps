<?php

  sys_load_run("$dir_plugins/News/news_conf.php","");

  function news_init(){
    global $n_page,$n_page_env,
           $n_page_rss,$no_out_html,
           $n_page_name,$n_page_rss_name;

    //$fs="$dir_plugins/$n_name/$n_css_file";
    //sys_style($fs);
    $n_page=sys_env_plugin_find($n_page_env);
    if ($n_page==$n_page_rss_name){
      $no_out_html=true;
      $n_page_rss=true;
    }else{
      if ($n_page==""){
        $n_page=1;
      }
    }
    sys_env_plugin_del($n_page_env);
  }

  function news(){
    global $n_page_rss;

    if ($n_page_rss){
      rss_out();
    }else{
      news_out();
    }
  }

  function rss_out(){
    global $sitepos,$sitedata,$siteline,$default_site,
           $k_szerk,$l_open,$l_end,$s_program,$s_plugin,
           $s_program,$sitepage,$k_print,$n_page,$n_mark,
           $printed,$editor,$dir_plugins,$n_name,
           $n_page_db,$n_page_env,$s_img,$s_line,
           $n_page_rss_name,$n_page_rss_db,$usercode,
           $description,$lang_system,$s_full_program,
           $s_full_path,$dir_site,$dir_img,$site_logo;

    echo('<?xml version="1.0" encoding="ISO-8859-2" ?>');
    echo('<!DOCTYPE rss PUBLIC "-//Netscape Communications//DTD RSS 0.91//EN" ');
    echo('"http://my.netscape.com/publish/formats/rss-0.91.dtd">');
    echo('<rss version="2.0">');
    sys_env_del($usercode);
    $lap=sys_env_find($sitepos);
    if ($lap==""){
      $lap=$default_site;
    }
    $bord=0;
    $f="$lap";
    $ig=$n_page_rss_db;
    site_in($f);
    $x=0;
    $kidata=0;
    $db=0;
    $open=false;
    $siteline=count($sitedata);
    echo("<channel>");
    echo("<title>$default_site</title>");
    echo("<link>$s_full_program?site=$defalt_site</link>");
    echo("<description>$description</description>");
    echo("<language>$lang_system</language>");
    $d=date('D, d M Y G:i:s O');
    echo("<pubDate>$d</pubDate>");
    echo("<image>");
    echo("<title>$default_site</title>");
    $k="$s_full_path".substr($dir_site,3,strlen($dir_site)-3)."/$default_site/$dir_img/$site_logo";
    echo("<url>$k</url>");
    echo("<link>$s_full_program?site=$defalt_site</link>");
    echo("</image>");
    $firstline=true;
    $new=false;
    while ($x<$siteline) {
      if (substr($s,1,3)==substr($s_line,0,3)){
        $x=$siteline;
        $kidata=$ig;
      }else{
        $s=$sitedata[$x];
        if ($kidata<$ig){
          $v0=0;
          while ($v0<strlen($s)){
            if (substr($s,$v0,1)==$n_mark){
              $v1=$v0+1;
              while (($v1<strlen($s))and(substr($s,$v1,1)<>$n_mark)){
                $v1+=1;
              }
              if (substr($s,$v1,1)==$n_mark){
                $s2=substr($s,$v0+1,$v1-$v0-1);
                $t=explode(' ',$s2);
                $dat1=str_replace(".","-",$t[0]);
                if (substr($dat1,strlen($dat1)-1,1)=="-"){
                  $dat1=substr($dat1,0,substr($dat1)-1);
                }
                $dat1=$dat1." ".$t[1];
                $dat=strtotime($dat1);
                $d=date('D, d M Y G:i:s O',$dat);
                $s=substr($s,0,$v0).$l.substr($s,$v1+1,strlen($s));
              }
            }
            if (substr($s,$v0,1)==$l_open){
              $v1=$v0+1;
              while (($v1<strlen($s))and(substr($s,$v1,1)<>$l_end)){
                $v1+=1;
              }
              if (substr($s,$v1,1)==$l_end){
                $s2=substr($s,$v0+1,$v1-$v0-1);
                $t=explode(' ',$s2);
                $l="";
                if (($t[0]<>$s_plugin)and($t[0]<>$s_program)){
                  $l=site_lang($s2);
                  if (substr($l,1,3)=="<hr"){
                    $new=true;
                  }
                }else{
                  $s="";
                }
                $s=substr($s,0,$v0).substr($s,$v1+1,strlen($s));
              }
              $v0=0;
            }
            $v0+=1;
          }
          if ($s<>""){
            if ($new){
              $kidata+=1;
              $db+=1;
              $new=false;
              echo("</description>");
              echo("<pubDate>$d</pubDate>");
              echo("</item>");
              $firstline=true;
            }else{
              $s=strip_tags($s);
              if (strlen($s)>3){
                if ($firstline){
                  echo("<item>");
                  echo("<title>$s</title>");
                  $fn="$s";
                  $fn=sys_standard_name($fn);
                  sys_env_new($sitepos,$fn);
                  $e=sys_env_plugin_pack();
                  echo("<link>$s_full_program?$e</link>");
                  $firstline=false;
                  echo("<description>");
                }else{
                  echo("$s");
                }
              }else{
                $s="";
              }
            }
          }
        }
      }
      $x+=1;
    }
    echo("</description>");
    echo("</item>");
    echo("</channel>");
    echo("</rss>");
  }


  function news_out(){
    global $sitepos,$sitedata,$siteline,$default_site,
           $k_szerk,$l_open,$l_end,$s_program,$s_plugin,
           $s_program,$sitepage,$k_print,$n_page,
           $printed,$editor,$dir_plugins,$n_name,$n_lang_file,
           $n_page_db,$n_lang,$n_lang_db,$n_page_env,$s_img,$s_line,
           $comment_ext,$site_data_css_container,$n_mark,
           $n_page_rss_name,$usercode,$n_page_rss_support,
           $n_page_div_head,$n_page_div_line;

    $fl="$dir_plugins/$n_name/$n_lang_file";
    $lap=sys_env_find($sitepos);
    if ($lap==""){
      $lap=$default_site;
    }
    $bord=0;
    if ($printed){
      $bord=1;
    }
    $f="$lap";
    $alap=$n_page;
    if ($alap==""){
      $alap=1;
      $tol=-1;
    }else{
      $tol=($alap-1)*$n_page_db;
    }
    echo("<div class='$n_page_div_head'>");
    site_in($f);
    $tov=sys_line("Tov�bb",$fl,$n_lang,$n_lang_db);
    $x=0;
    $kidata=0;
    $uj=true;
    $link="";
    $db=0;
    $open=false;
    $add=true;
    while ($x<$siteline) {
      $s=$sitedata[$x];
      if (($kidata>=$tol)and($kidata<($tol+$n_page_db))){
        $v0=0;
        while ($v0<strlen($s)){
          if (substr($s,$v0,1)==$n_mark){
            $v1=$v0+1;
            while (($v1<strlen($s))and(substr($s,$v1,1)<>$n_mark)){
              $v1+=1;
            }
            if (substr($s,$v1,1)==$n_mark){
              $s2=substr($s,$v0+1,$v1-$v0-1);
              $t=explode(' ',$s2);
              echo("<br /><i> - $t[2], $t[0] $t[1]</i>");
              $s=substr($s,0,$v0).substr($s,$v1+1,strlen($s));
            }
          }
          if (substr($s,$v0,1)==$l_open){
            $v1=$v0+1;
            while (($v1<strlen($s))and(substr($s,$v1,1)<>$l_end)){
              $v1+=1;
            }
            if (substr($s,$v1,1)==$l_end){
              $s2=substr($s,$v0+1,$v1-$v0-1);
              $t=explode(' ',$s2);
              $l="";
              if (($t[0]<>$s_plugin)and($t[0]<>$s_program)){
                $l=site_lang($s2);
              }else{
                $s="";
              }
              $s=substr($s,0,$v0).$l.substr($s,$v1+1,strlen($s));
            }
            $v0=0;
          }
          $v0+=1;
        }
        if (($x==$siteline)and($open)){
          $s="<hr";
        }
        if ($s<>""){
          if (substr($s,1,3)=="<hr"){
            $link=trim($link," ");
            if (strlen($link)>1){
              $uj=true;
              $add=true;
              $kidata+=1;
              $db+=1;
              if (($printed<>true)and($editor<>true)){
                //$fn="$link$comment_ext";
                $fn="$link";
                $fn=sys_standard_name($fn);
                sys_env_new($sitepos,$fn);
                $e=sys_env_plugin_pack();
                echo("<label class='n_label_1'>");
                echo("<a class='href' href='$s_program?$e'>$tov</a>");
                echo("</label><br /><br />");
                if ($site_data_css_container<>""){
                  $open=false;
                }
              }
            }
            $link="";
          }else{
            if (strlen($s)>1){
              if ($uj){
                $uj=false;
                if ($x<$siteline){
                  if (($printed<>true)and($editor<>true)){
                    $open=true;
                    if ($site_data_css_container<>""){
                      //echo("</div>");
                      //echo("<div class='$site_data_css_container'>");
                    }else{
                      //echo("<hr width='85%' />");
  	            }
                    echo("</div><div class='$n_page_div_line'>");
                  }
                }
                if (($printed<>true)and($editor<>true)){
                  //$fn="$link$comment_ext";
                  $fn=$s;
                  $fn=strip_tags($fn);
                  $fn=sys_standard_name($fn);
                  sys_env_new($sitepos,$fn);
                  $e=sys_env_plugin_pack();
                  $s="<a class='href' href='$s_program?$e'>$s</a>";
                  echo($s);
                  if ($site_data_css_container<>""){
                    $open=false;
                  }
                }
              }else{
                if ($add){
                  if (($printed<>true)and($editor<>true)){
                    echo("</div>");
                    echo("<div class='$n_page_div_head'>");
                  }
                  $add=false;
                }
                echo("$s ");
              }
              if ($link==""){
                $link=$s;
                $link=strip_tags($link);
                if (strlen($link)<4){
                  $link="";
                }
              }
            }
          }
        }
      }else{
        if (substr($s,1,3)==substr($s_line,0,3)){
          $db+=1;
          $kidata+=1;
        }
      }
      $x+=1;
    }
    if (($x==$siteline)and($open)){
      if (($printed<>true)and($editor<>true)){
        $link=trim($link," ");
        if (strlen($link)>1){
          //$fn="$link$comment_ext";
          $fn="$link";
          $fn=sys_standard_name($fn);
          sys_env_new($sitepos,$fn);
          $e=sys_env_plugin_pack();
          echo("<label class='n_label_1'><a class='href' href='$s_program?$e'>$tov</a></label>");
          echo("<br /><br />");
        }
      }
    }
    if (!$open){
      if ($site_data_css_container<>""){
        echo("</div>");
      }else{
        echo("<hr width='85%' />");
      }
    }
    sys_env_new($sitepos,$lap);
    if (!$printed){
      if ($db>$n_page_db){
        if ($site_data_css_container<>""){
          //echo("</div>");
          //echo("<div class='$site_data_css_container'>");
        }else{
          //echo("<hr width='85%' />");
        }
        //echo("</div>");
        site_pageing($db,$n_page_db,$alap,$n_page_env);
      }
    }
    if (($n_page==1)and($n_page_rss_support)){
      if (($site_data_css_container<>"")and(!$printed)){
        echo("</div>");
        echo("<div class='$site_data_css_container'>");
        sys_env_new($n_page_env,$n_page_rss_name);
        $uc=sys_env_find($usercode);
        sys_env_del($usercode);
        $e=sys_env_plugin_pack();
        $rski="RSS szolg�ltat�s"; //sys_line("RSS",$fl,$n_lang,$n_lang_db);
        echo("<label class='n_label_1'><a class='href' href='$s_program?$e'>$rski</a></label>");
        sys_env_plugin_del($n_page_env);
        sys_env_new($usercode,$uc);
      }else{
        echo("<hr width='85%' />");
      }
    }
  }

?>
