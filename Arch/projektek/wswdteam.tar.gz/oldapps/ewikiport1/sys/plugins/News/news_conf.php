<?php

  global $n_name,$n_css_file,$n_lang_file,
         $n_page_db,$n_page_env,$n_langdb,$n_page,
         $n_page_rss_name,$n_page_rss_db,$n_page_rss,
         $n_page_rss_support,$n_mark,
         $n_page_div_head,$n_page_div_line;

  $n_name="News";
  $n_css_file="news.css";

  $n_lang_file="lang/lang.txt";

  $n_page_db=10;
  $n_page_env="nlap";
  $n_mark="|";

  $n_page_rss_name="rss";
  $n_page_rss_db="20";
  $n_page_rss=false;

  $n_page_rss_support=true;

  $n_page_div_head="menu_block";
  $n_page_div_line="add_line";

  $n_langdb=0;
  $n_page="";

?>
