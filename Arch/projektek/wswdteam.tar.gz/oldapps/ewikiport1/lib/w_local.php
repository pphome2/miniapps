<?php

  // w_robot --- PHP portalrobot
  // (verzioadatok a konfiguracios fajlban)
  //
  // fejleszto: Zebulon.hu Team



  // include es futtatas

  function site_load_run($pluginname,$runfunc,$p0,$p1,$p2,$p3,$p4){
    global $dir_plugins;

    $incfile="$dir_plugins/$pluginname/$pluginname.php";
    if (file_exists($incfile)){
      include($incfile);
      if ($runfunc<>""){
        call_user_func($runfunc,$p0,$p1,$p2,$p3,$p4);
      }
    }else{
      if ($pluginname<>""){
        call_user_func($pluginname,$runfunc,$p0,$p1,$p2,$p3,$p4);
      }
    }
  }

  // a site inditasa

  function site_open(){
    global $usercode,$sitepos,$default_site,$no_out_html,
           $administrator,$site_adm,$s_dev_mail,
	   $reg_menu_ext,$guest_user,$user_admin,
	   $local_menu_ext,$dir_data,$dir_files,$dir_img,
	   $search_dir,$search_dir_name,$open_page,
	   $template_path,$file_template_css,$site_adsense,
	   $file_template_css_page,$dir_site,$file_system_css,
	   $file_site_css,$file_meta,$sitename,$file_adsense,
	   $lang_file,$lang_label,$language,$langfile,
	   $dir_system,$dir_lang,$lang_system,$dir_conf,
	   $doctype,$xmltype,$htmlpar,$keyword,$description,
	   $dir_plugins,$env_plugin_style_file;

    if (!$no_out_html){
      if (!$site_adm){
        $administrator=$s_dev_mail;
      }
      $lang_file=$lang_file.$lang_system;
      $langfile="../$dir_lang/$lang_file";
      $n=sys_env_find($usercode);
      if ($n<>""){
        $n2=site_user("");
        if ($n2==""){
          sys_env_del($usercode);
        }
        if ($n2==$administrator){
          $user_admin=true;
        }
      }
      $lap=sys_env_find($sitepos);
      if ($lap==""){
        sys_env_new($sitepos,$default_site);
        $open_page=true;
      }
      $guest_user=sys_line_local($guest_user);
      $reg_menu_ext=sys_line_local($reg_menu_ext);
      $local_menu_ext=sys_line_local($local_menu_ext);
      $search_dir_name[0]=sys_line_local("Adatt�r");
      $search_dir[0]="$dir_data";
      $search_dir_name[1]=sys_line_local("K�nyvt�r");
      $search_dir[1]="$dir_files";
      //$search_dir_name[2]=sys_line_local("K�pt�r");
      //$search_dir[2]="$dir_img";
      echo($xmltype);
      echo($doctype);
      echo("<html $htmlpar>");
      echo("<head>");
      $f="$dir_site/$default_site/$file_meta";
      sys_meta($f,$keyword,$description);
      $f="$dir_site/$default_site/$file_adsense";
      if (file_exists($f)){
        sys_load_run("$f","");
      }
      $siten=sys_env_find($sitename);
      if ($siten==""){
        $siten=$default_site;
      }
      $siten=sys_unstandard_name($siten);
      $file="$dir_conf/$file_system_css";
      sys_style($file);
      $file="$dir_site/$default_site/$file_site_css";
      sys_style($file);
      $file="$template_path/$file_template_css_page";
      sys_style($file);
      $file="$template_path/$file_template_css";
      sys_style($file);
      sys_style_in($dir_plugins,$env_plugin_style_file);
      echo("<title>$siten</title>");
      echo("</head>");
      site_lang_init($lang_system);
    }
  }


function site_lang_init(){
  global $guest_user,$help_main_page,$reg_menu_ext,$local_menu_ext;

  $guest_user=sys_line_local($guest_user);
  $help_main_page=sys_line_local($help_main_page);
  $reg_menu_ext=sys_line_local($reg_menu_ext);
  $local_menu_ext=sys_line_local($local_menu_ext);
}

function site_lang_move($tomb){
  $i=0;
  $y=count($tomb);
  while ($i<$y){
    $tomb[$i]=sys_line_local($tomb[$i]);
    $i+=1;
  }
}


  // a site zarasa

  function site_end(){
    global $page_div_close,$no_out_html;

    if (!$no_out_html){
      if ($page_div_close){
        echo("</div>");
      }
      echo("</div></body></html>");
    }
  }


  function site_page_div_close(){
    global $page_div_close;

    $page_div_close=true;
  }

  // adatok beolvasasa

  function site_file_in($f,&$tomb,&$tindex){
    sys_file_in($f,$tomb);
    $tindex=count($tomb);
  }

  // adatok kiirasa

  function site_file_out($f,$tomb,$tindex){
    sys_empty($tomb);
    sys_file_out($f,$tomb);
  }

  // adatok beolvasasa

  function site_file_in_lock($f,&$tomb,&$tindex){
    sys_file_in_lock($f,$tomb);
    $tindex=count($tomb);
  }

  // adatok kiirasa

  function site_file_out_lock($f,$tomb,$tindex){
    sys_empty($tomb);
    sys_file_out_lock($f,$tomb);
  }

  // site adatok beolvasasa

  function site_in($file){
    global $sitedata,$siteline,
           $dir_site,$default_site,$dir_data;

    if (substr($file,0,2)==".."){
      $filename="$file";
    }else{
      $filename="$dir_site/$default_site/$dir_data/$file";
    }
    sys_file_in($filename,$sitedata);
    $siteline=count($sitedata);
  }

  // site adatok kiirasa

  function site_out($file){
    global $sitedata,$siteline,
           $dir_data,$dir_site,$default_site;

    if (substr($file,0,2)==".."){
      $filename="$file";
    }else{
      $filename="$dir_site/$default_site/$dir_data/$file";
    }

    sys_empty_db($sitedata,$siteline);
    sys_file_out($filename,$sitedata);
  }

  // egy lap nev visszaadasa

  function site_page_name(){
    global $sitepos;

    $lap=sys_env_find($sitepos);
    $nev=sys_unstandard_name($lap);
    return($nev);
  }

  // bejelentkezes, uj felhasznalo

  function site_enter_in(){
    global $tk,$te,$usercode,$sitepage,
           $dir_data,$separator,$administrator,
           $regdata,$regdb,$s_program,
           $file_reg,$dir_site,$default_site;

    $filename="$dir_site/$default_site/$file_reg";
    site_file_in($filename,$regdata,$regdb);
    $ok=sys_data_post($dbx,$tkx,$tex);
    $unev="";
    $s=0;
    while ($s<$regdb){
      if ($regdata[$s]!=""){
	$tomb=explode($separator,$regdata[$s]);
	$s=md5($tex[1]);
	if (($tomb[3]==$tex[0])and($tomb[4]==md5($tex[1]))){
	  $utime=time();
	  $unev=$tomb[0];
	  if ($tomb[3]==$administrator){
	    //$unev=$tomb[7];
	  }else{
	    if (count($tomb)>=7){
	      if ($tomb[2]<>0){
	        $timelimit=$tomb[1]+$tomb[2];
	      }else{
	        $timelimit=$utime+1;
	      }
	      if ($timelimit>=$utime){
	        $unev=$tomb[0];
	      }else{
	        site_user_del($tomb[0]);
	      }
	    }
	  }
	  $s=$regdb;
	}
      }
      $s+=1;
    }
    if ($unev<>""){
      sys_env_del($sitepage);
      sys_env_new($usercode,$unev);
    }
    return($unev);
  }

  // user nevenek visszaadasa

  function site_user($kod){
    global $usercode,$sitepage,$file_reg,
           $dir_data,$separator,
           $regdata,$regdb,
           $dir_site,$default_site;

    $filename="$dir_site/$default_site/$file_reg";
    if ($kod==""){
      $kod=sys_env_find($usercode);
      $n=false;
    }else{
      $n=true;
    }
    site_file_in($filename,$regdata,$regdb);
    $unev="";
    $s=0;
    while ($s<$regdb){
      if ($regdata[$s]!=""){
	$tomb=explode($separator,$regdata[$s]);
	if ($n){
	  if ($tomb[3]==$kod){
	    $unev=$tomb[3];
	    $s=$regdb;
	  }
	}else{
	  if ($tomb[0]==$kod){
	    $unev=$tomb[3];
	    $s=$regdb;
	  }
	}
      }
      $s+=1;
    }
    return($unev);
  }

  // user adatai

  function site_user_data(){
    global $usercode,$sitepage,$file_reg,
           $dir_data,$separator,
           $regdata,$regdb,
           $dir_site,$default_site;

    $filename="$dir_site/$default_site/$file_reg";
    $kod=sys_env_find($usercode);
    site_file_in($filename,$regdata,$regdb);
    $unev="";
    $s=0;
    while ($s<$regdb){
      if ($regdata[$s]!=""){
	$tomb=explode($separator,$regdata[$s]);
	if ($tomb[0]==$kod){
	  $unev=$regdata[$s];
	  $s=$regdb;
	}
      }
      $s+=1;
    }
    return($unev);
  }

  // felhasznalok kezelese tombben

  function site_user_check(&$tch,$sep){
    global $usercode,$sitepage,$file_reg,
           $dir_data,$separator,
           $regdata,$regdb,
           $dir_site,$default_site;

    $filename="$dir_site/$default_site/$file_reg";
    $kod=sys_env_find($usercode);
    site_file_in($filename,$regdata,$regdb);
    $tchdb=count($tch);
    $x=0;
    while ($x<$tchdb){
      $s=0;
      $tn=explode($sep,$tch[$x]);
      if ($tn[0]<>""){
        $tchok=false;
        while ($s<$regdb){
	  $tomb=explode($separator,$regdata[$s]);
	  if ($tomb[0]<>""){
            if ($tn[0]==$tomb[0]){
              $tchok=true;
              $s=$regdb;
            }
          }
          $s+=1;
        }
        if (!$tchok){
          $tch[$x]="";
        }
      }
      $x+=1;
    }
    $x=0;
    $xy=0;
    $tch2=array();
    while ($x<$tchdb){
      if ($tch[$x]<>""){
        $tch2[$xy]=$tch[$x];
        $xy+=1;
      }
      $x+=1;
    }
    $tch=$tch2;
  }

  // user torlese

  function site_user_del($kod){
    global $dir_site,$default_site,$file_reg,
           $regdata,$regdb,$separator;

    if ($kod<>""){
      $filename="$dir_site/$default_site/$file_reg";
      site_file_in_lock($filename,$regdata,$regdb);
      $x=0;
      while (($x<$regdb)and($kod<>"")) {
        $tomb=explode($separator,$regdata[$x]);
        if ($tomb[0]<>""){
          if ($tomb[0]==$kod){
            $kod="";
            $regdata[$x]="";
          }
        }
        $x+=1;
      }
      site_file_out_lock($filename,$regdata,$regdb);
    }
  }

  // uj felhasznalo felvitele

  function site_new_reg(){
    global $newdata,$separator,
           $regdb,$regdata,$dataedit,
           $s_program,$file_reg,
           $dir_site,$default_site;

    $filename="$dir_site/$default_site/$file_reg";
    if ($dataedit){
      sys_env_del($newdata);
      $ok=1;
      $data="";
      $d=date("U");
      $data=$data.$d.$separator;
      $nuser="";
      $ok2=sys_data_post($dbx,$tkx,$tex);
      $x=0;
      while ($x<$dbx){
        if ($x==2){
	  $nuser=$tex[$x];
	}
        if ($x==3){
	  $tex[$x]=md5($tex[$x]);
	}
	$data=$data.$tex[$x];
	$data=$data.$separator;
	if ($tex[$x]==""){
	  $ok=0;
	}$ki=sys_line_local("A regisztr�ci� siker�lt. Jelentkezzen be");
	$x+=1;
      }
      if ($ok==1){
        $n=site_user($nuser);
        if ($n==""){
          site_file_in_lock($filename,$regdata,$regdb);
          $x=0;
          //$regdb+=1;
	  $regdata[$regdb]=$data;
          site_file_out_lock($filename,$regdata,$regdb);
          $ki=sys_line_local("A regisztr�ci� siker�lt. Jelentkezzen be");
	  echo("<br />$ki.<br /><br />");
	}else{
          $ki=sys_line_local("Ezen a n�ven m�r l�tezik regisztr�ci�. K�rem haszn�ljon m�s nevet");
	  echo("<br />$ki.<br /><br />");
	}
      }else{
        $ki=sys_line_local("A regisztr�ci�s adatok nincsenek megfelel�en kit�ltve");
        echo("<br /><br />$ki.<br /><br />");
        $ki=sys_line_local("K�rem, ellen�rizze az adatokat");
        echo("$ki.<br /><br />");
      }
    }else{
      site_reg_new();
    }
  }

  // uzenofal megvalositasa

  function site_message_wall_menu(){
    site_message_wall("","");
  }

  // site adminisztracio

  function site_admin($m){
    global $sitepos,$regdb,$regdata,$deldata,$delkod,
           $usercode,$user_admin,$separator,$dirdata,
           $dir_site,$default_site,$dir_data,$dir_img,
           $k_admin_1,$k_admin_2,$k_admin_3,$k_admin_4,
           $k_admin_5,$k_admin_6,$dir_files,$file_reg,
           $file_user_config;

    if ($user_admin){
      switch ($m){
        case $k_admin_1:
          site_user_del($delkod);
          break;
        case $k_admin_2:
          if ($delkod<>""){
            if (substr($delkod,0,2)<>".."){
            }else{
	      sys_file_del($delkod);
            }
	    $delkod="";
          }
          break;
        case $k_admin_3:
          if ($delkod<>""){
            if (substr($delkod,0,2)<>".."){
              $filename="$dir_site/$default_site/$dir_data/$delkod";
	      sys_file_del($filename);
            }else{
	      sys_file_del($delkod);
            }
            $delkod="";
          }else{
	    if (isset($_FILES['userfile']['name'])){
              if (basename($_FILES['userfile']['name'])<>""){
                $uploaddir="$dir_site/$default_site/$dir_img";
                //$t=explode("/",$data);
                //$c=count($t);
                //if ($c<0){
                //  $c=0;
                //}
                //$fn=$t[$c];
                //if ($fn==""){
                //  $fn=$t[$c-1];
                //}
                $uploadfile=$uploaddir."/".basename($_FILES['userfile']['name']);
                //$uploadfile=$uploaddir."/".$fn;
                if (move_uploaded_file($_FILES['userfile']['tmp_name'], $uploadfile)) {
                  $ki=sys_line_local("A felt�lt�s megt�rt�nt");
                  echo("<br />$ki.<br />");
                }else{
                  $ki=sys_line_local("Hiba a felt�lt�s k�zben");
                  echo("<br />$ki.<br />");
		}
              }
            }
          }
          break;
        case $k_admin_4:
          if ($delkod<>""){
            if (substr($delkod,0,2)<>".."){
              $filename="$dir_site/$default_site/$dir_data/$delkod";
	      sys_file_del($filename);
            }else{
	      sys_file_del($delkod);
            }
            $delkod="";
          }else{
	    if ($dirdata<>""){
	      $uploaddir=$dirdata;
	    }else{
              $uploaddir="$dir_site/$default_site/$dir_files";
	    }
	    if (isset($_FILES['userfile']['name'])){
              if (basename($_FILES['userfile']['name'])<>""){
                //$t=explode("/",$dirdata);
                //$c=count($t)-1;
                //if ($c<0){
                //  $c=0;
                //}
                //$fn=$t[$c];
                //if ($fn==""){
                //  $fn=$t[$c-1];
                //}
                $uploadfile=$uploaddir."/".basename($_FILES['userfile']['name']);
                //$uploadfile=$uploaddir."/".$fn;
                if (move_uploaded_file($_FILES['userfile']['tmp_name'], $uploadfile)) {
                  $ki=sys_line_local("A felt�lt�s megt�rt�nt");
                  echo("<br />$ki.<br />");
                }else{
                  $ki=sys_line_local("Hiba a felt�lt�s k�zben");
                  echo("<br />$ki.<br />");
		}
              }else{
                $ok=sys_data_post($db,$tk,$te);
		if ($ok){
		  $te[0]=sys_standard_name($te[0]);
		  sys_mkdir("$uploaddir/$te[0]");
		}
	      }
            }
          }
          break;
        case $k_admin_5:
          break;
        case $k_admin_6:
          $ok=sys_data_post($db,$tkx,$tex);
          if ($ok){
            $conffile="$dir_site/$default_site/$file_user_config";
            $d=date("U");
            $conffilesave=$conffile."-".$d;
            $ki=sys_line_local("Ment�s");
            $ki2=sys_line_local("nem siker�lt");
            $ki3=sys_line_local("siker�lt, friss�tse az oldalt");
            $ok=sys_file_copy($conffile,$conffilesave);
            if ($ok){
              $x=0;
              while ($x<=$db){
	        $s[$x]=str_replace("\\\"","\"",$tex[$x]);
	        //$s[$x]=$tex[$x];
	        $x+=1;
	      }
              sys_file_out($conffile,$s);
              echo("<br />$ki $ki3.<br /><br />");
            }else{
              echo("<br />$ki $k2.<br /><br />");
            }
          }
          break;
        }
      }
    // tovabbi admin feladatok
    site_global_admin($m);
  }

  // sajat adatok szerkesztese

  function site_privat(){
    global $regdb,$regdata,$usercode,$separator,
           $dir_site,$default_site,$file_reg;

    $filename="$dir_site/$default_site/$file_reg";
    $ukod=sys_env_find($usercode);
    $dbx=0;
    $data="";
    $ok=sys_data_post($dbx,$tkx,$tex);
    if ($ok){
      site_file_in_lock($filename,$regdata,$regdb);
      $db=0;
      $tomb[0]="";
      $tomb[7]="";
      while (($db<$regdb)and($ukod<>$tomb[0])){
        $tomb=explode($separator,$regdata[$db]);
        $db+=1;
      }
      if ($tomb[0]<>""){
        $x=0;
        while ($x<$dbx){
          if ($x==4){
            if ($tomb[4]<>$tex[$x]){
              $tex[$x]=md5($tex[$x]);
            }else{
              //echo("<br />Jelsz� v�ltozatlan: $x.<br />");
            }
          }
          $data=$data.$tex[$x];
          $data=$data.$separator;
          $x+=1;
        }
        //$data=$data.$ukod."$separator";
        $regdata[$db-1]=$data;
      }
      site_file_out_lock($filename,$regdata,$regdb);
      echo("");
      $ki=sys_line_local("Adatok ment�se megt�rt�nt");
      echo("$ki.");
      echo("<br /><br />");
    }
    site_privat_edit();
  }

  // hirlevel kerese

  function site_mail(){
    global $regdb,$regdata,$usercode,$separator,
           $hirdata,$hirdb,$delkod,$deldata,$sitepage,
           $s_program,$file_mail,$file_reg,$k_mail,
           $dir_data,$dir_site,$default_site;

    $filename2="$dir_site/$default_site/$file_reg";
    site_file_in($filename2,$regdata,$regdb);
    $ukod=sys_env_find($usercode);
    $filename="$dir_site/$default_site/$file_mail";
    if ($ukod<>""){
      $db=0;
      $tomb[0]="";
      $tomb[7]="";
      while (($db<$regdb)and($ukod<>$tomb[0])){
        $tomb=explode($separator,$regdata[$db]);
        $db+=1;
      }
      if ($ukod==$tomb[0]){
        site_file_in_lock($filename,$hirdata,$hirdb);
        $x=0;
        while (($x<$hirdb)and($hirdata[$x]<>$tomb[7])){
	  $x+=1;
	}
	if ($x==$hirdb){
	  $hirdata[$hirdb]=$tomb[7];
          $s=sys_env_find("$usercode");
          sys_env_new($deldata,$s);
          sys_env_new($sitepage,$k_mail);
          $e=sys_env_pack();
	  $ki=sys_line_local("A regisztr�ci� a h�rlev�lre megt�rt�nt");
	  echo("<br /><br />$ki.<br /><br />");
          $ki=sys_line_local("H�rlev�l lemomd�s�hoz kattintson");
          echo("<br />$ki <a class='href' href='./$s_program?$e'>");
          $ki=sys_line_local("ide");
          echo(" $ki.</a><br />");
          echo("<br /><br />");
	}else{
	  if ($delkod<>""){
	    $hirdata[$x]="";
	    $ki=sys_line_local("A h�rlev�l lemond�sa megt�rt�nt.");
	    echo("<br /><br />$ki<br />");
            echo("<br /><br />");
	  }else{
            $s=sys_env_find("$usercode");
            sys_env_new($deldata,$s);
            sys_env_new($sitepage,$k_mail);
            $e=sys_env_pack();
  	    $ki=sys_line_local("M�r l�tezik regisztr�ci� a h�rlev�lre");
	    echo("<br /><br />$ki.<br /><br />");
            $ki=sys_line_local("H�rlev�l lemomd�s�hoz kattintson");
            echo("<br />$ki");
            $ki=sys_line_local("ide");
            echo("<a class='href' href='./$s_program?$e'> $ki</a>.<br />");
            echo("<br /><br />");
	  }
	}
        site_file_out_lock($filename,$hirdata,$hirdb);
      }
    }
  sys_env_del($deldata);
  sys_env_del($sitepage);
  }

// lapozas

function site_pageing($alldb,$pagedb,$page,$param){
  global $printed,$editor,$plugin_start,$s_program,
         $page_num_out,$validpage,$validaktpage,
         $validpagedb;

  //echo("page");
  if ((!$printed)and(!$editor)){
    if ($alldb>0){
      //echo("<hr width='85%' />");
      //echo("<label class=label_p2>");
      if ($param==""){
        $param=$validpage;
      }
      if ($page==""){
        $page=$validaktpage;
      }
      if ($pagedb==""){
        $pagedb=$validpagedb;
      }
      $maxlap=round($alldb/$pagedb+0.4);
      //echo("$alldb-$pagedb");
      if ($maxlap<1){
        $maxlap=1;
      }
      if ($maxlap>1){
        $ki=sys_line_local("Lap");
        //echo("$ki: $page/$maxlap.</label>");
        echo("<div class='label_p1'>");
        if ($maxlap<$page_num_out){
          $tol=0;
          $ig=$page_num_out+5;
        }else{
          if ($page>$maxlap-2){
            $tol=$maxlap-$page_num_out+1;
            $ig=$maxlap;
          }else{
            if ($page<$page_num_out){
              $tol=0;
              $ig=$page_num_out;
            }else{
              $tol=round($page-($page_num_out/2));
              $ig=round($page+($page_num_out/2)-0.6);
            }
          }
        }
        $kis="";
        if (($maxlap>$page_num_out)and($tol>1)){
          $ki=sys_line_local("Els�");
          if ($plugin_start){
            sys_env_plugin_new($param,$page-1);
            $e=sys_env_plugin_pack();
          }else{
            sys_env_new($param,1);
            $e=sys_env_pack();
          }
          $kis=$kis."<label class='label_page1'><a class='href' href='$s_program?$e'>$ki</a></label> ";
        }
        if ($page>1){
          $ki=sys_line_local("El�z�");
          if ($plugin_start){
            sys_env_plugin_new($param,$page-1);
            $e=sys_env_plugin_pack();
          }else{
            sys_env_new($param,$page-1);
            $e=sys_env_pack();
          }
          $kis=$kis."<label class='label_page1'><a class='href' href='$s_program?$e'>$ki</a></label> ";
        }
        $x=0;
        $y=1;
        while ($x<$alldb){
          if (($y>=$tol)and($y<=$ig)){
            if ($plugin_start){
              sys_env_plugin_new($param,$y);
              $e=sys_env_plugin_pack();
            }else{
              sys_env_new($param,$y);
              $e=sys_env_pack();
            }
            if ($y<>$page){
              $kis=$kis."<label class='label_page1'><a class='href' href='$s_program?$e'>$y</a></label> ";
            }else{
              $kis=$kis."<label class='label_page2'>$y</label> ";
            }
          }
          $x+=$pagedb;
          $y+=1;
        }
        if ($page<$y-1){
          $ki=sys_line_local("K�vetkez�");
          if ($plugin_start){
            sys_env_plugin_new($param,$page+1);
            $e=sys_env_plugin_pack();
          }else{
            sys_env_new($param,$page+1);
            $e=sys_env_pack();
          }
          $kis=$kis."<label class='label_page1'><a class='href' href='$s_program?$e'>$ki</a></label> ";
        }
        if (($maxlap>$page_num_out)and($ig<$maxlap)){
          $ki=sys_line_local("Utols�");
          if ($plugin_start){
            sys_env_plugin_new($param,$page-1);
            $e=sys_env_plugin_pack();
          }else{
            sys_env_new($param,$maxlap);
            $e=sys_env_pack();
          }
          $kis=$kis."<label class='label_page1'><a class='href' href='$s_program?$e'>$ki</a></label>";
        }
        echo("$kis");
        echo("<br /></div>");
      }
    }else{
        //$ki=sys_line_local("Lap");
        //echo("$ki: $page/$maxlap.</label>");
        //echo("<label class=label_p1>");
    }
  }
}


  // search

  function site_search(){
    global $dir_site,$default_site,$dir_data,$max_search,
           $s_program,$sitepos,$search_dir_name,$search_dir,
	   $dir_data,$dir_img,$dir_files,$sitepage,$k_bigpic,
	   $dir_site,$default_site,$l_open,$s_sys;

    $ok=sys_data_post($db,$tk,$te);
    if ($ok){
      site_find_local_h($te[0],$te[1]);
    }else{
      site_find_local_h("","");
    }
    if ($ok){
      if (true){
        $l=sys_env_find($sitepos);
        $ki=sys_line_local("Keresett kifejez�s");
        echo("<br /><b>$ki: $te[0]</b><br />");
        $ki=sys_line_local("Tal�latok");
	$cc=count($search_dir_name);
	$ccc=0;
	while (($ccc<$cc)and($te[1]<>$search_dir_name[$ccc])){
	  $ccc+=1;
	}
	$inview=true;
	if ($ccc<$cc){
          $dir="$dir_site/$default_site/$search_dir[$ccc]";
	  if ($search_dir[$ccc]<>$dir_data){
	    $inview=false;
	  }else{
	    $inview=true;
	  }
	}else{
          $dir="$dir_site/$default_site/$dir_data";
	  $inview=true;
	}
        sys_dir_list($dir,$dl);
	$tkif=strtolower($te[0]);
        $x=0;
        $y=count($dl);
	$kisor=0;
        while ($x<$y){
          if (!is_dir("$$dir/$dl[$x]")){
	    $u=0;
	    $h=strlen($dl[$x])-strlen($tkif)+1;
	    $p=sys_unstandard_name($dl[$x]);
	    $p2=strtolower($p);
	    while (($u<$h)and
	          (substr($p2,$u,strlen($tkif))<>$tkif)){
	      $u+=1;
	    }
	    if ($u<$h){
	      if ($kisor==0){
                echo("<b>$ki:</b><br />");
	      }
	      if ($search_dir[$ccc]==$dir_data){
	        $kisor+=1;
	        sys_env_new($sitepos,$dl[$x]);
	        $e=sys_env_pack();
	        echo("<br /><b>$kisor. <a class='href' href='./$s_program?$e'>$p</a></b><br />");
	      }else{
	        if ($search_dir[$ccc]==$dir_img){
	          $kisor+=1;
	          sys_env_new($sitepos,"$dir/$dl[$x]");
		  sys_env_new($sitepage,$k_bigpic);
	          $e=sys_env_pack();
	          echo("<br /><b>$kisor. <a class='href' href='./$s_program?$e'>$p</a></b><br />");
	        }else{
	          if ($search_dir[$ccc]==$dir_files){
	          $kisor+=1;
	            echo("<br /><b>$kisor. <a class='href' href='$dir/$dl[$x]'>$p</a></b><br />");
	          }else{
	            //echo("<br /><b>$kisor. - plug-in</b><br />");
	          }
	        }
	      }
	    }else{
	      if ($inview){
	        $ft=array();
	        sys_file_in("$dir/$dl[$x]",$ft);
	        $z=0;
	        $c=count($ft);
	        while (($z<$c)and
	              ($kisor<=$max_search)){
		  $ll=$l_open.$s_sys;
		  $lh=strlen($ll);
		  if (substr($ft[$z],0,$lh)<>$ll){
	            $u=0;
	            $h=strlen($ft[$z])-strlen($tkif);
		    $fkif=strtolower($ft[$z]);
	            while (($u<$h)and
	                  (substr($fkif,$u,strlen($tkif))<>$tkif)){
	              $u+=1;
	            }
	            if ($u<$h){
	              $kisor+=1;
	              if ($kisor==1){
                        echo("<b>$ki:</b><br />");
	              }
		      $p=sys_unstandard_name($dl[$x]);
		      sys_env_new($sitepos,$dl[$x]);
		      $e=sys_env_pack();
		      echo("<br /><b>$kisor. <a class='href' href='./$s_program?$e'>$p</a></b><br /><ul class='ul_menu'>");
		      if ($z<1){
		        $q=0;
		      }else{
		        $q=$z-1;
		      }
		      $p=strip_tags($ft[$q]);
		      if ($p<>""){
		        echo("<li class='li_me2'>$p</li>");
		      }
		      $q+=1;
		      $p=strip_tags($ft[$q]);
		      if ($p<>""){
		        echo("<li class='li_me2'>$p</li>");
		      }
		      $q+=1;
		      $p=strip_tags($ft[$q]);
		      if ($p<>""){
		        echo("<li class='li_me2'>$p</li>");
		      }
		      $z=$c;
		      echo("</ul>");
	            }
		  }
	          $z+=1;
	        }
	      }
	    }
          }
          $x+=1;
        }
	if ($kisor==0){
          $ki=sys_line_local("Nincs tal�lat");
          echo("<br /><b>$ki.</b><br /><br />");
	}else{
          $ki=sys_line_local("Tal�latok sz�ma");
          echo("<br /><br /><b>$ki: $kisor.</b><br />");
	  if ($kisor>$max_search){
            $ki=sys_line_local("Tov�bbi tal�latok lehets�gesek");
            echo("$ki...</b>");
	  }
	  echo("<br />");
	}
	sys_env_new($sitepos,$l);
      }else{
      }
    }else{
      $ki=sys_line_local("Adja meg a keres�si felt�telt");
      echo("<br />$ki.<br /><br />");
    }
  }

?>
