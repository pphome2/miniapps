<?php

  // w_robot --- PHP portalrobot
  // (verzioadatok a konfiguracios fajlban)
  //
  // fejleszto: Zebulon.hu Team


  // system files in


  $system_config_file="w_config.php";

  error_reporting(E_ALL);
  if (function_exists("date_default_timezone_set")){
    date_default_timezone_set("CET");
  }

  $system_ready=true;
  $system_ready_f2=false;

  if (file_exists("./$system_config_file")){
    include("./$system_config_file");
    $dir_include="../$dir_include";
    $dir_conf="../$dir_conf";
  }else{
    $system_ready=false;
  }

  if (($system_ready)and(file_exists("$dir_conf/$file_sysvar"))){
    include("$dir_conf/$file_sysvar");
  }else{
    $system_ready=false;
  }

  if ($system_ready){
    $i=0;
    $y=count($file_lib);
    while ($i<$y){
      if (file_exists("$dir_include/$file_lib[$i]")){
        include("$dir_include/$file_lib[$i]");
      }else{
        $system_ready=false;
      }
      $i+=1;
    }
  }

  // prepare system

  if ($system_ready){
    if (isset($_SERVER['HTTPS'])){
      $s_full_program="https://";
    }else{
      $s_full_program="http://";
    }
    $s_full_program=$s_full_program.$_SERVER['SERVER_NAME'].$_SERVER['PHP_SELF'];
    $s_program=basename($s_full_program);
    $s_full_path=substr($s_full_program,0,strlen($s_full_program)-strlen($s_program)-strlen($dir_bin)-1);
    set_error_handler("sys_error");
    $system_ready_f2=false;
    sys_env_in();
    $akt_site=sys_env_find($sitename);
    if ($akt_site!==""){
      $default_site=$akt_site;
    }else{
      sys_env_new($sitename,$default_site);
    }
    $dir_site="../$dir_site";
    $dir_system="../$dir_system";
    $dir_templates="../$dir_templates";
    $dir_plugins="../$dir_plugins";
    if (file_exists("$dir_site/$default_site/$file_user_config")){
      include("$dir_site/$default_site/$file_user_config");
      if (file_exists("$dir_plugins/$file_plugins")){
        include("$dir_plugins/$file_plugins");
      }
      $error_log_file="$dir_site/$default_site/$dir_ldata/$error_log_file";
      $lang_system=sys_env_find($language);
      if ($lang_system==""){
        $lang_system=$lang_label[0];
      }
      $st=sys_env_find($sitepos);
      if (($st=="")and($first_page_template<>"")){
        $default_template=$first_page_template;
      }
      $template_path="$dir_templates/$default_template";
      if (file_exists("$template_path/$file_template_main")){
        include("$template_path/$file_template_main");
        $system_ready_f2=true;
      }
    }
  }else{
    system_error();
  }

  // start

  if ($system_ready_f2){
    fmain();
  }else{
    if ($system_ready){
      site_error();
    }else{
      system_error();
    }
  }

  // files error

  function system_error(){
    echo("<html><title>Rendszerhiba</title><body>");
    echo("</body></html>");
  }

  // foprogram - vezerles

  function fmain(){
    global $sitepage,$usercode,$k_message,$k_enter,$k_regist,
           $k_edit,$k_privat,$k_mail,$k_print,$k_history,$k_dir,
           $k_bigpic,$k_files,$k_admin_1,$k_admin_2,$k_admin_3,
           $k_admin_4,$k_admin_5,$k_admin_6,$k_search,
           $sitepos,$printed,$xmltype,$no_out_html;

    sys_site_open();
    plugins_init();
    site_open();
    if (!$no_out_html){
      $menu=sys_env_find($sitepage);
      sys_env_del($sitepage);

      switch ($menu){
        case $k_message:
          site_page_open();
          design();
          site_message_wall_menu();
          design_end();
          site_page_close();
          break;
        case $k_enter:
          sys_env_del($usercode);
          if (site_enter_in()==""){
            site_page_open();
            design();
            site_page_out();
            design_end();
            site_page_close();
          }else{
            $printed=true;
            site_refresh();
          }
          break;
        case $k_regist:
          site_page_open();
          design();
          site_new_reg();
          design_end();
          site_page_close();
          break;
        case $k_edit:
          site_page_open();
          design();
          site_edit();
          design_end();
          site_page_close();
          break;
        case $k_admin_1:
        case $k_admin_2:
        case $k_admin_3:
        case $k_admin_4:
        case $k_admin_5:
        case $k_admin_6:
          site_page_open();
          design();
          site_admin($menu);
          design_end();
          site_page_close();
          break;
        case $k_privat:
          site_page_open();
          design();
          site_privat();
          design_end();
          site_page_close();
          break;
        case $k_mail;
          site_page_open();
          design();
          site_mail();
          design_end();
          site_page_close();
          break;
        case $k_history:
          site_page_open();
          design();
          site_history();
          design_end();
          site_page_close();
          break;
        case $k_print:
          site_page_open_print();
          site_page_out();
          site_page_close();
          break;
        case $k_dir:
          site_page_open();
          design();
          site_directory();
          design_end();
          site_page_close();
          break;
        case $k_files:
          site_page_open();
          design();
          site_files();
          design_end();
          site_page_close();
          break;
        case $k_bigpic:
          site_page_open();
          design();
          site_bigpic();
          design_end();
          site_page_close();
          break;
        case $k_search:
          site_page_open();
          design();
          site_search();
          design_end();
          site_page_close();
          break;
        default:
          site_page_open();
          design();
          site_page_out();
          design_end();
          site_page_close();
          break;
      }

    }else{
      site_page_out();
    }

    plugins_end();
    site_end();
    sys_site_end();
  }

?>
