<?php

  // w_robot --- PHP portalrobot
  // (verzioadatok a konfiguracios fajlban)
  //
  // fejleszto: Zebulon.hu Team




function site_error(){
  global $site_error_1,$site_error_2;

  site_page_open();
  echo("<br /><br /><b>$site_error_1");
  echo("</b><br /><br />$site_error_2<br /><br />");
  site_page_close();
}


function site_admin_menu(){
  global $sitepage,$user_admin,$usercode,
         $s_program,$sitepos,$dir_data,
         $k_admin_1,$k_admin_2,$k_admin_3,
         $k_admin_4,$k_admin_5,$k_admin_6,
         $dir_site,$default_site,$file_mail,
	 $admin_menu_plus,
	 $enable_new_reg,$k_regist;

  $m=sys_env_find($sitepage);
  $p=sys_env_find($sitepos);
  if ($user_admin){
    sys_env_new($sitepage,$k_regist);
    $e=sys_env_pack();
    $k=sys_line_local("�j felhaszn�l�");
    echo("<a class='href' href='./$s_program?$e'>$k</a><br />");
    sys_env_new($sitepage,$k_admin_1);
    $e=sys_env_pack();
    $k=sys_line_local("Felhaszn�l�k");
    echo("<a class='href' href='./$s_program?$e'>$k</a><br />");
    sys_env_new($sitepage,$k_admin_2);
    $e=sys_env_pack();
    $k=sys_line_local("Adatt�r");
    echo("<a class='href' href='./$s_program?$e'>$k</a><br />");
    sys_env_new($sitepage,$k_admin_3);
    $e=sys_env_pack();
    $k=sys_line_local("K�pt�r");
    echo("<a class='href' href='./$s_program?$e'>$k</a><br />");
    sys_env_new($sitepage,$k_admin_4);
    $e=sys_env_pack();
    $k=sys_line_local("K�nyvt�r");
    echo("<a class='href' href='./$s_program?$e'>$k</a><br />");
    sys_env_new($sitepage,$k_admin_5);
    $e=sys_env_pack();
    $k=sys_line_local("H�rlevelet k�r�k");
    echo("<a class='href' href='./$s_program?$e'>$k</a><br />");
    sys_env_new($sitepage,$k_admin_6);
    $e=sys_env_pack();
    $k=sys_line_local("Be�ll�t�sok");
    echo("<a class='href' href='./$s_program?$e'>$k</a><br />");
    //echo("<br />");
    $x=0;
    $y=count($admin_menu_plus);
    if ($y>0){
      echo("<br />");
      sys_env_del($sitepage);
      while ($x<$y){
        $k=sys_standard_name($admin_menu_plus[$x]);
        sys_env_new($sitepos,$k);
        $e=sys_env_pack();
        echo("<a class='href' href='./$s_program?$e'>$admin_menu_plus[$x]</a><br />");
        $x+=1;
      }
    }
  }else{
    //$ki=sys_line_local("Nincs adminisztr�tori jogosults�ga");
    //echo("$ki.");
  }
  sys_env_new($sitepage,$m);
  sys_env_new($sitepos,$p);
}



function site_global_admin($admin_pont){
  global $deldata,$regdata,$regdb,$k_admin,$sitepage,
         $s_program,$sitepos,$dir_img,$dir_files,
         $dir_site,$default_site,$dir_data,$file_mail,
         $k_admin_1,$k_admin_2,$k_admin_3,$k_admin_4,
         $k_admin_5,$k_admin_6,$dirdata,$file_user_config,
         $specchar2,$site_data_css_container;

  switch ($admin_pont){
    case $k_admin_1:
      sys_env_new($sitepage,$k_admin_1);
      $ki=sys_line_local("Adminisztr�ci�");
      echo("<label class='label_p'><b>$ki</b></label>");
      echo("<br />");
      $ki=sys_line_local("Felhaszn�l�k");
      echo("<label class='label_p'><b>$ki</b></label>");
      echo("<br />");
      echo("<center><div class='page_table'>");
      $ki=sys_line_local("Feladat");
      echo("<label class='label_a1'><b>$ki</b></label>");
      $ki=sys_line_local("N�v");
      echo("<label class='label_a2'><b>$ki</b></label>");
      $ki=sys_line_local("Teljes n�v");
      echo("<label class='label_a3'><b>$ki, ");
      $ki=sys_line_local("lakc�m, ");
      echo("$ki");
      $ki=sys_line_local("e-mail");
      echo("$ki");
      echo("<br />");
      $ki=sys_line_local("Regisztr�ci�");
      echo("$ki, ");
      $ki=sys_line_local("lej�rat");
      echo("$ki");
      echo("</b></label>");
      $ki=sys_line_local("T�r�l");
      $db=0;
      while ($db<$regdb){
        $tomb=explode("-",$regdata[$db]);
        $db+=1;
        if ($tomb[0]<>""){
          echo("<br /><br />");
          sys_env_new($deldata,$tomb[0]);
          $e=sys_env_pack();
          echo("<label class='label_a1'>");
          echo("<a class='href' href='./$s_program?$e'>$ki</a>");
          echo("</label>");
          echo("<label class='label_a2'>$tomb[3]</label>");
          echo("<label class='label_a3'>");
	  echo("$tomb[5], ");
          echo("$tomb[6], ");
          echo("$tomb[7]");
          echo("<br />");
          $s=$tomb[0];
          $ki2=date("Y.m.d. h:s","$s");
	  echo("$ki2, ");
	  if ($tomb[6]==0){
            $ki2=sys_line_local("nincs lej�rat");
	  }else{
            $ki2=sys_line_local("lej�r");
            $t=$tomb[1]+$tomb[2];
	    $ki2=$ki2.": ".date("Y.m.d. h:s",$t);
	  }
          echo("$ki2");
          echo("</label>");
          echo("<br />");
        }
      }
      $ki=sys_line_local("�sszesen");
      $db-=1;
      echo("<br /><br /><label class='label_p'>$ki: $db.</label>");
      echo("</div></center><br />");
      break;
    case $k_admin_2;
      $ki2=sys_line_local("Adatt�r");
      echo("<label class='label_p'><b>$ki2</b></label>");
      echo("<br />");
      $dirname="$dir_site/$default_site/$dir_data";
      $admin=true;
      $dload=false;
      sys_env_del($deldata);
      sys_env_new($sitepage,$k_admin_2);
      site_directory_list($dirname,$admin,$dload);
      break;
    case $k_admin_3:
      $ki2=sys_line_local("K�pt�r");
      echo("<label class='label_p'><b>$ki2</b></label>");
      echo("<br />");
      $dirname="$dir_site/$default_site/$dir_img";
      $admin=true;
      $dload=false;
      sys_env_del($deldata);
      sys_env_new($sitepage,$k_admin_3);
      $e=sys_env_pack();
      site_directory_list($dirname,$admin,$dload);
      if ($site_data_css_container!=""){
        echo("</div><div class='$site_data_css_container'>");
      }
      $ki2=sys_line_local("K�p felt�lt�se k�pt�rba");
      echo("<br /><br /><label class='label_p'><b>$ki2</b></label>");
      echo("<br /><br />");
      echo("<center>");
      echo("<form method='post' enctype='multipart/form-data' action='./$s_program?$e'>");
      $ki=sys_line_local("K�pf�jl");
      echo("<label class='label_r1'>$ki: </label>");
      echo("<input class='input_r1' type='file' id='userfile' name='userfile' size='120' maxlength='100' /><br />");
      $ki=sys_line_local("Mehet");
      echo("<button class='button_1' type='submit' id='b01' name='b01' value='$ki'>$ki</button>");
      echo("</form>");
      echo("</center><br />");
      break;
    case $k_admin_4:
      $ki2=sys_line_local("K�nyvt�r");
      echo("<label class='label_p'><b>$ki2</b></label>");
      echo("<br />");
      $dirname=$dirdata;
      if ($dirname==""){
        $dirname="$dir_site/$default_site/$dir_files";
      }
      sys_env_del($deldata);
      sys_env_new($sitepage,$k_admin_4);
      $admin=true;
      $dload=true;
      site_directory_list($dirname,$admin,$dload);
      $e=sys_env_pack();
      if ($site_data_css_container!=""){
        echo("</div><div class='$site_data_css_container'>");
      }
      $ki2=sys_line_local("F�jl felt�lt�se k�nyvt�rba");
      echo("<br /><br /><b>$ki2:</b><br /><br />");
      echo("<center>");
      echo("<form method='post' enctype='multipart/form-data' action='./$s_program?$e'>");
      $ki=sys_line_local("F�jl");
      echo("<label class='label_r1'>$ki: </label>");
      echo("<input class='input_r1' type='file' id='userfile' name='userfile' size='120' maxlength='100' /><br /><br />");
      $ki=sys_line_local("�j k�nyvt�r");
      echo("<label class='label_r1'>$ki: </label>");
      echo("<input class='input_r1' type='text' id='userdir' name='userdir' size='120' maxlength='100' /><br /><br />");
      echo("<input type='hidden' id='aktdir' size='120' maxlength='100' value='$dirname' />");
      $ki=sys_line_local("Mehet");
      echo("<button class='button_1' type='submit' id='b02' name='b02' value='$ki'>$ki</button>");
      echo("</form>");
      echo("</center><br />");
      break;
    case $k_admin_5:
      $ki2=sys_line_local("H�rlevelet k�r�k");
      echo("<label class='label_p'><b>$ki2</b></label>");
      echo("<br />");
      $mailfile="$dir_site/$default_site/$file_mail";
      site_file_in($mailfile,$sdata,$sline);
      $x=0;
      while ($x<$sline){
        echo("$sdata[$x]");
        $x+=1;
      }
      break;
    case $k_admin_6:
      $ki2=sys_line_local("Be�ll�t�sok");
      echo("<label class='label_p'><b>$ki2</b></label><br />");
      $ki2=sys_line_local("A m�dos�t�s a rendszer �szzeoml�s�t is okozhatja");
      echo("<label class='label_p'><b>$ki2.</b></label>");
      sys_env_new($sitepage,$k_admin_6);
      $e=sys_env_pack();
      echo("<br />");
      $conffile="$dir_site/$default_site/$file_user_config";
      site_file_in($conffile,$sdata,$sline);
      echo("<center>");
      echo("<form method='post' action='./$s_program?$e'>");
      echo("<textarea class='textarea_e1' id='tartalom' name='tartalom' cols='70' rows='25'>");
      $x=0;
      while ($x<$sline){
        echo($sdata[$x]);
        if ($x<$sline-1){
          echo($specchar2);
        }
        $x+=1;
      }
      echo("</textarea><br /><br />");
      $ki=sys_line_local("Mehet");
      echo("<button class='button_1' type='submit' id='b03' name='b03' value='$ki'>$ki</button>");
      echo("</form>");
      echo("</center>");
      break;
  }
  sys_env_del($sitepage);
}


function site_directory(){
  global $sitepage,$k_dir;

  $ki=sys_line_local("Az adatt�r tartalma");
  echo("<label class='label_p'><b>$ki</b></label>");
  echo("<br />");
  $admin=false;
  $dload=false;
  $dir="";
  sys_env_new($sitepage,$k_dir);
  site_directory_list($dir,$admin,$dload);
  sys_env_del($sitepage);
}



function site_files(){
  global $dir_files,$default_site,$dir_site,$dirdata,
         $sitepage,$k_files;

  $ki=sys_line_local("A k�nyvt�r tartalma");
  echo("<label class='label_p'><b>$ki</b></label>");
  echo("<br />");
  $admin=false;
  $dload=true;
  if ($dirdata<>""){
    $dir=$dirdata;
  }else{
    $dir="$dir_site/$default_site/$dir_files";
  }
  sys_env_new($sitepage,$k_files);
  site_directory_list($dir,$admin,$dload);
  sys_env_del($sitepage);
}



function site_find_local(){
  global $k_search,$sitepage,$s_program;

  $sp=sys_env_find($sitepage);
  sys_env_new($sitepage,$k_search);
  $e=sys_env_pack();
  sys_env_new($sitepage,$sp);
  echo("<form method='post' action='./$s_program?$e'>");
  echo("<input class='input_k1' type='text' id='qc' name='qc' size='20' maxlength='255' /><br />");
  $ki=sys_line_local("Mehet");
  echo("<button class='button_1' type='submit' id='b0' name='b0' value='$ki'>$ki</button>");
  echo("</form>");
}


function site_find_local_h($s,$v){
  global $k_search,$sitepage,$s_program,
         $search_dir_name,$search_dir;

  $sp=sys_env_find($sitepage);
  sys_env_new($sitepage,$k_search);
  $e=sys_env_pack();
  sys_env_new($sitepage,$sp);
  $ki=sys_line_local("Keres�s");
  echo("<br /><center><form method='post' action='./$s_program?$e'>");
  echo("<label class='label_f1'>$ki:</label>");
  echo("<input class='input_f1' type='text' id='q' name='q' size='30' maxlength='255' value='$s' />");
  echo("<label class='label_f1'> ");
  echo("<select id='s1' name='s1' class='select_d1'>");
  $y=0;
  $x=count($search_dir);
  while ($y<$x){
    if ($search_dir_name[$y]==$v){
      echo("<option selected='selected'>$search_dir_name[$y]</option>");
    }else{
      echo("<option>$search_dir_name[$y]</option>");
    }
    $y+=1;
  }
  echo("</select></label>");
  $ki=sys_line_local("Mehet");
  echo("<button class='button_1' type='submit' id='b1' name='b1' value='$ki'>$ki</button>");
  echo("</form><br /><hr width='60%' /></center>");
}


function site_find_local_g(){
  global $site_title,$s_domain,$s_c_code;

  $e=sys_env_pack();
  echo("<form method='get' action='http://www.google.com/search'>");
  echo("<input type='hidden' id='ie' name='ie' value='iso-8859-2' />");
  echo("<input type='hidden' id='oe' name='oe' value='iso-8859-2' />");
  echo("<input type='hidden' id='hl' name='hl' value='hu' />");
  echo("<input class='input_k1' type='text' id='qx' name='qx' size='20' maxlength='255' />");
  echo("<input class='input_k1' type='hidden' id='sitesearch' name='sitesearch' value='$s_domain/$site_title' />");
  echo("<input type='hidden' id='domains' name='domains' value='$s_domain' /><br />");
  $ki=sys_line_local("Mehet");
  echo("<button class='button_1' type='submit' id='b2' name='b2' value='$ki'>$ki</button>");
  echo("</form>");
}



function site_find_local_g2(){
  global $site_title,$s_domain,$s_c_code;

  $e=sys_env_pack();
  echo("<form method='get' action='http://www.google.com/search'>");
  echo("<input class='input_k1' type='hidden' id='ie' name='ie' value='iso-8859-2' />");
  echo("<input class='input_k1' type='hidden' id='oe' name='oe' value='iso-8859-2' />");
  echo("<input class='input_k1' type='hidden' id='hl' name='hl' value='hu' />");
  echo("<input class='input_k1' type='text' id='qv' name='qv' size='20' maxlength='255' />");
  echo("<select class='select_k1' id='sitesearch' name='sitesearch'>");
  $ki=sys_line_local("Ezeken a lapokon");
  echo("<option value='$s_domain'>$ki</option>");
  $ki=sys_line_local("Magyar oldalakon");
  echo("<option value='$s_c_code'>$ki</option>");
  $ki=sys_line_local("Weben");
  echo("<option value=''>$ki</option>");
  echo("</select><br />");
  echo("<input type='hidden' id='domains' name='domains' value='$s_domain' />");
  $ki=sys_line_local("Mehet");
  echo("<button class='button_1' type='submit' id='b3' name='b3' value='$ki'>$ki</button>");
  echo("</form>");
}



function site_history(){
  global $hist_db;

  $ki=sys_line_local("A lap t�rt�nete");
  echo("<label class='label_p'><b>$ki</b></label>");
  echo("<br />");
  $n=site_page_name();
  $ki=sys_line_local("az utols� $hist_db m�dos�t�s adatai");
  echo("<b>($n: $ki.)</b><br /><br />");
  site_history_line();
}



function site_enter(){
  global $sitepage,$k_regist,$k_enter,$s_program,
         $enable_new_reg;

  sys_env_new($sitepage,$k_enter);
  $e=sys_env_pack();
  echo("<center>");
  echo("<form method='post' action='./$s_program?$e'>");
  $i=sys_line_local("Felhaszn�l�i n�v �s jelsz�");
  echo("$i:<br />");
  echo("<input class='input_b1' type='text' id='b1' name='b1' size='20' /><br />");
  echo("<input class='input_b1' type='password' id='b2' name='b2' size='20' /><br />");
  $ki=sys_line_local("Mehet");
  echo("<button class='button_1' type='submit' id='b4' name='b4' value='$ki'>$ki</button>");
  echo("</form>");
  if ($enable_new_reg){
    sys_env_new($sitepage,$k_regist);
    $e=sys_env_pack();
    $i=sys_line_local("�j felhaszn�l� l�trehoz�sa");
    echo("<a class='href' href='./$s_program?$e'>$i</a>");
    //echo("<br />");
  }
  echo("</center>");
  sys_env_del($sitepage);
}



function site_mail_reg(){
  global $deldata,$usercode,$s_program,
         $sitepage,$k_mail;

  $s=sys_env_find("$usercode");
  sys_env_new($deldata,$s);
  sys_env_new($sitepage,$k_mail);
  $e=sys_env_pack();
  echo("<br /><br />");
  $ki=sys_line_local("Regisztr�ci� a h�rlev�lre megt�rt�nt");
  echo("<label class='label_p'><b>$ki</b></label>");
  echo("<br />");
  echo("<br />$ki.<br />");
  echo("<br /><br />");
  $ki=sys_line_local("H�rlev�l lemomd�s�hoz kattintson");
  $ki2=sys_line_local("ide");
  echo("<label class='label_p'>$ki");
  echo("$ki <a class='href' href='./$s_program?$e'>");
  echo("$ki2.</label>");
  echo("<br />");
  sys_env_del($deldata);
  sys_env_del($sitepage);
}



function site_mess_new($mcim,$jel,$sysmess){
  global $sitepage,$newdata,$s_program,$pont,
         $comment_rate,$k_message;

  sys_env_new($newdata,$newdata);
  if ($sysmess){
    sys_env_new($sitepage,$k_message);
  }
  $e=sys_env_pack();
  if ($mcim==""){
    $ki=sys_line_local("�j �zenet");
  }else{
    $ki=$mcim;
  }
  echo("<label class='label_p'><b>$ki</b></label>");
  echo("<br />");
  echo("<br /><br />");
  echo("<center>");
  echo("<form method='post' action='./$s_program?$e'>");
  echo("<textarea class='textarea_m1' id='x1' name='x1' cols='50' rows='10'></textarea><br /><br />");
  if (($jel<>"")and($comment_rate)){
    $ki=sys_line_local("�rt�kel�s");
    echo("$ki: ");
    $ki=sys_line_local("pont");
    $x=0;
    while ($x<=$pont){
      if ($x==3){
        echo("<input type='radio' id='radio$x' name='radio$x' value='$x' checked='checked' />$x $ki ");
      }else{
        echo("<input type='radio' id='radio$x' name='radio$x' value='$x' />$x $ki ");
      }
      $x+=1;
    }
  }
  $ki=sys_line_local("Mehet");
  echo("<button class='button_1' type='submit' id='b5' name='b5' value='$ki'>$ki</button>");
  echo("</form>");
  echo("<br />");
  echo("</center>");
  sys_env_del($newdata);
  if ($sysmess){
    sys_env_del($sitepage);
  }
}


function site_page_close(){
  global $s_dev_program,$s_dev_version,
         $s_dev_copyright,$s_dev_team,
	 $s_dev_mail,$s_dev_web,$printed;

  if ($printed){
    echo("<br /><br />");
  }
  echo("<center>");
  echo("-[ $s_dev_copyright <a class='href' href='http://$s_dev_web'>$s_dev_team</a>
       - $s_dev_program $s_dev_version ]-<br />");
  echo("</center>");
}


function site_page_edit(){
  global $newdata,$newmenu,$sitedata,$siteline,$deldata,
         $k_edit,$sitepage,$default_site,$dir_img,$dir_site,
         $s_program,$s_link,$s_img,$s_sys,$s_pos,$s_posp,
         $s_cent,$s_ecent,$s_nline,$s_line,
         $s_h,$s_eh,$s_bold,$s_ebold,$s_ita,$s_eita,
         $s_und,$s_eund,$s_par,$s_epar,$s_plugin,
         $plugin_start,$s_menu,$s_submenu,$s_nocomment,
         $s_col,$s_ecol1,$s_ecol,$s_table,$s_etable,
         $s_row,$s_erow,$s_data,$s_edata,$s_language,
         $s_comment,$s_commentrate,$s_mail,
         $site_data_css_container;

  sys_env_new($newdata,$newdata);
  sys_env_new($sitepage,$k_edit);
  $e=sys_env_pack();
  echo("<br /><br />");
  echo("</div><div class='$site_data_css_container'>");
  $n=site_page_name();
  $ki=sys_line_local("Szerkeszt�s");
  echo("<b>$ki ($n):</b><br /><br />");
  echo("<center>");
  echo("<form method='post' action='./$s_program?$e'>");
  echo("<textarea class='textarea_e1' id='tartalom' name='tartalom' cols='70' rows='25'>");
  site_page_out_2();
  echo("</textarea>");
  echo("<br /><br />");
  $ki=sys_line_local("Mehet");
  echo("<button class='button_1' type='submit' id='b6' name='b6' value='$ki'>$ki</button>");
  echo("</form>");
  echo("</center>");
  if ($site_data_css_container!=""){
    echo("</div><div class='$site_data_css_container'>");
  }
  echo("<div class='help_h0'>");
  echo("<center>");
  echo("<br />");
  $ki=sys_line_local("Haszn�lhat� elemek");
  $ki2=sys_line_local("Feladat");
  echo("<label class='label_h1'><b><i>$ki</i></b></label>");
  echo("<label class='label_h2'><b><i>$ki2</i></b></label>");
  //echo("<br /><br />");
  $ki=sys_line_local("lap neve");
  $ki2=sys_line_local("saj�t lapra link");
  echo("<label class='label_h1'><b>[$ki]</b></label>");
  echo("<label class='label_h2'>$ki2</label>");
  //echo("<br /><br />");
  $ki=sys_line_local("link m�s oldalra");
  $ki2=sys_line_local("lapn�v");
  echo("<label class='label_h1'><b>[$s_link www.xyz.hu $ki2]</b></label>");
  echo("<label class='label_h2'>$ki</label>");
  //echo("<br /><br />");
  $ki=sys_line_local("elektronikus lev�l k�ld�se");
  $ki2=sys_line_local("lev�lc�m");
  echo("<label class='label_h1'><b>[$s_mail $ki2]</b></label>");
  echo("<label class='label_h2'>$ki</label>");
  //echo("<br /><br />");
  $ki=sys_line_local("k�p besz�r�sa alk�nyvt�rb�l");
  $ki2=sys_line_local("k�p_neve nagy_k�p_neve");
  echo("<label class='label_h1'><b>[$s_img $ki2]</b></label>");
  echo("<label class='label_h2'>$ki ($dir_site/$default_site/$dir_img)</label>");
  //echo("<br /><br />");
  $ki=sys_line_local("k�z�pre rendez�s");
  echo("<label class='label_h1'><b>[$s_cent]</b></label>");
  echo("<label class='label_h2'>$ki</label>");
  //echo("<br /><br />");
  $ki=sys_line_local("k�z�pre rendez�s v�ge");
  echo("<label class='label_h1'><b>[$s_ecent]</b></label>");
  echo("<label class='label_h2'>$ki</label>");
  //echo("<br /><br />");
  $ki=sys_line_local("�j sor (kett� eset�n �res sor)");
  echo("<label class='label_h1'><b>[$s_nline]</b></label>");
  echo("<label class='label_h2'>$ki</label>");
  //echo("<br /><br />");
  $ki=sys_line_local("vonal h�z�sa a sz�veg al�");
  echo("<label class='label_h1'><b>[$s_line]</b></label>");
  echo("<label class='label_h2'>$ki</label>");
  //echo("<br /><br />");
  $ki=sys_line_local("c�msor (a sz�m 1-5 lehet)");
  $ki2=sys_line_local("sz�m");
  $ki=sys_line_local("vonal h�z�sa a sz�veg al�");
  echo("<label class='label_h1'><b>[$s_h $ki2]</b></label>");
  echo("<label class='label_h2'>$ki</label>");
  //echo("<br /><br />");
  $ki=sys_line_local("c�msor v�ge");
  echo("<label class='label_h1'><b>[$s_eh]</b></label>");
  echo("<label class='label_h2'>$ki</label>");
  //echo("<br /><br />");
  $ki=sys_line_local("vastag�tott bet�s ki�r�s");
  echo("<label class='label_h1'><b>[$s_bold]</b></label>");
  echo("<label class='label_h2'>$ki</label>");
  //echo("<br /><br />");
  $ki=sys_line_local("vastag�tott bet�s ki�r�s v�ge");
  echo("<label class='label_h1'><b>[$s_ebold]</b></label>");
  echo("<label class='label_h2'>$ki</label>");
  //echo("<br /><br />");
  $ki=sys_line_local("d�lt bet�s ki�r�s");
  echo("<label class='label_h1'><b>[$s_ita]</b></label>");
  echo("<label class='label_h2'>$ki</label>");
  //echo("<br /><br />");
  $ki=sys_line_local("d�lt bet�s ki�r�s v�ge");
  echo("<label class='label_h1'><b>[$s_eita]</b></label>");
  echo("<label class='label_h2'>$ki</label>");
  //echo("<br /><br />");
  $ki=sys_line_local("al�h�zott bet�s ki�r�s");
  echo("<label class='label_h1'><b>[$s_und]</b></label>");
  echo("<label class='label_h2'>$ki</label>");
  //echo("<br /><br />");
  $ki=sys_line_local("al�h�zott bet�s ki�r�s v�ge");
  echo("<label class='label_h1'><b>[$s_eund]</b></label>");
  echo("<label class='label_h2'>$ki</label>");
  //echo("<br /><br />");
  $ki=sys_line_local("bekezd�s kezd�se");
  echo("<label class='label_h1'><b>[$s_par]</b></label>");
  echo("<label class='label_h2'>$ki</label>");
  //echo("<br /><br />");
  $ki=sys_line_local("bekezd�s v�ge");
  echo("<label class='label_h1'><b>[$s_epar]</b></label>");
  echo("<label class='label_h2'>$ki</label>");
  //echo("<br /><br />");
  $ki=sys_line_local("t�bb oszlopos �r�s - sz�m: ennyi oszlop lesz");
  $ki2=sys_line_local("sz�m");
  echo("<label class='label_h1'><b>[$s_ecol $ki2]</b></label>");
  echo("<label class='label_h2'>$ki</label>");
  //echo("<br /><br />");
  $ki=sys_line_local("egy oszlop v�ge");
  echo("<label class='label_h1'><b>[$s_ecol1]</b></label>");
  echo("<label class='label_h2'>$ki</label>");
  //echo("<br /><br />");
  $ki=sys_line_local("t�bb oszlopos �r�s v�ge");
  echo("<label class='label_h1'><b>[$s_ecol]</b></label>");
  echo("<label class='label_h2'>$ki</label>");
  //echo("<br /><br />");
  $ki=sys_line_local("t�bl�zat kezdete");
  echo("<label class='label_h1'><b>[$s_table]</b></label>");
  echo("<label class='label_h2'>$ki</label>");
  //echo("<br /><br />");
  $ki=sys_line_local("t�bl�zat v�ge");
  echo("<label class='label_h1'><b>[$s_etable</b></label>");
  echo("<label class='label_h2'>$ki</label>");
  //echo("<br /><br />");
  $ki=sys_line_local("t�bl�zat sor�nak kezdete");
  echo("<label class='label_h1'><b>[$s_row]</b></label>");
  echo("<label class='label_h2'>$ki</label>");
  //echo("<br /><br />");
  $ki=sys_line_local("t�bl�zat sor�nak v�ge");
  echo("<label class='label_h1'><b>[$s_erow]</b></label>");
  echo("<label class='label_h2'>$ki</label>");
  //echo("<br /><br />");
  $ki=sys_line_local("t�bl�zat sor�ban egy adat kezdete");
  echo("<label class='label_h1'><b>[$s_data]</b></label>");
  echo("<label class='label_h2'>$ki</label>");
  //echo("<br /><br />");
  $ki=sys_line_local("t�bl�zatban sor�ban egy adat v�ge");
  echo("<label class='label_h1'><b>[$s_edata]</b></label>");
  echo("<label class='label_h2'>$ki</label>");
  //echo("<br /><br />");
  $ki=sys_line_local("men�");
  $ki2=sys_line_local("men�pont neve");
  echo("<label class='label_h1'><b>[$s_menu $ki2]</b></label>");
  echo("<label class='label_h2'>$ki</label>");
  //echo("<br /><br />");
  $ki=sys_line_local("almen�");
  $ki2=sys_line_local("almen� neve");
  echo("<label class='label_h1'><b>[$s_submenu $ki2]</b></label>");
  echo("<label class='label_h2'>$ki</label>");
  //echo("<br /><br />");
  $ki=sys_line_local("plugin ind�t�sa");
  $ki2=sys_line_local("plugin-n�v param�terek");
  echo("<label class='label_h1'><b>[$s_plugin $ki2]</b></label>");
  echo("<label class='label_h2'>$ki</label>");
  //echo("<br /><br />");
  $ki=sys_line_local("nyelv v�laszt�s");
  $ki2=sys_line_local("param�ter (pl.: hu)");
  echo("<label class='label_h1'><b>[$s_language $ki2]</b></label>");
  echo("<label class='label_h2'>$ki</label>");
  //echo("<br /><br />");
  $ki=sys_line_local("hozz�sz�l�s a laphoz nem enged�lyezett");
  echo("<label class='label_h1'><b>[$s_nocomment]</b></label>");
  echo("<label class='label_h2'>$ki</label>");
  //echo("<br /><br />");
  $ki=sys_line_local("hozz�sz�l�s enged�lyezett");
  echo("<label class='label_h1'><b>[$s_comment]</b></label>");
  echo("<label class='label_h2'>$ki</label>");
  //echo("<br /><br />");
  $ki=sys_line_local("hozz�sz�l�s a laphoz enged�lyezett, pontoz�ssal");
  echo("<label class='label_h1'><b>[$s_commentrate]</b></label>");
  echo("<label class='label_h2'>$ki</label>");
  $x=0;
  while ($x<40){
    $x+=1;
    echo("<br />");
  }
  echo("</center></div>");
  sys_env_del($deldata);
  sys_env_del($newdata);
}



function site_page_open(){
  echo("<body class='body'>");
}



function site_page_open_print(){
  echo("<body class='printbody'>");
}



function site_refresh(){
  global $site_title,$sitename,$default_site,$s_program,
         $doctype,$xmltype,$htmlpar;

  $e=sys_env_pack();
  echo($xmltype);
  echo($doctype);
  echo("<meta http-equiv='refresh' content='1;URL=$s_program?$e'>");
  echo("<html $htmlpar>");
  echo("<head></head>");
  echo("<body></body>");
  echo("</html>");
}




function site_privat_edit(){
  global $newdata,$regdata,$regdb,$k_privat,$usercode,$s_program,
         $sitepage,$separator;

  sys_env_new($newdata,$newdata);
  sys_env_new($sitepage,$k_privat);
  $e=sys_env_pack();
  $ki=sys_line_local("Felhaszn�l�i adatok");
  echo("<label class='label_p'><b>$ki</b></label>");
  echo("<br /><br />");
  $db=0;
  $kod=sys_env_find($usercode);
  $tomb[0]="";
  $tomb[7]="";
  while (($db<$regdb)and($kod<>$tomb[0])){
    $tomb=explode($separator,$regdata[$db]);
    $db+=1;
  }
  if ($tomb[0]<>""){
    echo("<center>");
    echo("<form method='post' action='./$s_program?$e'>");
    echo("<input class='input_r1' type='hidden' id='m6' value='$tomb[0]' />");
    echo("<input class='input_r1' type='hidden' id='m7' value='$tomb[1]' />");
    echo("<input class='input_r1' type='hidden' id='m8' value='$tomb[2]' />");
    $ki=sys_line_local("N�v");
    echo("<label class='label_r1'>$ki:</label>");
    echo("<input class='input_r1' type='text' id='m1' name='m1' value='$tomb[3]' size='120' maxlength='100' /><br />");
    $ki=sys_line_local("Jelsz�");
    echo("<label class='label_r1'>$ki:</label>");
    echo("<input class='input_r1' type='password' id='m2' name='m2' value='$tomb[4]' size='120' maxlength='100' /><br />");
    $ki=sys_line_local("Teljes n�v");
    echo("<label class='label_r1'>$ki:</label>");
    echo("<input class='input_r1' type='text' id='m3' name='m3' value='$tomb[5]' size='120' maxlength='100' /><br />");
    $ki=sys_line_local("Lakc�m");
    echo("<label class='label_r1'>$ki:</label>");
    echo("<input class='input_r1' type='text' id='m4' name='m4' value='$tomb[6]' size='120' maxlength='100' /><br />");
    $ki=sys_line_local("E-mail");
    echo("<label class='label_r1'>$ki:</label>");
    echo("<input class='input_r1' type='text' id='m5' name='m5' value='$tomb[7]' size='120' maxlength='100' /><br />");
    echo("<br />");
    $ki=sys_line_local("Mehet");
    echo("<button class='button_1' type='submit' id='b7' name='b7' value='$ki'>$ki</button>");
    echo("</form>");
    echo("</center>");
  }else{
    $ki=sys_line_local("Adatok nem el�rhet�k");
    echo("$ki.");
  }
  sys_env_del($newdata);
  sys_env_del($sitepage);
}


function site_reg_menu(){
  global $sitepage,$user_admin,$usercode,
         $k_edit,$k_privat,$k_mail,$k_message,
         $s_program,$reg_menu_plus,$sitepos,
         $messpage,$menupos,$dirpos,
         $enable_messagewall,$enable_newsletter;

  $l=sys_env_find($sitepos);
  $m=sys_env_find($sitepage);
  $e=sys_env_pack();
  sys_env_new($sitepage,$k_privat);
  $e=sys_env_pack();
  $k=sys_line_local("Saj�t adatok");
  echo("<a class='href' href='./$s_program?$e'>$k</a><br />");
  if ($enable_newsletter){
    sys_env_new($sitepage,$k_mail);
    $e=sys_env_pack();
    $k=sys_line_local("H�rlev�l");
    echo("<a class='href' href='./$s_program?$e'>$k</a><br />");
  }
  if ($enable_messagewall){
    sys_env_new($sitepage,$k_message);
    $e=sys_env_pack();
    $k=sys_line_local("�zen�fal");
    echo("<a class='href' href='./$s_program?$e'>$k</a><br />");
  }
  if ($user_admin){
    sys_env_new($sitepage,$k_edit);
    $e=sys_env_pack();
    $k=sys_line_local("Szerkeszt�s");
    echo("<br />");
    echo("<a class='href' href='./$s_program?$e'>$k</a><br />");
  }
  $u=count($reg_menu_plus);
  if ($u>0){
    echo("<br />");
    sys_env_del($sitepage);
    $uu=0;
    while ($uu<$u){
      $sl=$reg_menu_plus[$uu];
      if ($sl<>""){
        $sl2=sys_standard_name($sl);
        sys_env_new($sitepos,$sl2);
        $e=sys_env_pack();
	echo("<a class='href' href='$s_program?$e'>$sl</a><br />");
      }
      $uu+=1;
    }
  }
  $u=sys_env_find($usercode);
  sys_env_del($usercode);
  sys_env_del($sitepage);
  sys_env_del($sitepos);
  $m1=sys_env_find($menupos);
  $m2=sys_env_find($dirpos);
  $m3=sys_env_find($messpage);
  sys_env_del($menupos);
  sys_env_del($dirpos);
  sys_env_del($messpage);
  $e=sys_env_pack();
  $k=sys_line_local("Kijelentkez�s");
  echo("<br />");
  echo("<a class='href' href='./$s_program?$e'>$k</a><br />");
  sys_env_new($usercode,$u);
  sys_env_new($sitepage,$m);
  sys_env_new($sitepos,$l);
  sys_env_new($menupos,$m1);
  sys_env_new($dirpos,$m2);
  sys_env_new($messpage,$m3);
}



function site_reg_new(){
  global $sitepage,$newdata,$s_robot,$s_program,$k_regist,
         $user_admin;

  sys_env_new($newdata,$newdata);
  sys_env_new($sitepage,$k_regist);
  $e=sys_env_pack();
  $ki=sys_line_local("Regisztr�ci�");
  echo("<label class='label_p'><b>$ki</b></label>");
  echo("<br />");
  $ki=sys_line_local("K�sz�nj�k bizalm�t.");
  echo($ki);
  echo("<br /><br />");
  $ki=sys_line_local("A regisztr�ci� ut�n k�nnyebben tarthatja a kapcsolatot");
  echo("$ki");
  $ki=sys_line_local("vel�nk, illetve k�rheti h�rlevel�nket is. Nyerem�nyj�t�kainkban");
  echo("$ki");
  $ki=sys_line_local("�s rendezv�nyeinken csak a regisztr�lt �gyfeleink vehetnek r�szt.");
  echo("$ki");
  echo("<br /><br />");
  $ki=sys_line_local("Adatait a hat�lyos jogszab�lyok betart�s�val kezelj�k,");
  echo("$ki");
  $ki=sys_line_local("azokat harmadik f�lnek nem adjuk ki, k�r�s�re azonnal t�r�lj�k.");
  echo("$ki");
  echo("<br /><br />");
  $ki=sys_line_local("Minden k�rt adatot t�lts�n ki a sikeres regisztr�ci�hoz.");
  echo("$ki");
  echo("<br /><br />");
  echo("<center>");
  echo("<form method='post' action='./$s_program?$e'>");
  $utime=time();
  echo("<input class='input_r1' type='hidden' id='b6' name='b6' value='$utime' />");
  if ($user_admin){
    $ki=sys_line_local("Bejelentkez�si korl�t");
    $kd=sys_line_local("nap");
    $kw=sys_line_local("h�t");
    $km=sys_line_local("h�nap");
    $ky=sys_line_local("�v");
    $ku=sys_line_local("Korl�tlan bel�p�s");
    echo("<label class='label_r1'>$ki:</label>");
    echo("<select class='select_r1' id='bx' name='bx'>");
    echo("<option value='0'>$ku</option>");
    echo("<option value='86400'>1 $kd</option>");
    echo("<option value='604800'>1 $kw</option>");
    echo("<option value='2678400'>1 $km</option>");
    echo("<option value='8035200'>3 $km</option>");
    echo("<option value='16070400'>6 $km</option>");
    echo("<option value='31536000'>1 $ky</option>");
    echo("</select>");
  }else{
    echo("<input class='input_r1' type='hidden' id='b0' name='b0' value='0' />");
  }
  $ki=sys_line_local("Bejelentkez�si n�v");
  echo("<label class='label_r1'>$ki:</label>");
  echo("<input class='input_r1' type='text' id='b1' name='b1' size='120' maxlength='100' /><br />");
  $ki=sys_line_local("Jelsz�");
  echo("<label class='label_r1'>$ki:</label>");
  echo("<input class='input_r1' type='password' id='b2' name='b2' size='120' maxlength='100' /><br />");
  $ki=sys_line_local("N�v");
  echo("<label class='label_r1'>$ki:</label>");
  echo("<input class='input_r1' type='text' id='b3' name='b3' size='120' maxlength='100' /><br />");
  $ki=sys_line_local("C�m");
  echo("<label class='label_r1'>$ki:</label>");
  echo("<input class='input_r1' type='text' id='b4' name='b4' size='120' maxlength='100' /><br />");
  $ki=sys_line_local("E-mail");
  echo("<label class='label_r1'>$ki:</label>");
  echo("<input class='input_r1' type='text' id='b5' name='b5' size='120' maxlength='100' /><br />");
  echo("<br />");
  $ki=sys_line_local("Mehet");
  echo("<button class='button_1' type='submit' id='b8' name='b8'>$ki</button>");
  echo("</form>");
  echo("</center>");
  sys_env_del($newdata);
  sys_env_del($sitepage);
}

?>
