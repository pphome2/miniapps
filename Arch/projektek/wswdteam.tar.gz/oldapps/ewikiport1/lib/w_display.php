<?php

  // w_robot --- PHP portalrobot
  // (verzioadatok a konfiguracios fajlban)
  //
  // fejleszto: Zebulon.hu Team



  // menu kiirasa

  function site_menu_global(){
    global $default_site;

    site_menu($default_site);
  }

  // menu kiirasa

  function site_menu_local(){
    global $default_site,$local_menu_ext;

    $menuf=$default_site." - ".$local_menu_ext;
    $menuf=sys_standard_name($menuf);
    site_menu($menuf);
  }

  // menu kiirasa

  function site_menu_privat(){
    global $default_site,$reg_menu_ext;

    $menuf=$default_site." - ".$reg_menu_ext;
    $menuf=sys_standard_name($menuf);
    site_menu($menuf);
  }

  // menu kiirasa

  function site_menu($menupage){
    global $sitepage,$default_page,$sitepos,$k_dir,
           $s_program,$dir_data,$default_site,
           $l_open,$l_end,$s_sys,$s_submenu,
	   $s_menu,$menupos,$s_line,$s_nline,
           $dir_site,$s_language,$lang_system;


    $alap=sys_env_find($sitepos);
    $mlap=sys_env_find($menupos);
    $slap=sys_env_find($sitepage);
    sys_env_del($sitepage);
    $filename="$dir_site/$default_site/$dir_data/$menupage";
    site_file_in($filename,$mdata,$mline);
    sys_env_new($sitepos,$menupage);
    sys_env_del($menupos);
    $e=sys_env_pack();
    sys_env_new($sitepos,$alap);
    if ($menupage<>$default_site){
      sys_env_new($menupos,$mlap);
    }
    //$n=sys_unstandard_name($menupage);
    $n=0;
    $menupage=sys_unstandard_name($menupage);
    echo("<a class='href' href='./$s_program?$e'><b>$menupage</b></a><br /><br /><ul class='ul_menu'>");
    $x=0;
    $aktlap="";
    $folap=0;
    $teljes=false;
    if ($slap==$default_site){
      $teljes=true;
    }else{
      $teljes=false;
    }
    $almenu=false;
    $elso=true;
    $ujs=0;
    $sor=0;
    $write_out=true;
    $menusor=0;
    while ($x<$mline) {
      if ($mdata[$x]!==""){
        if (substr($mdata[$x],0,1)==$l_open){
          $x2=1;
          $c=strlen($mdata[$x]);
          while (($x2<$c)and(substr($mdata[$x],$x2,1)<>$l_end)){
            $x2+=1;
          }
	  $md=substr($mdata[$x],1,$x2-1);
	  if (substr($md,0,strlen($s_sys))<>$s_sys){
	    $p=$md;
            sys_env_new($sitepos,$p);
            $t=explode(" ",$p);
            switch ($t[0]){
              case $s_submenu:
	        $ujs=0;
                $v=substr($p,2,strlen($p)-0);
                $p=sys_standard_name($v);
	        if (($almenu)or($teljes)){
	          sys_env_new($sitepos,$p);
	          sys_env_new($menupos,$x);
    	          $e=sys_env_pack();
                  $p="<li class='li_me2'><a class='href' href='./$s_program?$e'>$v</a></li>";
                  $menusor+=1;
		}else{
		  $p="";
		}
		if (($mlap==$x)and($elso)){
		  $almenu=true;
		  $elso=false;
                  $x=$folap;
		}
	        break;
	      case $s_menu:
	        $ujs=0;
                $v=substr($p,2,strlen($p)-0);
    	        $p=sys_standard_name($v);
  	        $aktlap=$p;
		$folap=$x;
		if ($mlap==$x){
		  $almenu=true;
		}else{
		  $almenu=false;
		}
                sys_env_new($sitepos,$p);
                sys_env_new($menupos,$x);
	        $e=sys_env_pack();
    	        $p="<li class='li_me1'><a class='href' href='./$s_program?$e'>$v</a></li> ";
    	        $menusor+=1;
	        break;
              case $s_language:
                if ($t[1]==$lang_system){
                  $write_out=true;
                }else{
                  $write_out=false;
                }
                $p="";
                break;
              case $s_nline:
	        $ujs+=1;
		if ($sor>0){
                  $p=" <br /><br />";
		}else{
		  $p="";
		}
                break;
              case $s_line:
                $p=" <hr width='70%' />";
                break;
              default:
	          $p="";
                break;
	    }
            $e=sys_env_pack();
	    if ($p<>""){
	      if ($write_out){
	        echo("$p");
	      }
	      $sor+=1;
	    }
	  }
	}
      }
      $x+=1;
    }
    if ($menusor==0){
      echo("<li class='li_me2'>-</li>");
    }
    echo("</ul>");
    if ($menupage==$default_site){
      sys_env_del($menupos);
    }
    sys_env_new($sitepos,$alap);
  }

  // Menu kiirasa

  function site_page_menu(){
    global $sitepage,$k_edit,$s_program,$sitepos,
           $k_history,$k_print,$k_dir,$k_files,$usercode,
           $enable_view,$enable_edit,$enable_history,
           $enable_print,$enable_dir,$wiki_style,
           $enable_reg_edit,$enable_files,$user_admin,
	   $k_search,$enable_search;

    $u=sys_env_find($sitepage);
    sys_env_del($sitepage);
    if ($wiki_style){
      echo("<label class='label_k1'>");
      $jel=" - ";
    }else{
      $jel="";
    }
    $unev=sys_env_find($usercode);
    if (($enable_reg_edit) and ($unev!=="")){
      $enable_edit=true;
    }else{
      $enable_edit=false;
    }
    //
    if ($user_admin){
      $enable_edit=true;
      $enable_view=true;
      $enable_history=true;
      $enable_print=true;
      $enable_dir=true;
      $enable_files=true;
    }
    $elso=true;
    if ($enable_view){
      $elso=false;
      $ki=sys_line_local("N�z");
      $e=sys_env_pack();
      echo("<a class='href' href='./$s_program?$e'>$ki</a>");
      if (!$wiki_style){
        echo("<br />");
      }
    }
    if ($enable_edit){
      if (!$elso){
        echo($jel);
      }else{
        $elso=false;
      }
      $ki=sys_line_local("Szerkeszt");
      sys_env_new($sitepage,$k_edit);
      $e=sys_env_pack();
      echo("<a class='href' href='./$s_program?$e'>$ki</a>");
      if (!$wiki_style){
        echo("<br />");
      }
    }
    if ($enable_history){
      if (!$elso){
        echo($jel);
      }else{
        $elso=false;
      }
      $ki=sys_line_local("T�rt�net");
      sys_env_new($sitepage,$k_history);
      $e=sys_env_pack();
      echo("<a class='href' href='./$s_program?$e'>$ki</a>");
      if (!$wiki_style){
        echo("<br />");
      }
    }
    if ($enable_print){
      if (!$elso){
        echo($jel);
      }else{
        $elso=false;
      }
      $ki=sys_line_local("Nyomtat�s");
      sys_env_new($sitepage,$k_print);
      $e=sys_env_pack();
      echo("<a class='href' href='./$s_program?$e'>$ki</a>");
      if (!$wiki_style){
        echo("<br />");
      }
    }
    if ($enable_dir){
      if (!$elso){
        echo($jel);
      }else{
        $elso=false;
      }
      $ki=sys_line_local("Adatt�r");
      sys_env_new($sitepage,$k_dir);
      $e=sys_env_pack();
      echo("<a class='href' href='./$s_program?$e'>$ki</a>");
      if (!$wiki_style){
        echo("<br />");
      }
    }
    if ($enable_files){
      if (!$elso){
        echo($jel);
      }else{
        $elso=false;
      }
      $ki=sys_line_local("Let�lt�sek");
      sys_env_new($sitepage,$k_files);
      $e=sys_env_pack();
      echo("<a class='href' href='./$s_program?$e'>$ki</a>");
      if (!$wiki_style){
        echo("<br />");
      }
    }
    if ($enable_search){
      if (!$elso){
        echo($jel);
      }else{
        $elso=false;
      }
      $ki=sys_line_local("Keres�s");
      sys_env_new($sitepage,$k_search);
      $e=sys_env_pack();
      echo("<a class='href' href='./$s_program?$e'>$ki</a>");
      if (!$wiki_style){
        echo("<br />");
      }
    }
    if ($wiki_style<>false){
      echo("</label>");
    }
    if ($u==""){
      sys_env_del($sitepage);
    }else{
      sys_env_new($sitepage,$u);
    }
  }

  // nyelvi elemek feldolgozasa

  function site_lang($p){
    global $sitepos,$s_program,$s_link,$s_img,$s_sys,
           $s_cent,$s_ecent,$s_nline,$s_line,$s_plugin,
           $s_h,$s_eh,$s_bold,$s_ebold,$s_ita,$s_eita,
           $s_und,$s_eund,$s_par,$s_epar,$s_submenu,
           $default_site,$dir_site,$dir_img,$s_menu,$k_bigpic,
           $plugin_start,$s_pos,$s_posp,$sitepage,$open_page,
           $s_col,$s_ecol1,$s_ecol,$s_table,$s_etable,
           $s_row,$s_erow,$s_data,$s_edata,$col_number,
           $s_language,$lang_system,$write_out,$s_nocomment,
           $s_comment,$s_commentrate,$s_mail,$aktrow,
           $comment_all,$comment_1_page,$comment_rate,$dataedit,
           $editor;

    $t=explode(" ",$p);
    $tdb=count($t);
    $lap=sys_env_find($sitepos);
    $sp=sys_env_find($sitepage);
    switch ($t[0]){
      case $s_menu:
        if (!$open_page){
          $p=substr($p,strlen($s_menu)+1,strlen($p));
          $v=$p;
          $p=sys_standard_name($p);
          sys_env_new($sitepos,$p);
          $e=sys_env_pack();
          $p=" <label class='label_me1'>";
	  $p=$p."<a class='href' href='./$s_program?$e'>$v</a></label>";
	}else{
	  $p="";
	}
        break;
      case $s_submenu:
        if (!$open_page){
          $p=substr($p,strlen($s_submenu)+1,strlen($p));
          $v=$p;
          $p=sys_standard_name($p);
          sys_env_new($sitepos,$p);
          $e=sys_env_pack();
          $p=" <label class='label_me2'>";
	  $p=$p."<a class='href' href='./$s_program?$e'>  $v</a></label>";
	}else{
	  $p="";
	}
        break;
      case $s_pos:
        $p="";
        break;
      case $s_posp:
        $p="";
        break;
      case $s_cent:
        $p=" <center>";
        break;
      case $s_ecent:
        $p=" </center>";
        break;
      case $s_nline:
        $p=" <br />";
        break;
      case $s_line:
        $p=" <hr width='70%' />";
        break;
      case $s_h:
        $p=" <h".$t[1].">";
        break;
      case $s_eh:
        $p=" </h".$t[1].">";
        break;
      case $s_bold:
        $p=" <b>";
        break;
      case $s_ebold:
        $p=" </b>";
        break;
      case $s_ita:
        $p=" <i>";
        break;
      case $s_eita:
        $p=" </i>";
        break;
      case $s_und:
        $p=" <u>";
        break;
      case $s_eund:
        $p=" </u>";
        break;
      case $s_par:
        $p=" <p>";
        break;
      case $s_epar:
        $p=" </p>";
        break;
      case $s_link:
        $c=strlen($s_link)+strlen($t[1])+2;
        $v=substr($p,$c,strlen($p)-$c);
        if (substr($t[1],0,1)=="."){
            $p=" <a class='href' href='$t[1]'>$v</a> ";
	}else{
          if (substr($t[1],0,4)=="http"){
            $p=" <a class='href' href='$t[1]'>$v</a> ";
	  }else{
            $p=" <a class='href' href='http://$t[1]'>$v</a> ";
	  }
	}
        break;
      case $s_mail:
        $p=" <a class='href' href='mailto:$t[1]'>$t[1]</a> ";
        break;
      case $s_img:
        $p=" <center>";
        if (($tdb>2)and($t[2]<>"")){
	  $ki=sys_line_local("Nagy�t");
	  sys_env_new($sitepos,"$dir_site/$default_site/$dir_img/$t[2]");
	  sys_env_new($sitepage,$k_bigpic);
          $e=sys_env_pack();
	  $p=$p."<img class='imgclass3' src=$dir_site/$default_site/$dir_img/$t[1] value='hely' />";
          $p=$p."<br /><a class='href' href='./$s_program?$e'> ";
	  $p=$p."$ki</a> ";
	}else{
          $p=$p."<img class='imgclass3' src=$dir_site/$default_site/$dir_img/$t[1] value='hely' /> ";
	}
        $p=$p."</center> ";
        break;
      case $s_sys:
        $p=" ";
        break;
      case $s_plugin:
        if ((!$plugin_start)and(!$dataedit)and(!$editor)){
          $i=0;
	  $p2="";
          foreach ($t as $k){
	    $i+=1;
	    if ($i>2){
	      $p2=$p2." ".$k;
	    }
	  }
          $ddd=count($t);
	  while ($ddd<=7){
	    $t[$ddd]="";
	    $ddd+=1;
	  }
	  site_load_run($t[1],$t[2],$t[3],$t[4],$t[5],$t[6],$t[7]);
	  $plugin_start=true;
	}
	$p="";
        break;
      case $s_col:
        $p="<center><table class='table_2' border='0'><tr>";
	if ($t[1]<>""){
	  $col_number=100/$t[1];
	}else{
	  $col_number=100/3;
	}
	$col_number=round($col_number,0);
	$p=$p."<td width='$col_number%' class='t_data' valign='top'>";
        break;
      case $s_ecol1:
        $p=" </td><td width='$col_number%' class='t_data' valign='top'>";
        break;
      case $s_ecol:
        $p=" </td></tr></table></center>";
        break;
      case $s_table:
        //$p=" <center><table class=table_1  border=1>";
        $p=" <center><table class='table_d1'>";
        break;
      case $s_etable:
        $p=" </table></center>";
        break;
      case $s_row:
        if ($aktrow==1){
          $aktrow=2;
          $p=" <tr class='row_d1'>";
        }else{
          $aktrow=1;
          $p=" <tr class='row_d2'>";
        }
        break;
      case $s_erow:
        $p=" </tr>";
        break;
      case $s_data:
        //$p=" <td class=t_data>";
        $p=" <td class='data_d1'>";
        break;
      case $s_edata:
        $p=" </td>";
        break;
      case $s_language:
        if ($t[1]==$lang_system){
          $write_out=true;
        }else{
          $write_out=false;
        }
        $p="";
        break;
      case $s_nocomment:
        $comment_all=false;
        //$comment_1_page=false;
        $comment_rate=false;
        $p="";
        break;
      case $s_comment:
        $comment_all=true;
        //$comment_1_page=true;
        $comment_rate=false;
        $p="";
        break;
      case $s_commentrate:
        $comment_all=true;
        //$comment_1_page=true;
        $comment_rate=true;
        $p="";
        break;
        break;
      default:
        $v=$p;
        $p=sys_standard_name($p);
        sys_env_new($sitepos,$p);
        $e=sys_env_pack();
        $p=" <a class='href' href='./$s_program?$e'>$v</a> ";
        break;
    }
    sys_env_new($sitepos,$lap);
    sys_env_new($sitepage,$sp);
    return($p);
  }

  // egy lap kiirasa

  function site_page_out(){
    global $sitepos,$sitedata,$siteline,$default_site,
           $k_edit,$l_open,$l_end,$s_program,$open_page,
           $s_program,$sitepage,$plugin_start,
           $comment_ext,$comment_all,$comment_1_page,
           $write_out,$editor,$no_out_html;

    $lap=sys_env_find($sitepos);
    if ($lap==""){
      $lap=$default_site;
    }
    $sp=sys_env_find($sitepage);
    sys_env_del($sitepage);
    $cc=strlen($comment_ext);
    if (substr($lap,strlen($lap)-$cc,$cc)==$comment_ext){
      $lap=substr($lap,0,strlen($lap)-$cc);
      $comment_1_page=true;
    }else{
      $comm_ent_1_page1=false;
    }
    if (substr($lap,0,2)==".."){
     $f="$lap";
     //$x=count($t);
     //$n=$t[$x-1];
     $n=$lap;
    }else{
     $f="$lap";
     $n=$lap;
    }
    if (!$no_out_html){
      $n=sys_unstandard_name($n);
      echo("<i>$n</i><br /><br />");
    }
    site_in($f);
    $x=0;
    if (($editor)and($siteline>=25)){
      $maxline=25;
    }else{
      $maxline=$siteline;
    }
    while (($x<$maxline)and(!$plugin_start)) {
      $s=$sitedata[$x];
      $sx="";
      $v0=0;
      while ($v0<strlen($s)){
        if (substr($s,$v0,1)==$l_open){
          $v1=$v0+1;
          while (($v1<strlen($s))and(substr($s,$v1,1)<>$l_end)){
            $v1+=1;
          }
          if (substr($s,$v1,1)==$l_end){
            $s2=substr($s,$v0+1,$v1-$v0-1);
  	    $la=site_lang($s2);
	    if (!$plugin_start){
	      $s=substr($s,0,$v0).$la.substr($s,$v1+1,strlen($s));
	    }else{
	      $s=="";
	    }
	  }
	  //$v0=0;
        }
        $v0+=1;
      }
      if (($s<>"")and(!$plugin_start)and($write_out)and(!$no_out_html)){
        echo("$s ");
        if (substr($s,strlen($s)-7,4)=="</a>"){
          echo("<br />");
        }
        if (substr($lap,0,2)==".."){
	  echo("<br />");
	}
      }
      $x+=1;
    }
    if (!$plugin_start){
      //echo("<br /><br />");
      if (($comment_all)and(!$open_page)and(!$no_out_html)){
	$fn=$f.$comment_ext;
	if ($comment_1_page){
          $ki=sys_line_local("Hozz�sz�l�sok");
          site_message_wall($fn,$ki);
	 }else{
  	  sys_env_new($sitepos,$fn);
	  $e=sys_env_pack();
          echo("<label class='label_mess'><a class='href' href='./$s_program?$e'>$ki</a></label>");
	}
      }
    }
    sys_env_new($sitepos,$lap);
    sys_env_new($sitepage,$sp);
  }

  // egy lap kiirasa

  function site_page_out_2(){
    global $sitedata,$siteline,
           $l_open,$s_sys,$specchar2;

    if ($siteline==0){
      $f="$lap";
      site_in($f);
    }
    if ($siteline==0){
    }else{
      $x=0;
      while ($x<$siteline) {
        if ((substr($sitedata[$x],0,1)==$l_open)and
	   (substr($sitedata[$x],1,strlen($s_sys))==$s_sys)){
	}else{
          echo("$sitedata[$x] ");
          if ($x<$siteline-1){
            echo("$specchar2");
          }
	}
        $x+=1;
      }
    }
  }

  // egy kep kirajzolasa

  function site_bigpic(){
    global $sitepos,$default_site;

    $lap=sys_env_find($sitepos);
    if ($lap==""){
      $lap=$default_site;
    }
    $ki=sys_line_local("Nagyitott k�p");
    echo("<i>$ki</i><br /><br />");
    echo("<br /><br /><center>");
    echo("<img class='imgclass' src=$lap value='hely' />");
    echo("</center><br /><br />");
  }

  // laptortenet kiirasa

  function site_history_line(){
    global $sitepos,$sitedata,$siteline,$default_site,
           $k_edit,$l_open,$l_end,$s_program,
           $s_program,$s_sys;

    $lap=sys_env_find($sitepos);
    if ($lap==""){
      $lap=$default_site;
    }
    $k1=sys_line_local("Felhaszn�l� neve");
    $k2=sys_line_local("D�tum");
    $k3=sys_line_local("Id�");
    $f="$lap";
    echo("<br /><br />");
    site_in($f);
    $x=0;
    while ($x<$siteline) {
      $s=$sitedata[$x];
      $sx="";
      $v0=0;
      $s2="";
      while ($v0<strlen($s)){
        if (substr($s,$v0,1)==$l_open){
	  $v1=$v0+1;
	  while (($v1<strlen($s))and(substr($s,$v1,1)<>$l_end)){
	    $v1+=1;
	  }
	  if (substr($s,$v1,1)==$l_end){
	    $s2=substr($s,$v0+1,$v1-$v0-1);
	    $l=explode(' ',$s2);
	    if ($l[0]<>$s_sys){
	      $s2="";
	    }
	  }
	  $v0=$v1;
	}
        $v0+=1;
      }
      if ($s2<>""){
        $kis=explode(' ',$s2);
	echo("<label class='label_t1'>");
	echo("<b>$k2:</b> $kis[2] ");
	echo("</label>");
	echo("<label class='label_t1'>");
	echo("<b>$k3:</b> $kis[3] ");
	echo("</label>");
	echo("<label class='label_t1'>");
	echo("<b>$k1:</b>");
	echo("</label>");
	echo("<label class='label_t1'>");
	echo("$kis[1] ");
	echo("</label>");
        echo("<br />");
      }
      $x+=1;
    }
        echo("<br />");
    sys_env_new($sitepos,$lap);
  }

  // directosy kiirasa

  function site_directory_list($dirname,$admin,$dload){
    global $sitepos,$sitepage,$deldata,$k_bigpic,$dirdata,
           $dir_site,$default_site,$dir_data,$list_pic,$delkod,
           $s_program,$delkod,$dir_files,$dirdata,$dirpos,
           $user_admin;

    $lap=sys_env_find($sitepos);
    $sp=sys_env_find($sitepage);
    $startdir="$dir_site/$default_site";
    if ($dirdata==""){
      $dirdata="$dir_site/$default_site/$dir_data";
    }else{
      $dirname=$dirdata;
    }
    if ($dirname==""){
      $dirname=$dirdata;
    }
    //if ($delkod<>""){
    //  sys_file_del($delkod);
    //  $delkod="";
    //}
    sys_dir_list($dirname,$files);
    if (substr($dirname,0,2)==".."){
      $cc=strlen($startdir)+1;
      $dirn=substr($dirname,$cc,strlen($dirname))."/";
      $x=0;
      $l="";
      $elso=true;
      $n="";
      while ($x<strlen($dirn)){
        $ch=substr($dirn,$x,1);
	if ($ch=="/"){
	  echo(" / ");
          //sys_env_new($sitepage,$sp);
	  $sdir=$startdir."/".$l;
          sys_env_new($dirpos,$sdir);
          $e=sys_env_pack();
	  if ($elso){
	    $ki=sys_line_local("T�rol�");
	    $elso=false;
	  }else{
	    $ki=$n;
	  }
	  $ki=sys_unstandard_name($ki);
          echo(" <a class='href' href='./$s_program?$e'>$ki</a> ");
	  $n="";
	}else{
          $n=$n.$ch;
	}
	$l=$l.$ch;
        $x+=1;
      }
    }
    $fdb=count($files);
    if ($fdb>0){
      sort($files);
      $x=0;
      $ki=sys_line_local("T�r�l");
      $kinu=sys_line_local("Nem �res");
      echo("<br /><br /><center>");
      echo("<div class='page_dir'>");
      while ($x<$fdb){
        sys_env_del($sitepage);
	$fn=$files[$x];
	if ($fn<>""){
	  $v=sys_unstandard_name($fn);
          sys_env_del($deldata);
	  $code=substr($fn,strlen($fn)-4,4);
	  $dir=false;
	  if (in_array($code,$list_pic)){
	    sys_env_new($sitepage,$k_bigpic);
	    sys_env_new($sitepos,"$dirname/$fn");
	  }else{
	    if (is_dir("$dirname/$fn")){
              sys_env_new($dirpos,"$dirname/$fn");
              sys_env_new($sitepage,$sp);
	      $down=false;
	      $dir=true;
	    }else{
	      sys_env_new($sitepos,"$dirname/$fn");
	      sys_env_del($dirpos);
	      $down=true;
	      $dir=false;
	      //sys_env_del($sitepage);
	    }
	  }
	  if ($user_admin){
	    echo("<label class='label_dir1'>");
	  }else{
	    echo("<label class='label_dir2'>");
	  }
	  if (($dload)and($down)){
            $file="$dirname/$fn";
            echo("<a class='href' href='$file'>$v</a>");
	  }else{
            //sys_env_new($dirpos,$dirname);
            $e=sys_env_pack();
            echo("<a class='href' href='./$s_program?$e'>$v</a>");
	  }
	  echo("</label>");
	  if ($user_admin){
	    if ($dir){
	      sys_dir_list("$dirname/$fn/",$ttt);
	      $c=count($ttt);
	      if ($c==0){
                sys_env_new($deldata,"$dirname/$fn");
                $del=true;
              }else{
                $del=false;
              }
            }else{
              sys_env_new($deldata,"$dirname/$fn");
              $del=true;
            }
            if ($del){
              sys_env_new($sitepage,$sp);
              sys_env_new($sitepos,$lap);
              sys_env_del($dirpos);
              $e=sys_env_pack();
              echo("<label class='label_dir3'><a class='href' href='./$s_program?$e'>$ki</a></label>");
              sys_env_del($deldata);
              sys_env_del($sitepage);
            }else{
              echo("<label class='label_dir3'>$kinu</label>");
            }
	  }else{
            //echo("<label class=label_dir2>-</label>");
	  }
	}
        $x+=1;
      }
      $ki1=sys_line_local("�sszesen");
      $ki2=sys_line_local("db");
      echo("$ki1: $fdb $ki2.");
      echo("</div>");
      echo("</center>");
      echo("<br />");
    }else{
      $ki=sys_line_local("A t�rol� �res");
      echo("<br /><br />$ki.<br /><br />");
    }
    sys_env_new($sitepos,$lap);
    sys_env_new($sitepage,$sp);
  }

  // site lapok szerkesztese

  function site_edit(){
    global $sitepos,$dataedit,$usercode,
           $siteline,$sitedata,$s_sys,$l_open,$l_end,
           $usercode,$guest_name,$hist_db,$l_open,$s_sys,
           $enable_edit,$enable_reg_edit,$user_admin;

    $lap=sys_env_find($sitepos);
    $f="$lap";
    if (($enable_edit)or
       (($$enable_reg_edit)and(sys_env_find($usercode)<>""))or
       ($user_admin)){
      if ($dataedit){
        site_in($f);
	$x=0;
	$hdb=0;
	$ht=array("");
        while ($x<$siteline) {
          if ((substr($sitedata[$x],0,1)==$l_open)and
	     (substr($sitedata[$x],1,strlen($s_sys))==$s_sys)){
	    $ht[$hdb]=$sitedata[$x];
	    $hdb+=1;
	  }
          $x+=1;
        }
        $ok=sys_data_post($db,$dk,$de);
	$sitedata[0]=strip_tags($de[0]);
        $c1=site_user("");
	if ($c1==""){
	  $c1=$guest_name;
	}
	$c2=date("Y.m.d. G:i");
	$sitedata[1]="$l_open$s_sys $c1 $c2$l_end";
	$siteline=1;
	if ($hdb+1>$hist_db){
	  $hdb=$hist_db;
	}
	$x=0;
        $siteline+=1;
	while ($x<$hdb){
	  $sitedata[$siteline]=$ht[$x];
	  $siteline+=1;
	  $x+=1;
	  //$hdb-=1;
	}
	site_out($f);
      }
      $siteline=0;
      site_page_out();
      site_page_edit();
    }
  }

  // uzenofal megvalositasa

  function site_message_wall($fn,$mcim){
    global $tk,$te,$default_site,$dir_site,$file_mess,$dir_data,
           $max_message,$separator,$dataedit,$guest_user,
           $messpage,$mess_per_page,$messaktpage,$s_program,
           $pont,$printed,$editor,$usercode,$comment_rate,
	   $comment_ext,$comment_all,$comment_1_page,
	   $site_data_css_container,$sitepage,$k_message;

    $sysmess=false;
    $uc=sys_env_find($usercode);
    if (!$editor){
      if ($fn==""){
        $sysmess=true;
        site_mess_new($mcim,$fn,$sysmess);
	sys_env_new($sitepage,$k_message);
        $filename="$dir_site/$default_site/$file_mess";
        $ki001=sys_line_local("�zenetek");
        $ki002=sys_line_local("Nincs m�g �zenet");
        $ki003=sys_line_local("Csak bejelentkez�s ut�n �rhat� �zenet");
        $ki004=sys_line_local("Lap");
        //$dataedit=true;
      }else{
        $cc=strlen($comment_ext);
        if (substr($fn,strlen($fn)-$cc,$cc)==$comment_ext){
          $filename="$dir_site/$default_site/$dir_data/$fn";
          $ki001=sys_line_local("Hozz�sz�l�sok");
          $ki002=sys_line_local("Nincs m�g hozz�sz�l�s");
          $ki003=sys_line_local("Csak bejelentkez�s ut�n �rhat� hozz�sz�l�s");
          $ki004=sys_line_local("Lap");
        }else{
          $filename="$dir_site/$default_site/$fn";
          $ki001=sys_line_local("V�lem�nyek");
          $ki002=sys_line_local("Nincs m�g v�lem�ny");
          $ki003=sys_line_local("Csak bejelentkez�s ut�n �rhat� v�lem�ny");
          $ki004=sys_line_local("Lap");
        }
      }
      if (($dataedit)and(!$editor)){
        $ok=sys_data_post($dbx,$tkx,$tex);
        if (strip_tags($tex[0])<>""){
          site_file_in_lock($filename,$utomb,$uindex);
          $x=count($utomb)-2;
          while ($x>=0){
            $utomb[$x+4]=$utomb[$x];
            $x-=1;
          }
          $ido=date("Y.m.d. H:i");
          $ki=sys_line_local("�rkezett");
          $ki2=sys_line_local("Bek�ldte");
          $ki3=sys_line_local("�rt�kel�s");
          $ki4=sys_line_local("pont");
          $n=site_user("");
	  if ($n=="") {
	    $n=$guest_user;
	  }
          $utomb[0]="<b>$n - $ido";
	  if (($dbx>1)and($tex[1]<>"")){
	    $utomb[0]=$utomb[0].". <br /> $ki3: $tex[1]";
	    $utomb[0]=$utomb[0]." $ki4";
	  }
	  $utomb[0]=$utomb[0].".</b><br />";
          $utomb[1]=strip_tags($tex[0]);
          $utomb[2]="";
          $utomb[3]="$separator";
          $uindex=count($utomb)-1;
          site_file_out_lock($filename,$utomb,$uindex);
        }
      }
      site_file_in($filename,$utomb,$uindex);
      if ($site_data_css_container<>""){
        echo("<label class='label_p'></label>");
        echo("</div><div class='$site_data_css_container'>");
      }else{
        echo("<hr width='85%' />");
      }
      $tol=($messaktpage-1)*$mess_per_page;
      if ($tol<=0){
        $tol=1;
      }else{
        if($tol>1){
          $tol+=1;
        }
      }
      $ig=$tol+$mess_per_page-1;
      $ig2=$tol;
      $db=1;
      $x=0;
      $data=0;
      $datadb=0;
      $kidata=0;
      $szamol=true;
      $ujkont=false;
      $first=true;
      echo("<div class=h_head><div class=h_line>");
      while ($x<$uindex){
        if ($utomb[$x]<>""){
          if ((substr($utomb[$x],0,1)==$separator)or
             (substr($utomb[$x],1,1)==$separator)){
            $db+=1;
    	    $utomb[$x]="";
    	    $szamol=true;
            if (($db>=$tol)and($db<=$ig)){
              $ig2+=1;
              if ($kidata>0){
  	        $ujkont=true;
  	      }
            }
          }else{
      	    if ($ujkont){
  	      //if (($db<>$ig)and($db<>$tol)){
                if ($site_data_css_container<>""){
	          echo("<label class='label_p'></label>");
                  //echo("</div><div class='$site_data_css_container'>");
	        }else{
	          //echo("<hr width='85%' />");
	        }
	      //}
              echo("<br /><br /><div class=h_line>");
              $first=true;
	      $ujkont=false;
	    }
            if (($db>=$tol)and($db<=$ig)){
	      sys_new_line($utomb[$x]);
              echo("$utomb[$x]");
              if ($first){
                $first=false;
                echo("</div>");
              }else{
                echo("<br />");
              }
              $kidata+=1;
	    }
	    if ($szamol){
	      $szamol=false;
  	      $u=strip_tags($utomb[$x]);
	      $d=substr($u,strlen($u)-7,2);
	      //echo($d);
	      if (($d>0)and($d<100)){
	        $data=$data+$d;
	        $datadb+=1;
	      }
	    }
	  }
        }
        $x+=1;
      }
      echo("<br /><br /></div>");
      if ($kidata>0){
        if ($messaktpage>1){
          $ig2=$ig2-1;
        }
        if ($ig2>$db-1){
          $ig2=$db-1;
        }
        $ttl=round($tol/10+1);
        if (($fn<>"")and($comment_rate)){
          if ($site_data_css_container<>""){
	    echo("<label class='label_p'></label>");
            echo("</div><div class='$site_data_css_container'>");
          }else{
            echo("<br /><br />");
          }
          //echo("<b>$ki004: $ttl. ");
          //echo("$ki001: ");
          //echo("$tol - $ig2.");
          //echo("</b>");
          $ki=sys_line_local("�rt�kel�s");
          $kis="<b>$ki: ";
          $ki=sys_line_local("�zenet");
          $darab=$db-1;
          $kis=$kis." $darab $ki, ";
          $ki=sys_line_local("adott pont");
          $kis=$kis." $data $ki. ";
          $ki=sys_line_local("�tlag pontsz�m");
          if (($data>0)and($datadb>0)){
            $c=$data/$datadb;
            $c=round($c,1);
          }else{
            $c=0;
          }
          $kis=$kis." $ki: $c. ";
          $kis=$kis."</b>";
          echo("$kis<br />");
        }
      }else{
        if ($datadb==0){
          echo("<b>$ki002.</b><br /><br />");
          if ($uc<>""){
            echo("</div>");
          }
        }
      }
      if ($db>$mess_per_page){
        if ($site_data_css_container<>""){
          echo("<label class='label_p'></label>");
          echo("</div><div class='$site_data_css_container'>");
        }else{
            echo("<br /><br />");
        }
      }
      site_pageing($db-1,$mess_per_page,$messaktpage,$messpage);
      if ((!$printed)and(!$editor)){
        if (($fn<>"")and($uc<>"")){
          if ($site_data_css_container<>""){
            echo("<label class='label_p'></label>");
            echo("</div><div class='$site_data_css_container'>");
          }else{
            echo("<hr width='85%' />");
  	  }
          site_mess_new($mcim,$fn,$sysmess);
        }else{
          if ($uc==""){
            echo("<br /><br />$ki003.<br /><br />");
            if ($datadb==0){
              echo("</div>");
            }
          }     
        }
      }
    }
    sys_env_del($sitepage);
  }

?>
