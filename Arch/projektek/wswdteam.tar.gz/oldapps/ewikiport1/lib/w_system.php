<?php

  // w_robot --- PHP portalrobot
  // (verzioadatok a konfiguracios fajlban)
  //
  // fejleszto: Zebulon.hu Team


  // directory, file name conversion

  // error handler

  function sys_error($errno,$errstr,$errfile,$errline){
    global $error_log_file,$error_all_mess;

    if (($error_all_mess)or($errno<>E_NOTICE)){
      $line=date("Y.m.d. H:i")." --- ";
      $line=$line."Error: $errno ($errstr). File: $errfile. Line: $errline.\n";
      if (substr($error_log_file,0,1)=="."){
        $day=date("Ymd");
        $ef=$error_log_file."-".$day;
      }else{
        $ef=$error_log_file;
      }
      sys_file_line_out($ef,$line);
    }
  }

  // include es futtatas

  function sys_load_run($incfile,$runfunc){
    global $dir_plugins;

    if (file_exists($incfile)){
      include($incfile);
      if ($runfunc<>""){
        call_user_func($runfunc);
      }
    }
  }

  // adat beolvasas get

  function sys_data_get(&$db,&$dtk,&$dte){
    $ok=false;
    $db=0;
    foreach ($_GET as $key => $data) {
      if ($data<>""){
        $dtk[$db]=$key;
        $dte[$db]=$data;
        if ($data<>""){
          $ok=true;
        }
        $db+=1;
      }
    }
    return($ok);
  }

  // adat beolvasas post

  function sys_data_post(&$db,&$dtk,&$dte){
    $ok=false;
    $db=0;
    foreach ($_POST as $key => $data) {
        $dtk[$db]=$key;
        $dte[$db]=$data;
        if ($data<>""){
          $ok=true;
        }
        $db+=1;
    }
    $db-=1;
    return($ok);
  }

  // nomalizalt nev

  function sys_standard_name($s){
    global $char_old,$char_new;

    $t=str_replace($char_old,$char_new,trim($s));
    return($t);
  }


  function sys_unstandard_name($s){
    global $char_old,$char_new;

    $t=str_replace($char_new,$char_old,$s);
    return($t);
  }

  // parancssor kezelese --- 4 fuggveny


  function sys_site_open(){
    global $newdata,$dataedit,$delkod,
           $deldata,$sitepage,$printed,
	   $k_print,$k_edit,$editor,$dirpos,
           $dirdata,$messpage,$messaktpage,
           $validpage,$validaktpage;

    sys_lang_in_local();
    $delkod=sys_env_find($deldata);
    if ($delkod<>""){
      sys_env_del($deldata);
    }
    $dirdata=sys_env_find($dirpos);
    if ($dirdata<>""){
      sys_env_del($dirpos);
    }
    $e=sys_env_find($newdata);
    if ($e<>""){
      $dataedit=true;
      sys_env_del($newdata);
    }
    $messaktpage=sys_env_find($messpage);
    sys_env_del($messpage);
    if (($messaktpage=="")or($messaktpage<1)){
      $messaktpage=1;
    }
    $validaktpage=sys_env_find($validpage);
    sys_env_del($validpage);
    if (($validaktpage=="")or($validaktpage<1)){
      $validaktpage=1;
    }
    $p=sys_env_find($sitepage);
    if ($p==$k_print){
      $printed=true;
    }
    if ($p==$k_edit){
      $editor=true;
    }
  }


  function sys_site_end(){
  }


  function sys_style($f){
    global $no_out_html;

    if (!$no_out_html){
      echo("<style type='text/css' media='screen'>");
      echo("<!--");
      sys_file_in($f,$t);
      $x=count($t);
      $y=0;
      while ($y<$x) {
        echo($t[$y]);
        $y+=1;
      }
      echo("--></style>");
    }
  }


  function sys_style_in($dir,$tl){
    global $no_out_html;

    if (!$no_out_html){
      $x=0;
      $y=count($tl);
      while ($x<$y){
        if ($tl[$x]!=""){
          sys_style("$dir/$tl[$x]");
        }
        $x+=1;
      }
    }
  }


  function sys_meta($f,$key,$desc){
    sys_file_in($f,$t);
    $x=count($t);
    $y=0;
    while ($y<$x) {
      echo($t[$y]);
      $y+=1;
    }
    echo("<meta name='Keywords' content='$key' />");
    echo("<meta name='Description' content='$desc' />");
  }


  function sys_env_pack(){
    global $envdb,$tk,$te,$param_separator;

    $x=0;
    $env="";
    while ($x<$envdb){
      if (($tk[$x]<>"")and($te[$x]<>"")){
        if ($env==""){
          $env="$tk[$x]=$te[$x]";
        }else{
          $env=$env.$param_separator."$tk[$x]=$te[$x]";
        }
      }
      $x+=1;
    }
    $env=str_replace("?","_",$env);
    return("$env");
  }

  function sys_env_find($kulcs){
    global $envdb,$tk,$te;

    $dat="";
    $x=0;
    while (($x<$envdb)and($tk[$x]<>$kulcs)){
      $x+=1;
    }
    if ($x<$envdb){
      $dat=$te[$x];
    }
    return($dat);
  }

  function sys_env_del($kulcs){
    global $envdb,$tk,$te;

    $x=0;
    while (($x<$envdb)and($tk[$x]<>$kulcs)){
      $x+=1;
    }
    if (($x<$envdb)and($tk[$x]==$kulcs)){
      $tk[$x]="";
      $te[$x]="";
    }
  }

  function sys_env_new($kulcs,$ertek){
    global $envdb,$tk,$te;

    $x=0;
    while (($x<$envdb)and($tk[$x]<>$kulcs)){
      $x+=1;
    }
    if (($x<$envdb)and($tk[$x]==$kulcs)){
      $te[$x]=$ertek;
    }else{
      $tk[$envdb]=$kulcs;
      $te[$envdb]=$ertek;
      $envdb+=1;
    }
  }

  function sys_env_in(){
    global $envdb,$tk,$te;

    $ok=sys_data_get($envdb,$tk,$te);
  }

  function sys_env_plugin_pack(){
    global $env_plugin_db,$env_plugin_name,$env_plugin_data,
           $param_separator;

    $x=0;
    $env=sys_env_pack();
    $y=count($env_plugin_name);
    while ($x<$y){
      if (($env_plugin_name[$x]<>"")and
         ($env_plugin_data[$x]<>"")){
        $env=$env.$param_separator."$env_plugin_name[$x]=$env_plugin_data[$x]";
      }
      $x+=1;
    }
    $env=str_replace("?","_",$env);
    return("$env");
  }

  function sys_env_plugin_new($kulcs,$ertek){
    global $env_plugin_db,$env_plugin_name,$env_plugin_data;

    $x=0;
    while (($x<$env_plugin_db)and
          ($env_plugin_name[$x]<>$kulcs)){
      $x+=1;
    }
    if ($kulcs==$env_plugin_name[$x]){
      $env_plugin_data[$x]=$ertek;
    }else{
      $env_plugin_name[$x]=$kulcs;
      $env_plugin_data[$x]=$ertek;
      $env_plugin_db+=1;
    }
  }

  function sys_env_plugin_del($kulcs){
    global $env_plugin_db,$env_plugin_name,$env_plugin_data;

    $x=0;
    while (($x<$env_plugin_db)and
          ($env_plugin_name[$x]<>$kulcs)){
      $x+=1;
    }
    if ($x<$env_plugin_db){
      $env_plugin_data[$x]="";
    }
  }

  function sys_env_plugin_find($kulcs){
    global $env_plugin_db,$env_plugin_name,$env_plugin_data;

    $dat="";
    $x=0;
    while (($x<$env_plugin_db)and
          ($env_plugin_name[$x]<>$kulcs)){
      $x+=1;
    }
    if ($x<$env_plugin_db){
      $dat=$env_plugin_data[$x];
    }
    return($dat);
  }

  function sys_env_plugin_in(){
    global $env_plugin_db,$env_plugin_name,$env_plugin_data;

    $env_plugin_db=count($env_plugin_name);
    $x=0;
    while ($x<$env_plugin_db){
      $env_plugin_data[$x]=sys_env_find($env_plugin_name[$x]);
      sys_env_del($env_plugin_name[$x]);
      $x+=1;
    }
  }

  // nyelvi kiiras, vagy mentes

  function sys_line_local($sor){
    global $lang,$langdb,$langfile;

    $s=sys_line($sor,$langfile,$lang,$langdb);
    return($s);
  }


  // nyelvi adatok beolvasasa

  function sys_lang_in_local(){
    global $lang,$langdb,$langfile;

    sys_lang_in($langfile,$lang,$langdb);
  }

  // nyelvi kiiras, vagy mentes

  function sys_Line($sor,$lf,&$lt,&$ltdb){
    if ($ltdb==0){
      sys_lang_in($lf,$lt,$ltdb);
    }
    $x=0;
    $ok=false;
    while (($ltdb>$x)and(!$ok)){
      if ($lt[$x][0]==$sor){
        $ok=true;
      }else{
        $x+=1;
      }
    }
    if ($ok){
        $sor=$lt[$x][1];
    }else{
      $ki="$sor=$sor\n";
      sys_file_line_out($lf,$ki);
      $ltdb+=1;
      $lt[$ltdb][0]=$sor;
      $lt[$ltdb][1]=$sor;
    }
    $sor=trim($sor,"\n");
    return($sor);
  }


  // nyelvi adatok beolvasasa

  function sys_lang_in($lf,&$lt,&$ltdb){
    global $specchar2;

    $ltdb=0;
    if (file_exists($lf)) {
      if (sys_file_open($lf,$fh,"r")){
        $lock=sys_file_lock_read($fh);
        if ($lock){
          while (!feof($fh)) {
            $sor=fgets($fh);
	    $sor=trim($sor,$specchar2);
	    if ($sor!=""){
	      $x=strpos($sor,"=");
              $lt[$ltdb][0]=substr($sor,0,$x);
              $lt[$ltdb][1]=substr($sor,$x+1,strlen($sor));
              $ltdb+=1;
	    }
          }
	  sys_file_unlock($fh);
          sys_file_close($fh);
	}
      }
    }
  }

  // fajl beolvasasa

  function sys_file_in($ofile,&$mibe){
    sys_file_in_work($ofile,$mibe,false);
  }

  // fajl beolvasasa

  function sys_file_in_lock($ofile,&$mibe){
    sys_file_in_work($ofile,$mibe,true);
  }

  // fajl beolvasasa

  function sys_file_in_work($ofile,&$mibe,$lock){
    global $specchar2,$specchar3,$fh;

    $mibe=array();
    if (file_exists($ofile)) {
      if (sys_file_open($ofile,$h,"r")){
        $lock1=sys_file_lock_read($h);
        $fh=$h;
      }
      if ($lock1){
        $db=0;
        while (!feof($h)) {
          $sor=fgets($h);
          $sor=trim($sor,$specchar2);
          $sor=trim($sor,$specchar3);
          $mibe[$db]=$sor;
          $db+=1;
        }
        if (!$lock){
          sys_file_unlock($h);
          sys_file_close($h);
	}
      }
    }
  }

  // fajl kiirasa

  function sys_file_out($ofile,&$mit){
    sys_file_out_work($ofile,$mit,false);
  }

  // fajl kiirasa

  function sys_file_out_lock($ofile,&$mit){
    sys_file_out_work($ofile,$mit,true);
  }

  // fajl kiirasa

  function sys_file_out_work($ofile,&$mit,$lock){
    global $specchar2,$specchar3,$fh;

    if (($lock)and(file_exists($ofile))){
      sys_file_unlock($fh);
      sys_file_close($fh);
    }
    $lock1=false;
    if (sys_file_open($ofile,$h,"w+")){
      $lock1=sys_file_lock_write($h);
    }
    if (($lock1)and($h)){
      $x=count($mit);
      $db=0;
      while($db<$x){
        $ki=$mit[$db];
	$ki=str_replace("\\\"","\"",$ki);
	$ki=str_replace($specchar3,"",$ki);
	$ki=rtrim($ki);
	if (substr($ki,strlen($ki)-1,1)<>$specchar2){
	  $ki=$ki.$specchar2;
	}
        fwrite($h, $ki);
        $db+=1;
      }
      sys_file_unlock($h);
      sys_file_close($h);
    }
  }

  // sor kiirasa

  function sys_file_line_out($ofile,$line){
    global $specchar2,$specchar3;

    if (file_exists($ofile)) {
      $jel="a+";
    }else{
      $jel="w+";
    }
    if (sys_file_open($ofile,$h,$jel)){
      $lock1=sys_file_lock_write($h);
      if ($lock1){
	$line=str_replace("\\\"","\"",$line);
	$line=str_replace($specchar3,"",$line);
        fwrite($h, $line);
      }
      sys_file_unlock($fh);
      sys_file_close($fh);
    }
  }

// file nyitasa

  function sys_file_open($file,&$h,$mod){
    global $try_open;

    $f=0;
    while ((!$h=fopen($file,$mod))and($f<$try_open)){
      usleep(200);
      $f+=1;
    }
    if ($f<$try_open){
      $ok=true;
    }else{
      $ok=false;
    }
    return($ok);
  }

  // file zarasa

  function sys_file_close(&$h){
    if ($h){
      $x=fclose($h);
    }
  }

  // fajl unlock

  function sys_file_unlock(&$h){
    if ($h){
      if ($x=flock($h,LOCK_UN)){
        $file_lock=false;
      }
    }
  }

  // file nyitasa

  function sys_file_lock_write(&$h){
    global $try_open;

    $f=0;
    while ((!flock($h,LOCK_EX))and($f<$try_open)){
      usleep(200);
      $f+=1;
    }
    if ($f<$try_open){
      $ok=true;
    }else{
      $ok=false;
    }
    return($ok);
  }

  // file nyitasa

  function sys_file_lock_read(&$h){
    global $try_open;

    $f=0;
    while ((!flock($h,LOCK_SH))and($f<$try_open)){
      usleep(200);
      $f+=1;
    }
    if ($f<$try_open){
      $ok=true;
    }else{
      $ok=false;
    }
    return($ok);
  }

  // fajl torlese

  function sys_file_del($file){
    global $try_open;

    $ok=false;
    if (!is_dir($file)){
      if (file_exists($file)){
        $f=0;
        while ((!unlink($file))and($f<$try_open)){
          usleep(200);
          $f+=1;
        }
        if ($f<$try_open){
          $ok=true;
        }
      }else{
        $ok=true;
      }
    }else{
      $f=0;
      while (!(rmdir($file))and($f<$try_open)){
        usleep(200);
        $f+=1;
      }
      if ($f<$try_open){
        $ok=true;
      }
    }
    return($ok);
  }

  // fajl atnevezese

  function sys_file_rename($file,$file2){
    global $try_open;

    $ok=false;
    if (!is_dir($file)){
      if (file_exists($file)){
        $f=0;
        while ((!rename($file,$file2))and($f<$try_open)){
          usleep(200);
          $f+=1;
        }
        if ($f<$try_open){
          $ok=true;
        }
      }else{
        $ok=true;
      }
    }
    return($ok);
  }

  // fajl masolasa

  function sys_file_copy($file,$file2){
    global $try_open;

    $ok=false;
    if (!is_dir($file)){
      if (file_exists($file)){
        $f=0;
        while ((!copy($file,$file2))and($f<$try_open)){
          usleep(200);
          $f+=1;
        }
        if ($f<$try_open){
          $ok=true;
        }
      }else{
        $ok=true;
      }
    }
    return($ok);
  }

  // konyvtar letrehozasa

  function sys_mkdir($dir){
    global $try_open;

    if(!is_dir($dir)){
      $f=0;
      while (!mkdir($dir)and($f<$try_open)){
        usleep(200);
        $f+=1;
      }
    }
  }

  // konyvtar listazasa

  function sys_dir_list($dirn,&$t){
    global $try_open;

    if (is_dir($dirn)){
      $f=0;
      while (!($dir=opendir($dirn))and($f<$try_open)){
        usleep(200);
        $f+=1;
      }
      $db=0;
      if ($dir){
        while ($fn=readdir($dir)){
          if (($fn<>".")and($fn<>"..")){
	    $t[$db]=$fn;
	    $db+=1;
          }
        }
        if (($dir)and($x=closedir($dir))){
	}
      }
    }
  }

  // ures sorok kiuritese

  function sys_empty(&$t){
    $xx=count($t);
    if ($xx>0){
      $x=0;
      $y=0;
      $t2=array();
      while($x<$xx){
        if ($t[$x]<>""){
          $t2[$y]=$t[$x];
	  $y+=1;
        }
        $x+=1;
      }
      $t=$t2;
    }
  }

  // ures sorok kiuritese

  function sys_empty_db(&$t,&$db){
    $xx=$db;
    $x=0;
    $y=0;
    while($x<$xx){
      if ($t[$x]<>""){
        $t2[$y]=$t[$x];
	$y+=1;
      }
      $x+=1;
    }
    $t=$t2;
    $db=count($t);
  }

  // new line

  function sys_new_line(&$t){
    $x=0;
    $y=count($t);
    while ($x<$y){
      $c=0;
      $cc=strlen($t[$x]);
      while ($c<$cc){
        if (substr($t[$x],$c,1)=="\n"){
	  $t[$x]=substr($t[$x],0,$c-1)."<br />".substr($t[$x],$c+1,strlen($t[$x])-$c);
	}
        $c+=1;
      }
      $x+=1;
    }
  }

  // sor elejerol, vegerol szokoz leszedese

  function sys_nospace($l){
    $szokoz=" ";
    trim($l,$szokoz);
    return($l);
  }

  //  tombbol kivalaszt egy sort tobb metodus alapjan

  function sys_random_line($t,$method){
    $line="";
    switch ($method){
      case 0:
        $c=count($t);
	$s=rand(0,$c-1);
	$line=$s;
        break;
      case 1:
        $c=count($t);
	$s=date("s");
	$line=$t[$s];
        //$line="";
        break;
      default:
        $c=count($t);
	$s=rand(0,$c-1);
        $line=$t[$s];
        break;
    }
    return($line);
  }

  // unix ido

  function sys_unix_time(){
    $dt=date("U");
    return($dt);
  }

?>
