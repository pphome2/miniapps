<?php

  // w_robot --- PHP portalrobot
  // (verzioadatok a konfiguracios fajlban)
  //
  // fejleszto: Zebulon.hu Team



function site_page_sig($container){
  global $developer,$developer_email,$licence;

  //echo("<label class=label_sig></label>");
  //echo("</div>");
  echo("<div class='$container'>");
  echo("<label class='label_sig'>$licence</label>");
  echo("<label class='label_sig'><a class='href' href='mailto:$developer_email'>$developer_email</a></label>");
  echo("</div>");
}


function site_page_banner_hor($logo){
  global $default_site,$dir_img,$dir_site,
         $banners_h,$banners_h_link;

  $n=sys_random_line($banners_h,0);
  $k="$dir_site/$default_site/$dir_img/$banners_h[$n]";
  echo("<div class='$logo'>");
  echo("<a class='hrefclass' href='$banners_h_link[$n]'><img class='imgclass2' src='$k' alt='$k' /></a>");
  echo("</div>");
}


function site_page_banner_open($logo,$n,$link){
  global $default_site,$dir_img,$dir_site,$banners_h,
         $s_program,$sitepos,$default_site;

  $k="$dir_site/$default_site/$dir_img/$n";
  echo("<div class='$logo'>");
  if ($link==""){
    sys_env_new($sitepos,$default_site);
    $e=sys_env_pack();
    $link="$s_program?$e";
  }
  echo("<a class='hrefclass' href='$link'><img class='imgclass2' src='$k' alt='$k' /></a>");
  echo("</div>");
}


function site_page_banner_vert($logo){
  global $default_site,$dir_site,$dir_img,
         $banners_v,$banners_v_link;

  $n=sys_random_line($banners_v,0);
  $k="$dir_site/$default_site/$dir_img/$banners_v[$n]";
  echo("<div class='$logo'>");
  echo("<br /><br />");
  echo("<a class='hrefclass' href='$banners_v_link[$n]'><img class='imgclass2' src='$k' alt='$k' /></a>");
  echo("<br /><br /><br />");
  echo("</div>");
}


function site_page_menu_wiki($container){
  global $template_path,$dir_temp_img,
         $wiki_style;

  if ($wiki_style){
    echo("<div class='$container'>");
    site_page_menu();
    echo("</div>");
  }
}


function site_page_menu_admin($head,$block,$line){
  echo("<div class='$head'>");
  $ki=sys_line_local("Adminisztr�ci�");
  echo("<center><div class='$line'><b>$ki</b></div></center>");
  echo("<div class='$block'>");
  site_admin_menu();
  echo("</div>");
  echo("</div>");
}


function site_page_enter_user($head,$block,$line){
  echo("<div class='$head'>");
  $ki=sys_line_local("Bejelentkez�s");
  echo("<center><div class='$line'><b>$ki</b></div></center>");
  echo("<div class='$block'>");
  site_enter();
  echo("</div>");
  echo("</div>");
}



function site_page_search($head,$block,$line){
  echo("<div class='$head'>");
  $ki=sys_line_local("Keres�s");
  echo("<center><div class='$line'><b>$ki</b></div></center>");
  echo("<div class='$block'>");
  echo("<center>");
  site_find_local();
  echo("</center>");
  echo("</div>");
  echo("</div>");
}


function site_page_lang($head,$block,$line){
  global $language,$lang_desc,$lang_label,$s_program,
         $sitepos,$sitepage,$menupos,$dirpos,$messpage;

  echo("<div class='$head'>");
  $ki=sys_line_local("Nyelv v�lszt�s");
  echo("<center><div class='$line'><b>$ki</b></div></center>");
  echo("<div class='$block'>");
  $y=count($lang_desc);
  if ($y>0){
    $m=sys_env_find($sitepage);
    $m4=sys_env_find($sitepos);
    $m1=sys_env_find($menupos);
    $m2=sys_env_find($dirpos);
    $m3=sys_env_find($messpage);
    $l=sys_env_find($language);
    sys_env_del($sitepage);
    sys_env_del($sitepos);
    sys_env_del($menupos);
    sys_env_del($dirpos);
    sys_env_del($messpage);
    $x=0;
    echo("<ul class='ul_menu'>");
    while($x<$y){
      sys_env_new($language,$lang_label[$x]);
      $e=sys_env_pack();
      echo("<li class='li_me1'>");
      echo("<a href='$s_program?$e'>$lang_desc[$x]</a>");
      echo("</li>");
      $x+=1;
    }
    echo("</ul>");
    sys_env_new($sitepage,$m);
    sys_env_new($sitepos,$m4);
    sys_env_new($menupos,$m1);
    sys_env_new($dirpos,$m2);
    sys_env_new($messpage,$m3);
    sys_env_new($language,$l);
  }else{
    $ki=sys_line_local("Nincs v�laszthat� nyelv");
    echo("<label class='label_me1'>");
    echo("$ki.");
    echo("</label></>");
  }
  echo("</div>");
  echo("</div>");
}



function site_page_logo($block){
  global $default_site,$dir_site,$dir_img,$site_logo,
         $developer,$dev_logo;

  $k="$dir_site/$default_site/$dir_img/$site_logo";
  echo("<div class='$block'>");
  echo("<center><br />");
  echo("<img class='imgclass' src='$k' alt='$k' />");
  echo("<br />");
  if ($dev_logo<>""){
    $k="$dir_site/$default_site/$dir_img/$dev_logo";
    echo("<img class='imgclass' src='$k' alt='$k' />");
  }else{
    echo("<br />$developer");
  }
  echo("<br /></center>");
  echo("</div>");
}



function site_page_menu_local($head,$block){
  echo("<div class='$head'>");
  echo("<div class='$block'>");
  site_menu_local();
  echo("</div>");
  echo("</div>");
}



function site_page_menu_global($head,$block){
  echo("<div class='$head'>");
  echo("<div class='$block'>");
  site_menu_global();
  echo("</div>");
  echo("</div>");
}


function site_page_menu_privat($head,$block){
  echo("<div class='$head'>");
  echo("<div class='$block'>");
  site_menu_privat();
  echo("</div>");
  echo("</div>");
}



function site_page_menu_reg($head,$block,$line){
  echo("<div class='$head'>");
  $ki=sys_line_local("Bejelentkezve");
  echo("<center><div class='$line'><b>$ki</b></div></center>");
  echo("<div class='$block'>");
  site_reg_menu();
  echo("</div>");
  echo("</div>");
}


function site_page_menu_site($head,$block,$line){
  echo("<div class='$head'>");
  $ki=sys_line_local("Rendszer");
  echo("<center><div class='$line'><b>$ki</b></div></center>");
  echo("<div class='$block'>");
  site_page_menu();
  echo("</div>");
  echo("</div>");
}

?>
