<?php

function i_left_contact(){
  global $local_lang_labels;

  echo("<div class='menu_head'>");
  $ki=$local_lang_labels[0];
  echo("<center><div class='add_line'><b>$ki</b></div></center>");
  echo("<div class='menu_block'>");
  $ki=$local_lang_labels[1];
  echo("<a class='href' href='mailto:wswdteam@gmail.com'>$ki</a><br />");
  //echo("<br />");
  $ki=$local_lang_labels[2];
  echo("<a class='href' href='http://wswdteam.vacau.com'>$ki</a><br />");
  echo("</div>");
  echo("</div>");
}

?>
