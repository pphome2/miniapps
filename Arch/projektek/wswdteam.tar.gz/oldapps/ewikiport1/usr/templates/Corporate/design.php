<?php

  // w_robot --- PHP portalrobot
  // (verzioadatok a konfiguracios fajlban)
  //
  // fejleszto: Zebulon.hu Team


  // fej, menuoldal, jobboldal, kozepresz nyitas
  // itt lehet megv�ltoztatni a portal felepiteset


  function design(){
    global $template_path,$dir_temp_inc,$usercode,$user_admin,
           $wiki_style,$reg_menu_panel,$site_data_css_container,
	   $loc_menu_panel,$local_lang_labels;

    $local_lang_labels=array("El�rhet�s�geink","Kapcsolat","Weblapunk","Aj�nlott oldalak","Rekl�m");
    site_lang_move($local_lang_labels);

    $site_data_css_container="container";

    $iut="$template_path/$dir_temp_inc";

    echo("<div class='col_all'>");
    echo("</div>");
    echo("<div class='col_center'>");

    site_page_logo("logo");
    site_page_search("menu_head2","menu_block","add_line");
    site_page_menu_global("menu_head2","menu_block");
    site_page_enter_user("menu_head2","menu_block","add_line");

    echo("</div>");
    echo("<div class='col_left'>");

    site_page_banner_open("container2","c.jpg","");


    echo("<div class='container'>");

    // display page
  }


  // kozep zar, lab

  function design_end(){
    global $template_path,$dir_temp_inc,$usercode,$user_admin,
           $wiki_style,$reg_menu_panel,$site_data_css_container,
	   $loc_menu_panel;

    $site_data_css_container="container";

    $iut="$template_path/$dir_temp_inc";

    echo("</div>");

    echo("<div class='col_left2'>");
    sys_load_run("$iut/i_left_contact.php","i_left_contact");

    sys_load_run("$iut/i_left_adsense.php","i_left_adsense");

    echo("</div>");

    echo("<div class='col_center2'>");
    echo("</div>");

    echo("<div class='col_right2'>");
    sys_load_run("$iut/i_left_link.php","i_left_link");
    site_page_sig("container3");
  }


?>
