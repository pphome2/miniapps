<?php

function i_left_adsense(){
  global $site_adsense,$local_lang_label;

  echo("<div class='menu_head'>");
  $ki=$local_lang_label[4];
  echo("<center><div class='add_line'><b>Rekl�m</b></div></center>");
  echo("<div class='menu_block'><center>");

  echo($site_adsense[0]);

  echo("</center>");
  echo("</div>");
  echo("</div>");
}

?>
