<?php

function i_left_link(){
  global $local_lang_labels;

  echo("<div class='menu_head'>");
  $ki=$local_lang_labels[3];
  echo("<center><div class='add_line'><b>$ki</b></div></center>");
  echo("<div class='menu_block'>");
  echo("Debian GNU/Linux project<br />");
  echo("<a class='href' href='http://www.debian.org'>Debian weblap</a><br /><br />");
  echo("Lighttpd project<br />");
  echo("<a class='href' href='http://www.lighttpd.org'>Lighttpd weblap</a><br /><br />");
  echo("PHP project<br />");
  echo("<a class='href' href='http://www.php.net'>PHP weblap</a><br />");
  echo("</div>");
  echo("</div>");
}

?>
