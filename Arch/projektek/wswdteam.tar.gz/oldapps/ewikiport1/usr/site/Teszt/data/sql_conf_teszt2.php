<?php

  global $sql_table_f,$sql_table_t;
  
  $sql_table_f=array("nev",
                     "datum");
                     
  $sql_table_t=array("varchar (20)",
                     "varchar (20)");
?>
