<?php

// example --- site_home/data/dchoose.php file

  global $dc_choose_template,$dc_choose_template_desc;


  $dc_choose_template=array("Corporate",
                            "Default",
                            "EShop",
                            "Helpdesk",
                            "IME",
                            "IME2",
                            "IME3",
                            "Leltaar",
                            "WSWDTeam",
                            "WSWDTeam-1",
                            "WSWDTeam_hu");
                            
  $dc_choose_template_desc=array("IME  - le�r�sa.",
                                 "IME2 - le�r�sa.",
                                 "IME3 - le�r�sa.");  
                                 
                                 
  function dc_lang_init($sys_lang_label){
    global $dc_choose_template_desc;
    
    switch ($sys_lang_label){
      case "en":
        $dc_choose_template_desc=array("IME  - standard view..",
                                       "IME2 - grey view.",
                                       "IME3 - orange view.");  
        break;
      default:
        $dc_choose_template_desc=array("IME  - alap kin�zet.",
                                       "IME2 - sz�rke sz�n� kin�zet.",
                                       "IME3 - narancs sz�n� kin�zet.");  
        break;
    }
  }

?>
