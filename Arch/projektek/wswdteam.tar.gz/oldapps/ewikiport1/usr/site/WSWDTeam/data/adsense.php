<?php
global $site_adsense;

$site_adsense[0]='
<script type="text/javascript"><!--
google_ad_client = "pub-1145041375849096";
/* 120x240, l�trehozva 2009.03.11. */
google_ad_slot = "9782466081";
google_ad_width = 120;
google_ad_height = 240;
//-->
</script>
<script type="text/javascript"
src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script>
';

?>