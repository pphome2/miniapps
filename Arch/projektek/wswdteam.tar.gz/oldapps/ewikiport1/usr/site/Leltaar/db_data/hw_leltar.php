<?php

  global $db_table,$db_table_name,$db_table_len,
         $db_table_idx,$db_table_space,$db_table_funcs;

  // tabla neve
  $db_table="Hardver lelt�r";
  
  // mezonevek
  $db_table_name=array("G�pn�v, azonos�t�",
                       "Gy�rt�, t�pus",
                       "Processzor",
		       "Alaplap",
		       "Mem�ria",
		       "HDD",
		       "Optikai meghajt�",
		       "H�l�zat",
		       "Grafika, hang",
		       "Egy�b"
		       );

  // mezohosszak
  $db_table_len=array(100,
                      100,
		      100,
		      100,
		      100,
		      100,
                      100,
		      100,
		      100,
		      100
		      );

  //indexfajl tartalma
  $db_table_idx=array(0,1,2,3,4);
  
  // elvalaszto ures sor a mezo elott
  $db_table_space=array(1);
  
  // ellenorzo fuggvenyek, visszateres false, ha nem jo
  $db_table_funcs=array("db_noempty",
                        "db_noempty",
			"db_noempty",
			"",
			"",
			"",
			"",
			"",
			"",
			""
			);

?>
