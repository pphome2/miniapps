<?php

  global $db_table,$db_table_name,$db_table_len,
         $db_table_idx,$db_table_space,$db_table_funcs;

  // tabla neve
  $db_table="Szoftver lelt�r";
  
  // mezonevek
  $db_table_name=array("Szoftvercsomag",
                       "Oper�ci�s rendszer",
		       "Irodai csomag",
		       "Levelez� kliens",
		       "Internet b�ng�sz�",
		       "Egy�b 1",
		       "Egy�b 2",
		       "Egy�b 3",
		       "Egy�b 4",
		       "Egy�b 5"
		       );

  // mezohosszak
  $db_table_len=array(100,
                      100,
		      100,
		      100,
		      100,
		      100,
                      100,
		      100,
		      0,
		      0
		      );

  //indexfajl tartalma
  $db_table_idx=array(0,1,2,3,4);
  
  // elvalaszto ures sor a mezo elott
  $db_table_space=array(1);
  
  // ellenorzo fuggvenyek, visszateres false, ha nem jo
  $db_table_funcs=array("db_noempty",
                        "db_noempty",
			"db_noempty",
			"",
			"",
			"",
			"",
			"",
			"",
			""
			);

?>
