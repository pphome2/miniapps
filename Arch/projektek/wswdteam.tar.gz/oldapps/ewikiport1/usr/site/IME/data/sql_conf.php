<?php

  global $sql_driver,$sql_support_driver,$sql_show_error,
         $sql_name,$sql_server,$sql_user,$sql_pass,
         $sql_db,$sql_table,$sql_show_messages;
  
  $sql_driver=$sql_support_driver[0];
  
  $sql_show_error=true;
  $sql_show_messages=true;
  
  $sql_name="poker";
  
  $sql_server="localhost";
  $sql_user="root";
  $sql_pass="debianlinux";  
  $sql_db="ime";
  
  $sql_table=array("ime1","ime2");
?>
