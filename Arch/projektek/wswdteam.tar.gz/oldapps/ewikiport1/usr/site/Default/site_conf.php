<?php

  // user config file

  $developer="WSWDTeam";
  $developer_email="wswdteam@gmail.com";
  $licence="[-] 2008. WSWDTeam";

  $keyword="";
  $description="";

  $dev_logo="d_logo.png";
  $site_logo="s_logo.png";

  $site_title="EWikiPort";

  $default_template="Default";
  $first_page_template="";

  //site konyvtarak
  $dir_img="img";
  $dir_data="sitedata";
  $dir_files="files";
  $dir_ldata="data";
  $file_mess="$dir_ldata/messages.txt";
  $file_reg="$dir_ldata/users.txt";
  $file_mail="$dir_ldata/emails.txt";
  $file_meta="$dir_ldata/meta.txt";
  $file_adsense="$dir_ldata/adsense.php";
  $file_site_css="site.css";

  $file_template_css_page="design_page.css";
  $file_template_css="design_panel.css";
  $file_template_main="design.php";
  // include design() and design_end() function !!!!!

  // template dirs
  $dir_temp_inc="inc";
  $dir_temp_img="img";
  $dir_temp_txt="txt";

  $administrator="Admin";
  // username

  $hist_db=10;
  $max_message=200;
  $mess_per_page=10;

  $loc_menu_panel=true;
  $reg_menu_panel=false;
  $reg_menu_plus=array();
  $admin_menu_plus=array();

  $enable_new_reg=true;

  $wiki_style=true;
  $comment_all=true;
  $comment_1_page=true;
  $comment_rate=true;

  $enable_view=true;
  $enable_edit=false;
  $enable_reg_edit=false;
  $enable_history=true;
  $enable_print=true;
  $enable_dir=true;
  $enable_files=true;
  $enable_search=true;

  $enable_messagewall=true;
  $enable_newsletter=true;

  $banners_h=array("bh1.png");
  $banners_h_link=array("http://www.debian.org");
  $banners_v=array("bv1.gif");
  $banners_v_link=array("http://www.debian.org");

  $local_lang_labels=array();

  $site_adsense=array();

?>
