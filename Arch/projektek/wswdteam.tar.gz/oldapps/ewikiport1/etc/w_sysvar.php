<?php

  // w_robot --- PHP portalrobot
  // (verzioadatok a konfiguracios fajlban)
  //
  // fejleszto: Zebulon.hu Team


  $site_error_1="Hiba t�rt�nt.";
  $site_error_2="Hiba: a k�rt adatok nem el�rhet�ek. Ellen�rizze az URL-t.";

  // parameterek nevei

  $newdata="uj";
  $sitename="site";
  $sitepage="lap";
  $usercode="ureg";
  $sitepos="poz";
  $deldata="ddel";
  $menupos="menu";
  $messpage="mlap";
  $validpage="llap";
  $dirpos="dir";
  $language="l";

  $s_program="";
  $s_full_program="";
  $s_full_path="";

  $s_menu="-";
  $s_submenu="+";
  $s_plugin="=";
  $s_language="#";
  $s_nocomment="hozz�sz�l�s-";
  $s_comment="hozz�sz�l�s+";
  $s_commentrate="hozz�sz�l�s++";
  $s_link="link";
  $s_mail="lev�l";
  $s_img="img";
  $s_sys="sys";
  $s_cent="k�z�pre";
  $s_ecent="/k�z�pre";
  $s_nline="�j";
  $s_line="vonal";
  $s_h="c�m";
  $s_eh="/c�m";
  $s_bold="vastag";
  $s_ebold="/vastag";
  $s_ita="d�lt";
  $s_eita="/d�lt";
  $s_und="al�";
  $s_eund="/al�";
  $s_par="bekezd�s";
  $s_epar="/bekezd�s";
  $s_pos="u";
  $s_posp="up";
  $s_col="oszlop";
  $s_ecol1="/o";
  $s_ecol="/oszlop";
  $s_table="t�bl�zat";
  $s_etable="/t�bl�zat";
  $s_row="sor";
  $s_erow="/sor";
  $s_data="adat";
  $s_edata="/adat";

  $k_message="u";
  $k_enter="b";
  $k_regist="r";
  $k_edit="e";
  $k_privat="v";
  $k_mail="n";
  $k_history="t";
  $k_print="p";
  $k_dir="d";
  $k_admin_1="a1";
  $k_admin_2="a2";
  $k_admin_3="a3";
  $k_admin_4="a4";
  $k_admin_5="a5";
  $k_admin_6="a6";
  $k_files="f";
  $k_bigpic="bp";
  $k_search="s";

  $no_out_html=false;

  $lang_file="lang_";
  $lang_desc= array("Magyar","English");
  $lang_label=array("hu",    "en"   );
  $lang_system="";

  // rendszervaltozok
  $guest_user="Vend�g";
  $help_main_page="Seg�ts�g";
  $comment_ext="-comments";

  // rendszervaltozok - alapadatok beallitasa
  // nem valtoztathato !!!
  $reg_menu_ext="regisztr�lt";
  $local_menu_ext="helyi";
  $plugin_start=false;
  $printed=false;
  $editor=false;
  $choose_lang="";
  $write_out=true;
  $messaktpage=1;
  $pont=5;
  $validaktpage=1;
  $validpagedb=25;
  $l_open="[";
  $l_end="]";
  $separator="-";
  $sitedata=array("");
  $siteline=0;
  $regdata=array("");
  $regdb=0;
  $default_page="";
  $newmenu="";
  $delkod="";
  $dirdata="";
  $dataedit=false;
  $specchar="
";
  $specchar2="\n";
  $specchar3="\r";
  $site_adm=true;
  $site_system_error=false;
  $lockext="_lock";
  $site_data_css_container="";
  $try_open=100;
  $max_search=20;
  $user_admin=false;
  $tk=array("");
  $td=array("");
  $envdb=0;
  $env_plugin_name=array("");
  $env_plugin_data=array("");
  $env_plugin_db=20;
  $search_dir_name=array("");
  $search_dir=array("");
  $error_log_file="error.log";
  $error_all_mess=true;
  $fh="";
  $aktrow=1;
  $scree_width=0;
  $scree_height=0;
  $col_number=33;
  $open_page=false;
  $page_num_out=10;
  $page_div_close=false;
  $xmltype="";
  $doctype="<!DOCTYPE html PUBLIC '-//W3C//DTD XHTML 1.0 Transitional//EN' 'http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd'>";
  $htmlpar="xmlns='http://www.w3.org/1999/xhtml' xml:lang='en' lang='en'";
  $param_separator="&amp;";
  $list_pic=array(".jpg",".gif",".png");
  $char_old=array("�",   "�",  "�", "�",   "�",  "�", "�", "�", "�", " ","�",   "�",  "�", "�",   "�",  "�", "�", "�", "�", ":", ".");
  $char_new=array("oooo","ooo","oo","uuuu","uuu","uu","ee","aa","ii","_","OOOO","OOO","OO","UUUU","UUU","UU","EE","AA","II","---","--");

?>
