<?php

  // w_robot --- PHP portalrobot
  // (verzioadatok a konfiguracios fajlban)
  //
  // fejleszto: Zebulon.hu Team

  $s_dev_program="E-WikiPort";
  $s_dev_version="0.1.4";
  $s_dev_copyright="(-) 2008.";
  $s_dev_team="WSWDTeam";
  $s_dev_mail="wswdteam@gmail.com";
  $s_dev_web="wswdteam.extra.hu";

  $s_domain="";
  $s_c_code="";

  // rendszer-konyvtarak
  $dir_templates="usr/templates";
  $dir_plugins="sys/plugins";
  $dir_site="usr/site";
  $dir_system="sys";
  $dir_include="lib";
  $dir_bin="bin";
  $dir_lang="sys/lang";
  $dir_conf="etc";

  $file_sysvar="w_sysvar.php";

  $file_lib[0]="w_design.php";
  $file_lib[1]="w_display.php";
  $file_lib[2]="w_local.php";
  $file_lib[3]="w_system.php";
  $file_lib[4]="w_user.php";

  // site (konyvtar-) neve
  $default_site="Teszt";

  // plugins vezerlo
  $file_plugins="plugins.php";
  $file_system_css="w_site.css";

  // egyeb szukseges, site-specifikus beallitasok
  $file_user_config="site_conf.php";

?>
