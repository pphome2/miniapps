<?php

// oldal eloallitasa

class page {

  function message($mess){
    if ($mess<>""){
      echo("<br />");
      echo("<br />");
      echo("<div class='mess'>$mess</div>");
      echo("<br />");
      echo("<br />");
    }
  }


  function messageline($mess){
    if ($mess<>""){
      echo("<div class='mess'>$mess</div>");
    }
  }

}



class allpage extends page{

  function head(){
    echo("<html>");
    echo("<head>");
    echo("<meta http-equiv='content-type' content='application/xhtml+xml; charset=iso-8859-2' />");
    echo("<meta http-equiv='content-language' content='hu' />");
    echo("<meta http-equiv='content-style-type' content='text/css' />");
    echo("<title>�zen�fal</title>");
  }


  function body($add){
    echo("<body>");
    echo("<link href='./inc/css.css' rel='stylesheet' type='text/css'>");
    echo("<script type='text/javascript' language='JavaScript' src='./inc/java.js'></script>");
    $this->headaddress($add);
  }

  function headaddress($add){
    echo("<div class='cim'>$add</div>");
    echo("<br /><br />");
  }

  function foot(){
    echo("</body>");
    echo("</html>");
  }

}


class messpage extends allpage{

  function dataget($data,$new,$uname,$uid,$db,$admin,$db2){
    if (count($data)==0){
      $data=array("","","","","","");
    }else{
    }
    echo("<a class='href' href='./index.php'>Kijelentkez�s</a><br />");
    if ($admin){
      echo("<a class='href' href='./index.php?p=$db2&uid=$uid'>Felhaszn�l�k</a>");
    }
    $readonly="";
    if (!$new){
      $readonly=" readonly ";
      echo("<a class='href' href='./index.php?p=$db&uid=$uid'>�j �zenet</a>");
    }
    if ($uname<>""){
      $data[1]=$uname;
      $readonly=" readonly ";
    }
    echo("<br />");
    echo("<br />");
    echo("<center>");
    echo("<form name='form1' id='form1' method='post' action='./index.php?p=$db&uid=$uid'>");
    echo("<input class='input_r1' name='d0' id='d0' type='hidden' value='$data[0]'/><br />");
    echo("<div class='div_r1'>N�v</div>");
    echo("<input class='input_r1' name='d1' id='d1' type='text' value='$data[1]' $readonly /><br />");
    echo("<div class='div_r1'>�zenet</div>");
    echo("<textarea class='text' name='d2' id='d2' />$data[2]</textarea><br />");
    echo("<br />");
    echo("<button type='submit' name='b' id='b' >Mehet</button>");
    echo("</form>");
    echo("<div class='error' id='checkresult'></div>");
    echo("<br />");
    echo("<br />");
    echo("</center>");
  }


  function table($alldata,$admin,$uid,$db){
    echo("<div class='table1'>ID</div>");
    echo("<div class='table2'>N�v</div>");
    echo("<div class='table3'>�zenet</div>");
    echo("<br />");
    foreach ($alldata as $one){
      echo("<dic class='trow'>");
      echo("<div class='table1'>$one[0]");
      if ($admin){
        echo("<a class='href' href='./index.php?p=$db&f=torol&uid=$uid&id=$one[0]'>T�r�l</a>");
      }
      if ($admin){
        echo("<a class='href' href='./index.php?p=$db&f=javit&uid=$uid&id=$one[0]'>Jav�t</a>");
      }
      echo("</div>");
      echo("<div class='table2'>$one[1]</div>");
      echo("<div class='table3'>$one[2]</div>");
      echo("</div>");
      echo("<br />");
    }
  }

}


class userpage extends allpage{

  function dataget($data,$new,$uid,$db){
    if (count($data)==0){
      $data=array("","","","","","","","");
    }else{
    }
    echo("<a class='href' href='./index.php'>Kijelentkez�s</a><br />");
    $readonly="";
    if ($new){
      echo("<form name='form1' id='form1' method='post' action='./index.php?p=$db&uid=$uid' onsubmit='return checkuser()'>");
    }else{
      echo("<a class='href' href='./index.php?p=mess&uid=$uid'>�zen�fal</a><br />");
      echo("<form name='form1' id='form1' method='post' action='./index.php?p=$db&uid=$uid'>");
      $readonly=" readonly ";
    }
    echo("<a class='href' href='./index.php'>�j felhaszn�l�</a>");
    echo("<br />");
    echo("<br />");
    echo("<center>");
    echo("<input class='input_r1' name='d0' id='d0'type='hidden' value='$data[0]'/><br />");
    echo("<div class='div_r1'>N�v</div>");
    echo("<input class='input_r1' name='d1' id='d1'type='text' value='$data[1]' $readonly /><br />");
    echo("<div class='div_r1'>Jelsz�</div>");
    echo("<input class='input_r1' name='d2' id='d2'type='text' value='$data[2]' /><br />");
    echo("<div class='div_r1'>Lakc�m</div>");
    echo("<input class='input_r1' name='d3' id='d3'type='text' value='$data[3]' /><br />");
    echo("<div class='div_r1'>E-mail</div>");
    echo("<input class='input_r1' name='d4' id='d4'type='text' value='$data[4]' /><br />");
    echo("<input class='input_r1' name='d5' id='d5'type='hidden' value='$data[5]' />");
    echo("<input class='input_r1' name='d6' id='d6'type='hidden' value='$data[6]' />");
    echo("<div class='div_r1'>Avatar</div>");
    echo("<input class='input_r1' name='d7' id='d7'type='text' value='$data[7]' /><br />");
    echo("<br />");
    echo("<button type='submit' name='b' id='b' >Mehet</button>");
    echo("</form>");
    echo("<div class='error' id='checkresult'></div>");
    echo("<br />");
    echo("<br />");
    echo("</center>");
  }


  function table($alldata,$admin,$uid,$db){
    echo("<div class='table1'>ID</div>");
    echo("<div class='table2'>N�v</div>");
    echo("<div class='table3'>E-mail</div>");
    echo("<br />");
    foreach ($alldata as $one){
      echo("<dic class='trow'>");
      echo("<div class='table1'>$one[0]");
      if ($admin){
        echo("<a class='href' href='./index.php?p=$db&f=torol&uid=$uid&id=$one[0]'>T�r�l</a>");
      }
      if ($admin){
        echo("<a class='href' href='./index.php?p=$db&f=javit&uid=$uid&id=$one[0]'>Jav�t</a>");
      }
      echo("</div>");
      echo("<div class='table2'>$one[1]</div>");
      echo("<div class='table3'><a href='mailto:$one[4]'>$one[4]</a></div>");
      echo("</div>");
      echo("<br />");
    }
  }

}


class loginpage extends allpage{

  function dataget($db){
    echo("<br />");
    echo("<br />");
    echo("<center>");
    echo("<form name='form1' id='form1' method='post' action='./index.php'>");
    echo("<div class='div_r1'>N�v</div>");
    echo("<input class='input_r1' name='d1' id='d1'type='text' value='' /><br />");
    echo("<div class='div_r1'>Jelsz�</div>");
    echo("<input class='input_r1' name='d2' id='d2'type='text' value='' /><br />");
    echo("<br />");
    echo("<button type='submit' name='b' id='b' >Mehet</button>");
    echo("</form>");
    echo("<div class='error' id='checkresult'></div>");
    echo("<br />");
    echo("<br />");
    echo("</center>");
    echo("<br />");
    echo("<br />");
    echo("<a class='href' href='./index.php?p=$db'>Regisztr�ci�</a>");
  }

}


?>
