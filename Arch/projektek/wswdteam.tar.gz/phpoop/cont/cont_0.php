<?php

// vezerloterem

class operator {
  private $dte=array(),
          $dtk=array(),
          $dbfunc="",
          $func="",
          $func_del="torol",
          $func_mod="javit",
          $mess_table="xmess",
          $user_table="xuser",
          $admin_user="admin",
          $admin=false,
          $uid="",
          $uname="",
          $id="";

  function __construct($db="",$user="",$pass="",$server=""){

    $this->mainpage=new allpage();
    $this->mainpage->head();

    $this->getdata();
    $x=count($this->dtk);
    while ($x>=0){
      $x--;
      switch ($this->dtk[$x]){
        case "p":
          $this->dbfunc=$this->dte[$x];
          break;
        case "f":
          $this->func=$this->dte[$x];
          break;
        case "id":
          $this->id=$this->dte[$x];
          break;
        case "uid":
          $this->uid=$this->dte[$x];
          break;
      }
    }
    $this->dbaseuser=new dbmodeluser($db,$user,$pass,$server,$this->user_table);
    $this->dbasemess=new dbmodelmess($db,$user,$pass,$server,$this->mess_table);

    $this->postdata();

    if ($this->uid<>""){
      $ad=$this->dbaseuser->getone($this->uid);
      if ($ad[1]<>""){
        $this->uname=$ad[1];
        if ($this->admin_user==$this->uname){
          $this->admin=true;
        }
      }
    }

    switch ($this->dbfunc){
      case $this->mess_table:
        $this->mainpage->body("�zen�fal");
        $this->mepage=new messpage();
        $newdata=true;
        switch ($this->func){
          case $this->func_del:
            $this->dbasemess->del($this->id);
            $this->mepage->message("ID: $id t�r�lve.");
            break;
          case $this->func_mod:
            $oned=$this->getonedata($this->id);
            $newdata=false;
            break;
          default:
            break;
        }
        $this->mepage->dataget($oned,$newdata,$this->uname,$this->uid,$this->dbfunc,$this->admin,$this->user_table);
        $alld=$this->getalldata();
        $this->mepage->table($alld,$this->admin,$this->uid,$this->dbfunc);
        break;
      case $this->user_table:
        $this->mainpage->body("Regisztr�ci�");
        $this->uspage=new userpage();
        $newdata=true;
        switch ($this->func){
          case $this->func_del:
            $this->dbaseuser->del($this->id);
            $this->uspage->message("ID: $id t�r�lve.");
            break;
          case $this->func_mod:
            $oned=$this->getonedata($this->id);
            $newdata=false;
            break;
          default:
            break;
        }
        $this->uspage->dataget($oned,$newdata,$this->uid,$this->dbfunc);
        $alld=$this->getalldata();
        $this->uspage->table($alld,$this->admin,$this->uid,$this->dbfunc);
        break;
      default:
        $this->mainpage->body("Bejelentkez�s");
        $this->lopage=new loginpage();
        $this->lopage->dataget($this->user_table);
        break;
    }

    $this->mainpage->foot();

  }

  function postdata(){
    $db=0;
    foreach ($_POST as $key=>$data) {
      $dtk[$db]=$key;
      $dte[$db]=$data;
      //echo("$key-$data<br/>");
      $db+=1;
    }
    switch ($this->dbfunc){
      case $this->mess_table:
        if (($db>2)and($dte[1]<>"")and($dte[2]<>"")){
          $this->mainpage->message("�j/jav�tott �zenet t�rolva.");
          $this->dbasemess->add($dte[0],$dte[1],$dte[2]);
        }else{
          if ($db>4){
            $this->mainpage->message("Hi�nyos az adatok kit�lt�se.");
          }
        }
        break;
      case $this->user_table:
        if (($db>4)and($dte[1]<>"")and($dte[2]<>"")){
          $this->mainpage->message("�j/jav�tott felhaszn�l� t�rolva.");
          $this->dbaseuser->add($dte[0],$dte[1],$dte[2],$dte[3],$dte[4],$dte[5],$dte[6],$dte[7]);
        }else{
          if ($db>4){
            $this->mainpage->message("Hi�nyos az adatok kit�lt�se.");
          }
        }
        break;
      default:
        if (($dte[0]<>"")and($dte[1]<>"")){
          $ad=$this->dbaseuser->getuserone($dte[0]);
          if (($dte[0]==$ad[1])and($dte[1]==$ad[2])){
            $this->dbfunc=$this->mess_table;
            $this->uid=$ad[0];
            $this->uname=$ad[1];
          }else{
            $this->mainpage->message("Felhaszn�l�i fi�k nem el�rhet�.");
          }
        }else{
          //$this->mainpage->message("Hi�nyos az adatok kit�lt�se.");
        }
        break;
    }
  }


  function getdata(){
    $db=0;
    foreach ($_GET as $key=>$data) {
      $this->dtk[$db]=$key;
      $this->dte[$db]=$data;
      //echo("$key-$data<br/>");
      $db++;
    }
    return($dte[0]);
  }

  function getalldata(){
    if ($this->dbfunc==$this->mess_table){
      $ad=$this->dbasemess->getall();
    }else{
      $ad=$this->dbaseuser->getall();
    }
    return($ad);
  }

  function getonedata($key){
    if ($this->dbfunc==$this->mess_table){
      $ad=$this->dbasemess->getone($key);
    }else{
      $ad=$this->dbaseuser->getone($key);
    }
    return($ad);
  }

}






class checkoperator {
  private $docpage,$dbase;

  function __construct($db="",$user="",$pass="",$server="",$table=""){
    $this->dbase=new dbmodeluser($db,$user,$pass,$server,$table);
    $this->docpage=new page();
    $d=$this->postdata();
    $mess=$this->usercheck($d);
    $this->docpage->messageline($mess);
  }


  function postdata(){
    $db=0;
    foreach ($_POST as $key=>$data) {
      $dtk[$db]=$key;
      $dte[$db]=$data;
      //echo("$key-$data<br/>");
      $db+=1;
    }
    $d="";
    if ($db>0){
      $d=$dte[0];
    }
    return($d);
  }

  function usercheck($user){
    $van=$this->dbase->getoneuser($user);
    if ($van){
      $mess="Felhaszn�l�i n�v foglalt.";
    }else{
      $mess="";
    }
    return($mess);
  }

}


?>
