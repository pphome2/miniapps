<?php

// kapcsolat az adatbazissal


class dbmodel {
  public $mydb,$table;

  function __construct($db="",$user="",$pass="",$server="",$table=""){
    $this->mydb=new mysql($db,$user,$pass,$server);
    $this->table=$table;
    $sqlline="create table if not exists ".$this->table." (id varchar(20), nev varchar(100), mess text );";
    $this->mydb->run($sqlline);
  }


  function add($id,$e1,$e2){
    if (($e1<>"")and($e2<>"")){
      if (strlen($id)<4){
        $dt=microtime();
        $t=explode(" ",$dt);
        $id=$t[1].substr($t[0],2,strlen($t[0]));
        $sqlline="insert into ".$this->table." values ('".$id."','".$e1."','".$e2."') ;";
      }else{
        $sqlline="update ".$this->table." set nev='".$e1."', mess='".$e2."' where id='".$id."' ;";
      }
      //echo($sqlline);
      $this->mydb->run($sqlline);
    }
  }


  function del($e1){
    if ($e1<>""){
      $sqlline="delete from ".$this->table." where id=$e1 ;";
      $this->mydb->run($sqlline);
    }
  }

  function getall(){
    $ad=array();
    $sqlline="select * from ".$this->table.";";
    $to=$this->mydb->run($sqlline);
    $db=$this->mydb->resdb($to);
    $x=0;
    while($x<$db){
      $ad[$x]=$this->mydb->getresdata($to,$x);
      $x++;
    }
    return($ad);
  }


  function getone($key){
    $ad=array();
    $sqlline="select * from ".$this->table." where id=$key;";
    $to=$this->mydb->run($sqlline);
    $db=$this->mydb->resdb($to);
    if ($db>0){
      $ad=$this->mydb->getresdata($to,0);
    }
    return($ad);
  }

}



class dbmodelmess extends dbmodel{

}




class dbmodeluser extends dbmodel{

  function __construct($db="",$user="",$pass="",$server="",$table=""){
    $this->table=$table;
    $this->mydb=new mysql($db,$user,$pass,$server);
    $sqlline="create table if not exists ".$this->table." (id varchar(20), nev varchar(100), jelszo varchar(100), cim varchar(100), email varchar(100) ,admin int(1), aktiv int(1), avatar varchar(100) );";
    $this->mydb->run($sqlline);
    $ad=$this->getoneuser("admin");
    if (!$ad){
      $this->add("0","admin","admin","Lakc�m","emailc�m",1,1,"avatar");
    }
  }


  function add($id,$e1,$e2,$e3,$e4,$e5,$e6,$e7){
    if (($e1<>"")and($e2<>"")){
      if (strlen($id)<4){
        $dt=microtime();
        $t=explode(" ",$dt);
        $id=$t[1].substr($t[0],2,strlen($t[0]));
        $sqlline="insert into ".$this->table." values ('".$id."','".$e1."','".$e2."','".$e3."','".$e4."',0,0,'".$e7."') ;";
      }else{
        $sqlline="update ".$this->table." set nev='".$e1."', jelszo='".$e2."', cim='".$e3."', email='".$e4."', avatar='".$e7."' where id='".$id."' ;";
      }
      //echo($sqlline);
      $this->mydb->run($sqlline);
    }
  }

  function getuserone($key){
    $ad=array();
    $sqlline="select * from ".$this->table." where nev='".$key."';";
    $to=$this->mydb->run($sqlline);
    $db=$this->mydb->resdb($to);
    if ($db>0){
      $ad=$this->mydb->getresdata($to,0);
    }
    return($ad);
  }

  function getoneuser($key){
    $ok=false;
    $sqlline="select * from ".$this->table." where nev='".$key."';";
    $to=$this->mydb->run($sqlline);
    $db=$this->mydb->resdb($to);
    if ($db>0){
      $ok=true;
    }
    return($ok);
  }

}

?>
