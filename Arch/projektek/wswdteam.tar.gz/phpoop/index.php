<?php

// start

  include("cont/cont_0.php");
  include("model/mod_0.php");
  include("view/view_0.php");
  include("obj/obj_mysql.php");

  $thisdoc=new operator("teszt","root","debianlinux","localhost");
  //$thisdoc=new operator("teszt","test11","yhAv1Lt3F","localhost");

?>