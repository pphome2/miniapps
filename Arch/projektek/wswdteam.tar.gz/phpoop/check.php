<?php
header("Content-Type: text/html; charset=iso-8859-2");

// start

  include("cont/cont_0.php");
  include("model/mod_0.php");
  include("view/view_0.php");
  include("obj/obj_mysql.php");

  $thisdoc=new checkoperator("teszt","root","debianlinux","localhost","xuser");
  //$thisdoc=new operator("teszt","test11","yhAv1Lt3F","localhost");");

?>