//alert("H");



var xmlHttp=null;

function ajaxopen(){
  try{          // Firefox, Opera 8.0+, Safari
    xmlHttp=new XMLHttpRequest();
  }
  catch (e){    // Internet Explorer
    try{
      xmlHttp=new ActiveXObject("Msxml2.XMLHTTP");
    }
    catch (e){
      xmlHttp=new ActiveXObject("Microsoft.XMLHTTP");
    }
  }
}

function kiir(){
  ok=false;
  if (xmlHttp.readyState==4){
    if (xmlHttp.responseText==""){
      ok=true;
      document.getElementById("checkresult").innerHTML='ok';
    }else{
      document.getElementById("checkresult").innerHTML=xmlHttp.responseText;
    }
  }
  return ok;
}

function checkuser(){
  okx=false;
  vig=document.form1.d1.value;
  ajaxopen();
  if (xmlHttp==null){
    alert("AJAX hiba.");
  }else{
    var url="check.php";
    xmlHttp.onreadystatechange=function(){
      okx=kiir();
    };
    xmlHttp.open("POST",url,false);
    xmlHttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    xmlHttp.send('x='+encodeURIComponent(vig));
  }
  return okx;
}
