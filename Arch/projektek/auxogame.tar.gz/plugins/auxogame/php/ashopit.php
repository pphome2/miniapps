<?php

 #
 # Auxogame
 #
 # info: main folder copyright file
 #
 #




function shop_item_edit(){
	global $ADIR_SHOP,$ADIR_FILENAME,$A_VALUTA;

	$itemdata=array("","","","","","","","","","","","","","","","");
	$pos=get_sublink("pos");
	if ($pos<>""){
		$f=$pos."/".$ADIR_FILENAME;
		if (file_exists($f)){
			$t=file_get_contents($f);
			$itemdata=json_decode($t,true);
		}
	}
	$question=FALSE;
	$gomb=get_postdata("gomb");
	switch ($gomb){
		case "Fájl törlése":
			$question=TRUE;
			$dir=get_postdata("item1");
			$dir=name_to_dir($dir);
			$item=get_postdata("item0");
			$file=get_postdata("item9");
			$file=dir_to_name($file);
			$dir2=$dir."/".$item;
			$dir2=name_to_dir($dir2);
			$file2=$ADIR_SHOP."/".$dir."/".$item."/".$file;
			$file2=name_to_dir($file2);
			auxo_message_q("Valóban töröljük a fájlt?",$dir2,$file2);
			break;
		case "Új fájl feltöltése":
			$dir=get_postdata("item1");
			$dir=name_to_dir($dir);
			$item=get_postdata("item0");
			$file=basename($_FILES["item10"]["name"]);
			$fdir=$ADIR_SHOP."/".$dir."/".$item;
			$fdir=name_to_dir($fdir);
			$file2=$ADIR_SHOP."/".$dir."/".$item."/".$ADIR_FILENAME;
			$file2=name_to_dir($file2);
			$t=file_get_contents($file2);
			$itemdata=json_decode($t,true);
			if (post_upload_file($fdir,"item10","gomb")){
				auxo_message2($file2,"Fájl feltöltése sikerült.");
			}else{
				auxo_message2($file2,"Hiba a feltöltés közben. (Fájl túl nagy vagy már létezik.)");
			}
			break;
		case "Kép cseréje":
			$dir=get_postdata("item1");
			$dir=name_to_dir($dir);
			$item=get_postdata("item0");
			$file2=$ADIR_SHOP."/".$dir."/".$item."/".$ADIR_FILENAME;
			$file2=name_to_dir($file2);
			$t=file_get_contents($file2);
			$itemdata=json_decode($t,true);
			$oldimg=get_postdata("itemimg");
			$o=get_postdata("gomb");
			if ($oldimg<>""){
				$fdir=$ADIR_SHOP."/".$dir."/".$item;
				$fdir=name_to_dir($fdir);
				if (post_upload_image($fdir,"item7","gomb","")){
					auxo_message2($file2,"Kép cseréje sikerült.");
					if (!unlink($oldimg)){
						auxo_message2($file2,"Régi kép törlése nem sikerült.");
					}
				}else{
					auxo_message2($file2,"Hiba a feltöltés közben. (Kép túl nagy, létezik vagy nem kép.)");
				}
			}
			break;
		case "Kép törlése":
			$question=TRUE;
			$data1=get_postdata("item0");
			$data2=get_postdata("item1");
			$data2=name_to_dir($data2);
			$file=get_postdata("itemimg");
			$data1=$data2."/".$data1;
			auxo_message_q("Valóban töröljük a képet?",$data1,$file);
			break;
		case "Új kép feltöltése":
			$dir=get_postdata("item1");
			$dir=name_to_dir($dir);
			$item=get_postdata("item0");
			$file=basename($_FILES["item8"]["name"]);
			$fdir=$ADIR_SHOP."/".$dir."/".$item;
			$fdir=name_to_dir($fdir);
			$file2=$ADIR_SHOP."/".$dir."/".$item."/".$ADIR_FILENAME;
			$file2=name_to_dir($file2);
			$t=file_get_contents($file2);
			$itemdata=json_decode($t,true);
			if (post_upload_image($fdir,"item8","gomb","")){
				auxo_message2($file2,"Kép feltöltése sikerült.");
			}else{
				auxo_message2($file2,"Hiba a feltöltés közben. (Kép túl nagy, nem létezik vagy nem kép.)");
			}
			break;
		case "Elem törlése":
			$question=TRUE;
			$data1=get_postdata("item0");
			$data2=get_postdata("item1");
			$data2=name_to_dir($data2);
			$data1=$data2."/".$data1;
			$data1=name_to_dir($data1);
			auxo_message_q("Valóban töröljük az elemet? ($data1)",$data1,"");
			break;
		case "Mentés":
			$file=shop_get_item();
			$t=file_get_contents($file);
			$itemdata=json_decode($t,true);
			auxo_message2($file,"A mentés sikerült.");
			break;
		case "Igen":
			$data1=get_postdata("code");
			$datax=get_postdata("code2");
			$data2=$ADIR_SHOP."/".$data1;
			$data2=name_to_dir($data2);
			if ($datax<>""){ 							# fájl törlés
				$file2=$data2."/".$ADIR_FILENAME;
				$t=file_get_contents($file2);
				$itemdata=json_decode($t,true);
				$file=$datax;
				if ($file<>""){
					$kit=substr($file,strlen($file)-3,3);
					$img=array("png","jpg","jpeg","gif");
					if (in_array($kit,$img)){			# kép
						if (unlink($file)){
							auxo_message2($file2,"Kép törlése sikerült.");
						}else{
							auxo_message2($file2,"Hiba a kép törlése közben.");
						}
					}else{
						if (unlink($file)){				# fájl
							auxo_message2($file2,"Fájl törlése sikerült.");
						}else{
							auxo_message2($file2,"Hiba a fájl törlése közben.");
						}
					}
				}
			}else{
				if ($data1<>""){						# teljes elem törlése
					$cd=name_to_dir($data2);
					$cdir=scandir($cd);
					$db=count($cdir);
					for($i=0;$i<$db;$i++){
						if (substr($cdir[$i],0,1)<>"."){
							$del=$ADIR_SHOP."/".$data1."/".$cdir[$i];
							$del=name_to_dir($del);
							unlink($del);
						}
					}
					rmdir($cd);
					$itemdata=array("","","","","","","","","","","","","","","","");
					auxo_message("Elem törölve. ($data1)");
				}else{
					auxo_message("Nincs megadva minden adat.");
				}
			}
			break;
		case "Tovább":
			$file=get_postdata("code");
			$t=file_get_contents($file);
			$itemdata=json_decode($t,true);
			break;
		case "Nem":
			$file=get_postdata("code");
			$file=$ADIR_SHOP."/".$file."/".$ADIR_FILENAME;
			$file=name_to_dir($file);
			$t=file_get_contents($file);
			$itemdata=json_decode($t,true);
			break;
		case "Rendben":
			$itemdata=array("","","","","","","","","","","","","","","","");
			break;
		default:
			$file=$pos."/".$ADIR_FILENAME;
			if (file_exists($file)){
				$t=file_get_contents($file);
				$itemdata=json_decode($t,true);
			}
			break;
	}

	if (!$question){
		echo("<br /><br />");
		if ($itemdata[0]==""){
			$itemdata[0]="Új elem";
			$line="Új elem létrehozása.";
		}else{
			$line="<b>$itemdata[0]</b> elem szerkesztése.";
		}
		echo("<fieldset name=d id=d style=\"display:snone;text-align:left;\"><legend><b>Termék szerkesztése</b></legend><br />");
		echo("<br />$line");
		echo("<br /><br /><br />");
		echo("<center>");
		echo("<table style=\"width:80%;margin-left:10%;\" >");
		echo("<form action=\"\" method=\"post\" enctype=\"multipart/form-data\">");
		echo("<input type=\"hidden\" name=\"item001\" id=\"item001\" value=\"$itemdata[1]\" style=\"width:300px;\">	");
		$cdir=scandir($ADIR_SHOP);
		echo("<tr><td width=20%>");
		echo("Név:");
		echo("</td><td>");
		echo("<input type=\"text\" name=\"item0\" id=\"item0\" value=\"$itemdata[0]\" style=\"width:300px;\">	");
		echo("</td></tr><tr><td>");
		echo("Kategória:");
		echo("</td><td>");
		echo("<select name=item1 id=item1 style=\"width:300px;\">");
		$db=count($cdir);
		if ($db>1){
			for($i=0;$i<$db;$i++){
				if (substr($cdir[$i],0,1)<>"."){
					$v=name_to_dir($cdir[$i]);
					$v2=dir_to_name($cdir[$i]);
					if ($cdir[$i]==$itemdata[1]){
						echo("<option value=$v selected>$v2</option>");
					}else{
						echo("<option value=$v>$v2</option>");
					}
				}
			}
		}
		echo("</select> ");
		echo("</td></tr><tr><td>");
		echo("Rövid leírás:");
		echo("</td><td>");
		echo("<textarea name=\"item2\" rows=\"4\" cols=\"70\" maxlenght=200>");
		echo("$itemdata[2]</textarea>");
		echo("</td></tr><tr><td>");
		echo("Részletek:");
		echo("</td><td>");
		echo("<textarea name=\"item3\" rows=\"4\" cols=\"70\" maxlenght=200>");
		echo("$itemdata[3]</textarea>");
		echo("</td></tr><tr><td>");
		echo("Ár: ($A_VALUTA)");
		echo("</td><td>");
		echo("<input type=\"text\" name=\"item4\" id=\"item4\" value=\"$itemdata[4]\" style=\"width:100px;\">	");
		echo("</td></tr><tr><td>");
		echo("Akciós ár: ($A_VALUTA)");
		echo("</td><td>");
		echo("<input type=\"text\" name=\"item5\" id=\"item5\" value=\"$itemdata[5]\" style=\"width:100px;\">	");
		echo("</td></tr><tr><td>");
		echo("Elérhető:");
		echo("</td><td>");
		if ($itemdata[6]<>""){
			$checked="checked";
		}else{
			$checked="";
		}
		echo("<input type=\"checkbox\" name=\"item6\" value=\"Elérhető\" $checked>");
		echo("<br />");
		echo("</td></tr><tr><td valign=top>");

		if (($itemdata[0]=="")or($itemdata[1]=="")){
			echo("</td><td>");
			echo("<br />Képek és fájlok kezelése az adatok mentése után lehetséges.");
			echo("</td><td>");
		}else{
			echo("Képek:");
			echo("</td><td>");
			echo("<table>");
			$cd=name_to_dir($ADIR_SHOP."/".$itemdata[1]."/".$itemdata[0]);
			$cdir=scandir($cd);
			$db=count($cdir);
			echo("<input type=hidden id=itemimg name=itemimg value=\"\">");
			echo("<input id=\"imchubmit\" type=\"submit\" name=\"gomb\" value=\"Kép cseréje\" style=\"width:200px;display:none;\">");
			echo("<input id=\"delsubmit\" type=\"submit\" name=\"gomb\" value=\"Kép törlése\" style=\"width:200px;display:none;\">");
			echo("<input type=\"file\" id=\"submitim\" name=\"item7\"  style=\"width:200px;display:none;\" onchange=\"document.getElementById('imchubmit').click()\">");
			for($i=0;$i<$db;$i++){
				if ((substr($cdir[$i],0,1)<>".")and($cdir[$i]<>$ADIR_FILENAME)){
					$fn=name_to_dir($cdir[$i]);
					$kit=substr($fn,strlen($fn)-3,3);
					$img=array("png","jpg","jpeg","gif");
					if (in_array($kit,$img)){
						$imgn=$ADIR_SHOP."/".$itemdata[1]."/".$itemdata[0]."/".$fn;
						$imgn=name_to_dir($imgn);
						echo("<tr><td>");
						echo("<img src=\"$imgn\" width=100px height=100px>");
						echo("</td><td>");
						echo("<input type=button id=submit name=\"$imgn\" value=\"Kép cseréje\" style=\"width:200px;\" onclick=\"document.getElementById('itemimg').value=this.name;document.getElementById('submitim').click();return false;\">");
						echo("<br /><br />");
						echo("<input type=button id=submit name=\"$imgn\" value=\"Kép törlése\" style=\"width:200px;\" onclick=\"document.getElementById('itemimg').value=this.name;document.getElementById('delsubmit').click();return false;\">");
						#echo("<button id=submit name=imgdel value=$imgn style=\"width:200px;\" >Kép törlése</button>");
						echo("<br /><br />");
						echo("</td></tr>");
					}
				}
			}
			echo("</table>");
			echo("<br />");
			echo("<input id=\"isubmit\" type=\"submit\" name=\"gomb\" value=\"Új kép feltöltése\" style=\"width:200px;display:none;\">");
			echo("<input type=\"file\" id=\"submitimage\" name=\"item8\"  style=\"width:200px;display:none;\" onchange=\"document.getElementById('isubmit').click()\">");
			echo("<input type=button id=submit name=submit value=\"Új kép feltöltése\" style=\"width:200px;\" onclick=\"document.getElementById('submitimage').click();return false;\">");
			echo("<br />");
			echo("<br />");
			echo("</td></tr>");

			echo("</td></tr><tr><td valign=top>");
			echo("Fájlok:");
			echo("</td><td>");
			echo("<select name=item9 id=item9 style=\"width:250px;\">");
			$cd=name_to_dir($ADIR_SHOP."/".$itemdata[1]."/".$itemdata[0]);
			$cdir=scandir($cd);
			$db=count($cdir);
			if ($i>0){
				for($i=0;$i<$db;$i++){
					if ((substr($cdir[$i],0,1)<>".")and($cdir[$i]<>$ADIR_FILENAME)){
						$fn=name_to_dir($cdir[$i]);
						$kit=substr($fn,strlen($fn)-3,3);
						$img=array("png","jpg","jpeg","gif");
						if (!in_array($kit,$img)){
							echo("<option value=$fn>$cdir[$i]</option>");
						}
					}
				}
			}
			echo("</select> ");
			echo("<input id=\"submit\" type=\"submit\" name=\"gomb\" value=\"Fájl törlése\" style=\"width:200px;\">");
			echo("<br /><br />");
			echo("<input id=\"fsubmit\" type=\"submit\" name=\"gomb\" value=\"Új fájl feltöltése\" style=\"width:200px;display:none;\">");
			echo("<input type=\"file\" id=submitfile name=\"item10\" style=\"width:200px;display:none;\" value=Fel onchange=\"document.getElementById('fsubmit').click()\">");
			echo("<input type=button id=submit name=submit value=\"Új fájl feltöltése\" style=\"width:200px;\" onclick=\"document.getElementById('submitfile').click();return false;\">");
		}
		echo("</td></tr></table>");
		echo("<br /><br />");
		echo("<br /><br />");


		echo("<table style=\"width:80%;margin-left:10%;\" >");
		echo("<tr><td>");
		echo("<input id=\"submit\" type=\"submit\" name=\"gomb\" value=\"Elem törlése\" style=\"width:200px;\">");
		echo("</td><td>");
		echo("<input id=\"submit\" type=\"submit\" name=\"gomb\" value=\"Mentés\" style=\"width:200px;\">");
		echo("</td></tr></table>");
		echo("</form>");
		echo("</center>");
		echo("<br /><br />");
		echo("</fieldset><br />");
		echo("<br /><br />");
	}
}




function shop_get_item(){
	global $ADIR_SHOP,$ADIR_FILENAME;

	$itemdata[0]=get_postdata("item0");
	$itemdata[1]=get_postdata("item1");
	$itemdata[2]=get_postdata("item2");
	$itemdata[3]=get_postdata("item3");
	$itemdata[4]=get_postdata("item4");
	$itemdata[5]=get_postdata("item5");
	$old=get_postdata("item001");
	$itemdir=$ADIR_SHOP."/".$itemdata[1]."/".$itemdata[0];
	$itemdir=name_to_dir($itemdir);
	$old=$ADIR_SHOP."/".$old."/".$itemdata[0];
	$old=name_to_dir($old);
	if (file_exists($old)){
		$t=file_get_contents($old."/".$ADIR_FILENAME);
		$itemdatax=json_decode($t,true);
		if (($itemdatax[0]==$itemdata[0])and($itemdatax[1]<>$itemdata[1])){
	echo("$old-$itemdir");
			rename($old,$itemdir);
		}
	}
	if (!is_dir($itemdir)){
		mkdir($itemdir);
	}
	$itemfile=$itemdir."/".$ADIR_FILENAME;
	$itemfile=name_to_dir($itemfile);
	$t=json_encode($itemdata);
	file_put_contents($itemfile,$t);
	return($itemfile);
}



 ?>


