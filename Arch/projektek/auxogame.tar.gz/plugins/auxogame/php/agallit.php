<?php

 #
 # Auxogame
 #
 # info: main folder copyright file
 #
 #


function ax_games_items($game){
	global $ADIR_GAMES,$ADIR_GAMESEXT;

	if ($game==""){
	}
	$g=dir_to_name($game);
	echo("<br /><h2>$g kezelése</h2>");
	echo("<form action=\"?content=Editor&dir=Games\" method=\"post\" enctype=\"multipart/form-data\">");
	echo("<input id=\"game\" type=\"hidden\" name=\"game\" value=\"$game\"> ");
	echo("<input id=\"submit\" type=\"submit\" name=\"gomb\" value=\"Vissza a játékhoz\" style=\"width:200px;\">");
	echo("</form>");
	$gsel=TRUE;
	if ($gsel){
		echo("<br /><br />");
		echo("<fieldset name=d id=d style=\"display:snone;text-align:left;\"><legend><b>$g szerkesztése</b></legend><center><br />");
		echo("<center>");
		echo("<form action=\"\" method=\"post\" enctype=\"multipart/form-data\">");
		echo("<br />");
		$pos=get_sublink('pos');
		$cd=scandir($ADIR_GAMES."/".$pos);
		echo("<select name=game id=game style=\"width:300px;\">");
		$db=count($cd);
		$bek=1;
		if ($db>1){
			for($i=0;$i<$db;$i++){
				if (substr($cd[$i],0,1)<>"."){
					$d=$cd[$i];
					if (is_dir($ADIR_GAMES."/".$pos."/".$d)){
						echo("<option value=$cd[$i]>$bek. bekezdés</option>");
						$bek++;
					}
				}
			}
		}
		echo("</select> ");
		echo("<br />");
		echo("<br /><br />");
		echo("<input id=\"submit\" type=\"submit\" name=\"gomb\" value=\"Kiválaszt\" style=\"width:200px;\"> ");
		echo("<input id=\"submit\" type=\"submit\" name=\"gomb\" value=\"Új bekezdés\" style=\"width:200px;\">");
		echo("</form>");
		echo("</center>");
		echo("</fieldset><br />");
		echo("<br /><br />");
		$gomb=get_postdata("gomb");
		switch ($gomb){
			case "Új bekezdés":
				$g=id();
				games_item_edit2($g);
				break;
			default:
				if ($game<>""){
					$g=get_postdata('game');
					if ($g==""){
						$g=get_postdata('code');
						if ($g==""){
							$g=id();
						}
					}
					games_item_edit2($g);
				}
				break;
		}
	}
}




function games_item_edit2($game){
	global $ADIR_GAMES,$ADIR_GAMESEXT;

	$question=FALSE;
	$pos=get_sublink('pos');
	$gomb=get_postdata("gomb");
	$itemdata=array("","","","","","","","","","","","","");
	switch ($gomb){
		case "Kép cseréje":
			$oldimg=get_postdata("itemimg");
			$file=basename($_FILES["item7"]["name"]);
			$o=get_postdata("gomb");
			if ($oldimg<>""){
				$fdir=$ADIR_GAMES."/".$pos."/".$game;
				if (($fdir."/".$file)<>$oldimg){
					if (post_upload_image($fdir,"item7","gomb","")){
						auxo_message2($game,"Kép cseréje sikerült.");
						if (file_exists($oldimg)){
							if (!unlink($oldimg)){
								auxo_message2($game,"Régi kép törlése nem sikerült.");
							}
						}else{
							auxo_message2($game,"Régi kép nem létezik.");
						}
						$file=games_get_item($game,$file);
					}else{
						auxo_message2($game,"Hiba a feltöltés közben. (Kép túl nagy, létezik vagy nem kép.)");
					}
				}else{
					auxo_message2($game,"A két fájl egyezik.");
				}
				$file=$fdir."/".$game.$ADIR_GAMESEXT;
				$t=file_get_contents($file);
				$itemdata=json_decode($t,true);
			}
			break;
		case "Kép törlése":
			$question=TRUE;
			$file=get_postdata("itemimg");
			$file2=$ADIR_GAMES."/".$pos."/".$game."/".$game.$ADIR_GAMESEXT;
			$file2=name_to_dir($file2);
			$t=file_get_contents($file2);
			$itemdata=json_decode($t,true);
			auxo_message_q("Valóban töröljük a képet?",$game,$file);
			break;
		case "Bekezdés törlése":
			$question=TRUE;
			$data1=$game;
			auxo_message_q("Valóban töröljük a bekezdést?",$data1,"");
			break;
		case "Új kép feltöltése":
			$file=basename($_FILES["item8"]["name"]);
			$fdir=$ADIR_GAMES."/".$pos."/".$game;
			$fdir=name_to_dir($fdir);
			$file2=$ADIR_GAMES."/".$pos."/".$game."/".$game.$ADIR_GAMESEXT;
			$file=name_to_dir($file);
			$t=file_get_contents($file2);
			$itemdata=json_decode($t,true);
			if (post_upload_image($fdir,"item8","gomb","")){
				auxo_message2($game,"Kép feltöltése sikerült.");
			}else{
				auxo_message2($game,"Hiba a feltöltés közben. (Kép túl nagy, létezik vagy nem kép.)");
			}
			break;
		case "Mentés":
			$file=games_get_item2($game,$pos);
			$file=name_to_dir($file);
			$t=file_get_contents($file);
			$itemdata=json_decode($t,true);
			auxo_message2($game,"A mentés sikerült.");
			break;
		case "Igen":
			#$question=TRUE;
			$data1=get_postdata("code");
			$datax=get_postdata("code2");
			if ($datax==""){
				$datax=$ADIR_GAMES."/".$pos."/".$data1;
				$datax=name_to_dir($datax);
				if (is_dir($datax)){
					$cd=scandir($datax);
					$db=count($cd);
					for($i=0;$i<$db;$i++){
						$cdd=name_to_dir($cd[$i]);
						if (substr($cdd,0,1)<>"."){
							unlink($datax."/".$cdd);
						}
					}
					if (rmdir($datax)){
						auxo_message("A bekezdés törlése sikerült.");
					}else{
						auxo_message2($game,"Hiba a törlés közben.");
					}
				}
				$game=id();
			}else{
				$game=$data1;
				$file2=$ADIR_GAMES."/".$pos."/".$game."/".$game.$ADIR_GAMESEXT;
				$file2=name_to_dir($file2);
				$t=file_get_contents($file2);
				$itemdata=json_decode($t,true);
				if (file_exists($datax)){
					if (unlink($datax)){
						auxo_message2($game,"Kép törlése sikerült.");
					}else{
						auxo_message2($game,"Hiba a törlés közben.");
					}
				}
			}
			break;
		case "Tovább":
			$file=$ADIR_GAMES."/".$pos."/".$game."/".$game.$ADIR_GAMESEXT;
			$file=name_to_dir($file);
			if (file_exists($file)){
				$t=file_get_contents($file);
				$itemdata=json_decode($t,true);
			}
			break;
		case "Nem":
			$file=$ADIR_GAMES."/".$pos."/".$game."/".$game.$ADIR_GAMESEXT;
			$t=file_get_contents($file);
			$itemdata=json_decode($t,true);
			break;
		case "Rendben":
			$file=$ADIR_GAMES."/".$pos."/".$game."/".$game.$ADIR_GAMESEXT;
			$file=name_to_dir($file);
			if (file_exists($file)){
				$t=file_get_contents($file);
				$itemdata=json_decode($t,true);
			}
			break;
		default:
			$file=$ADIR_GAMES."/".$pos."/".$game."/".$game.$ADIR_GAMESEXT;
			$file=name_to_dir($file);
			if (file_exists($file)){
				$t=file_get_contents($file);
				$itemdata=json_decode($t,true);
			}
			break;
	}

	if (!$question){
		echo("<br /><br />");
		if ($game<>""){
			$game2=" (".$game.")";
		}else{
			$game2="";
		}
		$pos=get_sublink('pos');
		$cd=scandir($ADIR_GAMES."/".$pos);
		$db=count($cd);
		$bek=0;
		$kiir="";
		for($i=0;$i<$db;$i++){
			if (substr($cd[$i],0,1)<>"."){
				$d=$cd[$i];
				$d=$cd[$i];
				if (is_dir($ADIR_GAMES."/".$pos."/".$d)){
					$bek++;
				}
				if ($game==$cd[$i]){
					$i=$db;
					$kiir=" - $bek. bekezdés";
				}else{
					$kiir=" - Új bekezdés";
				}
			}
		}
		echo("<fieldset name=d id=d style=\"display:snone;text-align:left;\"><legend><b>Játék adatok szerkesztése$kiir</b></legend><center><br />");
		echo("<br /><br />");
		echo("<center>");
		echo("<table style=\"width:80%;margin-left:10%;\" >");
		echo("<form action=\"\" method=\"post\" enctype=\"multipart/form-data\">");
		echo("<input type=hidden id=\"game\" name=\"game\" value=\"$game\">");
		echo("<tr><td width=20% valign=top>");
		echo("Cím:");
		echo("</td><td>");
		echo("<input type=\"text\" name=\"item0\" id=\"item0\" value=\"$itemdata[0]\" style=\"width:400px;\">	");
		echo("</td></tr><tr><td valign=top>");
		echo("Szöveg:");
		echo("</td><td>");
		echo("<textarea name=\"item1\" id=\"item1\" style=\"width:400px;\">$itemdata[1]</textarea>");
		echo("<br /><br />");
		echo("</td></tr><tr><td valign=top>");
		$itemfile=$ADIR_GAMES."/".$pos."/".$game."/".$game.$ADIR_GAMESEXT;
		echo("Képek:");
		echo("</td><td>");
		if (file_exists($itemfile)){
			echo("<table>");
			$ddir=$ADIR_GAMES."/".$pos."/".$game;
			$cdir=scandir($ddir);
			$db=count($cdir);
			echo("<input type=hidden id=itemimg name=itemimg value=\"\">");
			echo("<input id=\"imchubmit\" type=\"submit\" name=\"gomb\" value=\"Kép cseréje\" style=\"width:200px;display:none;\">");
			echo("<input id=\"delsubmit\" type=\"submit\" name=\"gomb\" value=\"Kép törlése\" style=\"width:200px;display:none;\">");
			echo("<input type=\"file\" id=\"submitim\" name=\"item7\"  style=\"width:200px;display:none;\" onchange=\"document.getElementById('imchubmit').click()\">");
			for($i=0;$i<$db;$i++){
				if ((substr($cdir[$i],0,1)<>".")and($cdir[$i]<>($game.$ADIR_GAMESEXT))){
					$fn=name_to_dir($cdir[$i]);
					$kit=substr($fn,strlen($fn)-3,3);
					echo("<tr><td>");
					$img=array("png","jpg","jpeg","gif");
					if (in_array($kit,$img)){
						$imgn=$ddir."/".$fn;
						echo("</td><td>");
						echo("<img src=\"$imgn\" width=100px hheight=100px>");
						echo("</td><td>");
						echo("<input type=button id=submit name=\"$imgn\" value=\"Kép cseréje\" style=\"width:200px;\" onclick=\"document.getElementById('itemimg').value=this.name;document.getElementById('submitim').click();return false;\">");
						echo("<br /><br />");
						echo("<input type=button id=submit name=\"$imgn\" value=\"Kép törlése\" style=\"width:200px;\" onclick=\"document.getElementById('itemimg').value=this.name;document.getElementById('delsubmit').click();return false;\">");
						#echo("<button id=submit name=imgdel value=$imgn style=\"width:200px;\" >Kép törlése</button>");
						echo("<br /><br />");
					echo("</td></tr>");
					}
				}
			}
			echo("</table>");
			echo("</td></tr>");
			echo("<tr><td>");
			echo("</td><td>");
			echo("<br />");
			echo("<input id=\"isubmit\" type=\"submit\" name=\"gomb\" value=\"Új kép feltöltése\" style=\"width:200px;display:none;\">");
			echo("<input type=\"file\" id=\"submitimage\" name=\"item8\"  style=\"width:200px;display:none;\" onchange=\"document.getElementById('isubmit').click()\">");
			echo("<input type=button id=submit name=submit value=\"Új kép feltöltése\" style=\"width:200px;\" onclick=\"document.getElementById('submitimage').click();return false;\">");
			echo("<br />");
		}else{
			echo("<tr><td>");
			echo("</td><td>");
			echo("Kép feltöltés csak a már mentett elemhez lehetséges.");
		}

		echo("</td></tr></table>");

		echo("<br /><br />");
		echo("<table style=\"width:80%;margin-left:10%;\" >");
		echo("<tr><td>");
		echo("<input id=\"submit\" type=\"submit\" name=\"gomb\" value=\"Bekezdés törlése\" style=\"width:200px;\">");
		echo("</td><td>");
		echo("<input id=\"submit\" type=\"submit\" name=\"gomb\" value=\"Mentés\" style=\"width:200px;\"  onclick=\"document.getElementById('game').value=document.getElementById('item2').value;document.getElementById('submitsave').click();return false;\">");
		echo("<input id=\"submitsave\" type=\"submit\" name=\"gomb\" value=\"Mentés\" style=\"display:none;\">");
		echo("</td></tr></table>");
		echo("<br />");
		echo("</form>");
		echo("</center>");
		echo("<br /><br />");
		echo("</fieldset><br />");
		echo("<br /><br />");
	}
}




function games_get_item2($game,$pos){
	global $ADIR_GAMES,$ADIR_GAMESEXT;

	$itemdata[0]=get_postdata("item0");
	$itemdata[1]=get_postdata("item1");
	$itemdata[2]=get_postdata("item2");
	$itemdata[3]=get_postdata("item3");
	$itemdir=$ADIR_GAMES."/".$pos."/".$game;
	if (!is_dir($itemdir)){
		mkdir($itemdir);
	}
	$itemfile=$itemdir."/".$game.$ADIR_GAMESEXT;
	$t=json_encode($itemdata);
	file_put_contents($itemfile,$t);
	return($itemfile);
}



 ?>


