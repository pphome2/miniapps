<?php

 #
 # Auxogame
 #
 # info: main folder copyright file
 #
 #


function ax_promo(){
	global $ADIR_PROMO,$ADIR_PFILENAME,$DIR_PLUGINS,$ADIR_GAMESEXT;

	$cd=scandir($ADIR_PROMO);
	$db=count($cd);
	$cdb=0;
	$cd2=array();
	$img=array("png","jpg","jpeg","gif");
	for($i=0;$i<$db;$i++){
		$kit=substr($cd[$i],strlen($cd[$i])-3,3);
		if (in_array($kit,$img)){
			$cd2[$cdb]=$cd[$i];
			$cdb++;
		}
	}
	if ($cdb>1){
		#$sec=$itemdata[0]+4;
		$sec=4+4;
		echo("<style>.aux-animate-fading{animation:fading $sec.0s infinite}@keyframes fading{0%{opacity:0.1}50%{opacity:1}100%{opacity:0.1}}</style>");
		echo("<center><div style=\"background-color:black;width:900px;height:auto;\">");
		for($i=0;$i<$cdb;$i++){
			$link=$ADIR_PROMO."/".$cd2[$i];
			$file=$link.$ADIR_GAMESEXT;
			$ilink="";
			$text="";
			$itemdata=array("","","","","");
			$ok=FALSE;
			if (file_exists($file)){
				$t=file_get_contents($file);
				$itemdata=json_decode($t,true);
				if ($itemdata[1]<>""){
					echo("$itemdata[1]-");
					$ok=TRUE;
					if ($itemdata[3]<>""){
						$kit=substr($itemdata[3],0,4);
						if (!in_array($kit,array("http","https"))){
							$ilink="http://".$itemdata[3];
						}else{
							$ilink=$itemdata[3];
						}
					}
				}
				if ($itemdata[2]<>""){
					$text=$itemdata[2];
				}
			}
			if ($ok){
				echo("<div class=\"mySlides aux-animate-fading\" style=\"width:900px;\">");
				if ($ilink<>""){
					echo("<a href=$ilink>");
				}
				if ($link<>""){
					echo("<img src=$link width=900px><br />");
				}
				if ($ilink<>""){
					echo("</a>");
				}
				echo("</div>");
				if ($text<>""){
					echo("$text<br />");
				}else{
					#echo("<br />");
				}
			}
			$q1=$i+1;
			$q2=$cdb;
		}
		axcss2($itemdata[0],$cdb);
		echo("</div></center><br />");
	}else{
		if (isset($cd2[0])and($cd2[0]<>"")){
			echo("<center><div style=\"background-color:black;width:900px;height:auto;\">");
			$link=$ADIR_PROMO."/".$cd2[0];
			$file=$link.$ADIR_GAMESEXT;
			$ilink="";
			$text="";
			$ok=FALSE;
			if (file_exists($file)){
				$t=file_get_contents($file);
				$itemdata=json_decode($t,true);
				if ($itemdata[1]<>""){
					$ok=TRUE;
					if ($itemdata[3]<>""){
						if (substr($itemdata[3],0,4)<>"http"){
							$ilink="http://".$itemdata[3];
						}else{
							$ilink=$itemdata[3];
						}
						if ($ilink<>""){
							echo("<a href=$ilink>");
						}
					}
				}
				if ($itemdata[2]<>""){
					$text=$itemdata[2];
				}
			}
			if ($ok){
				if ($link<>""){
					echo("<img src=$link width=900px><br />");
				}
				if ($text<>""){
					echo("$text<br />");
				}else{
					#echo("<br />");
				}
				if ($ilink<>""){
					echo("</a>");
				}
			}
			echo("</div></center>");
		}
	}
}



function promo_item_edit(){
	global $ADIR_PROMO,$ADIR_PFILENAME,$ADIR_GAMESEXT;

	$itemdata=array("","","","","","","","","","","","","","","","");
	$pos=get_sublink("pos");
	if ($pos<>""){
		$t=file_get_contents($pos."/".$ADIR_PFILENAME);
		$itemdata=json_decode($t,true);
	}
	$file=get_postdata('file');
	$datfile=$file.$ADIR_GAMESEXT;
	$question=FALSE;
	$gomb=get_postdata("gomb");
	switch ($gomb){
		case "Kép cseréje":
			$oldimg=get_postdata("itemimg");
			$fileq=$ADIR_PROMO."/".basename($_FILES["item7"]["name"]);
			$o=get_postdata("gomb");
			if ($oldimg<>""){
				$fdir=$ADIR_PROMO;
				if (post_upload_image($fdir,"item7","gomb","")){
					auxo_message("Kép cseréje sikerült.");
					if (file_exists($oldimg)){
						if (!unlink($oldimg)){
							auxo_message("Régi kép törlése nem sikerült.");
						}
					}
					rename($fileq,$oldimg);
				}else{
					auxo_message("Hiba a feltöltés közben. (Kép túl nagy, nem létezik vagy nem kép.)");
				}
			}
			break;
		case "Új kép feltöltése":
			$filen=basename($_FILES["item8"]["name"]);
			$fdir=$ADIR_PROMO;
			if (post_upload_image($fdir,"item8","gomb","")){
				auxo_message2($file,"Kép feltöltése sikerült.");
			}else{
				auxo_message2($file,"Hiba a feltöltés közben. (Kép túl nagy, nem létezik vagy nem kép.)");
			}
			$file=$fdir."/".$filen;
			break;
		case "Kép törlése":
			$question=TRUE;
			$fileq=get_postdata("itemimg");
			auxo_message_q("Valóban töröljük a képet?","",$fileq);
			break;
		case "Reklám törlése":
			$question=TRUE;
			$fileq=get_postdata("itemimg");
			auxo_message_q("Valóban töröljük a reklámot?","",$fileq);
			break;
		case "Mentés":
			$qfile=promo_get_item($datfile);
			$t=file_get_contents($datfile);
			$itemdata=json_decode($t,true);
			auxo_message2($file,"A mentés sikerült.");
			break;
		case "Igen":
			$data1=get_postdata("code");
			$datax=get_postdata("code2");
			if ($datax==""){
				$datax=$ADIR_PROMO;
				$cd=scandir($datax);
				$db=count($cd);
				for($i=0;$i<$db;$i++){
					$f=$ADIR_PROMO."/".$cd[$i];
					if (file_exists($f)){
						unlink($f);
					}
				}
				$datax=$ADIR_PROMO."/".$ADIR_PFILENAME;
				if (file_exists($datax)){
					if (unlink($datax)){
						auxo_message("Reklám törlése sikerült.");
					}else{
						auxo_message("Hiba a törlés közben.");
					}
				}
			}else{
				if (file_exists($datax)){
					if (unlink($datax)){
						$datf=$datax.$ADIR_GAMESEXT;
						if (file_exists($datf)){
							if (unlink($datf)){
							}
						}
						auxo_message("Kép törlése sikerült.");
					}else{
						auxo_message("Hiba a törlés közben.");
					}
				}
			}
			break;
		case "Tovább":
			$file=$ADIR_PROMO."/".$ADIR_PFILENAME;
			$t=file_get_contents($file);
			$itemdata=json_decode($t,true);
			break;
		case "Választás":
			$file=get_postdata('kep');
			$datfile=$file.$ADIR_GAMESEXT;
			if (file_exists($datfile)){
				$t=file_get_contents($datfile);
				$itemdata=json_decode($t,true);
			}
			break;
		case "Nem":
			break;
		default:
			break;
	}

	if (!$question){
		echo("<br /><br />");
		echo("<fieldset name=d id=d style=\"display:snone;text-align:left;\"><legend><b>Reklám fejléc szerkesztése - Választás</b></legend><center><br />");
		echo("<br /><br />");
		echo("<center>");
		echo("<form action=\"\" method=\"post\" enctype=\"multipart/form-data\">");
		echo("<input type=hidden id=file name=file value=\"$file\">");
		$cdir=scandir($ADIR_PROMO);
		$db=count($cdir);
		$imgnum=0;
		echo("<select name=kep id=kep style=\"width:300px;\">");
		if ($db>0){
			for($i=0;$i<$db;$i++){
				if ((substr($cdir[$i],0,1)<>".")and($cdir[$i]<>$ADIR_PFILENAME)){
					$fn=name_to_dir($cdir[$i]);
					$kit=substr($fn,strlen($fn)-3,3);
					$img=array("png","jpg","jpeg","gif");
					if (in_array($kit,$img)){
						$imgn=$ADIR_PROMO."/".$fn;
						$imgnum++;
						echo("<option value=$imgn>Reklámkép: $imgnum.</option>");
					}
				}
			}
		}
		echo("</select> ");
		echo("<input id=\"submit\" type=\"submit\" name=\"gomb\" value=\"Választás\" style=\"width:200px;\">");
		echo("</form>");
		echo("</center>");
		echo("<br /><br />");
		echo("</fieldset><br />");
		echo("<br /><br />");


		#$file=$ADIR_PROMO."/".$ADIR_PFILENAME;
		echo("<fieldset name=d id=d style=\"display:snone;text-align:left;\"><legend><b>Reklám fejléc szerkesztése</b></legend><center><br />");
		echo("<form action=\"\" method=\"post\" enctype=\"multipart/form-data\">");
		if (($file<>"")and(file_exists($file))){
			if (file_exists($datfile)){
				$t=file_get_contents($datfile);
				$itemdata=json_decode($t,true);
			}
			echo("<br /><br />");
			echo("<br /><br />");
			echo("<center>");
			echo("<table style=\"width:80%;margin-left:10%;\" >");
			echo("<input type=hidden id=file name=file value=\"$file\">");
			echo("<tr><td width=20% valign=top>");
			echo("Kép:");
			echo("</td><td>");

			echo("<table>");
			echo("<input type=hidden id=itemimg name=itemimg value=\"\">");
			echo("<input id=\"imchubmit\" type=\"submit\" name=\"gomb\" value=\"Kép cseréje\" style=\"width:200px;display:none;\">");
			echo("<input id=\"delsubmit\" type=\"submit\" name=\"gomb\" value=\"Kép törlése\" style=\"width:200px;display:none;\">");
			echo("<input type=\"file\" id=\"submitim\" name=\"item7\"  style=\"width:200px;display:none;\" onchange=\"document.getElementById('imchubmit').click()\">");
			$imgn=$file;
			echo("<tr><td valign=top>");
			echo("<img src=\"$imgn\" width=300px height=px>");
			echo("</td><td>");
			echo("<input type=button id=submit name=\"$imgn\" value=\"Kép cseréje\" style=\"width:200px;\" onclick=\"document.getElementById('itemimg').value=this.name;document.getElementById('submitim').click();return false;\">");
			echo("<br /><br />");
			echo("<input type=button id=submit name=\"$imgn\" value=\"Kép törlése\" style=\"width:200px;\" onclick=\"document.getElementById('itemimg').value=this.name;document.getElementById('delsubmit').click();return false;\">");
			#echo("<button id=submit name=imgdel value=$imgn style=\"width:200px;\" >Kép törlése</button>");
			echo("<br /><br />");
			echo("</td></tr>");


			echo("</table>");
			echo("<br />");
			echo("<br />");
			echo("<br />");
			echo("</td></tr>");

			echo("</td></tr><tr><td valign=top>");
			#echo("Idő:");
			echo("</td><td>");
			#echo("<input type=\"text\" name=\"item0\" id=\"item0\" value=\"$itemdata[0]\" style=\"width:50px;\">	másodperc");
			echo("</td></tr><tr><td valign=top>");
			echo("Elérhető:");
			echo("</td><td>");
			if ($itemdata[1]<>""){
				$checked="checked";
			}else{
				$checked="";
			}
			echo("<input type=\"checkbox\" name=\"item1\" value=\"Engedélyezve\" $checked>");
			echo("</td></tr><tr><td valign=top>");
			echo("Szöveg:");
			echo("</td><td>");
			echo("<textarea name=\"item2\" id=\"item2\" style=\"width:300px;\">$itemdata[2]</textarea>");
			echo("</td></tr><tr><td valign=top>");
			echo("Link:");
			echo("</td><td>");
			echo("<input type=\"text\" name=\"item3\" id=\"item3\" value=\"$itemdata[3]\" style=\"width:300px;\">	");
			echo("</td></tr></table>");

			echo("<br /><br />");
			echo("<table style=\"width:80%;margin-left:10%;\" >");
			echo("<tr><td>");
			echo("<input id=\"submit\" type=\"submit\" name=\"gomb\" value=\"Reklám törlése\" style=\"width:200px;\">");
			echo("</td><td>");
			echo("<input id=\"submit\" type=\"submit\" name=\"gomb\" value=\"Mentés\" style=\"width:200px;\">");
			echo("</td></tr></table>");
			echo("</center>");
			echo("<br /><br />");
		}
		echo("<br /><br />");
		echo("<input id=\"isubmit\" type=\"submit\" name=\"gomb\" value=\"Új kép feltöltése\" style=\"width:200px;display:none;\">");
		echo("<input type=\"file\" id=\"submitimage\" name=\"item8\"  style=\"width:200px;display:none;\" onchange=\"document.getElementById('isubmit').click()\">");
		echo("<input type=button id=submit name=submit value=\"Új kép feltöltése\" style=\"width:200px;\" onclick=\"document.getElementById('submitimage').click();return false;\">");
		echo("<br /><br />");
		echo("</form>");
		echo("</fieldset><br />");
		echo("<br /><br />");
	}
}




function promo_get_item($file){
	global $ADIR_PROMO,$ADIR_PFILENAME;

	$itemdata[0]=get_postdata("item0");
	$itemdata[1]=get_postdata("item1");
	$itemdata[2]=get_postdata("item2");
	$itemdata[3]=get_postdata("item3");
	$itemdir=$ADIR_PROMO;
	if (!is_dir($itemdir)){
		mkdir($itemdir);
	}
	$itemfile=$file;
	$t=json_encode($itemdata);
	file_put_contents($itemfile,$t);
	return($itemfile);
}



 ?>

