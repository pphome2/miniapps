<?php

 #
 # Auxogame
 #
 # info: main folder copyright file
 #
 #


function ax_games(){
	global $ADIR_GAMES,$ADIR_GAMESEXT;

	$gomb=get_postdata('gomb');
	$game=get_postdata('games');
	#echo("$gomb-$game");
	if ($game==""){
		$game=get_sublink('game');
	}
	if ($game==""){
		$game=get_postdata('item2');
		if ($game==""){
			$game=get_postdata('code');
			$t=explode('/',$game);
			$g=count($t)-1;
			$game=$t[$g];
			$t=explode('.',$game);
			$game=$t[0];
		}
	}
	if ($game<>""){
		$gsel=FALSE;
		games_item_edit($game);
	}else{
		$gsel=TRUE;
		switch ($gomb){
			case "Kiválaszt":
				$g=get_postdata('games');
				$gsel=FALSE;
				games_item_edit($g);
				break;
			case "Új játék":
				$gsel=FALSE;
				games_item_edit("");
				break;
		}
	}
	if ($gsel){
		echo("<br /><br />");
		echo("<fieldset name=d id=d style=\"display:snone;text-align:left;\"><legend><b>Játék szerkesztés</b></legend><center><br />");
		echo("<center>");
		echo("<form action=\"\" method=\"post\" enctype=\"multipart/form-data\">");
		echo("<input id=\"submit\" type=\"submit\" name=\"gomb\" value=\"Új játék\" style=\"width:200px;\">");
		echo("<input id=\"games\" type=\"hidden\" name=\"games\" value=\"\" style=\"width:200px;\"> ");
		echo("</form>");
		echo("<br />");
		$cd=scandir($ADIR_GAMES);
		#echo("<select name=games id=games style=\"width:300px;\">");
		$db=count($cd);
		if ($db>0){
			for($i=0;$i<$db;$i++){
				if (substr($cd[$i],0,1)<>"."){
					$d=$cd[$i];
					#echo("<option value=$cd[$i]>$d</option>");
					#echo("<input id=\"submit\" type=\"submit\" name=\"ggomb\" value=\"$d\" style=\"width:200px;\"  onclick=\"document.getElementById('games').value=document.getElementByName('ggomb').value;document.getElementById('submitsave').click();return false;\">");
					$link="?content=Editor&dir=Games&game=".$d;
					$d=dir_to_name($d);
					echo("<a href=$link><input id=\"submit\" type=\"submit\" name=\"ggomb\" value=\"$d\" style=\"width:200px;margin:5px;\"></a>");
				}
			}
		}
		#echo("</select> ");
		echo("<br />");
		#echo("<br /><br />");
		echo("<input id=\"submitsave\" type=\"submit\" name=\"gomb\" value=\"Kiválaszt\" style=\"display:none;\">");
		#echo("<input id=\"submit\" type=\"submit\" name=\"gomb\" value=\"Kiválaszt\" style=\"width:200px;\"> ");
		#echo("</form>");
		echo("</center>");
		echo("<br /><br />");
		echo("</fieldset><br />");
		echo("<br /><br />");
		echo("<br /><br />");
	}else{
	}
}




function games_item_edit($game){
	global $ADIR_GAMES,$ADIR_GAMESEXT;

	$question=FALSE;
	$itemdata=array("","","","","","","","","","","","","","","","");
	$gomb=get_postdata("gomb");
	switch ($gomb){
		case "Logó cseréje":
			$oldimg=get_postdata("itemimg");
			$oldimg=name_to_dir($oldimg);
			$file=basename($_FILES["item7"]["name"]);
			$o=get_postdata("gomb");
			if ($oldimg<>""){
				$fdir=$ADIR_GAMES."/".$game;
				$fdir=name_to_dir($fdir);
				if (($fdir."/".$file)<>$oldimg){
					if (post_upload_image($fdir,"item7","gomb","")){
						auxo_message2($game,"Logó cseréje sikerült.");
						if ((!is_dir($oldimg))and(file_exists($oldimg))){
							if (!unlink($oldimg)){
								auxo_message2($game,"Régi kép törlése nem sikerült.");
							}
						}else{
							auxo_message2($game,"Régi kép nem létezik.");
						}
						$file=games_get_item($game,$file);
					}else{
						auxo_message2($game,"Hiba a feltöltés közben. (Kép túl nagy, nem létezik vagy nem kép.)");
					}
				}else{
					auxo_message2($game,"A két fájl egyezik.");
				}
			}
			break;
		case "Játék törlése":
			$question=TRUE;
			auxo_message_q("Valóban töröljük a játékot?",$game,"");
			break;
		case "Mentés":
			$file=games_get_item($game,"");
			$t=file_get_contents($file);
			$itemdata=json_decode($t,true);
			auxo_message2($game,"A mentés sikerült.");
			break;
		case "Igen":
			$question=TRUE;
			$data1=get_postdata("code");
			$data1=name_to_dir($data1);
			$datax=get_postdata("code2");
			$datax=name_to_dir($datax);
			if ($datax==""){
				$datax=$ADIR_GAMES."/".$data1;
				$datax=name_to_dir($datax);
				$cd=scandir($datax);
				$db=count($cd);
				for($i=0;$i<$db;$i++){
					if (substr($cd[$i],0,1)<>"."){
						unlink($datax."/".$cd[$i]);
					}
				}
				if (rmdir($datax)){
					auxo_message("Játék törlése sikerült.");
				}else{
					auxo_message2($game,"Hiba a törlés közben.");
				}
			}else{
				if (unlink($datax)){
					auxo_message("Fájl törlése sikerült.");
				}else{
					auxo_message2($game,"Hiba a törlés közben.");
				}
			}
			break;
		case "Tovább":
			$file=get_postdata("code");
			$file=$ADIR_GAMES."/".$game."/".$game.$ADIR_GAMESEXT;
			if (file_exists($file)){
				$t=file_get_contents($file);
				$itemdata=json_decode($t,true);
			}
			break;
		case "Nem":
			$file=$ADIR_GAMES."/".$game."/".$game.$ADIR_GAMESEXT;
			if (file_exists($file)){
				$t=file_get_contents($file);
				$itemdata=json_decode($t,true);
			}
			break;
		case "Rendben":
			$file=$ADIR_GAMES."/".$game."/".$game.$ADIR_GAMESEXT;
			if (file_exists($file)){
				$file=name_to_dir($file);
				$t=file_get_contents($file);
				$itemdata=json_decode($t,true);
			}
			break;
		default:
			$file=$ADIR_GAMES."/".$game."/".$game.$ADIR_GAMESEXT;
			if (file_exists($file)){
				$file=name_to_dir($file);
				$t=file_get_contents($file);
				$itemdata=json_decode($t,true);
			}
			break;
	}

	if ($game<>""){
		$d=$ADIR_GAMES."/".$game."/".$game.$ADIR_GAMESEXT;
		$d=name_to_dir($d);
		if (file_exists($d)){
			$t=file_get_contents($d);
			$itemdata=json_decode($t,true);
		}
	}else{
		$game=get_postdata('game');
		if ($game<>""){
			$d=$ADIR_GAMES."/".$game."/".$game.$ADIR_GAMESEXT;
			$d=name_to_dir($d);
			$t=file_get_contents($d);
			$itemdata=json_decode($t,true);
		}
	}
	if (!$question){
		#echo("<form action=\"?content=Editor&dir=Games\" method=\"post\" enctype=\"multipart/form-data\">");
		#echo("<input id=\"submit\" type=\"submit\" name=\"gomb\" value=\"Vissza a játéklistához\" style=\"width:200px;\">");
		#echo("</form>");
		echo("<br /><br />");
		if ($game<>""){
			$game2=dir_to_name($game);
			$game2=" (".$game2.")";
		}else{
			$game2="";
		}
		echo("<fieldset name=d id=d style=\"display:snone;text-align:left;\"><legend><b>Játék adatok szerkesztése$game2</b></legend><center><br />");
		echo("<br /><br />");
		echo("<center>");
		echo("<table style=\"width:80%;margin-left:10%;\" >");
		echo("<form action=\"\" method=\"post\" enctype=\"multipart/form-data\">");
		echo("<input type=hidden id=\"game\" name=\"game\" value=\"$game\">");
		echo("<input type=hidden id=\"ngame\" name=\"ngame\" value=\"$itemdata[2]\">");
		echo("<input type=hidden id=\"item1\" name=\"item1\" value=\"$itemdata[1]\">");
		echo("<tr><td width=20% valign=top>");
		echo("Logó:");
		echo("</td><td>");

		if ($game<>""){
			echo("<table>");
			echo("<input type=hidden id=itemimg name=itemimg value=\"\">");
			echo("<input id=\"imchubmit\" type=\"submit\" name=\"gomb\" value=\"Logó cseréje\" style=\"width:200px;display:none;\">");
			echo("<input id=\"delsubmit\" type=\"submit\" name=\"gomb\" value=\"Logó törlése\" style=\"width:200px;display:none;\">");
				echo("<input type=\"file\" id=\"submitim\" name=\"item7\"  style=\"width:200px;display:none;\" onchange=\"document.getElementById('imchubmit').click()\">");
			$imgn=$ADIR_GAMES."/".$game."/".$itemdata[1];
			$imgn=name_to_dir($imgn);
			echo("<tr><td valign=top>");
			echo("<img src=\"$imgn\" width=200px hheight=200px>");
			echo("</td><td valign=top>");
			echo("<input type=button id=submit name=\"$imgn\" value=\"Logó cseréje\" style=\"width:200px;\" onclick=\"document.getElementById('itemimg').value=this.name;document.getElementById('submitim').click();return false;\">");
			echo("<br /><br />");
			echo("</td></tr>");
			echo("</table>");
		}else{
			echo("Logó feltöltés csak a játék mentése után elérhető.");
		}
		echo("</td></tr>");

		echo("</td></tr><tr><td valign=top><br />");
		echo("Új:");
		echo("</td><td>");
		if ($itemdata[0]<>""){
			$checked="checked";
		}else{
			$checked="";
		}
		echo("<input type=\"checkbox\" name=\"item0\" value=\"Engedélyezve\" $checked>");
		echo("</td></tr><tr><td valign=top>");
		echo("Teljes név:");
		echo("</td><td>");
		echo("<input type=\"text\" name=\"item2\" id=\"item2\" value=\"$itemdata[2]\" style=\"width:400px;\">	");
		echo("</td></tr><tr><td valign=top>");
		echo("Online név:");
		echo("</td><td>");
		echo("<input type=\"text\" name=\"item3\" id=\"item3\" value=\"$itemdata[3]\" style=\"width:400px;\">	");
		echo("</td></tr><tr><td valign=top>");
		echo("Rövid leírás:");
		echo("</td><td>");
		echo("<textarea name=\"item4\" id=\"item4\" style=\"width:400px;\">$itemdata[4]</textarea>");
		echo("</td></tr></table>");

		echo("<br /><br />");
		echo("<table style=\"width:80%;margin-left:10%;\" >");
		echo("<tr><td>");
		echo("<input id=\"submit\" type=\"submit\" name=\"gomb\" value=\"Játék törlése\" style=\"width:200px;\">");
		echo("</td><td>");
		echo("<input id=\"submit\" type=\"submit\" name=\"gomb\" value=\"Mentés\" style=\"width:200px;\"  onclick=\"document.getElementById('game').value=document.getElementById('item2').value;document.getElementById('submitsave').click();return false;\">");
		echo("<input id=\"submitsave\" type=\"submit\" name=\"gomb\" value=\"Mentés\" style=\"display:none;\">");
		echo("</td></tr></table>");
		echo("<br /><br />");
		echo("<br /><br />");
		$g=name_to_dir($game);
		echo("<a href=?content=Editor&dir=Games&pos=$g><input id=\"submit\" type=\"button\" name=\"gomb\" value=\"Részletes leírás\" style=\"width:200px;\"></a>");
		echo("</form>");
		echo("</center>");
		echo("<br /><br />");
		echo("</fieldset><br />");
		echo("<br /><br />");
	}
}




function games_get_item($game,$f){
	global $ADIR_GAMES,$ADIR_GAMESEXT;

	$itemdata[0]=get_postdata("item0");
	$itemdata[1]=get_postdata("item1");
	$itemdata[2]=get_postdata("item2");
	$itemdata[3]=get_postdata("item3");
	$itemdata[4]=get_postdata("item4");
	$old=get_postdata("ngame");
	$itemdir=$ADIR_GAMES."/".$game;
	$itemdir=name_to_dir($itemdir);
	$itemfile=$itemdir."/".$game.$ADIR_GAMESEXT;
	$itemfile=name_to_dir($itemfile);
	if ($old<>$itemdata[2]){
		$itemdir2=$ADIR_GAMES."/".$old;
		$itemdir2=name_to_dir($itemdir2);
		rename($itemdir2,$itemdir);
		#$itemdir=$itemdir2;
		$itemfile2=$itemdir."/".$old.$ADIR_GAMESEXT;
		$itemfile2=name_to_dir($itemfile2);
		rename($itemfile2,$itemfile);
		#$itemfile=$itemfile2;
	}
	if ($f<>""){
		$itemdata[1]=$f;
	}
	if (!is_dir($itemdir)){
		mkdir($itemdir);
	}
	$itemfile=$itemdir."/".$game.$ADIR_GAMESEXT;
	$itemfile=name_to_dir($itemfile);
	$t=json_encode($itemdata);
	file_put_contents($itemfile,$t);
	return($itemfile);
}



 ?>


