<?php

function axcss($gsec,$db){

?>

<script>
var slideIndex = 0;showSlides();

function showSlides() {
    var i;
    var slides = document.getElementsByClassName("mySlides");
    var dots = document.getElementsByClassName("dot");
    for (i = 0; i < slides.length; i++) {
       slides[i].style.display = "none";
    }
    slideIndex++;
    if (slideIndex> slides.length) {slideIndex = 1}
    for (i = 0; i < dots.length; i++) {
        dots[i].className = dots[i].className.replace(" active", "");
    }
    slides[slideIndex-1].style.display = "block";
    dots[slideIndex-1].className += " active";
    <?php
		$sec=1000*$gsec;
		echo("setTimeout(showSlides, $sec);");
    ?>
}
</script>

<?php
}
?>


<?php

function axcss2($gsec,$db){

?>


<script>
var myIndex = 0;
carousel();

function carousel() {
    var i;
    var x = document.getElementsByClassName("mySlides");
    var k;
    for (i = 0; i < x.length; i++) {
			x[i].style.display = "noney";
    }
    k=myIndex;
    myIndex++;
    if (myIndex > x.length) {myIndex = 1}
    x[myIndex-1].style.display = "block";
	x[k].style.display = "noney";
    <?php
		$sec=1000*($gsec+3.2);
		echo("setTimeout(carousel, $sec);");
    ?>
}
</script>

<?php
}
?>
