<?php

 #
 # Auxogame
 #
 # info: main folder copyright file
 #
 #


global $ADIR_GAMES,$ADIR_GAMESEXT,$ADIR_LOGONAME,
		$ADIR_SHOP,$ADIR_FILENAME,$A_VALUTA,
		$ADIR_PROMO,$ADIR_PFILENAME,$ADIR_GAMENAME;

$ADIR_GAMES="../content/_sub_games";
$ADIR_GAMESEXT=".dat";
$ADIR_LOGONAME="icon.png";
$ADIR_GAMENAME="icon_text.html";
$ADIR_SHOP="../content/_sub_shop";
$ADIR_FILENAME="item.dat";
$A_VALUTA="€";
$ADIR_PROMO="../content/_promo";
$ADIR_PFILENAME="promo.dat";


global $SYSTEM_MENU,$SYSTEM_MENU_PLUGIN,$SYSTEM_MENU_PLUGIN_FUNC,$LANGUAGE_TITLE;

if ($LANGUAGE_TITLE=="hu"){
	#$SYSTEM_MENU_PLUGIN=array("Játékok","Bolti elemek");
	$SYSTEM_MENU_PLUGIN=array("Auxo-Beállítások");
}else{
	#$l1=language("Játékok");
	$SYSTEM_MENU_PLUGIN=array("Auxo-Settings");
}
$SYSTEM_MENU_PLUGIN_FUNC=array("auxosettings");


function auxosettings(){
	echo("<script type=\"text/javascript\">location.href='../public/index.php?content=Settings';</script>");
}



function auxo_message($mess){
	echo("<br /><br />");
	echo("<b style=\"color:red;\">Üzenet:</b> $mess<br />");
	#echo("<fieldset name=d id=d style=\"display:snone;text-align:left;\"><legend><b>Üzenet</b></legend><center><br />");
	#echo("<center>");
	#echo($mess);
	#echo("<br />");
	#echo("<br />");
	#echo("<form action=\"\" method=\"post\" enctype=\"multipart/form-data\">");
	#echo("<input id=\"submit\" type=\"submit\" name=\"gomb\" value=\"Rendben\" style=\"width:200px;\">");
	#echo("</form>");
	#echo("</center>");
	#echo("</fieldset><br />");
	echo("<br /><br />");
}


function auxo_message2($code,$mess){
	echo("<br /><br />");
	echo("<b style=\"color:red;\">Üzenet:</b> $mess<br />");
	#echo("<fieldset name=d id=d style=\"display:snone;text-align:left;\"><legend><b>Üzenet</b></legend><center><br />");
	#echo("<center>");
	#echo($mess);
	#echo("<br />");
	#echo("<br />");
	#echo("<form action=\"\" method=\"post\" enctype=\"multipart/form-data\">");
	#echo("<input type=\"hidden\" name=\"code\" id=\"code\" value=\"$code\">");
	#echo("<input id=\"submit\" type=\"submit\" name=\"gomb\" value=\"Tovább\" style=\"width:200px;\">");
	#echo("</form>");
	#echo("</center>");
	#echo("</fieldset><br />");
	echo("<br /><br />");
}


function auxo_message_q($mess,$code,$code2){
	echo("<br /><br />");
	echo("<fieldset name=d id=d style=\"display:snone;text-align:left;\"><legend><b>Üzenet</b></legend><center><br />");
	echo("<center>");
	echo($mess);
	echo("<br />");
	echo("<br />");
	echo("<form action=\"\" method=\"post\" enctype=\"multipart/form-data\">");
	echo("<input type=\"hidden\" name=\"code\" id=\"code\" value=\"$code\">");
	echo("<input type=\"hidden\" name=\"code2\" id=\"code\" value=\"$code2\">");
	echo("<input id=\"submit\" type=\"submit\" name=\"gomb\" value=\"Igen\" style=\"width:200px;\"> ");
	echo("<input id=\"submit\" type=\"submit\" name=\"gomb\" value=\"Nem\" style=\"width:200px;\">");
	echo("</form>");
	echo("</center>");
	echo("</fieldset><br />");
	echo("<br /><br />");
}



 ?>

