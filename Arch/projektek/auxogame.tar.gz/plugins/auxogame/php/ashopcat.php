<?php

 #
 # Auxogame
 #
 # info: main folder copyright file
 #
 #



function shop_move_files($source,$destination){
	$files=scandir($source);
	foreach ($files as $file) {
		if (in_array($file, array(".",".."))){
		}else{
			$code=rename($source."/".$file, $destination."/".$file);
			echo($source."/".$file." - ".$destination."/".$file."<br>");
			echo($code);
		}
	}
}



function shop_cat_edit(){
	global $ADIR_SHOP;

	$question=FALSE;
	$gomb=get_postdata("gomb");
	$data1=get_postdata("deldir");
	$data2=get_postdata("createdir");
	$g=substr($gomb,0,1);
	switch ($gomb){
		case "Törlés":
			$question=TRUE;
			$data1=get_postdata("deldir");
			auxo_message_q("Valóban töröljük a kategóriát? ($data1)",$data1,"");
			break;
		case "Új kategória":
			if ($data2<>""){
				$d=$ADIR_SHOP."/".$data2;
				$d=name_to_dir($d);
				mkdir($d);
				auxo_message("Új kategória létrehozva. ($data2)");
			}else{
				auxo_message("Nincs megadva az új kategória neve.");
			}
			break;
		case "Kategórianév módosítása";
			if (($data2<>"")and($data2<>"")){
				$s=name_to_dir($ADIR_SHOP."/".$data1);
				$d=name_to_dir($ADIR_SHOP."/".$data2);
				$s=name_to_dir($s);
				$d=name_to_dir($d);
				rename($s,$d);
				auxo_message("Kategória átnevezve. ($data1 -> $data2)");
			}else{
				auxo_message("Nincs megadva minden adat.");
			}
			break;
		case "Igen":
			$data1=get_postdata("code");
			if ($data1<>""){
				$s=$ADIR_SHOP."/".$data1;
				$s=name_to_dir($s);
				$ca=array("0","1","2","3","4","5","6","7","8","9");
				$c=substr($data1,0,1);
				if (in_array($c,$ca)){
					$cdir=scandir($s);
					$db=count($cdir);
					for($i=0;$i<$db;$i++){
						if (substr($cdir[$i],0,1)<>"."){
							$del=$ADIR_SHOP."/".$data1."/".$cdir[$i];
							$del=name_to_dir($del);
							if (is_dir($del)){
								$cd=scandir($del);
								$dbx=count($cd);
								for($ix=0;$ix<$dbx;$ix++){
									if (substr($cd[$ix],0,1)<>"."){
										$delx=$ADIR_SHOP."/".$data1."/".$cdir[$i]."/".$cd[$ix];
										$delx=name_to_dir($delx);
										if (is_dir($delx)){
											rmdir($delx);
										}else{
											unlink($delx);
										}
									}
								}
								rmdir($del);
							}else{
								unlink($del);
							}
						}
					}
					$s=name_to_dir($s);
					rmdir($s);
				}else{
					$id=id();
					$d=$ADIR_SHOP."/".$id;
					$d=name_to_dir($d);
					rename($s,$d);
				}
				auxo_message("Kategória törölve. ($data1)");
			}else{
				auxo_message("Nincs megadva minden adat.");
			}
			break;
		default:
			break;
	}

	if (!$question){
		echo("<br /><br />");
		echo("<fieldset name=d id=d style=\"display:snone;text-align:left;\"><legend><b>Termék kategóriák szerkesztése</b></legend><center><br />");
		echo("<br /><br />");
		echo("<center>");
		echo("<table style=\"width:80%;margin-left:20%;\" >");
		echo("<form action=\"\" method=\"post\" enctype=\"multipart/form-data\">");
		$cdir=scandir($ADIR_SHOP);
		echo("<tr><td width=50%>");
		echo("<select name=deldir id=deldir style=\"width:300px;\">");
		$db=count($cdir);
		if ($db>1){
			for($i=0;$i<$db;$i++){
				if (substr($cdir[$i],0,1)<>"."){
					$d=$cdir[$i];
					$d=dir_to_name($d);
					echo("<option value=$cdir[$i]>$d</option>");
				}
			}
		}
		echo("</select> ");
		echo("</td><td>");
		echo("<input id=\"submit\" type=\"submit\" name=\"gomb\" value=\"Törlés\" style=\"width:200px;\">");
		echo("</td></tr>");
		echo("<tr><td>");
		echo("<input type=\"text\" name=\"createdir\" id=\"createdir\" value=\"\" style=\"width:300px;\">	");
		echo("</td><td>");
		echo("<input id=\"submit\" type=\"submit\" name=\"gomb\" value=\"Új kategória\" style=\"width:200px;\">");
		echo("</td></tr>");
		echo("<tr><td></td><td>");
		echo("<input id=\"submit\" type=\"submit\" name=\"gomb\" value=\"Kategórianév módosítása\" style=\"width:200px;\">");
		echo("</td></tr></table>");
		echo("</form>");
		echo("</center>");
		echo("<br /><br />");
		echo("</fieldset><br />");
		echo("<br /><br />");
	}
}




 ?>

