<?php

 #
 # Auxogame
 #
 # info: main folder copyright file
 #
 #


function ax_games_list(){
	global $ADIR_GAMES,$ADIR_GAMESEXT,$INDEX_FILE,$ADIR_LOGONAME,
			$DIR_TEMPLATE,$TEMPLATE,$ADIR_GAMENAME;

	$dir=$ADIR_GAMES;
	$dir2="";
	$iconimage=$ADIR_LOGONAME;
	$icontitle=$ADIR_GAMENAME;
	$colnum=3;
	$game=get_sublink('game');
	if ($game<>""){
		$fdata=$dir."/".$game."/".$game.$ADIR_GAMESEXT;
		if (file_exists($fdata)){
			$t=file_get_contents($fdata);
			$itemdata=json_decode($t,true);
			if ($itemdata[3]<>""){
				echo("<div id=\"play\"><a href=\"http://casino.auxogame.com/games/$itemdata[3]\">Play online!</a></div>");
			}
			echo("<div class=\"imgparent\">");
			echo("<img class=\"gwidelogo\" src=\"$dir/$game/$itemdata[1]\"><br />");
			if ($itemdata[0]<>""){
				echo("<img class=imgparentimg2 src=\"$DIR_TEMPLATE/$TEMPLATE/new.png\" width=120px>");
			}
			echo("</div>");
			echo("<h1>$itemdata[2]</h1>");
			echo("<br /><pre>$itemdata[4]</pre><br />");
			echo("<hr /><br />");
			echo("<div class=post>");
			$fdir=$dir."/".$game;
			$cd=scandir($fdir);
			$db=count($cd);
			for($i=0;$i<$db;$i++){
				$d=$fdir."/".$cd[$i];
				if (is_dir($d)){
					$be=$d."/".$cd[$i].$ADIR_GAMESEXT;
					if (file_exists($be)){
						$tx=file_get_contents($be);
						$itemd=json_decode($tx,true);
						$cad=scandir($d);
						$adb=count($cad);
						$im=1;
						#echo("<center><table><tr><td valign=top>");
						#echo("<h1>$itemd[0]</h1>");
						#echo("<br />");
						#echo("<p>$itemd[0]</p>");
						#echo("</td><td align:right>");
						for($k=0;$k<$adb;$k++){
							$kit=substr($cad[$k],strlen($cad[$k])-3,3);
							$img=array("png","jpg","jpeg","gif");
							if (in_array($kit,$img)){
								echo("<img src=\"$d/$cad[$k]\" class=\"tn\">");
								if ($im%2==0){
									#echo("<hr / style=\"ddisplay:none;\">");
									#echo("<br />");
								}
								$im++;

							}
						}
						#echo("</td></tr></table>");
						echo("<h1>$itemd[0]</h1>");
						echo("<br />");
						echo("<pre>$itemd[1]</pre>");
						echo("<br /><br />");
						echo("<hr /><br />");
					}
				}
			}
			echo("</div>");
		}else{
			echo("<div class=post>");
			$fdata=$dir."/".$game."/".$INDEX_FILE;
			show_file($fdata);
			echo("<hr /><br />");
			echo("</div>");
		}
		$cdx=scandir($dir);
		$c=0;
		for($i=0;$i<count($cdx);$i++){
			if (substr($cdx[$i],0,1)<>"."){
				$cd[$c]=$cdx[$i];
				$c++;
			}
		}
		$i=0;
		while(($cd[$i]<>$game)and($i<$c)){
			$i++;
		}
		if ($cd[$i]==$game){
			echo("<center>");
			$link="?content=Games&game=";
			if ($i==0){
				$link=$link.$cd[1];
				$n=dir_to_name($cd[1]);
				echo("<a href=$link>Next game ($n) ></a>");
			}else{
				if ($i==($c-1)){
					$x=$c-2;
					$link=$link.$cd[$x];
					$n=dir_to_name($cd[$x]);
					echo("<a href=$link>< Previous game ($n)</a>");
				}else{
					$x=$i-1;
					$link1=$link.$cd[$x];
					$n=dir_to_name($cd[$x]);
					echo("<a href=$link1>< Previous game ($n)</a> | ");
					$x=$i+1;
					$link2=$link.$cd[$x];
					$n=dir_to_name($cd[$x]);
					echo("<a href=$link2>Next game ($n) ></a>");
				}
			}
			echo("</center>");
		}
	}else{
		if (is_dir($dir)){
			echo("<center><table width=90% text-align=center border=0px>");
			$cdir=scandir("$dir");
			$col=0;
			foreach ($cdir as $key => $value){
				if (!in_array($value,array(".","..",".htaccess",$INDEX_FILE))){
					if ($col>=$colnum){
						echo("</tr>");
						$col=0;
					}
					if ($col==0){
						echo("<tr>");
					}
					echo("<td align=center>");
					$link="?content=Games&game=$value";
					$fdata=$dir."/".$value."/".$value.$ADIR_GAMESEXT;
					if (file_exists($fdata)){
						$t=file_get_contents($fdata);
						$itemdata=json_decode($t,true);
						echo("<div class=\"imgparent\">");
						echo("<a href=$link><img class=imgparentimg1 src=\"$dir/$value/$itemdata[1]\" width=200px><br />");
						if ($itemdata[0]<>""){
							echo("<img class=imgparentimg2 src=\"$DIR_TEMPLATE/$TEMPLATE/new.png\" width=80px>");
						}
						echo("</div>");
						echo($itemdata[2]);
						echo("</a>");
					}else{
						echo("<a href=$link><img src=\"$dir/$value/$iconimage\" width=200px><br />");
						if (file_exists("$dir/$value/$icontitle")){
							show_file("$dir/$value/$icontitle");
						}else{
							$v=normal_dirname($value);
							echo("$v");
						}
					}
					echo("</a><br />");
					echo("</td>");
					$col++;
				}
			}
			echo("</table>");
		}
	}

}
