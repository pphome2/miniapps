<?php

 #
 # Auxogame
 #
 # info: main folder copyright file
 #
 #




function shop_dir_show(){
	global $USER_ADMIN,$USER_EDITOR,$EDIT_IN_PAGE,$DIR_TEMPLATE,$TEMPLATE,
			$ADIR_SHOP,$ADIR_FILENAME,$A_VALUTA,$LOGGED_IN_USER;

	$dir=$ADIR_SHOP;
	$link="?content=Shop&dir=";
	if (is_dir($dir)){
		$sub=get_postdata("gocontact");
		$item0=get_postdata("item0");
		$item1=get_postdata("item1");
		$item2=get_postdata("item2");
		if (substr($sub,0,4)=="Cont"){
			echo("<script>location.href='?content=Contact&mess2=".$item1."'</script>");
		}
		if ($item1==""){
			$item1=$item0;
		}else{
			$item1=$item1.", ".$item0;
		}
		echo("<form action=\"\" method=\"post\" enctype=\"multipart/form-data\">");
		echo("<input type=submit id=submit name=submit value=\"Új\" style=\"display:none;\">");
		echo("<input type=\"hidden\" name=\"item0\" id=\"item0\" value=\"$item0\">");
		echo("<input type=\"hidden\" name=\"item1\" id=\"item1\" value=\"$item1\">");
		echo("<input type=\"hidden\" name=\"item2\" id=\"item2\" value=\"\" onchange=\"document.getElementById('submit').click();\" >");
		if ($item1<>""){
			echo("<div id=fixedelement>");
			echo("<fieldset name=d id=d style=\"display:snone;text-align:left;\"><legend><b>My list</b></legend><center><br />");
			echo("<center>");
			echo("List of my interested items:<br /><br />");
			echo("$item1<br /><br />");
			echo("<br />");
			echo("<input id=\"submit\" type=\"submit\" name=\"gomb\" value=\"Clear list\" style=\"width:200px;\" onclick=\"document.getElementById('item1').value='';document.getElementById('item0').value='';\"> ");
			echo("<input id=\"submit\" type=\"submit\" name=\"gocontact\" value=\"Contact sales\" style=\"width:200px;\" onclick=\"location.href='?content=Contact&mess2=".$item1."'\">");
			echo("</center>");
			echo("</fieldset>");
			echo("</div><br />");
		}
		echo("<br /><br />");
		echo("<div class=\"ppost\">");
		echo("<center><table width=100% text-align=center border=0px>");
		$cdir=scandir("$dir");
		$first="";
		echo("<tr>");
		echo("<td width=30% align=left valign=top>");
		foreach ($cdir as $key => $value){
			$e=substr($value,0,1);
			if ($USER_ADMIN or $USER_EDITOR){
				$d=array(".");
			}else{
				$d=array("0","1","2","3","4","5","6","7","8","9",".");
			}
			if (!in_array($e,$d)){
				if ($first==""){
					$first=$value;
				}
				$l2=$link.$value;
				$pos=$value;
				#echo("<a href=$l2>");
				$v=$value;
				$v=dir_to_name($v);
				#echo("$v");
				#echo("</a><br />");
				echo("<input type=button id=submitcat name=submitcat value=\"$v\" style=\"width:100%;\" onclick=\"document.getElementById('item2').value=this.value;document.getElementById('item2').onchange()\" ><br />");
			}
		}
		echo("</td>");
		if ($item2<>""){
			$akt=$item2;
		}else{
			$akt=get_sublink("dir");
		}
		if ($akt==""){
			$akt=$first;
		}
		$pos=$dir."/".$akt;
		$pos=name_to_dir($pos);
		$tabdb=0;
		echo("<td align=left valign=top>");
		$cdir=scandir($pos);
		$db=count($cdir);
		for($i=0;$i<$db;$i++){
			if (substr($cdir[$i],0,1)<>'.'){
				$posx=$pos."/".$cdir[$i];
				$t=file_get_contents($posx."/".$ADIR_FILENAME);
				$itemdata=json_decode($t,true);
				$imgtomb=array();
				if (($itemdata[6]<>"")or($USER_EDITOR or $USER_ADMIN)){
					if (($USER_ADMIN or $USER_EDITOR)and($EDIT_IN_PAGE)){
						echo("<a href=?content=Editor&dir=Shop&mode=1&pos=$posx><div class=\"edit\"><img src=$DIR_TEMPLATE/$TEMPLATE/edit.png></div></a><br /><br />");
					}
					$xdir=scandir($posx);
					$db2=count($xdir);
					$dbimg=0;
					$dbfile=0;
					for($k=0;$k<$db2;$k++){
						if ((substr($xdir[$k],0,1)<>".")and($xdir[$k]<>$ADIR_FILENAME)){
							$fn=name_to_dir($xdir[$k]);
							$kit=substr($fn,strlen($fn)-3,3);
							$img=array("png","jpg","jpeg","gif");
							if (in_array($kit,$img)){
								$imgtomb[$dbimg]=$xdir[$k];
								$dbimg++;
							}else{
								$filetomb[$dbfile]=$xdir[$k];
								$dbfile++;
							}
						}
					}
					echo("<table><tr><td valign=top>");
					if (isset($imgtomb[0])){
						$img=$posx."/".$imgtomb[0];
					}else{
						$img=$posx;
					}
					if ($itemdata[5]<>""){
						echo("<label class=imglabel><center>SALE !</center></label>");
					}
					echo("<img id=\"imgblock$dbimg\" class=bigimg src=$img onclick=\"modalstart(this.id);\"><br />");
					echo("<div id=\"myModal\" class=\"modal\">");
					echo("  <span class=\"close\">&times;</span>");
					echo("  <img class=\"modal-content\" id=\"img01\">");
					echo("  <div id=\"caption\"></div>");
					echo("</div>");
					#echo("<img id=\"imgblock\" class=bigimg src=$img onclick=\"document.getElementById('imgblock').style.width='600px';\"><br />");
					for($c=1;$c<=$dbimg;$c++){
						$img=$posx."/".$imgtomb[$c-1];
						echo("<img id=$img src=$img class=littleimg onclick=\"document.getElementById('imgblock$dbimg').src=this.id;\" >");
						if (($c%3)==0){
							echo("<br />");
						}
					}
					echo("</td><td valign=top align=right>");
					echo("<h2>$itemdata[0]</h2>");
					echo("<br /><br />");
					if ($itemdata[5]<>""){
						echo("<b>Price: <font size=+1 style=\"text-decoration: line-through;\">$A_VALUTA $itemdata[4]</font></b><br />");
						echo("<b style=\"color:red;\"><font size=+3>$A_VALUTA $itemdata[5]</font></b><br /><br />");
					}else{
						echo("<b>Price: <font size=+2>$A_VALUTA $itemdata[4]</font></b><br /><br />");
					}
					if ($itemdata[6]==""){
						echo("<b>No in stock.</b><br /><br />");
					}
					#echo("<button id=\"submit\" style=\"width:200px;\"><a href=\"?content=Contact&mess2=$cdir[$i]\"\">Contact sales</a></button><br />");
					echo("<button id=\"submit\" name=\"$itemdata[0]\" style=\"width:200px;\" onclick=\"document.getElementById('item0').value=this.name;\">Send to list</button><br />");
					echo("<br /><br /></td></tr></table>");
					echo("<div class=\"tabs\">");
					echo("<div class=\"tab\">");
					echo("	<input type=\"radio\" id=\"tab-$tabdb\" name=\"tab-group-$i\" checked>");
					echo("	<label for=\"tab-$tabdb\">General</label>");
					echo("	<div class=\"content\" style=\"overflow: scroll;\">");
					echo("		<pre>$itemdata[2]</pre>");
					echo("	</div>");
					echo("</div>");
					$tabdb++;
					echo("<div class=\"tab\">");
					echo("	<input type=\"radio\" id=\"tab-$tabdb\" name=\"tab-group-$i\">");
					echo("	<label for=\"tab-$tabdb\">Details</label>");
					echo("	<div class=\"content\" style=\"overflow: scroll;\">");
					echo("		<pre>$itemdata[3]</pre>");
					echo("	</div>");
					echo("</div>");
					$tabdb++;
					echo("<div class=\"tab\">");
					echo("	<input type=\"radio\" id=\"tab-$tabdb\" name=\"tab-group-$i\">");
					echo("	<label for=\"tab-$tabdb\">Download</label>");
					echo("	<div class=\"content\" style=\"overflow: scroll;\">");
					if ($LOGGED_IN_USER){
						for($c=0;$c<$dbfile;$c++){
							$fil=$posx."/".$filetomb[$c];
							$fil=name_to_dir($fil);
							echo("<a href=$fil>$filetomb[$c]</a><br>");
						}
					}else{
						echo("Please log to see this content...<br /><br />");
						echo("If you haven't login onformation, please contect sales for it...<br /><br />");
						echo("<span id=more><a href=\"?content=Contact&mess2=Login information\"\">Contact sales</a></span><br />");
					}
					echo("	</div>");
					echo("</div>");
					$tabdb++;
					echo("</div>");
					echo("<center><hr width=40%></center><br /><br />");
				}
			}
		}
		echo("</td>");
		echo("</table>");
		echo("</div>");
		echo("</form>");
	}

}



?>
