<?php

 #
 # Auxogame
 #
 # info: main folder copyright file
 #
 #


function Shop_show_file_in_box($aktitem,$fullfile){
	global $CONTENT_CONTAINER_OPEN,$CONTENT_CONTAINER_END;

	if (count($fullfile)==0){
		$fullfile=file($aktitem."/index.php");
	}
	#echo("<div style=\"border:1px;overflow:scroll;height:400px;\"> ");
	echo($CONTENT_CONTAINER_OPEN);
	$sec=1;
	echo("<fieldset><legend><a href=#q name=$sec onclick=showhide('$sec')>Section: $sec - Edit</a></legend>");
	foreach($fullfile as $line){
		if (substr($line,0,3)=="<im"){
			echo("");
			$x=strpos($line,"src=");
			if ($x>0){
				$l2=$line;
				$line=substr($line,$x+5,strlen($line));
				$y=strpos($line,"\"");
				$line=substr($line,0,$y);
				$lar=explode("/",$line);
				$l=count($lar)-1;
				$line=$lar[$l];
				$line=substr($l2,0,4);
				$line=$line." title=\"$lar[$l]\" ";
				$line=$line.substr($l2,4,strlen($l2));
			}
		}
		if (substr($line,0,3)=="<hr"){
			$sec++;
			$line="</fieldset><fieldset><legend><a href=#q name=$sec onclick=showhide('$sec')>Section: $sec - Edit</a></legend>";
		}
		echo("$line");
	}
	echo("</fieldest>");
	echo("<br /><br />");
	echo($CONTENT_CONTAINER_END);
	#echo("</div>");
}



function Shop_load_file($file,&$formurl,&$formaddress,&$formtext,&$fullfile){
	$filec=file($file);
	$fullfile=$filec;
	$a=0;
	$t=0;
	$harray=array("<h1","<h2");
	foreach($filec as $line){
		#$line=strip_tags($line);
		$tag=substr($line,0,3);
		if (in_array($tag,$harray)){
			$formaddress[$a]=strip_tags($line);
			$a++;
		}
		if ($tag=="<p>"){
			$formtext[$t]=strip_tags($line);
			$t++;
		}
		if ($tag=="<di"){
			$x=strpos($line,"href=");
			if ($x>0){
				$line=substr($line,$x+6,strlen($line));
				$y=strpos($line,">");
				$line=substr($line,0,$y-1);
				$formurl[0]=$line;
				#echo($line);
			}
		}
	}
}



function Shop_line_out($formaddress,$formtext,$aktitem,&$i,&$output,$cdir,$sec,$class){
	$data=FALSE;
	if ($class<>""){
		foreach ($cdir as $key => $value){
			if (!in_array($value,array(".","..",".htaccess","index.php"))){
				$ext=substr($value,strlen($value)-3,3);
				if (in_array($ext,array("png","gif","jpg"))){
					$output[$i]="<img src=\"$aktitem/$value\" class=\"$class\">";
					$i++;
					$data=TRUE;
				}
			}
		}
	}
	if ($formaddress[$sec]<>""){
		if ($sec=="0"){
			$output[$i]="<h1>$formaddress[$sec]</h1>";
		}else{
			$output[$i]="<h2>$formaddress[$sec]</h2>";
		}
		$i++;
		$data=TRUE;
	}
	if ($formtext[$sec]<>""){
		switch ($sec){
			case 1:
				$output[$i]="<p>$formtext[$sec]</p>";
				$output[$i]=str_replace(PHP_EOL,"<br/>",$output[$i]);
				break;
			case 2:
				$output[$i]="<p><font size=+1 color=red ><b>$formtext[$sec]</b></font></p>";
				$output[$i]=str_replace(PHP_EOL,"<br/><br/></b></font>",$output[$i]);
				break;
			default:
				$output[$i]="<p>$formtext[$sec]</p>";
				$output[$i]=str_replace(PHP_EOL,"<br/>",$output[$i]);
				break;
		}
		$i++;
		$data=TRUE;
	}
	if ($data){
		$output[$i]="<hr>";
		$i++;
	}
}


function Shop_put_file($aktitem,$formurl,$formaddress,$formtext){
	$file=$aktitem."/index.php";
	$output=array();
	$i=0;
	$cdir=scandir("$aktitem");
	Shop_line_out($formaddress,$formtext,$aktitem,$i,$output,$cdir,"0","tn2");
	Shop_line_out($formaddress,$formtext,$aktitem,$i,$output,$cdir,"1","");
	Shop_line_out($formaddress,$formtext,$aktitem,$i,$output,$cdir,"2","");
	$k=$i-1;
	if ($output[$k]=="<hr>"){
		$output[$k]="";
	}
	$ret=save_file($file,$output);
	return($ret);
}


function Shop(){
	$sectionnum=3;
	$fullfile=array();
	$aktitem="";
	if (post_create_dir("defaultdir","createdir")){
		echo("<b><font color=red>Directory created.</font></b><br /><br />");
		$aktitem=get_postdata("defaultdir")."/".get_postdata("createdir");
	}
	if (post_delete_file("aktitem","deletefile")){
		echo("<b><font color=red>File deleted.</font></b><br /><br />");
	}
	$dir=get_postdata("aktitem");
	if (post_upload_image($dir,"fileupload","submit","")){
		echo("<b><font color=red>Image saved. (To show this image press Save button to regenerate page.)</font></b><br /><br />");
	}
	$aktitem=get_sublink("item");
	if ($aktitem==""){
		$aktitem=get_postdata("item");
	}
	$formurl=array("");
	$formaddress=array("","","","","");
	$formtext=array("","","","","");
	if ($aktitem<>""){
		if (get_postdata("text0")<>""){
			$formaddress[0]=get_postdata("address0");
			$formaddress[1]=get_postdata("address1");
			$formaddress[2]=get_postdata("address2");
			$formtext[0]=get_postdata("text0");
			$formtext[1]=get_postdata("text1");
			$formtext[2]=get_postdata("text2");
			if (Shop_put_file($aktitem,$formurl,$formaddress,$formtext)){
				echo("<b><font color=red>Data saved.</font></b><br /><br />");
			}
		}else{
			$file=$aktitem."/index.php";
			if (file_exists($file)){
				Shop_load_file($file,$formurl,$formaddress,$formtext,$fullfile);
			}
		}
	}
	echo("<fieldset style=\"display:snone;text-align:left;\">");
	if ($aktitem==""){
		$aktdir="../content/_sub_shop";
		echo("<legend>Directory: $aktdir</legend><center>");
	}else{
		$ar=explode("/",$aktitem);
		$last=count($ar)-1;
		echo("<legend>Selected item: $aktitem</legend><center>");
	}
	$l=language("Bolt");
	$link="?content=$l&item=";
	if (is_dir($aktdir)){
		echo("<center><br /><table style=\"width:100%;border:1px solid;border-color:blue;\" >");
		echo("<tr>");
		$cdir=scandir($aktdir);
		$db=0;
		foreach ($cdir as $key => $value){
			if (!in_array($value,array(".","..",".htaccess"))){
				#echo("$aktdir/$value");
				if (is_dir("$aktdir/$value")){
						if ($db>14){
					echo("</td>");
						$db=0;
					}
					if ($db==0){
						echo("<td style=\"vertical-align:top;text-align:center;border:1px solid;border-color:grey;\">");
					}
					$l=$link.$aktdir."/".$value;
					echo("<a href=$l>$value</a><br />");
					$db++;
				}
			}
		}
		if ($db>0){
			echo("</td>");
		}
		echo("</tr>");
		echo("</table></center>");
		echo("<br /><br />");
	}else{
		$l=language("Bolt");
		$link="?content=$l";
		echo("<a href=$link>Back to all shop items</a><br /><br />");
	}
	echo("</fieldset>");

	echo("<br /><br />");

	if ($aktitem==""){
		echo("<center>");
		echo("<br /><br />");
		echo("<form action=\"\" method=\"post\" enctype=\"multipart/form-data\">");
		echo("<input name=\"defaultdir\" type=\"hidden\" value=\"$aktdir\" >");
		echo("Create new shop item: ");
		echo("<input type=\"text\" name=\"createdir\" id=\"createdir\" value=\"\">		");
		echo("<input id=\"submit\" type=\"submit\" name=\"subm\" value=\"Create\">");
		echo("</form>");
	}else{
		Shop_show_file_in_box($aktitem,$fullfile);
		echo("<center>");
		echo("<form action=\"\" method=\"post\" enctype=\"multipart/form-data\">");
		echo("<br /><br />");
		echo("<fieldset style=\"display:snone;text-align:left;\"><legend>Editor</legend><center>");
		echo("<fieldset><center>");
		echo("<table width=90%><tr>");
		echo("<td align=center><a href=#q name=1 onclick=showhide('1')>Section: 1</a> </td>");
		echo("<td align=center><a href=#q name=2 onclick=showhide('2')>Section: 2</a> </td>");
		echo("<td align=center><a href=#q name=3 onclick=showhide('3')>Section: 3</a> </td>");
		echo("</tr></table>");
		echo("<fieldset name=1 id=1 style=\"display:none;text-align:left;\"><legend>Section: 1</legend><center>");
		echo("Item information: ");
		echo("<br /><br /><textarea name=\"text0\" rows=\"4\" cols=\"80\" maxlenght=200>");
		echo("$formtext[0]</textarea>");
		echo("<br /><br />");
		echo("</fieldset>");
		echo("<fieldset name=2 id=2 style=\"display:none;text-align:left;\"><legend>Section: 2</legend><center>");
		echo("Item properties and order information: ");
		echo("<br /><br /><textarea name=\"text1\" rows=\"4\" cols=\"80\" maxlenght=200>");
		echo("$formtext[1]</textarea>");
		echo("<br /><br />");
		echo("</fieldset>");
		echo("<fieldset name=3 id=3 style=\"display:none;text-align:left;\"><legend>Section: 3</legend><center>");
		echo("Price and other: ");
		echo("<br /><br /><textarea name=\"text2\" rows=\"4\" cols=\"80\" maxlenght=200>");
		echo("$formtext[2]</textarea>");
		echo("<br /><br />");
		echo("</fieldset>");
		echo("<br /><br />");
		echo("<input id=\"submit\" type=\"submit\" name=\"submit\" value=\"Save\">");
		echo("<br /><br />");
		echo("</form>");
		echo("</fieldset>");


		echo("<br /><br />");
		echo("<br /><br />");
		echo("<fieldset name=f id=f style=\"display:snone;text-align:left;\"><legend>Image upload</legend><center><br />");
		echo("<form action=\"\" method=\"post\" enctype=\"multipart/form-data\">");
		echo("<input name=\"aktitem\" type=\"hidden\" value=\"$aktitem\" >");
		echo(" Image to upload: ");
		echo("<input type=\"file\" name=\"fileupload\" id=\"fileupload\"> ");
		echo("<input id=\"submit\" type=\"submit\" name=\"submit\" value=\"Upload\">");
		echo("</form>");
		echo("</fieldset>");
	}
	echo("<br /><br />");
	echo("<br /><br />");
	if (is_dir($aktitem)){
		echo("<center>");
		echo("<fieldset name=d id=d style=\"display:snone;text-align:left;\"><legend>Delete</legend><center><br />");
		echo("<form action=\"\" method=\"post\" enctype=\"multipart/form-data\">");
		echo("<input name=\"aktitem\" type=\"hidden\" value=\"$aktitem\" >");
		echo("File to delete: <select name=\"deletefile\">");
		$cdir=scandir($aktitem);
		$db=0;
		foreach ($cdir as $key => $value){
			if (!in_array($value,array(".","..",".htaccess"))){
				#echo("$aktdir/$value");
				echo("<option value=\"$value\">$value</option>");
			}
		}
		echo("</select>");
		echo(" <input id=\"submit\" type=\"submit\" name=\"submit\" value=\"Delete\">");
		echo("</form></center>");
		echo("</fieldset>");
		echo("<br /><br />");
	}
	echo("</center>");
}



function Shop_items(){
	Shop();
}




function shop1(){
	global $REQUEST_DATA,$PORTAL_NAME;

	$mess="";
	$pcount=count($REQUEST_DATA);
	if ($pcount>5){
		foreach($REQUEST_DATA['in'] as $selected){
			$mess=$mess."<br />".valid_input($selected);
		}
		if ($mess<>""){
			$mess="Please send me future information for this items:<br /><br />".$mess."<br /><br />";
		}
		$semail=valid_input($REQUEST_DATA["email"]);
		$smess=valid_input($REQUEST_DATA["mess"]);
		$skell=valid_input($REQUEST_DATA["kell"]);
		$skell2=valid_input($REQUEST_DATA["kell2"]);
	}
	return($mess);
}



?>
