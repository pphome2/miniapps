<?php

 #
 # Auxogame
 #
 # info: main folder copyright file
 #
 #




function Games_show_file_in_box($aktgame,$fullfile){
	global $CONTENT_CONTAINER_OPEN,$CONTENT_CONTAINER_END;

	if (count($fullfile)==0){
		$fullfile=file($aktgame."/index.php");
	}
	#echo("<div style=\"border:1px;overflow:scroll;height:400px;width:100%;\"> ");
	echo($CONTENT_CONTAINER_OPEN);
	$sec=1;
	echo("<fieldset><legend><a href=#q name=$sec onclick=showhide('$sec')>Section: $sec</a></legend>");
	foreach($fullfile as $line){
		if (substr($line,0,3)=="<im"){
			echo("");
			$x=strpos($line,"src=");
			if ($x>0){
				$l2=$line;
				$line=substr($line,$x+5,strlen($line));
				$y=strpos($line,"\"");
				$line=substr($line,0,$y);
				$lar=explode("/",$line);
				$l=count($lar)-1;
				$line=$lar[$l];
				$line=substr($l2,0,4);
				$line=$line." title=\"$lar[$l]\" ";
				$line=$line.substr($l2,4,strlen($l2));
			}
		}
		if (substr($line,0,3)=="<hr"){
			$sec++;
			$line="</fieldset><fieldset><legend><a href=#q name=$sec onclick=showhide('$sec')>Section: $sec - Edit</a></legend>";
		}
		echo("$line");
	}
	echo("<br /><br />");
	echo("<br /><br />");
	echo("<br /><br />");
	echo("</fieldest>");
	echo($CONTENT_CONTAINER_END);
	#echo("</div>");
}



function Games_load_file($file,&$formurl,&$formaddress,&$formtext,&$fullfile){
	$filec=file($file);
	$fullfile=$filec;
	$a=0;
	$t=0;
	$harray=array("<h1","<h2");
	foreach($filec as $line){
		#$line=strip_tags($line);
		$tag=substr($line,0,3);
		if (in_array($tag,$harray)){
			$formaddress[$a]=strip_tags($line);
			$a++;
		}
		if ($tag=="<p>"){
			$formtext[$t]=strip_tags($line);
			$t++;
		}
		if ($tag=="<di"){
			$x=strpos($line,"href=");
			if ($x>0){
				$line=substr($line,$x+6,strlen($line));
				$y=strpos($line,">");
				$line=substr($line,0,$y-1);
				$formurl[0]=$line;
				#echo($line);
			}
		}
	}
}



function Games_line_out($formaddress,$formtext,$aktgame,&$i,&$output,$cdir,$sec,$imgsec,$class){
	$data=FALSE;
	foreach ($cdir as $key => $value){
		if (!in_array($value,array(".","..",".htaccess","index.php"))){
			if (substr($value,0,1)==$imgsec){
				$output[$i]="<img src=\"$aktgame/$value\" class=\"$class\">";
				$i++;
				$data=TRUE;
			}
		}
	}
	if ($formaddress[$sec]<>""){
		if ($sec=="0"){
			$output[$i]="<h1>$formaddress[$sec]</h1>";
		}else{
			$output[$i]="<h2>$formaddress[$sec]</h2>";
		}
		$i++;
		$data=TRUE;
	}
	if ($formtext[$sec]<>""){
		$output[$i]="<p>$formtext[$sec]</p>";
		$output[$i]=str_replace(PHP_EOL,"<br/>",$output[$i]);
		$i++;
		$data=TRUE;
	}
	if ($data){
		$output[$i]="<hr>";
		$i++;
	}
}


function Games_put_file($aktgame,$formurl,$formaddress,$formtext){
	$file=$aktgame."/index.php";
	$output=array();
	$i=0;
	if ($formurl[0]<>""){
		$output[$i]="<div id=\"play\"><a href=\"".$formurl[0]."\">Play online!</a></div>";
		$i++;
	}
	$cdir=scandir("$aktgame");
	Games_line_out($formaddress,$formtext,$aktgame,$i,$output,$cdir,"0","1","gwidelogo");
	Games_line_out($formaddress,$formtext,$aktgame,$i,$output,$cdir,"1","2","tn");
	Games_line_out($formaddress,$formtext,$aktgame,$i,$output,$cdir,"2","3","tn");
	Games_line_out($formaddress,$formtext,$aktgame,$i,$output,$cdir,"3","4","tn");
	Games_line_out($formaddress,$formtext,$aktgame,$i,$output,$cdir,"4","5","tn");
	$k=$i-1;
	if ($output[$k]=="<hr>"){
		$output[$k]="";
	}
	$ret=save_file($file,$output);
	return($ret);
}


function Games(){
	$sectionnum=5;
	$fullfile=array();
	$aktgame="";
	if (post_create_dir("defaultdir","createdir")){
		echo("<b><font color=red>Directory created.</font></b><br /><br />");
		$aktgame=get_postdata("defaultdir")."/".get_postdata("createdir");
	}
	if (post_delete_file("aktgame","deletefile")){
		echo("<b><font color=red>File deleted.</font></b><br /><br />");
	}
	$dir=get_postdata("aktgame");
	$prename=get_postdata("prename");
	if ($prename<>""){
		$prename=$prename."_";
	}
	$target_file=basename($_FILES["fileupload"]["name"]);
	if ($target_file=="icon.png"){
		$prename="";
	}
	if (post_upload_image($dir,"fileupload","submit",$prename)){
		echo("<b><font color=red>Image saved. (To show this image press Save button to regenerate page.)</font></b><br /><br />");
	}
	$aktgame=get_sublink("game");
	if ($aktgame==""){
		$aktgame=get_postdata("game");
	}
	$formurl=array("");
	$formaddress=array("","","","","");
	$formtext=array("","","","","");
	if ($aktgame<>""){
		if (get_postdata("url")<>""){
			$formurl[0]=get_postdata("url");
			$formaddress[0]=get_postdata("address0");
			$formaddress[1]=get_postdata("address1");
			$formaddress[2]=get_postdata("address2");
			$formaddress[3]=get_postdata("address3");
			$formaddress[4]=get_postdata("address4");
			$formtext[0]=get_postdata("text0");
			$formtext[1]=get_postdata("text1");
			$formtext[2]=get_postdata("text2");
			$formtext[3]=get_postdata("text3");
			$formtext[4]=get_postdata("text4");
			if (Games_put_file($aktgame,$formurl,$formaddress,$formtext)){
				echo("<b><font color=red>Data saved.</font></b><br /><br />");
			}
		}else{
			$file=$aktgame."/index.php";
			if (file_exists($file)){
				Games_load_file($file,$formurl,$formaddress,$formtext,$fullfile);
			}
		}
	}
	echo("<fieldset style=\"display:snone;text-align:left;\">");
	if ($aktgame==""){
		$aktdir="../content/_sub_games";
		echo("<legend>Directory: $aktdir</legend><center>");
	}else{
		$ar=explode("/",$aktgame);
		$last=count($ar)-1;
		echo("<legend>Selected game: $aktgame</legend><center>");
	}

	$l=language("Játékok");
	$link="?content=$l&game=";
	if (is_dir($aktdir)){
		echo("<center><br /><table style=\"width:100%;border:1px solid;border-color:blue;\" >");
		echo("<tr>");
		$cdir=scandir($aktdir);
		$db=0;
		foreach ($cdir as $key => $value){
			if (!in_array($value,array(".","..",".htaccess"))){
				#echo("$aktdir/$value");
				if (is_dir("$aktdir/$value")){
						if ($db>14){
					echo("</td>");
						$db=0;
					}
					if ($db==0){
						echo("<td style=\"vertical-align:top;text-align:center;border:1px solid;border-color:grey;\">");
					}
					$l=$link.$aktdir."/".$value;
					echo("<a href=$l>$value</a><br />");
					$db++;
				}
			}
		}
		if ($db>0){
			echo("</td>");
		}
		echo("</tr>");
		echo("</table></center>");
		echo("<br /><br />");
	}else{
		$l=language("Játékok");
		$link="?content=$l";
		echo("<a href=$link>Back to all games</a><br /><br />");
	}
	echo("</fieldset>");

	echo("<br /><br />");

	if ($aktgame==""){
		echo("<center>");
		echo("<br /><br />");
		echo("<form action=\"\" method=\"post\" enctype=\"multipart/form-data\">");
		echo("<input name=\"defaultdir\" type=\"hidden\" value=\"$aktdir\" >");
		echo("Create new game item: ");
		echo("<input type=\"text\" name=\"createdir\" id=\"createdir\" value=\"\">		");
		echo("<input id=\"submit\" type=\"submit\" name=\"subm\" value=\"Create\">");
		echo("</form>");
	}else{
		Games_show_file_in_box($aktgame,$fullfile);
		echo("<center>");
		echo("<form action=\"\" method=\"post\" enctype=\"multipart/form-data\">");
		echo("<br /><br />");
		echo("<fieldset style=\"display:snone;text-align:left;\"><legend>Editor</legend><center>");
		echo("<fieldset><center>");
		echo("<table width=90%><tr>");
		echo("<td align=center><a href=#q name=0 onclick=showhide('0')>Play URL</a> </td>");
		echo("<td align=center><a href=#q name=1 onclick=showhide('1')>Section: 1</a> </td>");
		echo("<td align=center><a href=#q name=2 onclick=showhide('2')>Section: 2</a> </td>");
		echo("<td align=center><a href=#q name=3 onclick=showhide('3')>Section: 3</a> </td>");
		echo("<td align=center><a href=#q name=4 onclick=showhide('4')>Section: 4</a> </td>");
		echo("<td align=center><a href=#q name=5 onclick=showhide('5')>Section: 5</a> </td>");
		echo("</tr></table>");
		echo("</fieldset>");
		echo("<fieldset name=0 id=0 style=\"display:snone;text-align:left;\"><legend>Play URL</legend><center>");
		echo("<br />If demo available, give me ");
		echo("URL: <input name=\"url\" type=\"text\" value=\"$formurl[0]\" >");
		echo("<br /><br />");
		echo("</fieldset>");
		for($i=0;$i<$sectionnum;$i++){
			$k=$i+1;
			echo("<fieldset name=$k id=$k style=\"display:none;text-align:left;\"><legend>Section: $k</legend><center>");
			echo("Address and text: <input name=\"address$i\" type=\"text\" value=\"$formaddress[$i]\" >");
			echo("<br /><br /><textarea name=\"text$i\" rows=\"4\" cols=\"80\" maxlenght=200>");
			echo("$formtext[$i]</textarea>");
			echo("<br /><br />");
			echo("</fieldset>");
		}
		echo("<br /><br />");
		echo("<input id=\"submit\" type=\"submit\" name=\"submit\" value=\"Save\">");
		echo("<br /><br />");
		echo("</form>");
		echo("</fieldset>");


		echo("<br /><br />");
		echo("<br /><br />");
		echo("<fieldset name=f id=f style=\"display:snone;text-align:left;\"><legend>Image upload</legend><center><br />");
		echo("<form action=\"\" method=\"post\" enctype=\"multipart/form-data\">");
		echo("<input name=\"aktgame\" type=\"hidden\" value=\"$aktgame\" >");
		echo("Section: <select name=\"prename\">");
		for($i=0;$i<$sectionnum;$i++){
			$k=$i+1;
			echo("<option value=\"$k\">$k</option>");
		}
		echo("</select>");
		echo(" Image to upload: ");
		echo("<input type=\"file\" name=\"fileupload\" id=\"fileupload\"> ");
		echo("<input id=\"submit\" type=\"submit\" name=\"submit\" value=\"Upload\">");
		echo("</form>");
		echo("</fieldset>");
	}
	echo("<br /><br />");
	echo("<br /><br />");
	if (is_dir($aktgame)){
		echo("<center>");
		echo("<fieldset name=d id=d style=\"display:snone;text-align:left;\"><legend>Delete</legend><center><br />");
		echo("<form action=\"\" method=\"post\" enctype=\"multipart/form-data\">");
		echo("<input name=\"aktgame\" type=\"hidden\" value=\"$aktgame\" >");
		echo("File to delete: <select name=\"deletefile\">");
		$cdir=scandir($aktgame);
		$db=0;
		foreach ($cdir as $key => $value){
			if (!in_array($value,array(".","..",".htaccess"))){
				#echo("$aktdir/$value");
				echo("<option value=\"$value\">$value</option>");
			}
		}
		echo("</select>");
		echo(" <input id=\"submit\" type=\"submit\" name=\"submit\" value=\"Delete\">");
		echo("</form></center>");
		echo("</fieldset>");
		echo("<br /><br />");
	}
	echo("</center>");
}





?>
