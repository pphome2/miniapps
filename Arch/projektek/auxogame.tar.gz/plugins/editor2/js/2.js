
CKEDITOR.replace( 'filedataeditor' );