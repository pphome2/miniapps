
<?php
    #echo("<script src=\"https://cdn.ckeditor.com/4.6.2/full-all/ckeditor.js\"></script>");
    #echo("<script src=\"https://cdn.ckeditor.com/4.6.2/basic/ckeditor.js\"></script>");
    echo("<script src=\"https://cdn.ckeditor.com/4.6.2/standard/ckeditor.js\"></script>");

    #echo("<script src=\"../plugins/ckeditor/ckeditor.js\"></script>");

    #echo("<script src='https://cloud.tinymce.com/stable/tinymce.min.js'></script>");
    #echo("<script>  tinymce.init({    selector: '#filedata'  });  </script>");

    #echo("<script src='../plugins/ckeditor/ckeditor.js'></script>");

?>