
		echo("<img id=\"imgblock$dbimg\" class=bigimg src=$img onclick=\"modalstart(this.id);\"><br />");
		echo("<div id=\"myModal\" class=\"modal\">");
		echo("  <span class=\"close\">&times;</span>");
		echo("  <img class=\"modal-content\" id=\"img01\">");
		echo("  <div id=\"caption\"></div>");
		echo("</div>");
