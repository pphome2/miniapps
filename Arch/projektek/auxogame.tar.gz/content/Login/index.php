<br /><br />

<?php
    if (logged()){
	echo("Succesful logged in.");
?>

<center>
<form action="" method=post enctype=multipart/form-data>
<br /><br />
<br /><br />
<input type=hidden name="logout" id="logout" value="logout">
<input id=submit type=submit name=subm value=Logout>
</form>
<br /><br />
<br /><br />
<br /><br />
<br /><br />

<?php    }else{ ?>

<br /><br />
<br /><br />
<center>
<form action="" method=post enctype=multipart/form-data>
User name:
<br /><br />
<input type=text name="username" id="username">
<br /><br />
Password:
<br /><br />
<input type=password name="password" id="password">
<br /><br />
<br /><br />
<input id=submit type=submit name=subm value=Login>
</form>

<?php } ?>

<br /><br />
