<h1>Shop</h1>
<br /><img src="../content/Shop/shop.png" class="tn"><br />
<br /><br />
<h2>Items</h2>
<p>You see Here you can view and get information about new and used items we offer.</p>

<p>Select the item you are interested in and send your contact data
to inform other information.</p>

<p>Further information on the operation of the store, shipments, prices,
please contact us at the Contact page (from menu).</p>


<?php


$mess=shop();

$cf=array("email","mess");
$cfc=array("kell","kell2");
$co=contactform_to_mail($cf,$cfc,$mess);
if ($co<>""){
  if (strlen($co)>2){
    echo("<br /><br /><br /><h3 style=color:red;>Thanks, your e-mail sent to as. <br />We will contact you soon...</h3><br /><br /><br />");
  }else{
    if ($co=="-"){
      echo("<br /><br /><br /><h3 style=color:red;>Please fill in all fields...</h3><br /><br /><br />");
    }
  }
};

?>

<form id="shop" action="?content=shop" method="get" accept-charset="UTF-8">
    <input name="content" type="hidden" value="shop" >


<br /><br />
<h2>New items</h2>
<br /><br />

<center>
<table class="items">
    <tr>
	<th style="width:30%;border:1px solid;">Image</th>
	<th style="width:50%;border:1px solid;">Details</th>
	<th style="width:20%;border:1px solid;">I am interested</th>
    </tr>
    <tr>
	<td style="border:1px solid;">1</td>
	<td style="border:1px solid;">1</td>
	<td style="border:1px solid;"><input id="ch1" type="checkbox" name="in[]" value="1" />teszt</td>
    </tr>
    <tr>
	<td style="border:1px solid;">1</td>
	<td style="border:1px solid;">1</td>
	<td style="border:1px solid;"><input id="ch1" type="checkbox" name="in[]" value="2" />teszt</td>
    </tr>
    <tr>
	<td style="border:1px solid;">1</td>
	<td style="border:1px solid;">1</td>
	<td style="border:1px solid;"><input id="ch1" type="checkbox" name="in[]" value="3" />teszt</td>
    </tr>
    <tr>
	<td style="border:1px solid;">1</td>
	<td style="border:1px solid;">1</td>
	<td style="border:1px solid;"><input id="ch1" type="checkbox" name="in[]" value="4" />teszt</td>
    </tr>
</table>
</center>

<br /><br />
<h2>Used items</h2>
<br /><br />

<center>
<table style="border:1px solid;color:black;border-color:blue;width:90%">
    <tr>
	<th style="width:30%;border:1px solid;">Image</th>
	<th style="width:50%;border:1px solid;">Details</th>
	<th style="width:20%;border:1px solid;">I am interested</th>
    </tr>
    <tr>
	<td style="border:1px solid;">1</td>
	<td style="border:1px solid;">1</td>
	<td style="border:1px solid;"><input id="ch1" type="checkbox" name="in[]" value="5" />teszt</td>
    </tr>
</table>
</center>




<br /><br />
<h2>Your personal data</h2>
<br /><br />

	<center>
	<table>
	<tr>
		<td>Your E-mail:</td>
		<td><input type="text" name="email" value=""> </td>
	</tr>

	<tr>
		<td>Your message:</td>
		<td><?php echo("<text"."area");?> name="mess"><?php echo("</text":"area>"); ?></td>
	</tr>

	<tr>
		<?php $k1="0";$k2="0";$k3="0";form_protect($k1,$k2,$k3) ?>
		<td>Please give me amount of numbers:<br /> <?php echo("$k1 and $k2"); ?></td>
		<td><input type="text" name="kell" value="">
		<input name="kell2" type="hidden" value="<?php echo($k3); ?>" >
		</td>
	</tr>
	<tr>
		<td>&nbsp;</td>
		<td><input id="submit" type="submit" name="submit" value="Send"></td>
	</tr>
	</table>
</form>


