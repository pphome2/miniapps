
<?php
	//$l=language("Beállítások");
	//echo("<h1>$l</h1><br /><br />");

global $USER_ADMIN,$USER_EDITOR;


if ($USER_ADMIN or $USER_EDITOR){

?>

<h1>Beállítások</h1>

<center>
	<p id=more>
		<a href="../admin/index.php?content=Content&dir=../content/Home">Nyitóoldal, főlap szerkesztése</a><br />
		<a href="?content=Editor&dir=AD">Reklám (promóciós sáv) szerkesztése</a><br />
		<a href="../admin/index.php?content=Content&dir=../content/Platform">Platform oldal szerkesztése</a><br />
		<a href="?content=Editor&dir=Games">Játékok szerkesztése</a><br />
		<a href="?content=Editor&dir=Shop&mode=0">Shop kategóriák kezelése</a><br />
		<a href="?content=Editor&dir=Shop&mode=1">Shop elemek kezelése</a><br />
	</p>
</center>
<br /><br /><br /><br /><br /><br />


<?php

}else{

?>

<br /><br />
<p>Kérem jelentkezzen be megfelelő jogosultságú felhasználóként.</p>
<br /><br /><br /><br /><br /><br />

<?php

}

?>



