
<img src="../content/Home/auxogamevideoslot.png" style="float: right;">

<h1>What is AUXO game?</h1>

<p>AUXO game is a video slot machine board, with many multigame program packages.<br><br></p>



<p>As a slot machine operator you probably experienced that disappointing situation,
when a huge manufacturer’s expensive machine suddenly paid the last few months income
and instead of the money which seemed sure only unpleasant questions remained. Whether am I
going to see my money again? When will it occur again?</p>

<h2>This situation is avoided!</h2>

<p>AUXO game is not promising enormous profit but much more important security.
And in a long term stable, predictable monthly income, even for years. Of course
the algorithms of  many  years  development  along  to  the  safety  of  the  operators  offers  a  perfect
game  experience to the  players.  As  a  result  in many countries  of Europe  a few thousand
AUXO game is in operation giving great satisfaction both to operators and players. </p>

<h2>How much does it cost?</h2>

<p>The "quality" does not mean "expensive"! AUXO game offers the reliable quality cheaper
than the competitors. To have a concrete offer please ask quotation!</p>



<p id="more">
<a href="?content=Contact">I want more information about AUXO game!</a>
</p>
