<div id="play"><a href="http://casino.auxogame.com/games/jfruit">Play online!</a></div><img src="../content/_sub_games/jokerfruit/selogo_ovab.png" class="gwidelogo"><h1>Joker Fruit</h1>

<p>The game is a program with 4 reels and 5 winning lines from the left side, and another 5 winning
lines from the right side. The purpose of the game is to sort out as many similar symbols as possible
across the winning lines.</p>
<hr>
<img src="../content/_sub_games/jokerfruit/joker_fruit_win.jpg" class="tn">
<img src="../content/_sub_games/jokerfruit/joker_fruit_main.jpg" class="tn">
<h2>Playing the game</h2>
<p>At the beginning of the game the player can set the actual value of the bet with the BET button. The
value of the bet is deducted from the CREDIT after pressing the START button, the three reels start
to rotate and within a short time they will stop. If there was a winning combination, then its value
appears in the WIN field, with the START button it goes to the CREDIT field or with the BET
button the prize is transferred to the doubling process. If no winning combination is achieved, a new
game starts at the prize of bet by pressing the START button again. During the game all of the
twenty seven winning lines are always active.</p>
<hr>
<img src="../content/_sub_games/jokerfruit/joker_fruit_paytable.jpg" class="tn">
<h2>Bets and rewards</h2>
<p>The lower and upper limit of the bet is adjustable by the operator. The reward table is displayed on
the upper monitor in two screen mode; with one display the HOLD4 button shows.</p>
