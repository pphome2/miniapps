<img src="../content/_sub_games/golddigger/gold_digger_wide.png" class="gwidelogo"><h1>Gold Digger</h1>


<p>The game is a program with three reels and eight winning lines, in which the computer simulation of the traditional engine powered reels realised.
</p>

<hr>
<img src="../content/_sub_games/golddigger/fokep.png" class="tn">
<img src="../content/_sub_games/golddigger/win.jpg" class="tn">
<h2>Playing the game</h2>
<p>Set the value of the bet with the BET button. The value of the bet is deducted from the CREDIT after pressing the START button, the five reels starts to rotate and within a short time they will stop one by one. By pressing the HOLD button any reel can be stopped.
On one line three similar symbols means a winning combination. The SCATTER (GD) symbol can be anywhere on the game field, if two or more appears it means a reward.
If there was a winning combination, then its value appears in the WIN field, with the START button it goes to the CREDIT field or with the BET button to the doubling game.
</p>


<hr>
<h2>Bonus games</h2>
<p>The bonus table is on the left side of the game field. There are three different bonuses; each has its own counter. The reward lowers the appropriate counter and if it reaches 0, it is activated.
During the bonus games the rewards are the same as in the main game, but the bonus counters value in unchanged.
The sum of the main and bonus games reward goes into the prize. This value with the START button can be credited or with the BET button it can be doubled.
</p>

<hr>
<img src="../content/_sub_games/golddigger/bon_end.jpg" class="tn">
<img src="../content/_sub_games/golddigger/gd_bonus.jpg" class="tn">

<h2>Scatter bonus</h2>
<p>On the game field three or more SCATTER (GD) symbol lowers its counter and when it reaches zero, two free spins is the reward.
During the free spins the background colour of the game is changed, in the game only the Scatter, Star and Bag symbols plays, on the reels empty spaces left.
</p>

<hr>
<img src="../content/_sub_games/golddigger/colt_bonus.jpg" class="tn">
<h2>Colt bonus</h2>
<p>The counter is lowered by the COLT reward. When reaching the 0 the prize is five free spin and six bullets. After a rotation on any lines there are two similar symbols, and then the third can be replaced by a shot. The possible positions are viewable by the HOLD2 button and we can see the possible reward value too. The HOLD4 button is for the shot. After a spin we can shot as many as necessary according to the possible combinations or without any shot we can rotate a new by pressing the START button. It depends from the skills of the player the usage of the six shot in the five spin.
</p>

<hr>
<img src="../content/_sub_games/golddigger/robban.jpg" class="tn">
<img src="../content/_sub_games/golddigger/dinamit_bosus.jpg" class="tn">
<h2>Dynamite bonus</h2>
<p>The counter is lowered by the DYNAMITE reward. After reaching 0 an undefined number of free spins starts. The end of the game is signalled by a timed explosive device on the game field.
</p>

<hr>
<img src="../content/_sub_games/golddigger/info_table.jpg" class="tn">
<img src="../content/_sub_games/golddigger/win_table.jpg" class="tn">
<h2>Paytable</h2>
<p>The value of the bet is the following: 1, 5, 10, 20, 50, 100, 200, 300, 400, 500, 1000, 1500 and 2000. The lowest and highest limit of the selectable bet is adjustable by the operator and therefore it may differ from the above list.
</p>

<h2>Reward multipliers</h2>
<p>The base of the prize is all bets – the price of one spin.
</p>
