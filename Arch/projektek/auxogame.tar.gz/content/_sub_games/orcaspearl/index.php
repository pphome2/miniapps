<img src="../content/_sub_games/orcaspearl/orca_wide.png" class="gwidelogo"><h1>Orca's Pearl</h1>

<p>The game is a program with five reels and twenty winning lines, in which the computer simulation of the traditional engine powered reels realised. The purpose of the game is to sort out as many as possible similar symbols on the winning lines.
</p>

<hr>
<img src="../content/_sub_games/orcaspearl/win.jpg" class="tn">
<img src="../content/_sub_games/orcaspearl/fokep.png" class="tn">
<h2>Playing the game</h2>
<p>At the beginning of the game we can set the value of the bet with the BET button. When changing the lines, the winning lines are displayed on the game field. The value of the bet is deducted from the CREDIT after pressing the START button, the five reels starts to rotate and within a short time they will stop one by one. With the HOLD buttons the reels can be stopped.
If there was a winning combination, then its value appears in the WIN field. After the prize animation the winning symbols disappearing with a vortex animation and the empty spaces are filled with new symbols from the top to the bottom. The newly formed rewards are calculated double, triple, quadruple and quintuple multipliers. This multiplier maximum is five.
This prize can go to the CREDIT with the START button or with the BET button to the doubling game.
The WILD (Orca) symbol replaces any, except SCATTER (Shell), but alone it has a prize.
On the given line always the bigger prize is valid.
</p>


<hr>
<h2>Free spin</h2>
<p>The SCATTER (Shell) symbol counts on the whole game field, not just only on the active lines. If three or more SCATTER symbols occur, above the prize, 12 free spins is the reward and the rewards calculated as double. During the free spins, there can be 12 more free spins reward.
</p>
<img src="../content/_sub_games/orcaspearl/free_end.jpg" class="tn">
<img src="../content/_sub_games/orcaspearl/free_win.jpg" class="tn">
<img src="../content/_sub_games/orcaspearl/free_lett.jpg" class="tn">

<hr>
<img src="../content/_sub_games/orcaspearl/info_table.jpg" class="tn">
<h2>Bets and paytable</h2>
<p>The number of the winning lines is 20 and not adjustable.
The value of the bet on one line is the following: 1, 5, 6, 10, 20, 30, 40, 50, 60, 70, 80, 90 and 100. The value of all bets cannot be bigger than 2000 or the set maximum.
The lowest and highest limit of the selectable bet is adjustable by the operator and therefore it may differ from the above list. The Paytable is displayed on the upper screen in two monitor mode or it can be called by pressing the HOLD4 button in one screen configuration.
</p>

<hr>
<img src="../content/_sub_games/orcaspearl/win_table.jpg" class="tn">
<h2>Reward multipliers</h2>
<p>The base of the multipliers is the line bet, except the SCATTER, where the sum of all bets.
</p>


