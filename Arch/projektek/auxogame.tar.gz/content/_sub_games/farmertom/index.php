<img src="../content/_sub_games/farmertom/farmer_tom_wide.png" class="gwidelogo"><h1>Farmer Tom</h1>

<p>The game is a program with five reels and twenty winning lines, in which the computer simulation of the traditional engine powered reels realised. The purpose of the game is to sort out as many as possible similar symbols on the winning lines.
</p>

<hr>
<img src="../content/_sub_games/farmertom/fokep.png" class="tn">
<h2>Playing the game</h2>
<p>At the beginning of the game we can set the number of winning lines and the value of the bet with the BET and HOLD5 buttons. When changing the lines, the winning lines are displayed on the game field. The value of the bet is deducted from the CREDIT after pressing the START button, the five reels starts to rotate and within a short time they will stop one by one. By pressing the HOLD button any reel can be stopped.
If there was a winning combination, then its value appears in the WIN field, with the START button it goes to the CREDIT field  or with the BET button to the doubling game.
The WILD (Scarecrow) symbol replaces any, except the BONUS (Tom) and SCATTER (Housewife), but alone it has a prize.
On the given line always the bigger prize is valid.
</p>

<hr>
<h2>Free spin</h2>
<p>The SCATTER (Housewife) symbol counts on the whole game field, not just only on the active lines. If three or more SCATTER symbols occur, above the prize, 10 more free spins is the reward. During the free spins, 10 more free spin reward is possible. The value of the reward during the free spins is counted threefold, except bonus prize.
</p>
<img src="../content/_sub_games/farmertom/free_end.jpg" class="tn">
<img src="../content/_sub_games/farmertom/free_spin.jpg" class="tn">
<img src="../content/_sub_games/farmertom/free_win.jpg" class="tn">


<hr>
<h2>Market bonus</h2>
<p>If three or more BONUS (Tom) symbol appears on the active winning line this triggers the market bonus. By selecting one of the symbols it gives the bonus multiplier.
On the appearing bonus screen the player must select 3, 4 or 5 items from eight fruits, according to the number of the BONUS symbols. To move the selection use the HOLD2 and HOLD4 buttons, to select use the START. The value of the selected fruits appears immediately. The reward is calculated by the items point value times the achieved multiplier. The reward must be accepted by the START button, and on the usual way it can be doubled or credited.
</p>

<img src="../content/_sub_games/farmertom/bonus.jpg" class="tn">
<img src="../content/_sub_games/farmertom/bonus_end.jpg" class="tn">
<img src="../content/_sub_games/farmertom/bonus_lett.jpg" class="tn">

<hr>
<img src="../content/_sub_games/farmertom/harvest.jpg" class="tn">
<h2>Harvest bonus</h2>
<p>At a random time any of the fruits matures and for a few rounds the given fruits occur more often on the reels. Sound and visual effects notifies the player about the harvest bonus.
</p>

<hr>
<img src="../content/_sub_games/farmertom/info_table.jpg" class="tn">
<h2>Bets and paytable</h2>
<p>The number of the winning lines can be 1 – 20.
The value of the bet on one line is the following: 1, 5, 6, 10, 20, 30, 40, 50, 60, 70, 80, 90 and 100. The value of all bets cannot be bigger than 2000 or the set maximum.
The lowest and highest limit of the selectable bet is adjustable by the operator and therefore it may differ from the above list.
The paytable is displayed on the information screen, this can be called by pressing the HOLD4 button or it is on the second monitor.
</p>

<hr>
<img src="../content/_sub_games/farmertom/win_table.jpg" class="tn">
<h2>Reward multipliers</h2>
<p>The base of the rewards is the line bet, except the SCATTER rewards, it is based on the sum of all bets.
</p>
