<img src="../content/_sub_games/chinamagic/selogo_ovab.png" class="gwidelogo"><h1>China Magic</h1>
<p>The game is a program with five reels and twenty winning lines, in which the computer simulation
of the traditional engine powered reels realised. The purpose of the game is to sort out as many as
possible similar symbols on the winning lines.
</p>

<hr>
<img src="../content/_sub_games/chinamagic/china_magic_main.jpg" class="tn">
<h2>Playing the game</h2>
<p>At the beginning of the game we can set the number of winning lines and the value of the bet with
the BET and HOLD5 buttons. The value of the bet is deducted from the CREDIT after pressing the
START button, the five reels starts to rotate and within a short time they will stop one by one. By
pressing the HOLD buttons any reel can be stopped. If there was a winning combination, then its
value appears in the WIN field, with the START button it goes to the CREDIT field or with the BET
button   to   the  doubling   game.  The  WILD   (Chinese  warrior)   symbol   replaces   any,   except   the
SCATTER (geisha), but alone it has a prize. On the given line always the bigger prize is valid.
</p>

<!-- <div class="clear"></div> -->

<hr>
<h2>Free Spin</h2>
<p>
The SCATTER symbol counts on the whole game
field, not just only on the active lines. If three or
more SCATTER symbols occur, above the prize,
10 more spin is the reward. During the free spins,
more   free   spin   reward   is   possible.   At   the
beginning of the free spins a tablet falls into the
screen.   The   program   chooses   one   from   the
symbols   on   the   tablet;   this   will   be   the  bonus
symbol during the free spins. The selected bonus
symbol acts as a SCATTER – for winning it does
not have to be on the winning lines – furthermore
in the case of winning, the prize is multiplied by
the number of the winning lines, as if turned in on all winning lines, this is indicated with the
symbol copied in the full height of the reel. If a free spin comes during the free spin cycle, there is
no new bonus symbol selection, just the number of the free spins increases.
</p>
<img src="../content/_sub_games/chinamagic/china_magic_fswinwin.jpg" class="tn">
<img src="../content/_sub_games/chinamagic/china_magic_fswin.jpg" class="tn">
<img src="../content/_sub_games/chinamagic/china_magic_scatter.jpg" class="tn">
<hr>
<img src="../content/_sub_games/chinamagic/china_magic_bonus.jpg" class="tn">
<img src="../content/_sub_games/chinamagic/china_magic_bonuswin.jpg" class="tn">
<h2>China Bonus</h2>
<p>If on the reels the CHINA word reads from the left, the china bonus game begins. On the bonus
screen from the eight chests 1 to 8 can be selected. The selection ends if there are no more chest or
in the selected chest the Game Over label appears instead of a reward.</p>
<hr>
<img src="../content/_sub_games/chinamagic/china_magic_info.jpg" class="tn">
<h2>Bets and Paytable</h2>
<p>The lowest and highest limit of the selectable bet is adjustable by the operator. To see the Paytable
press the HOLD4 button or on dual screens it is displayed on the second monitor.</p>
<hr>
<img src="../content/_sub_games/chinamagic/china_magic_paytable.jpg" class="tn">
<h2>Reward multipliers</h2>
<p>The base of the rewards is the line bet, except the SCATTER rewards, it is based on the sum of all
bets.</p>
