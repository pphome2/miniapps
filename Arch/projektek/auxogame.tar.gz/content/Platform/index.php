<h1>Platform</h1>

<hr>
<img src="../content/Platform/auxogameboard.png" class="tn">
<h2>Hardware</h2>

<h3>General</h3>

<ul>
<li>Based on higly reliable, long time supported automotive components</li>
<li>Manufactured in the EU under strict quality control</li>
<li>Modular design gives high fexibility at low cost</li>
</ul>

<h3>Multimedia</h3>

<ul>
<li>Dual video output</li>
<li>Stereo audio with onboard amplifier</li>
</ul>

<div class="clear"></div>
<img src="../content/Platform/auxogamebox.png" class="tn">

<h3>Connectivity</h3>
<ul>
<li>Digital I/O</li>
<li>RS232</li>
<li>ccTalk</li>
<li>Ethernet</li>
<li>USB</li>
</ul>

<h3>Options</h3>

<ul>
<li>Extra Bonus topper display</li>
<li>Reel driver</li>
<li>Lamp matrix driver</li>
</ul>

<hr>
<img src="../content/Platform/menu.jpg" class="tn">
<h2>Software</h2>

<h3>General</h3>

<ul>
<li>Interactive graphical menu</li>
<li>Multi level user access via electronic keys</li>
<li>Multi level bookkeeping</li>
<li>Custom configuration of the edge connector's pinout</li>

</ul>

<h3>Supported peripherals</h3>

<ul>

<li>Coin acceptors</li>
<li>Bill validators</li>
<li>Hoppers</li>
<li>Touch screens</li>

</ul>



