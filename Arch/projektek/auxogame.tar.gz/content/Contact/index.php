<h1>Contact</h1>
<p>If you wish to have a quotation or have any other question, please contact us one of our
contact:</p>

<h2>Instant message</h2>
<p>To send an instant message, please fill the form and press the Send button.</p>


<?php

$messfrom=FALSE;
$email="";
$mess=get_sublink("mess2");
if ($mess<>""){
	if (substr($mess,0,4)<>"Dear"){
		$mess="Dear Manufacturer! \n \nPlease send me other information about: ".$mess;
		$mess=$mess."\n \nThank you.";
	}
}

$cf=array("email","mess");
$cfc=array("kell","kell2");

$co=contactform_to_mail($cf,$cfc,$mess,"post");

if ($co<>""){
	switch ($co){
		case "1":
			echo("<br /><br /><br /><h3 style=color:red;>Thanks, your e-mail sent to as. <br />We will contact you soon...</h3><br /><br /><br />");
			break;
		case "2":
			echo("<br /><br /><br /><h3 style=color:red;>Please fill in all fields...</h3><br /><br /><br />");
			if ($mess==""){
				$mess=get_postdata("mess");
			}
			$email=get_postdata("email");
			break;
		case "3":
			echo("<br /><br /><br /><h3 style=color:red;>Please correct protect code...</h3><br /><br /><br />");
			if ($mess==""){
				$mess=get_postdata("mess");
			}
			$email=get_postdata("email");
			break;
	}
}


?>

<form id="kapcsolat" action="?content=Contact" method="post" accept-charset="UTF-8">
    <input name="content" type="hidden" value="Contact" >
	<table>
	<tr>
		<td width=50%>Your E-mail:</td>
		<td><input type="text" name="email" value="<?php echo($email);?>"> </td>
	</tr>

	<tr>
		<td>&nbsp;</td>
		<td><p id="policy">The email address is mandatory but we use it to answer your
							questions and we do not store it in any other way. We won’t
							give it to third person or won’t send any unwanted emails.
							We respect Your privacy!</p></td>
	</tr>


	<tr>
		<td>Your message:</td>
		<td><?php echo("<text"."area"); ?> name="mess"><?php echo($mess);?><?php echo("</text"."area>");?></td>
	</tr>

	<tr>
		<?php $k1="0";$k2="0";$k3="0";form_protect($k1,$k2,$k3) ?>
		<td>Please give me amount of numbers:<br /> <?php echo("$k1 and $k2"); ?></td>
		<td><input type="text" name="kell" value="">
		<input name="kell2" type="hidden" value="<?php echo($k3); ?>" >
		</td>
	</tr>
	<tr>
		<td>&nbsp;</td>
		<td><input id="submit" type="submit" name="submit" value="Send"></td>
	</tr>
	</table>
</form>
<h2>E-mail</h2>
<p>Please send Your e-mail message to
	<?php $m=show_sys_mail(); echo("<a href=mailto:$m > Berkotech Ltd.</a>"); ?>.
</p>

