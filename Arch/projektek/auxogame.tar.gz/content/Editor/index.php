
<?php

	global $USER_ADMIN,$USER_EDITOR;

	if ($USER_ADMIN or $USER_EDITOR){
		$pos=get_sublink("dir");
		echo("<h1>Editor: $pos</h1>");

		switch ($pos){
			case "AD":
				promo_item_edit();
				break;
			case "Home":
				echo("<center><p id=more>");
				echo("<a href=\"../admin/index.php?content=Content&dir=../content/Home\">Nyitóoldal, főlap szerkesztése</a>");
				echo("</p></center>");
				break;
			case "Platform":
				echo("<center><p id=more>");
				echo("<a href=\"../admin/index.php?content=Content&dir=../content/Platform\">Platform oldal szerkesztése</a>");
				echo("</p></center>");
				break;
			case "Games":
				$game=get_sublink('pos');
				if ($game<>""){
					ax_games_items($game);
				}else{
					ax_games();
				}
				break;
			case "Contact":
				echo("<center><p id=more>");
				echo("<a href=\"../admin/index.php?content=Content&dir=../content/Contact\">Kapcsolatok oldal szerkesztése</a>");
				echo("</p></center>");
				break;
			case "Shop":
				$mode=get_sublink("mode");
				if ($mode=="0"){
					shop_cat_edit();
				}
				if ($mode=="1"){
					shop_item_edit();
				}
				break;
			default:
				echo("<br /><br /><br />Lehetőségek a Beállítások (Settings) menüben.");
				break;
		}
	}else{
		echo("<br /><br /><br />Kérem jelentkezzen be megfelelő jogosultságú felhasználóként.");
	}

?>
