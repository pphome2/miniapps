<?php

 #
 # PHPPortal
 #
 # info: main folder copyright file
 #
 #

# configuration - need change it

$COPYRIGHT="© 2017. ";

$PORTAL_NAME="Auxogame";
$PORTAL_DEV="Webstarthely.hu";
$PORTAL_ADMIN_NAME="p";
$PORTAL_ADMIN_PASSWORD="83878c91171338902e0fe0fb97a8c47a";
# p (generate: echo password -n |md5sum)
$PORTAL_ADMIN_PASSWORD_MD5=TRUE;
$PORTAL_ADMIN_MAIL="sales@berkotech.com";
$PORTAL_DEV_MAIL="pphome@gmail.com";

$MYSQL_SERVER="";
$MYSQL_PORT="";
$MYSQL_DATABASE="";
$MYSQL_USER="";
$MYSQL_PASSWORD="";

$SMTP_HOST="ssl://smtp.gmail.com";
$SMTP_SECURE="ssl";
$SMTP_PORT="465";
#$SMTP_PORT="587";
$SMTP_USER="";
$SMTP_PASSWORD="";
$SMTP_FROM="";
$SMTP_DOMAIN="gmail.com";
$SMTP_TO="";
$PHPMAIL=FALSE;

$TEMPLATE="auxogame";

$USERS_MENU=array();

# change in program

$SMTP_SUBJECT=$PORTAL_NAME." - Üzenet";
$SMTP_MESSAGE="";
$SMTP_HEADERS="Content-Type: text/html; charset=UTF-8";


?>
