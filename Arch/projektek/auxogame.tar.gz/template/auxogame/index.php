<!DOCTYPE HTML>
<html>
	<head>
		<title><?php global $PORTAL_NAME; echo("$PORTAL_NAME") ?></title>
		<meta charset="utf-8" />
		<meta http-equiv="Content-Type" content="text/html;charset=UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1" />

		<meta name="_globalsign-domain-verification" content="REeQys2w8x4R_WS3Le1NcnySqtViq3oyf-CHigZopw" />

	</head>

<body>

	<?php
		global $PORTAL_NAME,$LANGUAGE_AVAIL_LANG,$TEMPLATE_DIRNAME,$LANGUAGE_TITLE,
				$USER_ADMIN,$USER_EDITOR,$LOGGED_IN_USER,$DIR_CONTENT,$EDIT_IN_PAGE,
				$DIR_CONTENT,$INDEX_FILE,$DIR_CONTENT,$DIR_CONTENT,$INDEX_CSS_FILE,
				$COPYRIGHT;

		$db=count($LANGUAGE_AVAIL_LANG);
		if ($db>0){
			echo("<br /><div class=lang>");
			for($i=0;$i<$db;$i++){
				if ($i>0){
					echo(" / ");
				}
				echo("<a href=../admin/index.php?lang=$LANGUAGE_AVAIL_LANG[$i]>$LANGUAGE_AVAIL_LANG[$i]</a>");
			}
			echo("</div>");
		}
	?>

	<div id="wrapper">
		<div id="header">
			<div id="logo">
			</div>
			<div id="social"><a href="http://www.youtube.com/auxogame"><img src="<?php echo $TEMPLATE_DIRNAME?>/youtube_logo.png"></a>
			</div>
		</div>

		<div id="topmenu">
			<?php
				if ($LANGUAGE_TITLE=="hu"){
					$ll1="Tartalom";
					$ll2="Jatekok";
					$ll3="Bolti_elemek";
					#$ledit=language("A lap szerkesztése");
					$ledit="A lap szerkesztése";
					$USERS_MENU=array();
				}
				if ($LANGUAGE_TITLE=="en"){
					$ll1="Content";
					$ll2="Games";
					$ll3="Shop";
					#$ledit=language("A lap szerkesztése");
					$ledit="Edit this content";
					$USERS_MENU=array();
				}
				if ($USER_ADMIN or $USER_EDITOR){
					$menu=array(	"Home",	"Platform",	"Games","Contact",	"Shop","Settings");
					$menu_div=array("",		"post",		"",		"post",		"",    "");
				}else{
					$menu=array(	"Home",	"Platform",	"Games","Contact",	"Shop");
					$menu_div=array("",		"post",		"",		"post",		"");
				}
				if ($LOGGED_IN_USER){
					$db=count($USERS_MENU);
					for($i=0;$i<$db;$i++){
						$l=$USERS_MENU[$i];
						#$USERS_MENU[$i]=language($l);
					}
					$menu=array_merge($menu,$USERS_MENU);
				}
				$link="?content=";
				$content=menu_generate("content",$menu,$menu_div,$link,"active",$divclass,0,"","",$menuname);
			?>
			<span></span>
			<div id="keeper"></div>
			<div class="clear"></div>
		</div>

		<div id="promo">
			<div id="ice2">
				<?php
					$file="$DIR_CONTENT/_promo";
					if (($USER_ADMIN or $USER_EDITOR)and($EDIT_IN_PAGE)){
						echo("<a href=?content=Editor&dir=AD><div class=edit><img src=$DIR_TEMPLATE/$TEMPLATE/edit.png></div></a>");
					}
					ax_promo();
				?>
			</div>
		</div>

		<div id="container">
			<div id="contentbox">
				<div id="content">
					<?php
						$CONTENT_CONTAINER_OPEN="<div id=container><div id=contentbox><div id=content><div class=$content>";
						$CONTENT_CONTAINER_END="</div></div></div></div>";
						if (strpos($content,'_sub_games')!==false){
							$EDIT_IN_PAGE_LINK="content=$ll2&game=$DIR_CONTENT/$content";
						}
						if (strpos($content,'Shop')!==false){
							$cont=get_sublink("dir");
							if ($cont==""){
								$cont=get_dir_first("$DIR_CONTENT/_sub_shop");
							}
							$EDIT_IN_PAGE_LINK="content=$ll3&item=$DIR_CONTENT/_sub_shop/$cont";
						}
						$file="$DIR_CONTENT/".$content."/".$INDEX_FILE;
						$filedir="$DIR_CONTENT/".$content;
						$filecss="$DIR_CONTENT/".$content."/".$INDEX_CSS_FILE;
						$pageaddr=substr($content,0,4);
						$pagenoedit=array("Home","Platform","Editor","Settings","Login","Contact");
						if (($USER_ADMIN or $USER_EDITOR)and($EDIT_IN_PAGE)){
							if (!in_array($content,$pagenoedit)){
								if ($content=="Shop"){
									echo("<a href=?content=Editor&dir=$content&mode=0><div class=edit><img src=$DIR_TEMPLATE/$TEMPLATE/edit_cat.png></div></a><br />");
									echo("<a href=?content=Editor&dir=$content&mode=1><div class=edit><img src=$DIR_TEMPLATE/$TEMPLATE/edit_item.png></div></a>");
								}else{
									if ($content=="Games"){
										$g=get_sublink('game');
										if ($g<>""){
											$content=$content."&game=".$g;
											echo("<a href=?content=Editor&dir=$content><div class=edit><img src=$DIR_TEMPLATE/$TEMPLATE/edit.png></div></a>");
										}else{
											$content=$content."&game=Új_játék";
											echo("<a href=?content=Editor&dir=$content><div class=edit><img src=$DIR_TEMPLATE/$TEMPLATE/edit.png></div></a>");
										}
									}else{
										echo("<a href=?content=Editor&dir=$content><div class=edit><img src=$DIR_TEMPLATE/$TEMPLATE/edit.png></div></a>");
									}
								}
							}
						}
						echo("<div class=$divclass>");
						include_cssfile($filecss);
						echo("<div class=$content>");
						include_phpfile($file);
						echo("</div>");
						echo("</div>");
					?>
					<div class="clear"></div>
				</div>
				<br />
			</div>
		</div>

		<div id="footer">
			<?php
				echo("$COPYRIGHT auxogame.com | All rights reserved! - ");
				$link="?content=Login";
				if ($LOGGED_IN_USER){
					$l=get_cookie("gusername");
					echo("<a href=$link style='color:grey;'>[ Logout - User: $l ]</a> ");
					$link2="../admin";
					if ($USER_ADMIN or $USER_EDITOR){
						echo("<a href=$link2 target=_blank style='color:grey;'>[ Admin Site ]</a>");
					}
				}else{
					echo("<a href=$link style='color:grey;'>[ Login ]</a>");
				}
			?>
		</div>
	</div>


</body>
</html>
