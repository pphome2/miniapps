<!DOCTYPE HTML>
<html>
	<head>
		<title><?php echo("$PORTAL_NAME") ?></title>
		<meta charset="utf-8" />
		<meta http-equiv="Content-Type" content="text/html;charset=UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1" />

		<meta name="_globalsign-domain-verification" content="REeQys2w8x4R_WS3Le1NcnySqtViq3oyf-CHigZopw" />

	</head>

<body>

	<?php
		$db=count($LANGUAGE_AVAIL_LANG);
		if ($db>0){
			echo("<br /><div class=lang>");
			for($i=0;$i<$db;$i++){
				if ($i>0){
					echo(" / ");
				}
				echo("<a href=../admin/index.php?lang=$LANGUAGE_AVAIL_LANG[$i]>$LANGUAGE_AVAIL_LANG[$i]</a>");
			}
			echo("</div>");
		}
	?>

	<div id="wrapperhead">
		<div id="header">
			<div id="logo">
			</div>
		</div>

		<div id="promo">
			<?php $l=language("Adminisztrációs oldal"); echo("<h1>$l</h1>"); ?>
		</div>
	</div>


	<div id="wrapper">
		<div id="topmenu">
				<?php
					$menu=admin_menu();
					$menu_div=array("","","","","","","","","","");
					$link="?content=";
					$content=menu_generate("content",$menu,$menu_div,$link,"active",$divclass,1,"","",$menuname);
				?>
				<span></span>
				<div id="keeper"></div>
				<div class="clear"></div>
			</div>

			<div id="container">
				<div id="contentbox"><br />
					<div id="content">

						<?php
							$v=normal_dirname($menuname);
							$l=language("Adminisztráció");
							#echo("<br/><br /><h2>$l: $v</h2><br /><br />");
							$CONTENT_CONTAINER_OPEN="<div style=\"border:1px;overflow:scroll;height:400px;\"><div id=\"container\"><div id=\"contentbox\"><div id=\"content\">";
							$CONTENT_CONTAINER_END="</div></div></div></div>";
							control_admin($content,$menu);
						?>
						<div class="clear"></div>
					</div>
					<br />
				</div>
			</div>

			<div id="footer">
				<?php
					echo("$COPYRIGHT auxogame.com | All rights reserved! - ");
					$link="?content=Login";
					if ($LOGGED_IN_USER){
						if (isset($_COOKIE["gusername"])){
							$l=$_COOKIE["gusername"];
						}else{
							$l="";
						}
						echo("<a href=$link style=\"color:grey;\">[ Logout - $l ]</a>");
					}else{
						echo("<a href=$link style=\"color:grey;\">[ Login ]</a>");
					}
				?>
			</div>
		</div>
	</div>

</body>
</html>
